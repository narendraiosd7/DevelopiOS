//
//  ViewController.swift
//  DailProtocol
//
//  Created by Vadde Narendra on 4/9/20.
//  Copyright © 2020 Narendra Vadde. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate, UITableViewDataSource {
    
    @IBOutlet weak var buttonLaunch: UIButton!
    
    @IBOutlet weak var buttonBroadcast: UIButton!
    
    @IBOutlet weak var buttonStop: UIButton!
    
    @IBOutlet weak var textAppNameTF: UITextField!
    
    @IBOutlet weak var textViewer: UITextView!
    
    @IBOutlet weak var tableView: UITableView!
    
    var tableData = [AnyHashable]()
    var runningBroadcast:Bool?
    var launchURL:String?
    var dialMgr = DIALManager()
    var discovery = Discovery()
    var countDiscovered:Int?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("ViewController viewDidLoad")

        // Do any additional setup after loading the view, typically from a nib.
        tableView.dataSource = self
        tableView.layer.borderWidth = 1.0
        tableView.layer.borderColor = UIColor.gray.cgColor
        
        // listeners to dismiss the keyboard when finished typing
        textAppNameTF.delegate = self
        textAppNameTF.returnKeyType = .done
        textAppNameTF.addTarget(self, action: #selector(textFieldFinished(_:)), for: .editingDidEndOnExit)
        
//    buttonBroadcastPressed()
        // Do any additional setup after loading the view.
    }
    
    /// dismiss the keyboard

    @IBAction func textFieldFinished(_ sender: Any) {
        view.endEditing(true)
    }
    
    /// apply the text to the message

    func message(_ msg: String?) {
        textViewer.text = "\(textViewer.text)\n\(msg ?? "")"
//        textViewer.scrollRangeToVisible(NSRange(location: textViewer.text.length - 1, length: 1))
    }
    
    
    @IBAction func scanButtonTapped(_ sender: UIButton) {
   
        if runningBroadcast == true {
            return
        }

        print("ViewController buttonBroadcastPressed")
        message("\nBroadcast Scan ...")

        tableData = [AnyHashable]()

        countDiscovered = 0
        runningBroadcast = true
        buttonBroadcast.isEnabled = false

        /// call start broadcast
        Discovery.startSSDPBroadcast((SSDPDiscoveryDelegateListener(owner: self) as! DiscoveryEventsDelegate))
        
    }
    
    @IBAction func launchButtonTapped(_ sender: UIButton) {
        
        print("ViewController buttonLaunchPressed")
        message("Launch the channel ...")
        buttonBroadcast.isEnabled = false

        let indexPath = tableView.indexPathForSelectedRow
        let selected = indexPath?.row ?? 0
        let box = tableData[selected] as? DiscoveredRokuBox
        if box == nil {
            return
        }
        if let dialURL = box?.dialURL {
            print("DIAL URL: \(dialURL)")
        }


        launchURL = dialMgr.launchApp(box?.dialURL, textAppNameTF.text)
        buttonBroadcast.isEnabled = true
        
    }
    
    
    @IBAction func stopButtonTapped(_ sender: UIButton) {
        
        print("ViewController buttonStopPressed")

        dialMgr.sendDelete(launchURL)
        
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cellIdentifier = "DiscoveredBoxCell"

        var cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier)

        if cell == nil {
            cell = UITableViewCell(style: .subtitle, reuseIdentifier: cellIdentifier)
        }

        let obj = tableData[indexPath.row] as? DiscoveredRokuBox
        cell?.textLabel?.text = obj?.modelName
        cell?.detailTextLabel?.text = obj?.serialNumber
        return cell!
    }
}

class SSDPDiscoveryDelegateListener {
    
    var owner = ViewController()
    
    init(owner: ViewController?) {
        self.owner = owner!
    }

    func onFound(_ box: DiscoveredRokuBox?) {
        if let ip = box?.ip {
            print("SSDPDiscoveryDelegateListener onDevice url: \(ip)")
        }
        if let box = box {
            self.owner.tableData.append(box)
        }
        if let ip = box?.ip {
            owner.message("Found IP: \(ip)")
        }

        owner.countDiscovered! += 1
        owner.dialMgr.fetchDetails(box)
    }

    func onFinished(_ count: Int) {
        owner.tableView.reloadData()
        print(String(format: "SSDPDiscoveryDelegateListener onFinished count: %i found", count))
        owner.message(String(format: "Finished Broadcast: %i discovered", owner.countDiscovered!))

        owner.runningBroadcast = false
        owner.buttonBroadcast.isEnabled = true
        owner.buttonLaunch.isEnabled = true
    }
}

