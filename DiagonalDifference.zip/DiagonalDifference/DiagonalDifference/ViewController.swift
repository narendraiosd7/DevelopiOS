//
//  ViewController.swift
//  DiagonalDifference
//
//  Created by Vadde Narendra on 4/2/20.
//  Copyright © 2020 Narendra Vadde. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        print(diagnolDifference(arr: [[11, 2, 4], [4, 5, 6], [10, 8, -12]]))
        
        // Do any additional setup after loading the view.
    }
    
    func diagnolDifference(arr:[[Int]]) -> Int {
        
        let arrCount = arr.count //4
        var primaryDaignolSum = 0
        var secondaryDaignolSum = 0
        var result  = 0
        
        for index in 0..<arrCount {
            
            primaryDaignolSum += arr[index][index]
            secondaryDaignolSum += arr[index][arrCount-index-1]
    
        }
        
         result = abs(primaryDaignolSum-secondaryDaignolSum)
        
        return result
    }
}

