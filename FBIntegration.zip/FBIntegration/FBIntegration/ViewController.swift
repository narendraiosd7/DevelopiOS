//
//  ViewController.swift
//  FBIntegration
//
//  Created by Vadde Narendra on 1/29/20.
//  Copyright © 2020 Vadde Narendra. All rights reserved.
//

import UIKit
import FacebookCore
import FacebookLogin
import FacebookShare

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    @IBAction func login(_ sender: Any) {
        
        let loginManager = LoginManager()
        loginManager.logIn(
            permissions: [.publicProfile, .userFriends],
            viewController: self
        ) { result in
            self.loginManagerDidComplete(result)
        }
        
        
    }
    
    
    @IBAction func logout(_ sender: Any) {
        
        let loginManager = LoginManager()
            loginManager.logOut()

            let alertController = UIAlertController(title: "Logout", message: "Logged out Successfully", preferredStyle: UIAlertController.Style.alert)
            present(alertController, animated: true, completion: nil)
        }
    
    
    func loginManagerDidComplete(_ result: LoginResult) {
    var alertController: UIAlertController
    switch result {
    case .cancelled:

     alertController = UIAlertController(title: "Login Cancelled", message: "User cancelled login.", preferredStyle: UIAlertController.Style.alert)
     
    case .failed(let error):
        
     
       alertController = UIAlertController(title: "Login Fail", message: "Login failed with error \(error)", preferredStyle: UIAlertController.Style.alert)

    case .success(let grantedPermissions, _, _):
        
     
     var pvc = self.storyboard?.instantiateViewController(identifier: "MainNC")
     
     present(pvc!, animated: true, completion: nil)
    
}

}
}
