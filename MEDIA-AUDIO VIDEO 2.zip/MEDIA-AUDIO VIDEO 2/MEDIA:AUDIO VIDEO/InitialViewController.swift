
//  InitialViewController.swift
//  MEDIA:AUDIO VIDEO
//
//  Created by Syed.Reshma Ruksana on 29/11/19.
//  Copyright © 2019 Syed.Reshma Ruksana. All rights reserved.
//

import UIKit
import AVKit


class InitialViewController: UIViewController
{
    var allButtonObj =  [UIButton]()
    var allLabelsObj =  [UILabel]()
    var allAudioUrl = [[String]]()
    var alltrailer = [String]()
    
    @IBOutlet weak var stackView: UIStackView!
    
    let loadButton = UIButton()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("hiii")
        
//Load Button
        loadButton.backgroundColor = .orange
        loadButton.setTitle("LOAD ALL", for: UIControl.State.normal)
        loadButton.addTarget(self, action: #selector(loadingObjects), for: UIControl.Event.touchUpInside)
        stackView.addArrangedSubview(loadButton)
        
        
        
        // Do any additional setup after loading the view.
    }
    
    
    @objc func loadingObjects()
    {
    loadAllUIObjects()

    }

    func loadAllUIObjects()
    {
        
        
        //Stack View
        stackView.spacing = 20
        
        
        var i = 0
        
        let data = imageFromURL()
        for x in data
        {
            
            //Audio Url
            let audioUrl = x["songs"] as! [String]
            
//            let trailer = x["trailer"] as! String
            
//            alltrailer.append(trailer)
            
            allAudioUrl.append(audioUrl)
            
            
            
            
            var urlInString = (x["posters"] as! [String])[0]
            
            urlInString = "https://www.brninfotech.com/tws/" + urlInString
            
            urlInString = urlInString.replacingOccurrences(of: " ", with: "%20")
            
            print(urlInString)
            
            let image = fetchImage(urlInString: urlInString)
            
            
            
            let button = UIButton()
            button.setImage(image, for: UIControl.State.normal)
            button.contentMode = .scaleToFill
            button.addTarget(self, action: #selector(posterButtonTapped), for: UIControl.Event.touchUpInside)
            button.tag = i
            i += 1
             allButtonObj.append(button)
            //Autolayout Constraits
            button.translatesAutoresizingMaskIntoConstraints = false
            button.heightAnchor.constraint(equalToConstant: 300).isActive = true
            
            stackView.addArrangedSubview(button)
            
//            var secondVC = storyboard?.instantiateViewController(withIdentifier: "SecondVC") as! SecondViewController
            
//            present(secondVC,animated: true)
            
            
            
            
            let label = UILabel()
            label.text = x["title"] as! String
            label.textAlignment = .center
            allLabelsObj.append(label)

            stackView.addArrangedSubview(label)
            
        }
        
        
    }
    
    
    func fetchAudio(urlInString:String) -> AVPlayer
    {
        let url = URL(string: urlInString)!
        
       return AVPlayer(url: url)
    }
    
    
   @objc func fetchImage(urlInString:String) -> UIImage
    {
        
        let url = URL(string: urlInString)!
        var image:UIImage!
        do
        {
            let imageInFormOfData = try Data(contentsOf: url)
            
            image = UIImage(data: imageInFormOfData)
            
        }
        catch
        {
            print("Failed To Get Image")
        }
        
        return image
    }
    
    @objc func imageFromURL() -> [[String:Any]]
    {
        
        var convertedData:[[String:Any]]?
        
        var dataTaskObj=URLSession.shared.dataTask(with: URL(string: "https://www.brninfotech.com/tws/MovieDetails2.php?mediaType=movies")!){(data,connDetails,err) in
            
            
            do
            {
                convertedData = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.allowFragments) as? [[String:Any]]
                
                print(convertedData!)
            }
            catch
            {
                print("Failed")
            }
            
            
            
        }
        dataTaskObj.resume()
        
        while convertedData == nil {
            
        }
        
        return convertedData!
    }
    
    @objc func posterButtonTapped(button:UIButton)
    {
        
        Movie.shared.buttonTapped = button.tag
        
        for x in allAudioUrl[Movie.shared.buttonTapped!]
        {
            let urlInString = ("https://www.brninfotech.com/tws/" + x).replacingOccurrences(of: " ", with: "%20")
            let url = URL(string: urlInString)!
            Movie.shared.audio.append(AVPlayer(url: url))
        }
        
        
        
        
        var secondVC = storyboard?.instantiateViewController(withIdentifier: "SecondVC") as! SecondViewController
        
        present(secondVC,animated: true)
        
        
    }
    
    
    
    
    
}
