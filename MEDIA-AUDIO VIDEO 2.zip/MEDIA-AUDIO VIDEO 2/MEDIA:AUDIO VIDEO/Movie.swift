//
//  Movie.swift
//  MEDIA:AUDIO VIDEO
//
//  Created by Sagi Harika on 12/2/19.
//  Copyright © 2019 Syed.Reshma Ruksana. All rights reserved.
//

import UIKit
import AVKit

class Movie: NSObject
{
    static var shared = Movie()
    
    var buttonTapped:Int?
    
    var audio = [AVPlayer]()
    
    
    private override init()
    {
        super.init()
    }
    
}
