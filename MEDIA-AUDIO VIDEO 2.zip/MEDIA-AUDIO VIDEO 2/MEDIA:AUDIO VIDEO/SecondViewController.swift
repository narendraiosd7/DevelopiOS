//
//  SecondViewController.swift
//  MEDIA:AUDIO VIDEO
//
//  Created by Syed.Reshma Ruksana on 30/11/19.
//  Copyright © 2019 Syed.Reshma Ruksana. All rights reserved.
//

import UIKit
import AVKit

class SecondViewController: UIViewController {

    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        
       
    let button = UIButton()
        button.addTarget(self, action: #selector(playButton), for: UIControl.Event.touchUpInside)
        button.frame = CGRect(x: 50, y: 100, width: 200, height: 50)
        button.backgroundColor = .black
        view.addSubview(button)

        // Do any additional setup after loading the view.
        
        
        
        let videoButton = UIButton()
//        videoButton.addTarget(self, action: #selector(view), for: UIControl.Event.touchUpInside)
        
        videoButton.frame = CGRect(x: 50, y: 200, width: 200, height: 50)
        videoButton.backgroundColor = .green
        view.addSubview(videoButton)
    }
    
    
    @objc func playButton()
    {
        Movie.shared.audio[Movie.shared.buttonTapped!].play()
    }
//    @objc func video()
//    {
//        let videoVC = AVPlayerViewController()
    
//        videoVC.player =
        
//present(videoVC, animated: <#T##Bool#>, completion: <#T##(() -> Void)?##(() -> Void)?##() -> Void#>)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


