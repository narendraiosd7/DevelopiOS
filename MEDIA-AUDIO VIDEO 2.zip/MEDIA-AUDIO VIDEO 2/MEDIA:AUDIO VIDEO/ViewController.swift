//
//  ViewController.swift
//  MEDIA:AUDIO VIDEO
//
//  Created by Syed.Reshma Ruksana on 28/11/19.
//  Copyright © 2019 Syed.Reshma Ruksana. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    
    @IBOutlet weak var posterBtn: UIButton!
    
    @IBOutlet weak var titleLbl: UILabel!
    
    
    var imageView:UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    @IBAction func onLoadBtnTap(_ sender: UIButton) {
    
        
        let info = imageFromURL()
        var i=0
        for x in info
        {
            
            print("link \(i)",x["posters"] as! [String])
            print("link \(i)",x["songs"] as! [String])
//            print("link \(i)",x["story"] as! [String])

            i += 1
        }
        imageView=UIImageView()
        imageView.frame=CGRect(x: 20, y: 200, width: 300, height: 300)
        view.addSubview(imageView)
        
    }
    
    @IBAction func posterBtn(_ sender: Any) {
        
        let string = "https://www.brninfotech.com/tws/media2/posters/The_Zoya_Factor_poster.jpg"
        
        let url = URL(fileURLWithPath: string)
        
        let data = try!Data(contentsOf: url)
        
        
        
        posterBtn.setBackgroundImage(UIImage(data: data), for: UIControl.State.normal)
        
        
        posterBtn.addTarget(self, action: #selector(imageFromURL), for: UIControl.Event.touchUpInside)
    }
    
   @objc  func imageFromURL() -> [[String:Any]]
   
    {
        
        var convertedData:[[String:Any]]?
        
        var dataTaskObj=URLSession.shared.dataTask(with: URL(string: "https://www.brninfotech.com/tws/MovieDetails2.php?mediaType=movies")!){(data,connDetails,err) in
            
            
            do
            {
                convertedData = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.allowFragments) as! [[String:Any]]
            }
            catch
            {
                print("Failed")
            }
            
            
            
        }
        dataTaskObj.resume()
        
        while convertedData == nil {
            
        }
        
        return convertedData!
    }
}

