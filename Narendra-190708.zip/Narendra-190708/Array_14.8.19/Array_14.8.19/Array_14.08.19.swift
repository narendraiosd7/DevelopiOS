//
//  Array_14.08.19.swift
//  Array_14.8.19
//
//  Created by Vadde Narendra on 14/08/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import Foundation

struct District {
    
    var districtName:String = ""
    var headquarters:String = ""
    
    init (districtName:String, headquarters:String){
        
        self.districtName = districtName
        self.headquarters = headquarters
        
    }
}
