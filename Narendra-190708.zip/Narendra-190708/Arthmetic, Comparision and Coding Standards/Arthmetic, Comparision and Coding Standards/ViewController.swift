//
//  ViewController.swift
//  VariablesAndDatatypes
//
//  Created by BRN1907 on 7/25/19.
//  Copyright © 2019 BRN1907. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let a:String = "Dhoni"
        
        let aEngMarks:UInt8 = 32
        let aTelMarks:UInt8 = 45
        let aHinMarks:UInt8 = 48
        let aMatMarks:UInt8 = 58
        let aSciMarks:UInt8 = 64
        let aSocMarks:UInt8 = 72
        
        
        let dhoniMarks:UInt16 = UInt16(aEngMarks)+UInt16(aTelMarks)+UInt16(aMatMarks)+UInt16(aHinMarks)+UInt16(aSocMarks)+UInt16(aSciMarks)
        
        print("Dhoni's Total Marks are \(dhoniMarks)")
        
        let totalMarksA:Float = Float(dhoniMarks)
        let totalMarks:Float = 600
        
        let percentageA:Float = (totalMarksA/totalMarks)*100
        
        print("Dhoni's Percentage is \(percentageA)")
            
            if aEngMarks >= 35 {
            print("Dhoni passed English")
            } else {
            print("Dhoni failed English")
            }
            
            if aTelMarks >= 35 {
            print("Dhoni passed Telugu")
            } else {
            print("Dhoni failed Telugu")
            }
            
            if aHinMarks >= 35 {
            print("Dhoni passed Hindi")
            } else {
            print("Dhoni failed Hindi")
            }
            
            if aMatMarks >= 35 {
            print("Dhoni passed Maths")
            } else {
            print("Dhoni failed Maths")
            }
            
            if aSciMarks >= 35 {
            print("Dhoni passed Science")
            } else {
            print("Dhoni failed Science")
            }
            
            if aSocMarks >= 35 {
            print("Dhoni passed Social")
            } else {
            print("Dhoni failed Social")
        }
        
        if (aTelMarks >= 35 && aEngMarks >= 35 && aHinMarks >= 35 && aMatMarks >= 35 && aSciMarks >= 35 && aSocMarks >= 35){
            print("Dhoni PASSED")
        } else {
            print("Dhoni FAILED")
        }
        
       
        
        let b:String = "Kohli"
        
        
        let bEngMarks:UInt8 = 35
        let bTelMarks:UInt8 = 42
        let bHinMarks:UInt8 = 56
        let bMatMarks:UInt8 = 61
        let bSciMarks:UInt8 = 73
        let bSocMarks:UInt8 = 89
        
        let kohliMarks:UInt16 = UInt16(bEngMarks)+UInt16(bTelMarks)+UInt16(bMatMarks)+UInt16(bHinMarks)+UInt16(bSocMarks)+UInt16(bSciMarks)
        
        print("Kohli's Total Marks are \(kohliMarks)")
        
        
        let totalMarksB:Float = Float(kohliMarks)
        
        let percentageB:Float = (totalMarksB/totalMarks)*100
        
        print("Kohli's Percentage is \(percentageB)")
        
        if bEngMarks >= 35 {
            print("Kohli passed English")
        } else {
            print("Kohli failed English")
        }
        
        if bTelMarks >= 35 {
            print("Kohli passed Telugu")
        } else {
            print("Kohli failed Telugu")
        }
        
        if bHinMarks >= 35 {
            print("Kohli passed Hindi")
        } else {
            print("Kohli failed Hindi")
        }
        
        if bMatMarks >= 35 {
            print("Kohli passed Maths")
        } else {
            print("Kohli failed Maths")
        }
        
        if bSciMarks >= 35 {
            print("Kohli passed Science")
        } else {
            print("Kohli failed Science")
        }
        
        if bSocMarks >= 35 {
            print("Kohli passed Social")
        } else {
            print("Kohli failed Social")
        }
        
        if (bTelMarks >= 35 && bEngMarks >= 35 && bHinMarks >= 35 && bMatMarks >= 35 && bSciMarks >= 35 && bSocMarks >= 35){
            print("Kohli PASSED")
        } else {
            print("Kohli FAILED")
        }
        
        
        
        let c:String = "Rohit"
        
        let cEngMarks:UInt8 = 35
        let cTelMarks:UInt8 = 45
        let cHinMarks:UInt8 = 52
        let cMatMarks:UInt8 = 65
        let cSciMarks:UInt8 = 25
        let cSocMarks:UInt8 = 50
        
        let rohitMarks:UInt16 = UInt16(cEngMarks)+UInt16(cTelMarks)+UInt16(cMatMarks)+UInt16(cHinMarks)+UInt16(cSocMarks)+UInt16(cSciMarks)
        
        print("Rohit's Total Marks are \(rohitMarks)")
        
        
        let totalMarksC:Float = Float(rohitMarks)
        
        let percentageC:Float = (totalMarksC/totalMarks)*100
        
        print("Rohit's Percentage is \(percentageC)")
        
        if cEngMarks >= 35 {
            print("Rohit passed English")
        } else {
            print("Rohit failed English")
        }
        
        if cTelMarks >= 35 {
            print("Rohit passed Telugu")
        } else {
            print("Rohit failed Telugu")
        }
        
        if cHinMarks >= 35 {
            print("Rohit passed Hindi")
        } else {
            print("Rohit failed Hindi")
        }
        
        if cMatMarks >= 35 {
            print("Rohit passed Maths")
        } else {
            print("Rohit failed Maths")
        }
        
        if cSciMarks >= 35 {
            print("Rohit passed Science")
        } else {
            print("Rohit failed Science")
        }
        
        if cSocMarks >= 35 {
            print("Rohit passed Socail")
        } else {
            print("Rohit failed Social")
        }
        
        if (cTelMarks >= 35 && cEngMarks >= 35 && cHinMarks >= 35 && cMatMarks >= 35 && cSciMarks >= 35 && cSocMarks >= 35){
            print("Rohit PASSED")
        } else {
            print("Rohit FAILED")
        }
        
        
        
        let d:String = "Rahul"
        
        let dEngMarks:UInt8 = 57
        let dTelMarks:UInt8 = 64
        let dHinMarks:UInt8 = 72
        let dMatMarks:UInt8 = 81
        let dSciMarks:UInt8 = 96
        let dSocMarks:UInt8 = 75
        
        let rahulMarks:UInt16 = UInt16(dEngMarks)+UInt16(dTelMarks)+UInt16(dMatMarks)+UInt16(dHinMarks)+UInt16(dSocMarks)+UInt16(dSciMarks)
        
        print("Rahul's Total Marks are \(rahulMarks)")
        
        
        let totalMarksD:Float = Float(rahulMarks)
        
        let percentageD:Float = (totalMarksD/totalMarks)*100
        
        print("Rahul's Percentage is \(percentageD)")
        
        
        if dEngMarks >= 35 {
            print("Rahul passed English")
        } else {
            print("Rahul failed English")
        }
        
        if dTelMarks >= 35 {
            print("Rahul passed Telugu")
        } else {
            print("Rahul failed Telugu")
        }
        
        if dHinMarks >= 35 {
            print("Rahul passed Hindi")
        } else {
            print("Rahul failed Hindi")
        }
        
        if dMatMarks >= 35 {
            print("Rahul passed Maths")
        } else {
            print("Rahul failed Maths")
        }
        
        if dSciMarks >= 35 {
            print("Rahul passed Science")
        } else {
            print("Rahul failed Science")
        }
        
        if dSocMarks >= 35 {
            print("Rahul passed Social")
        } else {
            print("Rahul failed Social")
        }
        
        if (dTelMarks >= 35 && dEngMarks >= 35 && dHinMarks >= 35 && dMatMarks >= 35 && dSciMarks >= 35 && dSocMarks >= 35){
            print("Rahul PASSED")
        } else {
            print("Rahul FAILED")
        }
        
        
        
        let e:String = "Pandya"
        
        let eEngMarks:UInt8 = 99
        let eTelMarks:UInt8 = 86
        let eHinMarks:UInt8 = 57
        let eMatMarks:UInt8 = 85
        let eSciMarks:UInt8 = 81
        let eSocMarks:UInt8 = 76
        
        let pandyaMarks:UInt16 = UInt16(eEngMarks)+UInt16(eTelMarks)+UInt16(eMatMarks)+UInt16(eHinMarks)+UInt16(eSocMarks)+UInt16(eSciMarks)
        
        print("Pandya's Total Marks are \(pandyaMarks)")
        
        let totalMarksE:Float = Float(pandyaMarks)
        
        let percentageE:Float = (totalMarksE/totalMarks)*100
        
        print("Pandya's Percentage is \(percentageE)")
        
        if eEngMarks >= 35 {
            print("Pandya passed English")
        } else {
            print("Pandya failed English")
        }
        
        if eTelMarks >= 35 {
            print("Pandya passed Telugu")
        } else {
            print("Pandya failed Telugu")
        }
        
        if eHinMarks >= 35 {
            print("Pandya passed Hindi")
        } else {
            print("Pandya failed Hindi")
        }
        
        if eMatMarks >= 35 {
            print("Pandya passed Maths")
        } else {
            print("Pandya failed Maths")
        }
        
        if eSciMarks >= 35 {
            print("Pandya passed Science")
        } else {
            print("Pandya failed Science")
        }
        
        if eSocMarks >= 35 {
            print("Pandya passed Social")
        } else {
            print("Pandya failed Social")
        }
        
        if (eTelMarks >= 35 && eEngMarks >= 35 && eHinMarks >= 35 && eMatMarks >= 35 && eSciMarks >= 35 && eSocMarks >= 35){
            print("Pandya PASSED")
        } else {
            print("Pandya FAILED")
        }
        
        
        
        let f:String = "Jadeja"
        
        let fEngMarks:UInt8 = 33
        let fTelMarks:UInt8 = 44
        let fHinMarks:UInt8 = 55
        let fMatMarks:UInt8 = 66
        let fSciMarks:UInt8 = 77
        let fSocMarks:UInt8 = 88
        
        let jadejaMarks:UInt16 = UInt16(fEngMarks)+UInt16(fTelMarks)+UInt16(fMatMarks)+UInt16(fHinMarks)+UInt16(fSocMarks)+UInt16(fSciMarks)
        
        print("Jadeja's Total Marks are \(jadejaMarks)")
        
        
        
        let totalMarksF:Float = Float(jadejaMarks)
        
        let percentageF:Float = (totalMarksF/totalMarks)*100
        
        print("Jadeja's Percentage is \(percentageF)")
        
        if fEngMarks >= 35 {
            print("Jadeja passed English")
        } else {
            print("Jadeja failed English")
        }
        
        if fTelMarks >= 35 {
            print("Jadeja passed Telugu")
        } else {
            print("Jadeja failed Telugu")
        }
        
        if fHinMarks >= 35 {
            print("Jadeja passed Hindi")
        } else {
            print("Jadeja failed Hindi")
        }
        
        if fMatMarks >= 35 {
            print("Jadeja passed Maths")
        } else {
            print("Jadeja failed Maths")
        }
        
        if fSciMarks >= 35 {
            print("Jadeja passed Science")
        } else {
            print("Jadeja failed Science")
        }
        
        if fSocMarks >= 35 {
            print("Jadeja passed Social")
        } else {
            print("Jadeja failed Socail")
        }
        
        if (fTelMarks >= 35 && fEngMarks >= 35 && fHinMarks >= 35 && fMatMarks >= 35 && fSciMarks >= 35 && fSocMarks >= 35){
            print("Jadeja PASSED")
        } else {
            print("Jadeja FAILED")
        }
        
        
        
        let g:String = "Bhuvaneswar"
        
        let gEngMarks:UInt8 = 99
        let gTelMarks:UInt8 = 88
        let gHinMarks:UInt8 = 77
        let gMatMarks:UInt8 = 66
        let gSciMarks:UInt8 = 55
        let gSocMarks:UInt8 = 44
        
        let bhuvaneswarMarks:UInt16 = UInt16(gEngMarks)+UInt16(gTelMarks)+UInt16(gMatMarks)+UInt16(gHinMarks)+UInt16(gSocMarks)+UInt16(gSciMarks)
        
        print("Bhuvaneswar's Total Marks are \(bhuvaneswarMarks)")
        
        let totalMarksG:Float = Float(bhuvaneswarMarks)
        
        let percentageG:Float = (totalMarksG/totalMarks)*100
        
        print("Bhuvaneswar's Percentage is \(percentageG)")
        
        if gEngMarks >= 35 {
            print("Bhuvaneswar passed English")
        } else {
            print("Bhuvaneswar failed English")
        }
        
        if gTelMarks >= 35 {
            print("Bhuvaneswar passed Telugu")
        } else {
            print("Bhuvaneswar failed Telugu")
        }
        
        if gHinMarks >= 35 {
            print("Bhuvaneswar passed Hindi")
        } else {
            print("Bhuvaneswar failed Hindi")
        }
        
        if gMatMarks >= 35 {
            print("Bhuvaneswar passed Maths")
        } else {
            print("Bhuvaneswar failed Maths")
        }
        
        if gSciMarks >= 35 {
            print("Bhuvaneswar passed Science")
        } else {
            print("Bhuvaneswar failed Science")
        }
        
        if gSocMarks >= 35 {
            print("Bhuvaneswar passed Social")
        } else {
            print("Bhuvaneswar failed Social")
        }
        
        if (gTelMarks >= 35 && gEngMarks >= 35 && gHinMarks >= 35 && gMatMarks >= 35 && gSciMarks >= 35 && gSocMarks >= 35){
            print("Bhuvaneswar PASSED")
        } else {
            print("Bhuneswar FAILED")
        }
        
        let h:String = "Bumrah"
        
        let hEngMarks:UInt8 = 25
        let hTelMarks:UInt8 = 35
        let hHinMarks:UInt8 = 45
        let hMatMarks:UInt8 = 55
        let hSciMarks:UInt8 = 65
        let hSocMarks:UInt8 = 75
        
        let bumrahMarks:UInt16 = UInt16(hEngMarks)+UInt16(hTelMarks)+UInt16(hMatMarks)+UInt16(hHinMarks)+UInt16(hSocMarks)+UInt16(hSciMarks)
        
        print("Bumrah's Total Marks are \(bumrahMarks)")
        
        let totalMarksH:Float = Float(bumrahMarks)
        
        let percentageH:Float = (totalMarksH/totalMarks)*100
        
        print("Bumrah's Percentage is \(percentageH)")
        
        if hEngMarks >= 35 {
            print("Bumrah passed English")
        } else {
            print("Bumrah failed English")
        }
        
        if hTelMarks >= 35 {
            print("Bumrah passed Telugu")
        } else {
            print("Bumrah failed Telugu")
        }
        
        if hHinMarks >= 35 {
            print("Bumrah passed Hndi")
        } else {
            print("Bumrah failed Hindi")
        }
        
        if hMatMarks >= 35 {
            print("Bumrah passed Maths")
        } else {
            print("Bumrah failed Maths")
        }
        
        if hSciMarks >= 35 {
            print("Bumrah passed Science")
        } else {
            print("Bumrah failed Science")
        }
        
        if hSocMarks >= 35 {
            print("Bumrah passed Social")
        } else {
            print("Bumrah failed Social")
        }
        
        if (hTelMarks >= 35 && hEngMarks >= 35 && hHinMarks >= 35 && hMatMarks >= 35 && hSciMarks >= 35 && hSocMarks >= 35){
            print("Bmrah PASSED")
        } else {
            print("Bumrah FAILED")
        }
        
        let i:String = "Shami"
        
        let iEngMarks:UInt8 = 42
        let iTelMarks:UInt8 = 54
        let iHinMarks:UInt8 = 66
        let iMatMarks:UInt8 = 78
        let iSciMarks:UInt8 = 80
        let iSocMarks:UInt8 = 92
        
        let shamiMarks:UInt16 = UInt16(iEngMarks)+UInt16(iTelMarks)+UInt16(iMatMarks)+UInt16(iHinMarks)+UInt16(iSocMarks)+UInt16(iSciMarks)
        
        print("Shami's Total Marks are \(shamiMarks)")
        
        
        let totalMarksI:Float = Float(shamiMarks)
        
        let percentageI:Float = (totalMarksI/totalMarks)*100
        
        print("Shami's Percentage is \(percentageI)")
        
        if iEngMarks >= 35 {
            print("Shami passed English")
        } else {
            print("Shami failed English")
        }
        
        if iTelMarks >= 35 {
            print("Shami passed Telugu")
        } else {
            print("Shami failed Telugu")
        }
        
        if iHinMarks >= 35 {
            print("Shami passed Hndi")
        } else {
            print("Shami failed Hindi")
        }
        
        if iMatMarks >= 35 {
            print("Shami passed Maths")
        } else {
            print("Shami failed Maths")
        }
        
        if iSciMarks >= 35 {
            print("Shami passed Science")
        } else {
            print("Shami failed Science")
        }
        
        if iSocMarks >= 35 {
            print("Shami passed Social")
        } else {
            print("Shami failed Social")
        }
        
        if (iTelMarks >= 35 && iEngMarks >= 35 && iHinMarks >= 35 && iMatMarks >= 35 && iSciMarks >= 35 && iSocMarks >= 35){
            print("Shami PASSED")
        } else {
            print("Shami FAILED")
        }
        
        let j:String = "Raina"
        
        let jEngMarks:UInt8 = 92
        let jTelMarks:UInt8 = 81
        let jHinMarks:UInt8 = 70
        let jMatMarks:UInt8 = 69
        let jSciMarks:UInt8 = 58
        let jSocMarks:UInt8 = 47
        
        let rainaMarks:UInt16 = UInt16(jEngMarks)+UInt16(jTelMarks)+UInt16(jMatMarks)+UInt16(jHinMarks)+UInt16(jSocMarks)+UInt16(jSciMarks)
        
        print("Raina's Total Marks are \(rainaMarks)")
        
        
        let totalMarksJ:Float = Float(rainaMarks)
        
        let percentageJ:Float = (totalMarksJ/totalMarks)*100
        
        print("Raina's Percentage is \(percentageJ)")
        
        if jEngMarks >= 35 {
            print("Raina passed English")
        } else {
            print("Raina failed English")
        }
        
        if jTelMarks >= 35 {
            print("Raina passed Telugu")
        } else {
            print("Raina failed Telugu")
        }
        
        if jHinMarks >= 35 {
            print("Raina passed Hndi")
        } else {
            print("Raina failed Hindi")
        }
        
        if jMatMarks >= 35 {
            print("Raina passed Maths")
        } else {
            print("Raina failed Maths")
        }
        
        if jSciMarks >= 35 {
            print("Raina passed Science")
        } else {
            print("Raina failed Science")
        }
        
        if jSocMarks >= 35 {
            print("Raina passed Social")
        } else {
            print("Raina failed Social")
        }
        
        if (jTelMarks >= 35 && jEngMarks >= 35 && jHinMarks >= 35 && jMatMarks >= 35 && jSciMarks >= 35 && jSocMarks >= 35){
            print("Raina PASSED")
        } else {
            print("Raina FAILED")
        }
        
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }
}

