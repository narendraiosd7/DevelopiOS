//
//  ViewController.swift
//  BRN Pulse
//
//  Created by Vadde Narendra on 11/4/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{

    override func viewDidLoad()
    {
        super.viewDidLoad()
    }

    @IBAction func checkBoxTapped(_ sender: UIButton)
    {
        if sender.isSelected
        {
            sender.isSelected = false
        }
        else
        {
            sender.isSelected = true
        }
        
    }
    
    
}

