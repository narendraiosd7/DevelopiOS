//
//  BtechCalculations.swift
//  Classes
//
//  Created by Vadde Narendra on 06/08/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class BtechCalculations: NSObject {

    
    // First Year Marks subjects
    
    var communicativeEngMarks:UInt8 = 0
    var enggPhysicsMarks:UInt8 = 0
    var enggChemistryMarks:UInt8 = 0
    var enggGraphicsMarks:UInt8 = 0
    var proCAndDatastructureMarks:UInt8 = 0
    var enggPhyAndEnggCheLabMarks:UInt8 = 0
    var enggAndITWorkShopMarks:UInt8 = 0
    var enggLangComSkillLabMarks:UInt8 = 0
    var mathematics2Marks:UInt8 = 0
    var mathematics1Marks:UInt8 = 0
    
    func calFirstYearBtechResults()->(firstYearBtechResults:Bool,gained1stYearBtechMarks:UInt16,firstYearBtechPercentage:Float)
    {
        
        // Calculating Total Marks
        
        let gained1stYearBtechMarks:UInt16 = UInt16(communicativeEngMarks)+UInt16(enggPhysicsMarks)+UInt16(enggChemistryMarks)+UInt16(enggGraphicsMarks)+UInt16(proCAndDatastructureMarks)+UInt16(enggPhyAndEnggCheLabMarks)+UInt16(enggAndITWorkShopMarks)+UInt16(enggLangComSkillLabMarks)+UInt16(mathematics2Marks)+UInt16(mathematics1Marks)
        
        print("Total Marks in B-Tech 1st Year = \(gained1stYearBtechMarks)")
        
        // Calculating Percentage
        
        let firstYearBtechTotalMarks:Float = 1000
        
        let firstYearBtechMarks:Float = Float(gained1stYearBtechMarks)
        
        let firstYearBtechPercentage:Float = (firstYearBtechMarks/firstYearBtechTotalMarks)*100
        
        print("B-Tech 1st Year Percentage = \(firstYearBtechPercentage)")
        
        // finding out 1st Year subject wise pass or fail
        
        let subPassMarks:UInt8 = 35
        let labPassMarks:UInt8 = 27
        
        var communicativeEnglish:Bool = false
        var engineeringPhysics:Bool = false
        var engineeringChemistry:Bool = false
        var engineeringGraphics:Bool = false
        var programmingCAndDataStructure:Bool = false
        var engineeringPhysicsAndEngineeringChemistryLab:Bool = false
        var mathematics1:Bool = false
        var mathematics2:Bool = false
        var engineeringAndITWorkShop:Bool = false
        var englishLanguageCommunicationSkillLab:Bool = false
        var programmingCAndDataStructureLab:Bool = false
        
        if communicativeEngMarks >= subPassMarks
        {
            communicativeEnglish = true
        } else {
            communicativeEnglish = false
        }
        
        if enggGraphicsMarks >= subPassMarks
        {
            engineeringGraphics = true
        } else {
            engineeringGraphics = false
        }
        
        if enggChemistryMarks >= subPassMarks
        {
            engineeringChemistry = true
        } else {
            engineeringChemistry = false
        }
        
        if mathematics1Marks >= subPassMarks
        {
            mathematics1 = true
        } else {
            mathematics1 = false
        }
        
        if mathematics2Marks >= subPassMarks
        {
            mathematics2 = true
        } else {
            mathematics2 = false
        }
        
        if proCAndDatastructureMarks >= subPassMarks
        {
            programmingCAndDataStructure = true
        } else {
            programmingCAndDataStructure = false
        }
        
        if enggPhyAndEnggCheLabMarks >= labPassMarks
        {
            engineeringPhysicsAndEngineeringChemistryLab = true
        } else {
            engineeringPhysicsAndEngineeringChemistryLab = false
        }
        
        if enggAndITWorkShopMarks >= labPassMarks
        {
            engineeringAndITWorkShop = true
        } else {
            engineeringAndITWorkShop = false
        }
        
        if proCAndDatastructureMarks >= labPassMarks
        {
            programmingCAndDataStructureLab = true
        } else {
            programmingCAndDataStructureLab = false
        }
        
        if enggLangComSkillLabMarks >= labPassMarks
        {
            englishLanguageCommunicationSkillLab = true
        } else {
            englishLanguageCommunicationSkillLab = false
        }
        
        if enggPhysicsMarks >= subPassMarks
        {
            engineeringPhysics = true
        } else {
            engineeringPhysics = false
        }
        
        // finding out B-Tech 1st Year Passed or Failed and giving grade
        
        
        var firstYearBtechResults:Bool = false
        
        if (communicativeEnglish == true && engineeringGraphics == true && engineeringChemistry == true && mathematics1 == true && mathematics2 == true && programmingCAndDataStructure == true && engineeringPhysicsAndEngineeringChemistryLab == true && engineeringAndITWorkShop == true && programmingCAndDataStructureLab == true && englishLanguageCommunicationSkillLab == true && engineeringPhysics == true)
        {
            switch firstYearBtechPercentage
             {
             case 90...100:
             print("Grade A")
             case 75..<90:
             print("Grade B")
             case 50..<75:
             print("Grade C")
             case 35..<50:
             print("Grade D")
             default:
             print("Grade E")
             }
            firstYearBtechResults = true
            print("Passed B-Tech 1st Year")
            
        }
        else
        {
            firstYearBtechResults = false
            print("Failed B-Tech 1st Year")
        }
        
        let firstYearBtechResult:(firstYearBtechResults:Bool,gained1stYearBtechMarks:UInt16,firstYearBtechPercentage:Float) = (firstYearBtechResults,gained1stYearBtechMarks,firstYearBtechPercentage)
        
        return firstYearBtechResult
    }
    
    
    
    // 2nd Year 1st Sem Marks
    
    var mathematics3Marks:UInt8 = 0
    var environmentalSciMarks:UInt8 = 0
    var basicFMHMMarks:UInt8 = 0
    var elecDevCirsMarks:UInt8 = 0
    var elecMachines1Marks:UInt8 = 0
    var elecCircuitsMarks:UInt8 = 0
    var basicFMHMLabMarks:UInt8 = 0
    var electronicDevCirsLabMarks:UInt8 = 0
    
    func cal2ndYear1stSemBtechResults() -> (secondYear1stSemGainedMarks:UInt16,secondYear1stSemPercentage:Float,secondYear1stSemResults:Bool)
    {
        // Calculating Total Marks
        
        let secondYear1stSemGainedMarks:UInt16 = UInt16(mathematics3Marks)+UInt16(environmentalSciMarks)+UInt16(basicFMHMMarks)+UInt16(elecDevCirsMarks)+UInt16(elecMachines1Marks)+UInt16(elecCircuitsMarks)+UInt16(basicFMHMLabMarks)+UInt16(electronicDevCirsLabMarks)
        
        print("B-Tech 2nd Year 1st Sem Total Marks = \(secondYear1stSemGainedMarks)")
        
        // Calculating Percentage
        
        let totalMarks1stSem:Float = 750
        
        let firstSemGainedMarks:Float = Float(secondYear1stSemGainedMarks)
        
        let secondYear1stSemPercentage:Float = (firstSemGainedMarks/totalMarks1stSem)*100
        
        print("B-Tech 2nd Year 1st Sem Percentage = \(secondYear1stSemPercentage)")
        
        // finding out subject wise pass or fail
        
        let subPassMarks:UInt8 = 35
        let labPassMarks:UInt8 = 27
        
        var mathematics3:Bool = false
        var environmentalScience:Bool = false
        var basicFMHM:Bool = false
        var electronicDevicesAndCircuits:Bool = false
        var electricalMachines1:Bool = false
        var electricalCircuits:Bool = false
        var basicFMHMLab:Bool = false
        var electronicDevicesAndCircuitsLab:Bool = false
        
        if mathematics3Marks >= subPassMarks
        {
            mathematics3 = true
        } else {
            mathematics3 = false
        }
        
        if environmentalSciMarks >= subPassMarks
        {
            environmentalScience = true
        } else {
            environmentalScience = false
        }
        
        if basicFMHMMarks >= subPassMarks
        {
            basicFMHM = true
        } else {
            basicFMHM = false
        }
        
        if elecDevCirsMarks >= subPassMarks
        {
            electronicDevicesAndCircuits = true
        } else {
            electronicDevicesAndCircuits = false
        }
        
        if elecMachines1Marks >= subPassMarks
        {
            electricalMachines1 = true
        } else {
            electricalMachines1 = false
        }
        
        if elecCircuitsMarks >= subPassMarks
        {
            electricalCircuits = true
        } else {
            electricalCircuits = false
        }
        
        if basicFMHMLabMarks >= labPassMarks
        {
            basicFMHMLab = true
        } else {
            basicFMHMLab = false
        }
        
        if  electronicDevCirsLabMarks >= labPassMarks
        {
            electronicDevicesAndCircuitsLab = true
        } else {
            electronicDevicesAndCircuitsLab = false
        }
        
        // Total 2nd Year 1st Sem pass or fail with grade
        
        var secondYear1stSemResults:Bool = false
        
        if (mathematics3 == true && environmentalScience == true && basicFMHM == true && electronicDevicesAndCircuits == true && electricalMachines1 == true && electricalCircuits == true && basicFMHMLab == true && electronicDevicesAndCircuitsLab == true)
        {
            switch secondYear1stSemPercentage
             {
             case 90...100:
             print("Grade A")
             case 75..<90:
             print("Grade B")
             case 50..<75:
             print("Grade C")
             case 35..<50:
             print("Grade D")
             default:
             print("Grade E")
             }
            secondYear1stSemResults = true
            print("B-Tech 2nd Year 1st Sem Passed")
        }
        else
        {
            secondYear1stSemResults = false
            print("B-Tech 2nd Year 1st Sem Failed")
        }
        
        
        let seconYear1stSemBtechResult:(secondYear1stSemGainedMarks:UInt16,secondYear1stSemPercentage:Float,secondYear1stSemResults:Bool) = (secondYear1stSemGainedMarks,secondYear1stSemPercentage,secondYear1stSemResults)
        
        return seconYear1stSemBtechResult
        
    }
    
    // 2nd Year 2nd sem marks
    
    var EMFMarks:UInt8 = 0
    var GEPMarks:UInt8 = 0
    var AECMarks:UInt8 = 0
    var STLDMarks:UInt8 = 0
    var NTMarks:UInt8 = 0
    var EM2Marks:UInt8 = 0
    var EM1LabMarks:UInt8 = 0
    var ECSLabMarks:UInt8 = 0
    
    func cal2ndYear2ndSemBtechResults() -> (secondYear2ndSemGainedMarks:UInt16,secondYear2ndSemPercentage:Float,secondYear2ndSemResults:Bool)
    {
        // Calculating Total Marks
        
        let secondYear2ndSemGainedMarks:UInt16 = UInt16(EMFMarks)+UInt16(GEPMarks)+UInt16(AECMarks)+UInt16(STLDMarks)+UInt16(EM2Marks)+UInt16(NTMarks)+UInt16(EM1LabMarks)+UInt16(ECSLabMarks)
        
        print("B-Tech 2nd Year 2nd Sem Total Marks = \(secondYear2ndSemGainedMarks)")
        
        // Calculating Percentage
        
        let totalMarks2ndSem:Float = 750
        
        let secondSemGainedMarks:Float = Float(secondYear2ndSemGainedMarks)
        
        let secondYear2ndSemPercentage:Float = (secondSemGainedMarks/totalMarks2ndSem)*100
        
        print("B-Tech 2nd Year 2nd Sem Percentage = \(secondYear2ndSemPercentage)")
        
        // finding out subject wise pass or fail
        
        let subPassMarks:UInt8 = 35
        let labPassMarks:UInt8 = 27
        
        var electroMagneticField:Bool = false
        var generationOfElectricalPower:Bool = false
        var analogElectroniccsAndCircuts:Bool = false
        var switchingThoeryAndLogicalDesign:Bool = false
        var electricalMachines2:Bool = false
        var NetworkTheory:Bool = false
        var electricalMachines1Lab:Bool = false
        var electricalCircuitsAndSimulationLab:Bool = false
        
        if EMFMarks >= subPassMarks
        {
            electroMagneticField = true
        } else {
            electroMagneticField = false
        }
        
        if GEPMarks >= subPassMarks
        {
            generationOfElectricalPower = true
        } else {
            generationOfElectricalPower = false
        }
        
        if AECMarks >= subPassMarks
        {
            analogElectroniccsAndCircuts = true
        } else {
            analogElectroniccsAndCircuts = false
        }
        
        if STLDMarks >= subPassMarks
        {
            switchingThoeryAndLogicalDesign = true
        } else {
            switchingThoeryAndLogicalDesign = false
        }
        
        if EM2Marks >= subPassMarks
        {
            electricalMachines2 = true
        } else {
            electricalMachines2 = false
        }
        
        if NTMarks >= subPassMarks
        {
            NetworkTheory = true
        } else {
            NetworkTheory = false
        }
        
        if EM1LabMarks >= labPassMarks
        {
            electricalMachines1Lab = true
        } else {
            electricalMachines1Lab = false
        }
        
        if  ECSLabMarks >= labPassMarks
        {
            electricalCircuitsAndSimulationLab = true
        } else {
            electricalCircuitsAndSimulationLab = false
        }
        
        // Total 2nd Year 2nd Sem pass or fail with grade
        
        var secondYear2ndSemResults:Bool = false
        
        if (electroMagneticField == true && generationOfElectricalPower == true && switchingThoeryAndLogicalDesign == true && analogElectroniccsAndCircuts == true && electricalMachines2 == true && NetworkTheory == true && electricalMachines1Lab == true && electricalCircuitsAndSimulationLab == true)
        {
            switch secondYear2ndSemPercentage
             {
             case 90...100:
             print("Grade A")
             case 75..<90:
             print("Grade B")
             case 50..<75:
             print("Grade C")
             case 35..<50:
             print("Grade D")
             default:
             print("Grade E")
             }
            secondYear2ndSemResults = true
            print("B-Tech 2nd Year 2nd Sem Passed")
        }
        else
        {
            secondYear2ndSemResults = false
            print("B-Tech 2nd Year 2nd Sem Failed")
        }
        
        let secondYear2ndSemBtechResult:(secondYear2ndSemGainedMarks:UInt16,secondYear2ndSemPercentage:Float,secondYear2ndSemResults:Bool) = (secondYear2ndSemGainedMarks,secondYear2ndSemPercentage,secondYear2ndSemResults)
        
        return secondYear2ndSemBtechResult
        
    }
    
    // 3rd Year 1st sem Marks
    
    var MEFAMarks:UInt8 = 0
    var EEMMarks:UInt8 = 0
    var TEPMarks:UInt8 = 0
    var CSMarks:UInt8 = 0
    var PEMarks:UInt8 = 0
    var EM3Marks:UInt8 = 0
    var EMLab2Marks:UInt8 = 0
    var CSSimLabMarks:UInt8 = 0
    
    func cal3rdYear1stSemBtechResults() -> (thirdYear1stSemGainedMarks:UInt16,thirdYear1stSemPercentage:Float,thirdYear1stSemResults:Bool)
    {
        // Calculating Total Marks
        
        let thirdYear1stSemGainedMarks:UInt16 = UInt16(MEFAMarks)+UInt16(EEMMarks)+UInt16(TEPMarks)+UInt16(CSMarks)+UInt16(PEMarks)+UInt16(EM3Marks)+UInt16(EMLab2Marks)+UInt16(CSSimLabMarks)
        
        
        print("B-Tech 3rd Year 1st Sem Percentage = \(thirdYear1stSemGainedMarks)")
        
        // Calculating Percentage
        
        let totalMarks1stSem:Float = 750
        
        let thirdYearFirstSemGainedMarks:Float = Float(thirdYear1stSemGainedMarks)
        
        let thirdYear1stSemPercentage:Float = (thirdYearFirstSemGainedMarks/totalMarks1stSem)*100
        
        print("B-Tech 3rd Year 1st Sem Percentage = \(thirdYear1stSemPercentage)")
        
        // finding out subject wise pass or fail
        
        let subPassMarks:UInt8 = 35
        let labPassMarks:UInt8 = 27
        
        var managerialEconomicsAndFinancialAnalysis:Bool = false
        var electricalAndElectronicsMeasurements:Bool = false
        var transmissionOfELectricalPower:Bool = false
        var controlSystems:Bool = false
        var powerElectronics:Bool = false
        var electricalMachines3:Bool = false
        var electricalMachinesLab2:Bool = false
        var controlSystemsAndSimulationLab:Bool = false
        
        if MEFAMarks >= subPassMarks
        {
            managerialEconomicsAndFinancialAnalysis = true
        } else {
            managerialEconomicsAndFinancialAnalysis = false
        }
        
        if EEMMarks >= subPassMarks
        {
            electricalAndElectronicsMeasurements = true
        } else {
            electricalAndElectronicsMeasurements = false
        }
        
        if TEPMarks >= subPassMarks
        {
            transmissionOfELectricalPower = true
        } else {
            transmissionOfELectricalPower = false
        }
        
        if CSMarks >= subPassMarks
        {
            controlSystems = true
        } else {
            controlSystems = false
        }
        
        if PEMarks >= subPassMarks
        {
            powerElectronics = true
        } else {
            powerElectronics = false
        }
        
        if EM3Marks >= subPassMarks
        {
            electricalMachines3 = true
        } else {
            electricalMachines3 = false
        }
        
        if EMLab2Marks >= labPassMarks
        {
            electricalMachinesLab2 = true
        } else {
            electricalMachinesLab2 = false
        }
        
        if  CSSimLabMarks >= labPassMarks
        {
            controlSystemsAndSimulationLab = true
        } else {
            controlSystemsAndSimulationLab = false
        }
        
        // Total 3rd Year 1st Sem pass or fail with grade
        
        var thirdYear1stSemResults:Bool = false
        
        if (managerialEconomicsAndFinancialAnalysis == true && electricalAndElectronicsMeasurements == true && transmissionOfELectricalPower == true && controlSystems == true && powerElectronics == true && electricalMachines3 == true && electricalMachinesLab2 == true && controlSystemsAndSimulationLab == true)
        {
            switch thirdYear1stSemPercentage
             {
             case 90...100:
             print("Grade A")
             case 75..<90:
             print("Grade B")
             case 50..<75:
             print("Grade C")
             case 35..<50:
             print("Grade D")
             default:
             print("Grade E")
             }
            thirdYear1stSemResults = true
            print("B-Tech 3rd Year 1st Sem Passed")
        }
        else
        {
            thirdYear1stSemResults = false
            print("B-Tech 3rd Year 1st Sem Failed")
        }
        
        let thirdYear1stSemBtechResult:(thirdYear1stSemGainedMarks:UInt16,thirdYear1stSemPercentage:Float,thirdYear1stSemResults:Bool) = (thirdYear1stSemGainedMarks,thirdYear1stSemPercentage,thirdYear1stSemResults)
        
        return thirdYear1stSemBtechResult
        
    }
    
    // 3rd Year 2nd Sem Marks
    
    var MSMarks:UInt8 = 0
    var PSDMarks:UInt8 = 0
    var PSAMarks:UInt8 = 0
    var MPMCMarks:UInt8 = 0
    var PSOCMarks:UInt8 = 0
    var LDICAMarks:UInt8 = 0
    var AECSLLabMarks:UInt8 = 0
    var EMLabMarks:UInt8 = 0
    
    func cal3rdYear2ndSemBtechResults() -> (thirdYear2ndSemGainedMarks:UInt16,thirdYear2ndSemPercentage:Float,thirdYear2ndSemResults:Bool)
    {
        // Calculating Total Marks
        
        let thirdYear2ndSemGainedMarks:UInt16 = UInt16(MSMarks)+UInt16(PSDMarks)+UInt16(PSAMarks)+UInt16(MPMCMarks)+UInt16(PSOCMarks)+UInt16(LDICAMarks)+UInt16(AECSLLabMarks)+UInt16(EMLabMarks)
        
        print("B-Tech 3rd Year 2nd Sem Total = \(thirdYear2ndSemGainedMarks)")
        
        // Calculating Percentage
        
        let totalMarks2ndSem:Float = 750
        
        let thirdYearSecondSemGainedMarks:Float = Float(thirdYear2ndSemGainedMarks)
        
        let thirdYear2ndSemPercentage:Float = (thirdYearSecondSemGainedMarks/totalMarks2ndSem)*100
        
        print("B-Tech 3rd Year 2nd Sem Percentage = \(thirdYear2ndSemPercentage)")
        
        // finding out subject wise pass or fail
        
        let subPassMarks:UInt8 = 35
        let labPassMarks:UInt8 = 27
        
        var managementScience:Bool = false
        var powerSemiconductorDrives:Bool = false
        var powerSystemAnalysis:Bool = false
        var microprocessorsAndMicrocontrollers:Bool = false
        var powerOperationsAndControl:Bool = false
        var linearAndDigitalICApplications:Bool = false
        var advancedEnglishCommunicationSkillsLab:Bool = false
        var electricalMeasurementsLab:Bool = false
        
        if MSMarks >= subPassMarks
        {
            managementScience = true
        } else {
            managementScience = false
        }
        
        if PSDMarks >= subPassMarks
        {
            powerSemiconductorDrives = true
        } else {
            powerSemiconductorDrives = false
        }
        
        if PSAMarks >= subPassMarks
        {
            powerSystemAnalysis = true
        } else {
            powerSystemAnalysis = false
        }
        
        if MPMCMarks >= subPassMarks
        {
            microprocessorsAndMicrocontrollers = true
        } else {
            microprocessorsAndMicrocontrollers = false
        }
        
        if PSOCMarks >= subPassMarks
        {
            powerOperationsAndControl = true
        } else {
            powerOperationsAndControl = false
        }
        
        if LDICAMarks >= subPassMarks
        {
            linearAndDigitalICApplications = true
        } else {
            linearAndDigitalICApplications = false
        }
        
        if AECSLLabMarks >= labPassMarks
        {
            advancedEnglishCommunicationSkillsLab = true
        } else {
            advancedEnglishCommunicationSkillsLab = false
        }
        
        if  EMLabMarks >= labPassMarks
        {
            electricalMeasurementsLab = true
        } else {
            electricalMeasurementsLab = false
        }
        
        // Total 3rd Year 2nd Sem pass or fail with grade
        
        var thirdYear2ndSemResults:Bool = false
        
        if (managementScience == true && powerSemiconductorDrives == true && powerSystemAnalysis == true && microprocessorsAndMicrocontrollers == true && powerOperationsAndControl == true && linearAndDigitalICApplications == true && electricalMeasurementsLab == true && advancedEnglishCommunicationSkillsLab == true)
        {
            switch thirdYear2ndSemPercentage
             {
             case 90...100:
             print("Grade A")
             case 75..<90:
             print("Grade B")
             case 50..<75:
             print("Grade C")
             case 35..<50:
             print("Grade D")
             default:
             print("Grade E")
             }
            thirdYear2ndSemResults = true
            print("B-Tech 3rd Year 2nd Sem Passed")
        }
        else
        {
            thirdYear2ndSemResults = false
            print("B-Tech 3rd Year 2nd Sem Failed")
        }
        
        let thirdYear2ndSemBtechResult:(thirdYear2ndSemGainedMarks:UInt16,thirdYear2ndSemPercentage:Float,thirdYear2ndSemResults:Bool) = (thirdYear2ndSemGainedMarks,thirdYear2ndSemPercentage,thirdYear2ndSemResults)
        
        return thirdYear2ndSemBtechResult
        
    }
    
    // 4th year 1st sem marks
    
    var DEPMarks:UInt8 = 0
    var DSPMarks:UInt8 = 0
    var fundamentalsOfHVDCFactsDevicesMarks:UInt8 = 0
    var SGPMarks:UInt8 = 0
    var InstrumentationMarks:UInt8 = 0
    var OTMarks:UInt8 = 0
    var MPMCLabMarks:UInt8 = 0
    var PESimLabMarks:UInt8 = 0
    
    func cal4thYear1stSemBtechResults() -> (fourthYear1stSemGainedMarks:UInt16,fourthYear1stSemPercentage:Float,fourthYear1stSemResults:Bool)
    {
        // Calculating Total Marks
        
        let fourthYear1stSemGainedMarks:UInt16 = UInt16(DEPMarks)+UInt16(DSPMarks)+UInt16(fundamentalsOfHVDCFactsDevicesMarks)+UInt16(SGPMarks)+UInt16(InstrumentationMarks)+UInt16(OTMarks)+UInt16(MPMCLabMarks)+UInt16(PESimLabMarks)
        
        print("B-Tech 4th Year 1st Sem Total Marks = \(fourthYear1stSemGainedMarks)")
        
        // Calculating Percentage
        
        let totalMarks1stSem:Float = 750
        
        let fourthYearFirstSemGainedMarks:Float = Float(fourthYear1stSemGainedMarks)
        
        let fourthYear1stSemPercentage:Float = (fourthYearFirstSemGainedMarks/totalMarks1stSem)*100
        
        print("B-Tech 4th Year 1st Sem Percentage = \(fourthYear1stSemPercentage)")
        
        // finding out subject wise pass or fail
        
        let subPassMarks:UInt8 = 35
        let labPassMarks:UInt8 = 27
        
        var distributionOfElectricalPower:Bool = false
        var digitalSignalProcessing:Bool = false
        var fundamentalsOfHVDCFactsDevices:Bool = false
        var switchGearAndProtection:Bool = false
        var Instrumentation:Bool = false
        var optimizationTechniques:Bool = false
        var microprocessorsAndMicrocontrollersLab:Bool = false
        var powerElectronicsAndSimulationLab:Bool = false
        
        if DEPMarks >= subPassMarks
        {
            distributionOfElectricalPower = true
        } else {
            distributionOfElectricalPower = false
        }
        
        if DSPMarks >= subPassMarks
        {
            digitalSignalProcessing = true
        } else {
            digitalSignalProcessing = false
        }
        
        if fundamentalsOfHVDCFactsDevicesMarks >= subPassMarks
        {
            fundamentalsOfHVDCFactsDevices = true
        } else {
            fundamentalsOfHVDCFactsDevices = false
        }
        
        if SGPMarks >= subPassMarks
        {
            switchGearAndProtection = true
        } else {
            switchGearAndProtection = false
        }
        
        if InstrumentationMarks >= subPassMarks
        {
            Instrumentation = true
        } else {
            Instrumentation = false
        }
        
        if OTMarks >= subPassMarks
        {
            optimizationTechniques = true
        } else {
            optimizationTechniques = false
        }
        
        if MPMCLabMarks >= labPassMarks
        {
            microprocessorsAndMicrocontrollersLab = true
        } else {
            microprocessorsAndMicrocontrollersLab = false
        }
        
        if  PESimLabMarks >= labPassMarks
        {
            powerElectronicsAndSimulationLab = true
        } else {
            powerElectronicsAndSimulationLab = false
        }
        
        // Total 4th Year 1st Sem pass or fail with grade
        
        var fourthYear1stSemResults:Bool = false
        
        if (distributionOfElectricalPower == true && digitalSignalProcessing == true && fundamentalsOfHVDCFactsDevices == true && switchGearAndProtection == true && Instrumentation == true && optimizationTechniques == true && microprocessorsAndMicrocontrollersLab == true && powerElectronicsAndSimulationLab == true)
        {
            switch fourthYear1stSemPercentage
             {
             case 90...100:
             print("Grade A")
             case 75..<90:
             print("Grade B")
             case 50..<75:
             print("Grade C")
             case 35..<50:
             print("Grade D")
             default:
             print("Grade E")
             }
            fourthYear1stSemResults = true
            print("B-Tech 4th Year 1st Sem Passed")
        }
        else
        {
            fourthYear1stSemResults = false
            print("B-Tech 4th Year 1st Sem Failed")
        }
        
        let fourthYear1stSemBtechResult:(fourthYear1stSemGainedMarks:UInt16,fourthYear1stSemPercentage:Float,fourthYear1stSemResults:Bool) = (fourthYear1stSemGainedMarks,fourthYear1stSemPercentage,fourthYear1stSemResults)
        
        return fourthYear1stSemBtechResult
        
    }
    
    // 4th year 2nd sem marks
    
    var PPQMarks:UInt8 = 0
    var UEEMarks:UInt8 = 0
    var MCTMarks:UInt8 = 0
    var EADSMMarks:UInt8 = 0
    var seminarMarks:UInt8 = 0
    var ProjectWorkMarks:UInt16 = 0
    
    func cal4thYear2ndSemBtechResults() -> (fourthYear2ndSemGainedMarks:UInt16,fourthYear2ndSemPercentage:Float,fourthYear2ndSemResults:Bool)
    {
        // Calculating Total Marks
        
        let fourthYear2ndSemGainedMarks:UInt16 = UInt16(PPQMarks)+UInt16(UEEMarks)+UInt16(MCTMarks)+UInt16(EADSMMarks)+UInt16(seminarMarks)+ProjectWorkMarks
        
        print("B-Tech 4th Year 2nd Sem Total Marks = \(fourthYear2ndSemGainedMarks)")
        
        // Calculating Percentage
        
        let totalMarks2ndSem:Float = 750
        
        let fourthYearSecondSemGainedMarks:Float = Float(fourthYear2ndSemGainedMarks)
        
        let fourthYear2ndSemPercentage:Float = (fourthYearSecondSemGainedMarks/totalMarks2ndSem)*100
        
        print("B-Tech 4th Year 2nd Sem Percentage = \(fourthYear2ndSemPercentage)")
        
        // finding out subject wise pass or fail
        
        let subPassMarks:UInt8 = 35
        let projectPassMarks:UInt16 = 90
        let seminarPassMarks:UInt8 = 15
        
        var principlesOfPowerQuality:Bool = false
        var utilizationOfElectricalEnergy:Bool = false
        var modernControlTheory:Bool = false
        var EnergyAuditingAndDemandSideManagement:Bool = false
        var seminar:Bool = false
        var projectWork:Bool = false
        
        if PPQMarks >= subPassMarks
        {
            principlesOfPowerQuality = true
        } else {
            principlesOfPowerQuality = false
        }
        
        if UEEMarks >= subPassMarks
        {
            utilizationOfElectricalEnergy = true
        } else {
            utilizationOfElectricalEnergy = false
        }
        
        if MCTMarks >= subPassMarks
        {
            modernControlTheory = true
        } else {
            modernControlTheory = false
        }
        
        if EADSMMarks >= subPassMarks
        {
            EnergyAuditingAndDemandSideManagement = true
        } else {
            EnergyAuditingAndDemandSideManagement = false
        }
        
        if seminarMarks >= seminarPassMarks
        {
            seminar = true
        } else {
            seminar = false
        }
        
        if ProjectWorkMarks >= projectPassMarks
        {
            projectWork = true
        } else {
            projectWork = false
        }
        
        
        // Total 4th Year 2nd Sem pass or fail with grade
        
        var fourthYear2ndSemResults:Bool = false
        
        if (principlesOfPowerQuality == true && utilizationOfElectricalEnergy == true && modernControlTheory == true && EnergyAuditingAndDemandSideManagement == true && seminar == true && projectWork == true)
        {
            switch fourthYear2ndSemPercentage
             {
             case 90...100:
             print("Grade A")
             case 75..<90:
             print("Grade B")
             case 50..<75:
             print("Grade C")
             case 35..<50:
             print("Grade D")
             default:
             print("Grade E")
             }
            fourthYear2ndSemResults = true
            print("B-Tech 4th Year 2nd Sem Passed")
        }
        else
        {
            fourthYear2ndSemResults = false
            print("B-Tech 4th Year 2nd Sem Failed")
        }
        
        let fourthYear2ndSemBtechResult:(fourthYear2ndSemGainedMarks:UInt16,fourthYear2ndSemPercentage:Float,fourthYear2ndSemResults:Bool) = (fourthYear2ndSemGainedMarks,fourthYear2ndSemPercentage,fourthYear2ndSemResults)
        
        return fourthYear2ndSemBtechResult
        
    }
    
    
}
