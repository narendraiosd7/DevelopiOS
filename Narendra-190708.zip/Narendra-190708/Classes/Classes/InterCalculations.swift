//
//  InterCalculations.swift
//  Classes
//
//  Created by Vadde Narendra on 06/08/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class InterCalculations: NSObject {
    
    var sanMarks:UInt8 = 0
    var engMarks:UInt8 = 0
    var mathsAMarks:UInt8 = 0
    var mathsBMarks:UInt8 = 0
    var physicsMarks:UInt8 = 0
    var chemistryMarks:UInt8 = 0
    
    func interFirstMarks() -> (firsYearGainedMarks:UInt16,percentage:Float,interFirstYearResults:Bool){
        
        // 1st Year Inter pass marks & Total marks
        
        let subPassMarks1:UInt8 = 35
        let subPassMarks2:UInt8 = 24
        let subPassMarks3:UInt8 = 18
        
        // Inter 1st Year Percentage calculated below
        
        let total1stYearMarks:Float = 470
        
        var interFirstYearResults:Bool = false
    
        // Inters 1st Year Total Marks coding is available below
        
        let firsYearGainedMarks:UInt16 = UInt16(sanMarks)+UInt16(engMarks)+UInt16(mathsAMarks)+UInt16(physicsMarks)+UInt16(chemistryMarks)+UInt16(mathsBMarks)
        
        print("First Year Marks = \(firsYearGainedMarks)")
        
        // Inter 1st Year Marks of Nandu converted in Float & Calculating Percentage
        
        let firsYearMarks:Float = Float(firsYearGainedMarks)
        
        // Nandu's 1st Year Percentage is Printing below
        
        let percentage:Float = (firsYearMarks/total1stYearMarks)*100
        
        print("1st Year Percentage = \(percentage)")
        
        // Coding to the Nandu passed or failed in Inter subject-wise is given below
        
        var sanskrit:Bool = false
        var english:Bool = false
        var mathsA:Bool = false
        var mathsB:Bool = false
        var physics:Bool = false
        var chemistry:Bool = false
        
        
        if sanMarks >= subPassMarks1 {
            sanskrit = true
        } else {
            sanskrit = false
        }
        
        if engMarks >= subPassMarks1 {
            english = true
        } else {
            english = false
        }
        
        if mathsAMarks >= subPassMarks2 {
            mathsA = true
        } else {
            mathsA = false
        }
        
        if mathsBMarks >= subPassMarks2 {
            mathsB = true
        } else {
            mathsB = false
        }
        
        if physicsMarks >= subPassMarks3 {
            physics = true
        } else {
            physics = false
        }
        
        if chemistryMarks >= subPassMarks3 {
            chemistry = true
        } else {
            chemistry = false
        }
        
        // Coding to the Nandu passed or failed in Inter is given below
        
        if (sanskrit == true && english == true && mathsA == true && mathsB == true && physics == true && chemistry == true){
            switch percentage{
            case 90...100:
                print("Grade = A")
            case 75..<90:
                print("Grade = B")
            case 50..<75:
                print("Grade = C")
            case 35..<50:
                print("Grade = D")
            default:
                print("Grade = E")}
            interFirstYearResults = true
            print("Inter 1st Year PASSED")
        } else {
            interFirstYearResults = false
            print("Inter 1st Year FAILED")
        }
        
        let inter1stYearResult:(firsYearGainedMarks:UInt16,percentage:Float,interFirstYearResults:Bool) = (firsYearGainedMarks,percentage,interFirstYearResults)
        
        return inter1stYearResult
    }
    
    var san2ndYearMarks:UInt8 = 0
    var eng2ndYearMarks:UInt8 = 0
    var mathsA2ndYearMarks:UInt8 = 0
    var mathsB2ndYearMarks:UInt8 = 0
    var physics2ndYearMarks:UInt8 = 0
    var chemistry2ndYearMarks:UInt8 = 0
    var physicsLab:UInt8 = 0
    var chemistryLab:UInt8 = 0
    
    func inter2ndYear() -> (secondYearGainedMarks:UInt16,percentage:Float,interSecondYearResults:Bool){
        
        // Inter 2nd Year pass marks
        
        let subPassMarks1:UInt8 = 35
        let subPassMarks2:UInt8 = 24
        let labPassMarks:UInt8 = 18
        
        // Inter 2nd Year Total Marks are available in Float below
        
        let total2ndYearMarks:Float = 530
        
        var interSecondYearResults:Bool = false
        
        // Inters 2nd Year Total Marks coding is available below
        
        let secondYearGainedMarks:UInt16 = UInt16(san2ndYearMarks)+UInt16(eng2ndYearMarks)+UInt16(mathsA2ndYearMarks)+UInt16(mathsB2ndYearMarks)+UInt16(physics2ndYearMarks)+UInt16(chemistry2ndYearMarks)+UInt16(physicsLab)+UInt16(chemistryLab)
        
        print("2nd Year Marks = \(secondYearGainedMarks)")
        
        // Inter 2nd Year Marks of Nandu converted in Float
        
        let secondYearMarks:Float = Float(secondYearGainedMarks)
        
        // Inter 2nd Year Percentage calculated below
        
        let percentage:Float = (secondYearMarks/total2ndYearMarks)*100
        
        print("2nd Year Percentage = \(percentage)")
        
        // Coding to the Nandu passed or failed in Inter 2nd Year is given below
        
        var sanskrit:Bool = false
        var english:Bool = false
        var mathsA:Bool = false
        var mathsB:Bool = false
        var physics:Bool = false
        var chemistry:Bool = false
        var physicsPracticals:Bool = false
        var chemistryPracticals:Bool = false
        
        
        
        
        if sanMarks >= subPassMarks1 {
            sanskrit = true
        } else {
            sanskrit = false
        }
        
        if engMarks >= subPassMarks1 {
            english = true
        } else {
            english = false
        }
        
        if mathsAMarks >= subPassMarks1 {
            mathsA = true
        } else {
            mathsA = false
        }
        
        if mathsBMarks >= subPassMarks1 {
            mathsB = true
        } else {
            mathsB = false
        }
        
        if physicsMarks >= subPassMarks2 {
            physics = true
        } else {
            physics = false
        }
        
        if chemistryMarks >= subPassMarks2 {
            chemistry = true
        } else {
            chemistry = false
        }
        
        if physicsLab >= labPassMarks {
            physicsPracticals = true
        } else {
            physicsPracticals = false
        }
        
        if chemistryLab >= labPassMarks {
            chemistryPracticals = true
        } else {
            chemistryPracticals = false
        }
        
        // Coding to the Nandu passed or failed in Inter is given below
        
        if (sanskrit == true && english == true && mathsA == true && mathsB == true && physics == true && chemistry == true && physicsPracticals == true && chemistryPracticals == true){
            switch percentage {
            case 90...100:
                print("Grade = A")
            case 75...90:
                print("Grade = B")
            case 50...75:
                print("Grade = C")
            case 35...50:
                print("Grade = D")
            default:
                print("Grade = E")
            }
            interSecondYearResults = true
            print("Inter 2nd Year PASSED")
        } else {
            interSecondYearResults = false
            print("Inter 2nd Year FAILED")
        }
        
        let inter2ndYearResult:(secondYearGainedMarks:UInt16,percentage:Float,interSecondYearResults:Bool) = (secondYearGainedMarks,percentage,interSecondYearResults)
        
        return inter2ndYearResult
    }
    
}
