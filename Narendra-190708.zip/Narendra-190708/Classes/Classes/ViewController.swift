//
//  ViewController.swift
//  Classes
//
//  Created by Vadde Narendra on 06/08/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Person - 1
        
        print("********** Person - 1 **********")
        
        let narendra:TenthCalculations = TenthCalculations()
        
        narendra.telMarks = 90
        narendra.engMarks = 89
        narendra.hindiMarks = 87
        narendra.mathsMarks = 86
        narendra.sciMarks = 85
        narendra.socMarks = 84
        
        narendra.calTenthMarks()
        
        // Person - 2
        
        print("********** Person - 2 **********")
        
        let arun:TenthCalculations = TenthCalculations()
        
        arun.telMarks = 95
        arun.engMarks = 85
        arun.hindiMarks = 75
        arun.mathsMarks = 65
        arun.sciMarks = 55
        arun.socMarks = 45
        
        arun.calTenthMarks()
        
        // Person - 3
        
        print("********** Person - 3 **********")
        
        let arjun:TenthCalculations = TenthCalculations()
        
        arjun.telMarks = 66
        arjun.engMarks = 46
        arjun.hindiMarks = 26
        arjun.mathsMarks = 36
        arjun.sciMarks = 56
        arjun.socMarks = 66
        
        arjun.calTenthMarks()
        
        // Person - 4
        
        print("********** Person - 4 **********")
        
        let mitra:TenthCalculations = TenthCalculations()
        
        mitra.telMarks = 85
        mitra.engMarks = 83
        mitra.hindiMarks = 81
        mitra.mathsMarks = 79
        mitra.sciMarks = 77
        mitra.socMarks = 75
        
        mitra.calTenthMarks()
        
        // Person - 5
        
        print("********** Person - 5 **********")
        
        let maitri:TenthCalculations = TenthCalculations()
        
        maitri.telMarks = 71
        maitri.engMarks = 61
        maitri.hindiMarks = 51
        maitri.mathsMarks = 41
        maitri.sciMarks = 31
        maitri.socMarks = 45
        
        maitri.calTenthMarks()
        
        print("  ")
        print("  ")
        print("  ")
        
    // Inter Calculations
        
        print("********** Inter Calculations **********")
        
        //person - 1
        
        print("********** person - 1 **********")
        
        print("********** Inter 1st Year **********")
        
        let dharmaraj:InterCalculations = InterCalculations()
        
        dharmaraj.sanMarks = 71
        dharmaraj.engMarks = 82
        dharmaraj.mathsAMarks = 93
        dharmaraj.mathsBMarks = 94
        dharmaraj.physicsMarks = 65
        dharmaraj.chemistryMarks = 66
        
        dharmaraj.interFirstMarks()
        
        print("********** Inter 2nd Year **********")
        
        dharmaraj.san2ndYearMarks = 49
        dharmaraj.eng2ndYearMarks = 69
        dharmaraj.mathsA2ndYearMarks = 82
        dharmaraj.mathsB2ndYearMarks = 71
        dharmaraj.physics2ndYearMarks = 56
        dharmaraj.chemistry2ndYearMarks = 68
        dharmaraj.physicsLab = 35
        dharmaraj.chemistryLab = 31
        
        dharmaraj.inter2ndYear()
        
        // Inter Results
        
        let person1TotalMarks:UInt16 = dharmaraj.interFirstMarks().firsYearGainedMarks + dharmaraj.inter2ndYear().secondYearGainedMarks
        
        print("Inter Total Marks = \(person1TotalMarks)")
        
        let person1TotalInterMarks:Float = 1000
        
        let person1Percentage:Float = (Float(person1TotalMarks)/person1TotalInterMarks)*100
        
        print("Inter Percentage = \(person1Percentage)")
        
        if (dharmaraj.interFirstMarks().interFirstYearResults == true && dharmaraj.inter2ndYear().interSecondYearResults == true)
        {
            switch person1Percentage
            {
            case 90...100:
                print("Grade A")
            case 75..<90:
                print("Grade B")
            case 50..<75:
                print("Grade C")
            case 35..<50:
                print("Grade D")
            default:
                print("Grade E")
            }
            print("Inter Passed")
        }
        else
        {
            print("Inter Failed")
        }
        
        //person - 2
        
        print("********** person - 2 **********")
        
        print("********** Inter 1st Year **********")
        
        let bheemudu:InterCalculations = InterCalculations()
        
        bheemudu.sanMarks = 49
        bheemudu.engMarks = 36
        bheemudu.mathsAMarks = 93
        bheemudu.mathsBMarks = 94
        bheemudu.physicsMarks = 65
        bheemudu.chemistryMarks = 66
        
        bheemudu.interFirstMarks()
        
        print("********** Inter 2nd Year **********")
        
        bheemudu.san2ndYearMarks = 39
        bheemudu.eng2ndYearMarks = 48
        bheemudu.mathsA2ndYearMarks = 35
        bheemudu.mathsB2ndYearMarks = 71
        bheemudu.physics2ndYearMarks = 56
        bheemudu.chemistry2ndYearMarks = 68
        bheemudu.physicsLab = 35
        bheemudu.chemistryLab = 31
        
        bheemudu.inter2ndYear()
        
        // Inter Results
        
        let person2TotalMarks:UInt16 = bheemudu.interFirstMarks().firsYearGainedMarks + bheemudu.inter2ndYear().secondYearGainedMarks
        
        print("Inter Total Marks = \(person2TotalMarks)")
        
        let person2TotalInterMarks:Float = 1000
        
        let person2Percentage:Float = (Float(person2TotalMarks)/person2TotalInterMarks)*100
        
        print("Inter Percentage = \(person2Percentage)")
        
        if (bheemudu.interFirstMarks().interFirstYearResults == true && bheemudu.inter2ndYear().interSecondYearResults == true)
        {
            switch person2Percentage
            {
            case 90...100:
                print("Grade A")
            case 75..<90:
                print("Grade B")
            case 50..<75:
                print("Grade C")
            case 35..<50:
                print("Grade D")
            default:
                print("Grade E")
            }
            print("Inter Passed")
        }
        else
        {
            print("Inter Failed")
        }
        
        //person - 3
        
        print("********** person - 3 **********")
        
        print("********** Inter 1st Year **********")
        
        let arjuna:InterCalculations = InterCalculations()
        
        arjuna.sanMarks = 71
        arjuna.engMarks = 82
        arjuna.mathsAMarks = 96
        arjuna.mathsBMarks = 48
        arjuna.physicsMarks = 65
        arjuna.chemistryMarks = 66
        
        arjuna.interFirstMarks()
        
        print("********** Inter 2nd Year **********")
        
        arjuna.san2ndYearMarks = 38
        arjuna.eng2ndYearMarks = 69
        arjuna.mathsA2ndYearMarks = 48
        arjuna.mathsB2ndYearMarks = 71
        arjuna.physics2ndYearMarks = 56
        arjuna.chemistry2ndYearMarks = 68
        arjuna.physicsLab = 35
        arjuna.chemistryLab = 31
        
        arjuna.inter2ndYear()
        
        // Inter Results
        
        let person3TotalMarks:UInt16 = arjuna.interFirstMarks().firsYearGainedMarks + arjuna.inter2ndYear().secondYearGainedMarks
        
        print("Inter Total Marks = \(person3TotalMarks)")
        
        let person3TotalInterMarks:Float = 1000
        
        let person3Percentage:Float = (Float(person3TotalMarks)/person3TotalInterMarks)*100
        
        print("Inter Percentage = \(person3Percentage)")
        
        if (arjuna.interFirstMarks().interFirstYearResults == true && arjuna.inter2ndYear().interSecondYearResults == true)
        {
            switch person3Percentage
            {
            case 90...100:
                print("Grade A")
            case 75..<90:
                print("Grade B")
            case 50..<75:
                print("Grade C")
            case 35..<50:
                print("Grade D")
            default:
                print("Grade E")
            }
            print("Inter Passed")
        }
        else
        {
            print("Inter Failed")
        }
    
        //person - 4
        
        print("********** person - 4 **********")
        
        print("********** Inter 1st Year **********")
        
        let nakuludu:InterCalculations = InterCalculations()
        
        nakuludu.sanMarks = 71
        nakuludu.engMarks = 82
        nakuludu.mathsAMarks = 14
        nakuludu.mathsBMarks = 35
        nakuludu.physicsMarks = 65
        nakuludu.chemistryMarks = 66
        
        nakuludu.interFirstMarks()
        
        print("********** Inter 2nd Year **********")
        
        nakuludu.san2ndYearMarks = 95
        nakuludu.eng2ndYearMarks = 91
        nakuludu.mathsA2ndYearMarks = 58
        nakuludu.mathsB2ndYearMarks = 71
        nakuludu.physics2ndYearMarks = 56
        nakuludu.chemistry2ndYearMarks = 68
        nakuludu.physicsLab = 35
        nakuludu.chemistryLab = 31
        
        nakuludu.inter2ndYear()
        
        // Inter Results
        
        let person4TotalMarks:UInt16 = nakuludu.interFirstMarks().firsYearGainedMarks + nakuludu.inter2ndYear().secondYearGainedMarks
        
        print("Inter Total Marks = \(person4TotalMarks)")
        
        let person4TotalInterMarks:Float = 1000
        
        let person4Percentage:Float = (Float(person4TotalMarks)/person4TotalInterMarks)*100
        
        print("Inter Percentage = \(person4Percentage)")
        
        if (nakuludu.interFirstMarks().interFirstYearResults == true && nakuludu.inter2ndYear().interSecondYearResults == true)
        {
            switch person4Percentage
            {
            case 90...100:
                print("Grade A")
            case 75..<90:
                print("Grade B")
            case 50..<75:
                print("Grade C")
            case 35..<50:
                print("Grade D")
            default:
                print("Grade E")
            }
            print("Inter Passed")
        }
        else
        {
            print("Inter Failed")
        }
        
        //person - 5
        
        print("********** person - 5 **********")
        
        print("********** Inter 1st Year **********")
        
        let sahadev:InterCalculations = InterCalculations()
        
        sahadev.sanMarks = 71
        sahadev.engMarks = 82
        sahadev.mathsAMarks = 45
        sahadev.mathsBMarks = 94
        sahadev.physicsMarks = 65
        sahadev.chemistryMarks = 66
        
        sahadev.interFirstMarks()
        
        print("********** Inter 2nd Year **********")
        
        sahadev.san2ndYearMarks = 20
        sahadev.eng2ndYearMarks = 47
        sahadev.mathsA2ndYearMarks = 82
        sahadev.mathsB2ndYearMarks = 71
        sahadev.physics2ndYearMarks = 58
        sahadev.chemistry2ndYearMarks = 66
        sahadev.physicsLab = 34
        sahadev.chemistryLab = 28
        
        sahadev.inter2ndYear()
        
        // Inter Results
        
        let person5TotalMarks:UInt16 = sahadev.interFirstMarks().firsYearGainedMarks + sahadev.inter2ndYear().secondYearGainedMarks
        
        print("Inter Total Marks = \(person5TotalMarks)")
        
        let person5TotalInterMarks:Float = 1000
        
        let person5Percentage:Float = (Float(person5TotalMarks)/person5TotalInterMarks)*100
        
        print("Inter Percentage = \(person5Percentage)")
        
        if (sahadev.interFirstMarks().interFirstYearResults == true && sahadev.inter2ndYear().interSecondYearResults == true)
        {
            switch person5Percentage
            {
            case 90...100:
                print("Grade A")
            case 75..<90:
                print("Grade B")
            case 50..<75:
                print("Grade C")
            case 35..<50:
                print("Grade D")
            default:
                print("Grade E")
            }
            print("Inter Passed")
        }
        else
        {
            print("Inter Failed")
        }

        
        // B-Tech calculations
        
        
        
        print("  ")
        print("  ")
        print("  ")
        
        
        
        print("********** B-Tech **********")
        
        // Person - 1
        
        print("********** Person - 1 **********")
        
        
        let ramu:BtechCalculations = BtechCalculations()
        
        // 1st year B-Tech results
        
        print("********** B-Tech 1st Year **********")
        
        ramu.communicativeEngMarks = 80
        ramu.enggPhysicsMarks = 79
        ramu.enggChemistryMarks = 78
        ramu.enggGraphicsMarks = 77
        ramu.proCAndDatastructureMarks = 76
        ramu.enggPhyAndEnggCheLabMarks = 75
        ramu.enggAndITWorkShopMarks = 74
        ramu.enggLangComSkillLabMarks = 72
        ramu.mathematics2Marks = 73
        ramu.mathematics1Marks = 71
        
        ramu.calFirstYearBtechResults()
        
        // 2nd year 1st sem B-Tech results
        
        print("********** B-Tech 2nd Year 1st Sem **********")
        
        ramu.mathematics3Marks = 58
        ramu.environmentalSciMarks = 61
        ramu.basicFMHMMarks = 67
        ramu.elecDevCirsMarks = 74
        ramu.elecMachines1Marks = 78
        ramu.elecCircuitsMarks = 58
        ramu.basicFMHMLabMarks = 70
        ramu.electronicDevCirsLabMarks = 72
        
        ramu.cal2ndYear1stSemBtechResults()
        
        // 2nd year 2nd sem B-Tech results
        
        print("********** B-Tech 2nd Year 2nd Sem **********")
        
        ramu.EMFMarks = 85
        ramu.GEPMarks = 84
        ramu.AECMarks = 82
        ramu.STLDMarks = 84
        ramu.NTMarks = 74
        ramu.EM2Marks = 78
        ramu.EM1LabMarks = 70
        ramu.ECSLabMarks = 72
        
        ramu.cal2ndYear2ndSemBtechResults()
        
        // 3rd year 1st sem B-Tech results
        
        print("********** B-Tech 3rd Year 1st Sem **********")
        
        ramu.MEFAMarks = 84
        ramu.EEMMarks = 82
        ramu.TEPMarks = 81
        ramu.CSMarks = 88
        ramu.PEMarks = 86
        ramu.EM3Marks = 87
        ramu.EMLab2Marks = 71
        ramu.CSSimLabMarks = 70
        
        ramu.cal3rdYear1stSemBtechResults()
        
        // 3rd year 2nd sem B-Tech results
        
        print("********** B-Tech 3rd Year 2nd Sem **********")
        
        ramu.MSMarks = 78
        ramu.PSDMarks = 75
        ramu.PSAMarks = 74
        ramu.MPMCMarks = 71
        ramu.PSOCMarks = 73
        ramu.LDICAMarks = 70
        ramu.AECSLLabMarks = 73
        ramu.EMLabMarks = 71
        
        ramu.cal3rdYear2ndSemBtechResults()
        
        // 4th year 1st sem B-Tech results
        
        print("********** B-Tech 4th Year 1st Sem **********")
        
        ramu.DEPMarks = 83
        ramu.DSPMarks = 81
        ramu.fundamentalsOfHVDCFactsDevicesMarks = 81
        ramu.SGPMarks = 83
        ramu.InstrumentationMarks = 86
        ramu.OTMarks = 84
        ramu.MPMCLabMarks = 74
        ramu.PESimLabMarks = 75
        
        ramu.cal4thYear1stSemBtechResults()
        
        // 4th year 2nd sem B-Tech results
        
        print("********** B-Tech 4th Year 2nd Sem **********")
        
        ramu.PPQMarks = 86
        ramu.UEEMarks = 95
        ramu.MCTMarks = 75
        ramu.EADSMMarks = 78
        ramu.seminarMarks = 48
        ramu.ProjectWorkMarks = 287
        
        ramu.cal4thYear2ndSemBtechResults()
        
        // 2nd Year B-Tech Results
        
        print("********** B-Tech 2nd Year Results **********")
        
        let person1Total2ndYearBtechGainedMarks:UInt16 = ramu.cal2ndYear1stSemBtechResults().secondYear1stSemGainedMarks + ramu.cal2ndYear2ndSemBtechResults().secondYear2ndSemGainedMarks
        
        print("Total 2nd Year B-Tech Marks = \(person1Total2ndYearBtechGainedMarks)")
        
        let person1Total2ndYearBtechMarks:Float = 1500
        
        let person1percentage2ndYearBtech:Float = (Float(person1Total2ndYearBtechGainedMarks)/person1Total2ndYearBtechMarks)*100
        
        print("Percentage 2nd Year B-Tech = \(person1percentage2ndYearBtech)")
        
        if ramu.cal2ndYear1stSemBtechResults().secondYear1stSemResults == true && ramu.cal2ndYear2ndSemBtechResults().secondYear2ndSemResults == true
        {
            switch person1percentage2ndYearBtech
            {
            case 90...100:
                print("Grade A")
            case 75..<90:
                print("Grade B")
            case 50..<75:
                print("Grade C")
            case 35..<50:
                print("Grade D")
            default:
                print("Grade E")
            }
            print("2nd Year B-Tech Passed")
        }
        else
        {
            print("2nd Year B-Tech Failed")
        }
        
        // 3rd Year B-Tech Results
        
        print("********** B-Tech 3rd Year Results **********")
        
        let person1Total3rdYearBtechGainedMarks:UInt16 = ramu.cal3rdYear1stSemBtechResults().thirdYear1stSemGainedMarks +  ramu.cal2ndYear2ndSemBtechResults().secondYear2ndSemGainedMarks
        
        print("Total 3rd Year B-Tech Marks = \(person1Total3rdYearBtechGainedMarks)")
        
        let person1Total3rdYearBtechMarks:Float = 1500
        
        let person1percentage3rdYearBtech:Float = (Float(person1Total3rdYearBtechGainedMarks)/person1Total3rdYearBtechMarks)*100
        
        print("Percentage 3rd Year B-Tech = \(person1percentage3rdYearBtech)")
        
        if ramu.cal3rdYear1stSemBtechResults().thirdYear1stSemResults == true && ramu.cal3rdYear2ndSemBtechResults().thirdYear2ndSemResults == true
        {
            switch person1percentage3rdYearBtech
            {
            case 90...100:
                print("Grade A")
            case 75..<90:
                print("Grade B")
            case 50..<75:
                print("Grade C")
            case 35..<50:
                print("Grade D")
            default:
                print("Grade E")
            }
            print("3rd Year B-Tech Passed")
        }
        else
        {
            print("3rd Year B-Tech Failed")
        }
        
        // 4th Year B-Tech Results
        
        print("********** B-Tech 4th Year Results **********")
        
        let person1Total4thYearBtechgainedMarks:UInt16 = ramu.cal4thYear1stSemBtechResults().fourthYear1stSemGainedMarks + ramu.cal4thYear2ndSemBtechResults().fourthYear2ndSemGainedMarks
        
        
        print("Total 4th Year B-Tech Marks = \(person1Total4thYearBtechgainedMarks)")
        
        let person1Total4thYearBtechMarks:Float = 1500
        
        let person1Percentage4thYearBtech:Float = (Float(person1Total4thYearBtechgainedMarks)/person1Total4thYearBtechMarks)*100
        
        print("Percentage 4th Year B-Tech = \(person1Total4thYearBtechgainedMarks)")
        
        if ramu.cal4thYear1stSemBtechResults().fourthYear1stSemResults == true && ramu.cal4thYear2ndSemBtechResults().fourthYear2ndSemResults == true
        {
            switch person1Percentage4thYearBtech
            {
            case 90...100:
                print("Grade A")
            case 75..<90:
                print("Grade B")
            case 50..<75:
                print("Grade C")
            case 35..<50:
                print("Grade D")
            default:
                print("Grade E")
            }
            print("4th Year B-Tech Passed")
        }
        else
        {
            print("4th Year B-Tech Failed")
        }
        
        //Overall B-Tech results
        
        let person1TotalBtechGainedResults = ramu.calFirstYearBtechResults().gained1stYearBtechMarks + ramu.cal2ndYear1stSemBtechResults().secondYear1stSemGainedMarks + ramu.cal2ndYear2ndSemBtechResults().secondYear2ndSemGainedMarks + ramu.cal3rdYear1stSemBtechResults().thirdYear1stSemGainedMarks + ramu.cal3rdYear2ndSemBtechResults().thirdYear2ndSemGainedMarks + ramu.cal4thYear1stSemBtechResults().fourthYear1stSemGainedMarks + ramu.cal4thYear2ndSemBtechResults().fourthYear2ndSemGainedMarks
        
        print("Total B-Tech Marks = \(person1TotalBtechGainedResults)")
        
        let person1TotalBtechMarks:Float = 5500
        
        let person1PercentageBtech:Float = (Float(person1TotalBtechGainedResults)/person1TotalBtechMarks)*100
        
        print("B-Tech Percentage = \(person1PercentageBtech)")
        
        if (ramu.calFirstYearBtechResults().firstYearBtechResults == true && ramu.cal2ndYear1stSemBtechResults().secondYear1stSemResults == true && ramu.cal2ndYear2ndSemBtechResults().secondYear2ndSemResults == true && ramu.cal3rdYear1stSemBtechResults().thirdYear1stSemResults == true && ramu.cal3rdYear2ndSemBtechResults().thirdYear2ndSemResults == true && ramu.cal4thYear1stSemBtechResults().fourthYear1stSemResults == true && ramu.cal4thYear2ndSemBtechResults().fourthYear2ndSemResults == true)
        {
            switch person1PercentageBtech
            {
            case 90...100:
                print("Grade A")
            case 75..<90:
                print("Grade B")
            case 50..<75:
                print("Grade C")
            case 35..<50:
                print("Grade D")
            default:
                print("Grade E")
            }
            print("B-Tech Passed")
        }
        else
        {
            print("B-Tech Failed")
        }
        
        // Person - 2
        
        print("********** Person - 2 **********")
        
        
        let laxman:BtechCalculations = BtechCalculations()
        
        // 1st year B-Tech results
        
        print("********** B-Tech 1st Year **********")
        
        laxman.communicativeEngMarks = 48
        laxman.enggPhysicsMarks = 79
        laxman.enggChemistryMarks = 78
        laxman.enggGraphicsMarks = 77
        laxman.proCAndDatastructureMarks = 76
        laxman.enggPhyAndEnggCheLabMarks = 75
        laxman.enggAndITWorkShopMarks = 74
        laxman.enggLangComSkillLabMarks = 72
        laxman.mathematics2Marks = 73
        laxman.mathematics1Marks = 71
        
        laxman.calFirstYearBtechResults()
        
        // 2nd year 1st sem B-Tech results
        
        print("********** B-Tech 2nd Year 1st Sem **********")
        
        laxman.mathematics3Marks = 58
        laxman.environmentalSciMarks = 69
        laxman.basicFMHMMarks = 67
        laxman.elecDevCirsMarks = 74
        laxman.elecMachines1Marks = 78
        laxman.elecCircuitsMarks = 58
        laxman.basicFMHMLabMarks = 70
        laxman.electronicDevCirsLabMarks = 72
        
        laxman.cal2ndYear1stSemBtechResults()
        
        // 2nd year 2nd sem B-Tech results
        
        print("********** B-Tech 2nd Year 2nd Sem **********")
        
        laxman.EMFMarks = 85
        laxman.GEPMarks = 84
        laxman.AECMarks = 82
        laxman.STLDMarks = 65
        laxman.NTMarks = 74
        laxman.EM2Marks = 78
        laxman.EM1LabMarks = 70
        laxman.ECSLabMarks = 72
        
        laxman.cal2ndYear2ndSemBtechResults()
        
        // 3rd year 1st sem B-Tech results
        
        print("********** B-Tech 3rd Year 1st Sem **********")
        
        laxman.MEFAMarks = 84
        laxman.EEMMarks = 82
        laxman.TEPMarks = 48
        laxman.CSMarks = 88
        laxman.PEMarks = 86
        laxman.EM3Marks = 87
        laxman.EMLab2Marks = 71
        laxman.CSSimLabMarks = 70
        
        laxman.cal3rdYear1stSemBtechResults()
        
        // 3rd year 2nd sem B-Tech results
        
        print("********** B-Tech 3rd Year 2nd Sem **********")
        
        laxman.MSMarks = 78
        laxman.PSDMarks = 75
        laxman.PSAMarks = 74
        laxman.MPMCMarks = 35
        laxman.PSOCMarks = 73
        laxman.LDICAMarks = 70
        laxman.AECSLLabMarks = 73
        laxman.EMLabMarks = 71
        
        laxman.cal3rdYear2ndSemBtechResults()
        
        // 4th year 1st sem B-Tech results
        
        print("********** B-Tech 4th Year 1st Sem **********")
        
        laxman.DEPMarks = 83
        laxman.DSPMarks = 81
        laxman.fundamentalsOfHVDCFactsDevicesMarks = 81
        laxman.SGPMarks = 25
        laxman.InstrumentationMarks = 86
        laxman.OTMarks = 84
        laxman.MPMCLabMarks = 74
        laxman.PESimLabMarks = 75
        
        laxman.cal4thYear1stSemBtechResults()
        
        // 4th year 2nd sem B-Tech results
        
        print("********** B-Tech 4th Year 2nd Sem **********")
        
        laxman.PPQMarks = 86
        laxman.UEEMarks = 95
        laxman.MCTMarks = 48
        laxman.EADSMMarks = 78
        laxman.seminarMarks = 48
        laxman.ProjectWorkMarks = 296
        
        laxman.cal4thYear2ndSemBtechResults()
        
        // 2nd Year B-Tech Results
        
        print("********** B-Tech 2nd Year Results **********")
        
        let person2Total2ndYearBtechGainedMarks:UInt16 = laxman.cal2ndYear1stSemBtechResults().secondYear1stSemGainedMarks + laxman.cal2ndYear2ndSemBtechResults().secondYear2ndSemGainedMarks
        
        print("Total 2nd Year B-Tech Marks = \(person2Total2ndYearBtechGainedMarks)")
        
        let person2Total2ndYearBtechMarks:Float = 1500
        
        let person2percentage2ndYearBtech:Float = (Float(person2Total2ndYearBtechGainedMarks)/person2Total2ndYearBtechMarks)*100
        
        print("Percentage 2nd Year B-Tech = \(person2percentage2ndYearBtech)")
        
        if laxman.cal2ndYear1stSemBtechResults().secondYear1stSemResults == true && laxman.cal2ndYear2ndSemBtechResults().secondYear2ndSemResults == true
        {
            switch person2percentage2ndYearBtech
            {
            case 90...100:
                print("Grade A")
            case 75..<90:
                print("Grade B")
            case 50..<75:
                print("Grade C")
            case 35..<50:
                print("Grade D")
            default:
                print("Grade E")
            }
            print("2nd Year B-Tech Passed")
        }
        else
        {
            print("2nd Year B-Tech Failed")
        }
        
        // 3rd Year B-Tech Results
        
        print("********** B-Tech 3rd Year Results **********")
        
        let person2Total3rdYearBtechGainedMarks:UInt16 = laxman.cal3rdYear1stSemBtechResults().thirdYear1stSemGainedMarks +  laxman.cal2ndYear2ndSemBtechResults().secondYear2ndSemGainedMarks
        
        print("Total 3rd Year B-Tech Marks = \(person2Total3rdYearBtechGainedMarks)")
        
        let person2Total3rdYearBtechMarks:Float = 1500
        
        let person2percentage3rdYearBtech:Float = (Float(person2Total3rdYearBtechGainedMarks)/person2Total3rdYearBtechMarks)*100
        
        print("Percentage 3rd Year B-Tech = \(person2percentage3rdYearBtech)")
        
        if laxman.cal3rdYear1stSemBtechResults().thirdYear1stSemResults == true && laxman.cal3rdYear2ndSemBtechResults().thirdYear2ndSemResults == true
        {
            switch person2percentage3rdYearBtech
            {
            case 90...100:
                print("Grade A")
            case 75..<90:
                print("Grade B")
            case 50..<75:
                print("Grade C")
            case 35..<50:
                print("Grade D")
            default:
                print("Grade E")
            }
            print("3rd Year B-Tech Passed")
        }
        else
        {
            print("3rd Year B-Tech Failed")
        }
        
        // 4th Year B-Tech Results
        
        print("********** B-Tech 4th Year Results **********")
        
        let person2Total4thYearBtechgainedMarks:UInt16 = laxman.cal4thYear1stSemBtechResults().fourthYear1stSemGainedMarks + laxman.cal4thYear2ndSemBtechResults().fourthYear2ndSemGainedMarks
        
        
        print("Total 4th Year B-Tech Marks = \(person2Total4thYearBtechgainedMarks)")
        
        let person2Total4thYearBtechMarks:Float = 1500
        
        let person2Percentage4thYearBtech:Float = (Float(person2Total4thYearBtechgainedMarks)/person2Total4thYearBtechMarks)*100
        
        print("Percentage 4th Year B-Tech = \(person2Total4thYearBtechgainedMarks)")
        
        if laxman.cal4thYear1stSemBtechResults().fourthYear1stSemResults == true && laxman.cal4thYear2ndSemBtechResults().fourthYear2ndSemResults == true
        {
            switch person2Percentage4thYearBtech
            {
            case 90...100:
                print("Grade A")
            case 75..<90:
                print("Grade B")
            case 50..<75:
                print("Grade C")
            case 35..<50:
                print("Grade D")
            default:
                print("Grade E")
            }
            print("4th Year B-Tech Passed")
        }
        else
        {
            print("4th Year B-Tech Failed")
        }
        
        //Overall B-Tech results
        
        let person2TotalBtechGainedResults = laxman.calFirstYearBtechResults().gained1stYearBtechMarks + laxman.cal2ndYear1stSemBtechResults().secondYear1stSemGainedMarks + laxman.cal2ndYear2ndSemBtechResults().secondYear2ndSemGainedMarks + laxman.cal3rdYear1stSemBtechResults().thirdYear1stSemGainedMarks + laxman.cal3rdYear2ndSemBtechResults().thirdYear2ndSemGainedMarks + laxman.cal4thYear1stSemBtechResults().fourthYear1stSemGainedMarks + laxman.cal4thYear2ndSemBtechResults().fourthYear2ndSemGainedMarks
        
        print("Total B-Tech Marks = \(person2TotalBtechGainedResults)")
        
        let person2TotalBtechMarks:Float = 5500
        
        let person2PercentageBtech:Float = (Float(person2TotalBtechGainedResults)/person2TotalBtechMarks)*100
        
        print("B-Tech Percentage = \(person2PercentageBtech)")
        
        if (laxman.calFirstYearBtechResults().firstYearBtechResults == true && laxman.cal2ndYear1stSemBtechResults().secondYear1stSemResults == true && laxman.cal2ndYear2ndSemBtechResults().secondYear2ndSemResults == true && laxman.cal3rdYear1stSemBtechResults().thirdYear1stSemResults == true && laxman.cal3rdYear2ndSemBtechResults().thirdYear2ndSemResults == true && laxman.cal4thYear1stSemBtechResults().fourthYear1stSemResults == true && laxman.cal4thYear2ndSemBtechResults().fourthYear2ndSemResults == true)
        {
            switch person2PercentageBtech
            {
            case 90...100:
                print("Grade A")
            case 75..<90:
                print("Grade B")
            case 50..<75:
                print("Grade C")
            case 35..<50:
                print("Grade D")
            default:
                print("Grade E")
            }
            print("B-Tech Passed")
        }
        else
        {
            print("B-Tech Failed")
        }
    
        // Person - 3
        
        print("********** Person - 3 **********")
        
        
        let bharat:BtechCalculations = BtechCalculations()
        
        // 1st year B-Tech results
        
        print("********** B-Tech 1st Year **********")
        
        bharat.communicativeEngMarks = 80
        bharat.enggPhysicsMarks = 79
        bharat.enggChemistryMarks = 78
        bharat.enggGraphicsMarks = 77
        bharat.proCAndDatastructureMarks = 76
        bharat.enggPhyAndEnggCheLabMarks = 75
        bharat.enggAndITWorkShopMarks = 74
        bharat.enggLangComSkillLabMarks = 72
        bharat.mathematics2Marks = 73
        bharat.mathematics1Marks = 71
        
        bharat.calFirstYearBtechResults()
        
        // 2nd year 1st sem B-Tech results
        
        print("********** B-Tech 2nd Year 1st Sem **********")
        
        bharat.mathematics3Marks = 58
        bharat.environmentalSciMarks = 61
        bharat.basicFMHMMarks = 67
        bharat.elecDevCirsMarks = 74
        bharat.elecMachines1Marks = 78
        bharat.elecCircuitsMarks = 58
        bharat.basicFMHMLabMarks = 70
        bharat.electronicDevCirsLabMarks = 72
        
        bharat.cal2ndYear1stSemBtechResults()
        
        // 2nd year 2nd sem B-Tech results
        
        print("********** B-Tech 2nd Year 2nd Sem **********")
        
        bharat.EMFMarks = 85
        bharat.GEPMarks = 84
        bharat.AECMarks = 82
        bharat.STLDMarks = 84
        bharat.NTMarks = 74
        bharat.EM2Marks = 78
        bharat.EM1LabMarks = 70
        bharat.ECSLabMarks = 72
        
        bharat.cal2ndYear2ndSemBtechResults()
        
        // 3rd year 1st sem B-Tech results
        
        print("********** B-Tech 3rd Year 1st Sem **********")
        
        bharat.MEFAMarks = 84
        bharat.EEMMarks = 82
        bharat.TEPMarks = 81
        bharat.CSMarks = 88
        bharat.PEMarks = 86
        bharat.EM3Marks = 87
        bharat.EMLab2Marks = 71
        bharat.CSSimLabMarks = 70
        
        bharat.cal3rdYear1stSemBtechResults()
        
        // 3rd year 2nd sem B-Tech results
        
        print("********** B-Tech 3rd Year 2nd Sem **********")
        
        bharat.MSMarks = 78
        bharat.PSDMarks = 75
        bharat.PSAMarks = 74
        bharat.MPMCMarks = 71
        bharat.PSOCMarks = 73
        bharat.LDICAMarks = 70
        bharat.AECSLLabMarks = 73
        bharat.EMLabMarks = 71
        
        bharat.cal3rdYear2ndSemBtechResults()
        
        // 4th year 1st sem B-Tech results
        
        print("********** B-Tech 4th Year 1st Sem **********")
        
        bharat.DEPMarks = 83
        bharat.DSPMarks = 81
        bharat.fundamentalsOfHVDCFactsDevicesMarks = 81
        bharat.SGPMarks = 83
        bharat.InstrumentationMarks = 86
        bharat.OTMarks = 84
        bharat.MPMCLabMarks = 74
        bharat.PESimLabMarks = 75
        
        bharat.cal4thYear1stSemBtechResults()
        
        // 4th year 2nd sem B-Tech results
        
        print("********** B-Tech 4th Year 2nd Sem **********")
        
        bharat.PPQMarks = 86
        bharat.UEEMarks = 95
        bharat.MCTMarks = 75
        bharat.EADSMMarks = 78
        bharat.seminarMarks = 48
        bharat.ProjectWorkMarks = 197
        
        bharat.cal4thYear2ndSemBtechResults()
        
        // 2nd Year B-Tech Results
        
        print("********** B-Tech 2nd Year Results **********")
        
        let person3Total2ndYearBtechGainedMarks:UInt16 = bharat.cal2ndYear1stSemBtechResults().secondYear1stSemGainedMarks + bharat.cal2ndYear2ndSemBtechResults().secondYear2ndSemGainedMarks
        
        print("Total 2nd Year B-Tech Marks = \(person3Total2ndYearBtechGainedMarks)")
        
        let person3Total2ndYearBtechMarks:Float = 1500
        
        let person3percentage2ndYearBtech:Float = (Float(person3Total2ndYearBtechGainedMarks)/person3Total2ndYearBtechMarks)*100
        
        print("Percentage 2nd Year B-Tech = \(person3percentage2ndYearBtech)")
        
        if bharat.cal2ndYear1stSemBtechResults().secondYear1stSemResults == true && bharat.cal2ndYear2ndSemBtechResults().secondYear2ndSemResults == true
        {
            switch person3percentage2ndYearBtech
            {
            case 90...100:
                print("Grade A")
            case 75..<90:
                print("Grade B")
            case 50..<75:
                print("Grade C")
            case 35..<50:
                print("Grade D")
            default:
                print("Grade E")
            }
            print("2nd Year B-Tech Passed")
        }
        else
        {
            print("2nd Year B-Tech Failed")
        }
        
        // 3rd Year B-Tech Results
        
        print("********** B-Tech 3rd Year Results **********")
        
        let person3Total3rdYearBtechGainedMarks:UInt16 = bharat.cal3rdYear1stSemBtechResults().thirdYear1stSemGainedMarks +  bharat.cal2ndYear2ndSemBtechResults().secondYear2ndSemGainedMarks
        
        print("Total 3rd Year B-Tech Marks = \(person3Total3rdYearBtechGainedMarks)")
        
        let person3Total3rdYearBtechMarks:Float = 1500
        
        let person3percentage3rdYearBtech:Float = (Float(person3Total3rdYearBtechGainedMarks)/person3Total3rdYearBtechMarks)*100
        
        print("Percentage 3rd Year B-Tech = \(person3percentage3rdYearBtech)")
        
        if bharat.cal3rdYear1stSemBtechResults().thirdYear1stSemResults == true && bharat.cal3rdYear2ndSemBtechResults().thirdYear2ndSemResults == true
        {
            switch person3percentage3rdYearBtech
            {
            case 90...100:
                print("Grade A")
            case 75..<90:
                print("Grade B")
            case 50..<75:
                print("Grade C")
            case 35..<50:
                print("Grade D")
            default:
                print("Grade E")
            }
            print("3rd Year B-Tech Passed")
        }
        else
        {
            print("3rd Year B-Tech Failed")
        }
        
        // 4th Year B-Tech Results
        
        print("********** B-Tech 4th Year Results **********")
        
        let person3Total4thYearBtechgainedMarks:UInt16 = bharat.cal4thYear1stSemBtechResults().fourthYear1stSemGainedMarks + bharat.cal4thYear2ndSemBtechResults().fourthYear2ndSemGainedMarks
        
        
        print("Total 4th Year B-Tech Marks = \(person3Total4thYearBtechgainedMarks)")
        
        let person3Total4thYearBtechMarks:Float = 1500
        
        let person3Percentage4thYearBtech:Float = (Float(person3Total4thYearBtechgainedMarks)/person3Total4thYearBtechMarks)*100
        
        print("Percentage 4th Year B-Tech = \(person3Total4thYearBtechgainedMarks)")
        
        if bharat.cal4thYear1stSemBtechResults().fourthYear1stSemResults == true && bharat.cal4thYear2ndSemBtechResults().fourthYear2ndSemResults == true
        {
            switch person3Percentage4thYearBtech
            {
            case 90...100:
                print("Grade A")
            case 75..<90:
                print("Grade B")
            case 50..<75:
                print("Grade C")
            case 35..<50:
                print("Grade D")
            default:
                print("Grade E")
            }
            print("4th Year B-Tech Passed")
        }
        else
        {
            print("4th Year B-Tech Failed")
        }
        
        //Overall B-Tech results
        
        let person3TotalBtechGainedResults = bharat.calFirstYearBtechResults().gained1stYearBtechMarks + bharat.cal2ndYear1stSemBtechResults().secondYear1stSemGainedMarks + bharat.cal2ndYear2ndSemBtechResults().secondYear2ndSemGainedMarks + bharat.cal3rdYear1stSemBtechResults().thirdYear1stSemGainedMarks + bharat.cal3rdYear2ndSemBtechResults().thirdYear2ndSemGainedMarks + bharat.cal4thYear1stSemBtechResults().fourthYear1stSemGainedMarks + bharat.cal4thYear2ndSemBtechResults().fourthYear2ndSemGainedMarks
        
        print("Total B-Tech Marks = \(person3TotalBtechGainedResults)")
        
        let person3TotalBtechMarks:Float = 5500
        
        let person3PercentageBtech:Float = (Float(person3TotalBtechGainedResults)/person3TotalBtechMarks)*100
        
        print("B-Tech Percentage = \(person3PercentageBtech)")
        
        if (bharat.calFirstYearBtechResults().firstYearBtechResults == true && bharat.cal2ndYear1stSemBtechResults().secondYear1stSemResults == true && bharat.cal2ndYear2ndSemBtechResults().secondYear2ndSemResults == true && bharat.cal3rdYear1stSemBtechResults().thirdYear1stSemResults == true && bharat.cal3rdYear2ndSemBtechResults().thirdYear2ndSemResults == true && bharat.cal4thYear1stSemBtechResults().fourthYear1stSemResults == true && bharat.cal4thYear2ndSemBtechResults().fourthYear2ndSemResults == true)
        {
            switch person3PercentageBtech
            {
            case 90...100:
                print("Grade A")
            case 75..<90:
                print("Grade B")
            case 50..<75:
                print("Grade C")
            case 35..<50:
                print("Grade D")
            default:
                print("Grade E")
            }
            print("B-Tech Passed")
        }
        else
        {
            print("B-Tech Failed")
        }
        
        // Person - 4
        
        print("********** Person - 4 **********")
        
        
        let satrugn:BtechCalculations = BtechCalculations()
        
        // 1st year B-Tech results
        
        print("********** B-Tech 1st Year **********")
        
        satrugn.communicativeEngMarks = 74
        satrugn.enggPhysicsMarks = 79
        satrugn.enggChemistryMarks = 72
        satrugn.enggGraphicsMarks = 77
        satrugn.proCAndDatastructureMarks = 76
        satrugn.enggPhyAndEnggCheLabMarks = 75
        satrugn.enggAndITWorkShopMarks = 74
        satrugn.enggLangComSkillLabMarks = 72
        satrugn.mathematics2Marks = 73
        satrugn.mathematics1Marks = 71
        
        satrugn.calFirstYearBtechResults()
        
        // 2nd year 1st sem B-Tech results
        
        print("********** B-Tech 2nd Year 1st Sem **********")
        
        satrugn.mathematics3Marks = 58
        satrugn.environmentalSciMarks = 61
        satrugn.basicFMHMMarks = 67
        satrugn.elecDevCirsMarks = 74
        satrugn.elecMachines1Marks = 78
        satrugn.elecCircuitsMarks = 48
        satrugn.basicFMHMLabMarks = 70
        satrugn.electronicDevCirsLabMarks = 72
        
        satrugn.cal2ndYear1stSemBtechResults()
        
        // 2nd year 2nd sem B-Tech results
        
        print("********** B-Tech 2nd Year 2nd Sem **********")
        
        satrugn.EMFMarks = 85
        satrugn.GEPMarks = 84
        satrugn.AECMarks = 82
        satrugn.STLDMarks = 71
        satrugn.NTMarks = 74
        satrugn.EM2Marks = 78
        satrugn.EM1LabMarks = 70
        satrugn.ECSLabMarks = 72
        
        satrugn.cal2ndYear2ndSemBtechResults()
        
        // 3rd year 1st sem B-Tech results
        
        print("********** B-Tech 3rd Year 1st Sem **********")
        
        satrugn.MEFAMarks = 84
        satrugn.EEMMarks = 82
        satrugn.TEPMarks = 52
        satrugn.CSMarks = 88
        satrugn.PEMarks = 49
        satrugn.EM3Marks = 87
        satrugn.EMLab2Marks = 71
        satrugn.CSSimLabMarks = 70
        
        satrugn.cal3rdYear1stSemBtechResults()
        
        // 3rd year 2nd sem B-Tech results
        
        print("********** B-Tech 3rd Year 2nd Sem **********")
        
        satrugn.MSMarks = 78
        satrugn.PSDMarks = 75
        satrugn.PSAMarks = 74
        satrugn.MPMCMarks = 89
        satrugn.PSOCMarks = 73
        satrugn.LDICAMarks = 70
        satrugn.AECSLLabMarks = 73
        satrugn.EMLabMarks = 71
        
        satrugn.cal3rdYear2ndSemBtechResults()
        
        // 4th year 1st sem B-Tech results
        
        print("********** B-Tech 4th Year 1st Sem **********")
        
        satrugn.DEPMarks = 83
        satrugn.DSPMarks = 81
        satrugn.fundamentalsOfHVDCFactsDevicesMarks = 81
        satrugn.SGPMarks = 83
        satrugn.InstrumentationMarks = 86
        satrugn.OTMarks = 84
        satrugn.MPMCLabMarks = 56
        satrugn.PESimLabMarks = 75
        
        satrugn.cal4thYear1stSemBtechResults()
        
        // 4th year 2nd sem B-Tech results
        
        print("********** B-Tech 4th Year 2nd Sem **********")
        
        satrugn.PPQMarks = 86
        satrugn.UEEMarks = 95
        satrugn.MCTMarks = 48
        satrugn.EADSMMarks = 78
        satrugn.seminarMarks = 48
        satrugn.ProjectWorkMarks = 217
        
        satrugn.cal4thYear2ndSemBtechResults()
        
        // 2nd Year B-Tech Results
        
        print("********** B-Tech 2nd Year Results **********")
        
        let person4Total2ndYearBtechGainedMarks:UInt16 = satrugn.cal2ndYear1stSemBtechResults().secondYear1stSemGainedMarks + satrugn.cal2ndYear2ndSemBtechResults().secondYear2ndSemGainedMarks
        
        print("Total 2nd Year B-Tech Marks = \(person4Total2ndYearBtechGainedMarks)")
        
        let person4Total2ndYearBtechMarks:Float = 1500
        
        let person4percentage2ndYearBtech:Float = (Float(person4Total2ndYearBtechGainedMarks)/person4Total2ndYearBtechMarks)*100
        
        print("Percentage 2nd Year B-Tech = \(person4percentage2ndYearBtech)")
        
        if satrugn.cal2ndYear1stSemBtechResults().secondYear1stSemResults == true && satrugn.cal2ndYear2ndSemBtechResults().secondYear2ndSemResults == true
        {
            switch person4percentage2ndYearBtech
            {
            case 90...100:
                print("Grade A")
            case 75..<90:
                print("Grade B")
            case 50..<75:
                print("Grade C")
            case 35..<50:
                print("Grade D")
            default:
                print("Grade E")
            }
            print("2nd Year B-Tech Passed")
        }
        else
        {
            print("2nd Year B-Tech Failed")
        }
        
        // 3rd Year B-Tech Results
        
        print("********** B-Tech 3rd Year Results **********")
        
        let person4Total3rdYearBtechGainedMarks:UInt16 = satrugn.cal3rdYear1stSemBtechResults().thirdYear1stSemGainedMarks +  satrugn.cal2ndYear2ndSemBtechResults().secondYear2ndSemGainedMarks
        
        print("Total 3rd Year B-Tech Marks = \(person4Total3rdYearBtechGainedMarks)")
        
        let person4Total3rdYearBtechMarks:Float = 1500
        
        let person4percentage3rdYearBtech:Float = (Float(person4Total3rdYearBtechGainedMarks)/person4Total3rdYearBtechMarks)*100
        
        print("Percentage 3rd Year B-Tech = \(person4percentage3rdYearBtech)")
        
        if satrugn.cal3rdYear1stSemBtechResults().thirdYear1stSemResults == true && satrugn.cal3rdYear2ndSemBtechResults().thirdYear2ndSemResults == true
        {
            switch person4percentage3rdYearBtech
            {
            case 90...100:
                print("Grade A")
            case 75..<90:
                print("Grade B")
            case 50..<75:
                print("Grade C")
            case 35..<50:
                print("Grade D")
            default:
                print("Grade E")
            }
            print("3rd Year B-Tech Passed")
        }
        else
        {
            print("3rd Year B-Tech Failed")
        }
        
        // 4th Year B-Tech Results
        
        print("********** B-Tech 4th Year Results **********")
        
        let person4Total4thYearBtechgainedMarks:UInt16 = satrugn.cal4thYear1stSemBtechResults().fourthYear1stSemGainedMarks + satrugn.cal4thYear2ndSemBtechResults().fourthYear2ndSemGainedMarks
        
        
        print("Total 4th Year B-Tech Marks = \(person4Total4thYearBtechgainedMarks)")
        
        let person4Total4thYearBtechMarks:Float = 1500
        
        let person4Percentage4thYearBtech:Float = (Float(person4Total4thYearBtechgainedMarks)/person4Total4thYearBtechMarks)*100
        
        print("Percentage 4th Year B-Tech = \(person4Total4thYearBtechgainedMarks)")
        
        if satrugn.cal4thYear1stSemBtechResults().fourthYear1stSemResults == true && satrugn.cal4thYear2ndSemBtechResults().fourthYear2ndSemResults == true
        {
            switch person4Percentage4thYearBtech
            {
            case 90...100:
                print("Grade A")
            case 75..<90:
                print("Grade B")
            case 50..<75:
                print("Grade C")
            case 35..<50:
                print("Grade D")
            default:
                print("Grade E")
            }
            print("4th Year B-Tech Passed")
        }
        else
        {
            print("4th Year B-Tech Failed")
        }
        
        //Overall B-Tech results
        
        let person4TotalBtechGainedResults = satrugn.calFirstYearBtechResults().gained1stYearBtechMarks + satrugn.cal2ndYear1stSemBtechResults().secondYear1stSemGainedMarks + satrugn.cal2ndYear2ndSemBtechResults().secondYear2ndSemGainedMarks + satrugn.cal3rdYear1stSemBtechResults().thirdYear1stSemGainedMarks + satrugn.cal3rdYear2ndSemBtechResults().thirdYear2ndSemGainedMarks + satrugn.cal4thYear1stSemBtechResults().fourthYear1stSemGainedMarks + satrugn.cal4thYear2ndSemBtechResults().fourthYear2ndSemGainedMarks
        
        print("Total B-Tech Marks = \(person4TotalBtechGainedResults)")
        
        let person4TotalBtechMarks:Float = 5500
        
        let person4PercentageBtech:Float = (Float(person4TotalBtechGainedResults)/person4TotalBtechMarks)*100
        
        print("B-Tech Percentage = \(person4PercentageBtech)")
        
        if (satrugn.calFirstYearBtechResults().firstYearBtechResults == true && satrugn.cal2ndYear1stSemBtechResults().secondYear1stSemResults == true && satrugn.cal2ndYear2ndSemBtechResults().secondYear2ndSemResults == true && satrugn.cal3rdYear1stSemBtechResults().thirdYear1stSemResults == true && satrugn.cal3rdYear2ndSemBtechResults().thirdYear2ndSemResults == true && satrugn.cal4thYear1stSemBtechResults().fourthYear1stSemResults == true && satrugn.cal4thYear2ndSemBtechResults().fourthYear2ndSemResults == true)
        {
            switch person4PercentageBtech
            {
            case 90...100:
                print("Grade A")
            case 75..<90:
                print("Grade B")
            case 50..<75:
                print("Grade C")
            case 35..<50:
                print("Grade D")
            default:
                print("Grade E")
            }
            print("B-Tech Passed")
        }
        else
        {
            print("B-Tech Failed")
        }
        
        
        // Person - 5
        
        print("********** Person - 5 **********")
        
        
        let dasaratha:BtechCalculations = BtechCalculations()
        
        // 1st year B-Tech results
        
        print("********** B-Tech 1st Year **********")
        
        dasaratha.communicativeEngMarks = 58
        dasaratha.enggPhysicsMarks = 79
        dasaratha.enggChemistryMarks = 78
        dasaratha.enggGraphicsMarks = 77
        dasaratha.proCAndDatastructureMarks = 76
        dasaratha.enggPhyAndEnggCheLabMarks = 75
        dasaratha.enggAndITWorkShopMarks = 74
        dasaratha.enggLangComSkillLabMarks = 72
        dasaratha.mathematics2Marks = 73
        dasaratha.mathematics1Marks = 71
        
        dasaratha.calFirstYearBtechResults()
        
        // 2nd year 1st sem B-Tech results
        
        print("********** B-Tech 2nd Year 1st Sem **********")
        
        dasaratha.mathematics3Marks = 71
        dasaratha.environmentalSciMarks = 61
        dasaratha.basicFMHMMarks = 67
        dasaratha.elecDevCirsMarks = 74
        dasaratha.elecMachines1Marks = 78
        dasaratha.elecCircuitsMarks = 58
        dasaratha.basicFMHMLabMarks = 70
        dasaratha.electronicDevCirsLabMarks = 72
        
        dasaratha.cal2ndYear1stSemBtechResults()
        
        // 2nd year 2nd sem B-Tech results
        
        print("********** B-Tech 2nd Year 2nd Sem **********")
        
        dasaratha.EMFMarks = 85
        dasaratha.GEPMarks = 84
        dasaratha.AECMarks = 58
        dasaratha.STLDMarks = 84
        dasaratha.NTMarks = 74
        dasaratha.EM2Marks = 78
        dasaratha.EM1LabMarks = 70
        dasaratha.ECSLabMarks = 72
        
        dasaratha.cal2ndYear2ndSemBtechResults()
        
        // 3rd year 1st sem B-Tech results
        
        print("********** B-Tech 3rd Year 1st Sem **********")
        
        dasaratha.MEFAMarks = 84
        dasaratha.EEMMarks = 65
        dasaratha.TEPMarks = 81
        dasaratha.CSMarks = 88
        dasaratha.PEMarks = 86
        dasaratha.EM3Marks = 87
        dasaratha.EMLab2Marks = 71
        dasaratha.CSSimLabMarks = 70
        
        dasaratha.cal3rdYear1stSemBtechResults()
        
        // 3rd year 2nd sem B-Tech results
        
        print("********** B-Tech 3rd Year 2nd Sem **********")
        
        dasaratha.MSMarks = 78
        dasaratha.PSDMarks = 75
        dasaratha.PSAMarks = 74
        dasaratha.MPMCMarks = 75
        dasaratha.PSOCMarks = 73
        dasaratha.LDICAMarks = 70
        dasaratha.AECSLLabMarks = 73
        dasaratha.EMLabMarks = 71
        
        dasaratha.cal3rdYear2ndSemBtechResults()
        
        // 4th year 1st sem B-Tech results
        
        print("********** B-Tech 4th Year 1st Sem **********")
        
        dasaratha.DEPMarks = 83
        dasaratha.DSPMarks = 81
        dasaratha.fundamentalsOfHVDCFactsDevicesMarks = 81
        dasaratha.SGPMarks = 48
        dasaratha.InstrumentationMarks = 86
        dasaratha.OTMarks = 84
        dasaratha.MPMCLabMarks = 74
        dasaratha.PESimLabMarks = 75
        
        dasaratha.cal4thYear1stSemBtechResults()
        
        // 4th year 2nd sem B-Tech results
        
        print("********** B-Tech 4th Year 2nd Sem **********")
        
        dasaratha.PPQMarks = 95
        dasaratha.UEEMarks = 95
        dasaratha.MCTMarks = 48
        dasaratha.EADSMMarks = 78
        dasaratha.seminarMarks = 48
        dasaratha.ProjectWorkMarks = 287
        
        dasaratha.cal4thYear2ndSemBtechResults()
        
        // 2nd Year B-Tech Results
        
        print("********** B-Tech 2nd Year Results **********")
        
        let person5Total2ndYearBtechGainedMarks:UInt16 = dasaratha.cal2ndYear1stSemBtechResults().secondYear1stSemGainedMarks + dasaratha.cal2ndYear2ndSemBtechResults().secondYear2ndSemGainedMarks
        
        print("Total 2nd Year B-Tech Marks = \(person5Total2ndYearBtechGainedMarks)")
        
        let person5Total2ndYearBtechMarks:Float = 1500
        
        let person5percentage2ndYearBtech:Float = (Float(person5Total2ndYearBtechGainedMarks)/person5Total2ndYearBtechMarks)*100
        
        print("Percentage 2nd Year B-Tech = \(person5percentage2ndYearBtech)")
        
        if dasaratha.cal2ndYear1stSemBtechResults().secondYear1stSemResults == true && dasaratha.cal2ndYear2ndSemBtechResults().secondYear2ndSemResults == true
        {
            switch person5percentage2ndYearBtech
            {
            case 90...100:
                print("Grade A")
            case 75..<90:
                print("Grade B")
            case 50..<75:
                print("Grade C")
            case 35..<50:
                print("Grade D")
            default:
                print("Grade E")
            }
            print("2nd Year B-Tech Passed")
        }
        else
        {
            print("2nd Year B-Tech Failed")
        }
        
        // 3rd Year B-Tech Results
        
        print("********** B-Tech 3rd Year Results **********")
        
        let person5Total3rdYearBtechGainedMarks:UInt16 = dasaratha.cal3rdYear1stSemBtechResults().thirdYear1stSemGainedMarks +  dasaratha.cal2ndYear2ndSemBtechResults().secondYear2ndSemGainedMarks
        
        print("Total 3rd Year B-Tech Marks = \(person5Total3rdYearBtechGainedMarks)")
        
        let person5Total3rdYearBtechMarks:Float = 1500
        
        let person5percentage3rdYearBtech:Float = (Float(person5Total3rdYearBtechGainedMarks)/person5Total3rdYearBtechMarks)*100
        
        print("Percentage 3rd Year B-Tech = \(person5percentage3rdYearBtech)")
        
        if dasaratha.cal3rdYear1stSemBtechResults().thirdYear1stSemResults == true && dasaratha.cal3rdYear2ndSemBtechResults().thirdYear2ndSemResults == true
        {
            switch person5percentage3rdYearBtech
            {
            case 90...100:
                print("Grade A")
            case 75..<90:
                print("Grade B")
            case 50..<75:
                print("Grade C")
            case 35..<50:
                print("Grade D")
            default:
                print("Grade E")
            }
            print("3rd Year B-Tech Passed")
        }
        else
        {
            print("3rd Year B-Tech Failed")
        }
        
        // 4th Year B-Tech Results
        
        print("********** B-Tech 4th Year Results **********")
        
        let person5Total4thYearBtechgainedMarks:UInt16 = dasaratha.cal4thYear1stSemBtechResults().fourthYear1stSemGainedMarks + dasaratha.cal4thYear2ndSemBtechResults().fourthYear2ndSemGainedMarks
        
        
        print("Total 4th Year B-Tech Marks = \(person5Total4thYearBtechgainedMarks)")
        
        let person5Total4thYearBtechMarks:Float = 1500
        
        let person5Percentage4thYearBtech:Float = (Float(person5Total4thYearBtechMarks)/person5Total4thYearBtechMarks)*100
        
        print("Percentage 4th Year B-Tech = \(person5Total4thYearBtechgainedMarks)")
        
        if dasaratha.cal4thYear1stSemBtechResults().fourthYear1stSemResults == true && dasaratha.cal4thYear2ndSemBtechResults().fourthYear2ndSemResults == true
        {
            switch person5Percentage4thYearBtech
            {
            case 90...100:
                print("Grade A")
            case 75..<90:
                print("Grade B")
            case 50..<75:
                print("Grade C")
            case 35..<50:
                print("Grade D")
            default:
                print("Grade E")
            }
            print("4th Year B-Tech Passed")
        }
        else
        {
              print("4th Year B-Tech Failed")
            }
    
    //Overall B-Tech results
    
    let person5TotalBtechGainedResults = dasaratha.calFirstYearBtechResults().gained1stYearBtechMarks + dasaratha.cal2ndYear1stSemBtechResults().secondYear1stSemGainedMarks + dasaratha.cal2ndYear2ndSemBtechResults().secondYear2ndSemGainedMarks + dasaratha.cal3rdYear1stSemBtechResults().thirdYear1stSemGainedMarks + dasaratha.cal3rdYear2ndSemBtechResults().thirdYear2ndSemGainedMarks + dasaratha.cal4thYear1stSemBtechResults().fourthYear1stSemGainedMarks + dasaratha.cal4thYear2ndSemBtechResults().fourthYear2ndSemGainedMarks
        
        print("Total B-Tech Marks = \(person5TotalBtechGainedResults)")
    
        let person5TotalBtechMarks:Float = 5500
        
        let person5PercentageBtech:Float = (Float(person5TotalBtechGainedResults)/person5TotalBtechMarks)*100
        
        print("B-Tech Percentage = \(person5PercentageBtech)")
        
        if (dasaratha.calFirstYearBtechResults().firstYearBtechResults == true && dasaratha.cal2ndYear1stSemBtechResults().secondYear1stSemResults == true && dasaratha.cal2ndYear2ndSemBtechResults().secondYear2ndSemResults == true && dasaratha.cal3rdYear1stSemBtechResults().thirdYear1stSemResults == true && dasaratha.cal3rdYear2ndSemBtechResults().thirdYear2ndSemResults == true && dasaratha.cal4thYear1stSemBtechResults().fourthYear1stSemResults == true && dasaratha.cal4thYear2ndSemBtechResults().fourthYear2ndSemResults == true)
        {
            switch person5PercentageBtech
            {
            case 90...100:
                print("Grade A")
            case 75..<90:
                print("Grade B")
            case 50..<75:
                print("Grade C")
            case 35..<50:
                print("Grade D")
            default:
                print("Grade E")
            }
            print("B-Tech Passed")
        }
        else
        {
           print("B-Tech Failed")
        }
    }
    
        // Do any additional setup after loading the view, typically from a nib.
    }

