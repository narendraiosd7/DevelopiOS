//
//  ViewController.swift
//  classwitoutinit
//
//  Created by Vadde Narendra on 05/08/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Person - 1
        
        print("********** Person - 1 **********")
        
        let narendra:TenthMarks = TenthMarks(telMarks: 90, engMarks: 89, hindiMarks: 88, mathsMarks: 87, sciMarks: 86, socMarks: 85)
        narendra.calTenthMarks()
        
        // Person - 2
        
        print("********** Person - 2 **********")
        
        let veerendra:TenthMarks = TenthMarks(telMarks: 89, engMarks: 88, hindiMarks: 87, mathsMarks: 87, sciMarks: 86, socMarks: 85)
        veerendra.calTenthMarks()
        
        // Person - 3
        
        print("********** Person - 3 **********")
        
        let indra:TenthMarks = TenthMarks(telMarks: 90, engMarks: 89, hindiMarks: 88, mathsMarks: 87, sciMarks: 65, socMarks: 48)
        indra.calTenthMarks()
        
        // Person - 4
        
        print("********** Person - 4 **********")
        
        let raghu:TenthMarks = TenthMarks(telMarks: 65, engMarks: 55, hindiMarks: 45, mathsMarks: 35, sciMarks: 86, socMarks: 85)
        raghu.calTenthMarks()
        
        // Person - 5
        
        print("********** Person - 5 **********")
        
        let ravi:TenthMarks = TenthMarks(telMarks: 28, engMarks: 38, hindiMarks: 48, mathsMarks: 58, sciMarks: 84, socMarks: 78)
        ravi.calTenthMarks()
        
        // Person - 6
        
        print("********** Person - 6 **********")
        
        let ragav:TenthMarks = TenthMarks(telMarks: 35, engMarks: 45, hindiMarks: 46, mathsMarks: 57, sciMarks: 60, socMarks: 57)
        ragav.calTenthMarks()
        
        // Person - 7
        
        print("********** Person - 7 **********")
        
        let raja:TenthMarks = TenthMarks(telMarks: 75, engMarks: 65, hindiMarks: 68, mathsMarks: 71, sciMarks: 79, socMarks: 48)
        raja.calTenthMarks()
        
        // Person - 8
        
        print("********** Person - 8 **********")
        
        let ram:TenthMarks = TenthMarks(telMarks: 59, engMarks: 58, hindiMarks: 45, mathsMarks: 95, sciMarks: 48, socMarks: 59)
        ram.calTenthMarks()
        
        // Person - 9
        
        print("********** Person - 9 **********")
        
        let iswar:TenthMarks = TenthMarks(telMarks: 58, engMarks: 97, hindiMarks: 68, mathsMarks: 81, sciMarks: 81, socMarks: 68)
        iswar.calTenthMarks()
        
        // Person - 10
        
        print("********** Person - 10 **********")
        
        let nandu:TenthMarks = TenthMarks(telMarks: 59, engMarks: 57, hindiMarks: 68, mathsMarks: 61, sciMarks: 59, socMarks: 47)
        nandu.calTenthMarks()
        
    }
    // Do any additional setup after loading the view, typically from a nib.
}

// Creating class

class TenthMarks{
    var telMarks:UInt8
    var engMarks:UInt8
    var hindiMarks:UInt8
    var mathsMarks:UInt8
    var sciMarks:UInt8
    var socMarks:UInt8
    
    init(telMarks:UInt8,engMarks:UInt8,hindiMarks:UInt8,mathsMarks:UInt8,sciMarks:UInt8,socMarks:UInt8) {
        self.telMarks = telMarks
        self.engMarks = engMarks
        self.hindiMarks = hindiMarks
        self.mathsMarks = mathsMarks
        self.sciMarks = sciMarks
        self.socMarks = socMarks
    }
    
    // Creating function
    
    func calTenthMarks(){
        
        // Considering pass marks & total marks
        
        let passMarks:UInt8 = 35
        let totalMarks:Float = 600
        
        // calculatng total marks & printing
        
        let gainedMarks:UInt16 = UInt16(telMarks)+UInt16(engMarks)+UInt16(hindiMarks)+UInt16(mathsMarks)+UInt16(sciMarks)+UInt16(socMarks)
        
        print("Total Marks = \(gainedMarks)")
        
        // calculating percentage & printing
        
        let percentage:Float = (Float(gainedMarks)/totalMarks)*100
        
        print("Percentage = \(percentage)")
        
        // calculating grade with pass or fail overall tenth
        
        if (telMarks >= passMarks && engMarks >= passMarks && hindiMarks >= passMarks && mathsMarks >= passMarks && sciMarks >= passMarks && socMarks >= passMarks)
        {
            switch percentage
            {
            case 90...100:
                print("Grade A")
            case 75..<90:
                print("Grade B")
            case 50..<75:
                print("Grade C")
            case 35..<50:
                print("Grade D")
            default:
                print("Grade E")
            }
            print("Tenth Passed")
        }
        else
        {
            print("Tenth Failed")
        }
        
    }
}


