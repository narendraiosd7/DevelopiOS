//
//  ViewController.swift
//  CreateClassroomSetupUsingSwitches
//
//  Created by Vadde Narendra on 9/16/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

//  Creating drag and drop switches and lable
    @IBOutlet weak var mainPowerBoardSwitch: UISwitch!
    
    @IBOutlet weak var fluorescentLamp1Switch: UISwitch!
    
    @IBOutlet weak var fluorescentLamp2Switch: UISwitch!
    
    @IBOutlet weak var ceilingFan1Switch: UISwitch!
    
    @IBOutlet weak var ceilingFan2Switch: UISwitch!
    
    @IBOutlet weak var airConditionerSwitch: UISwitch!
    
    @IBOutlet weak var projectorSwitch: UISwitch!
    
    @IBOutlet weak var cameraSwitch: UISwitch!
    
    @IBOutlet weak var speakerSwitch: UISwitch!
    
    @IBOutlet weak var switchConditionLbl: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        mainPowerBoardSwitch.addTarget(self, action: #selector(onSwitchChanging), for: .valueChanged)
        
        fluorescentLamp1Switch.addTarget(self, action: #selector(onSwitchChaningLamps), for: UIControl.Event.valueChanged)
    
        projectorSwitch.addTarget(self, action: #selector(onSwitchChangingOfProjector), for: UIControl.Event.valueChanged)
        
        ceilingFan1Switch.addTarget(self, action: #selector(onSwitchChangingFans), for: UIControl.Event.valueChanged)
        
        airConditionerSwitch.addTarget(self, action: #selector(onSwitchChangingAC), for: UIControl.Event.valueChanged)
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
//    Creating Function to Main switch conditions
    
    @objc func onSwitchChanging(){
        
        if (mainPowerBoardSwitch.isOn == false) {
            
            fluorescentLamp1Switch.setOn(false, animated: true)
            fluorescentLamp1Switch.isEnabled = false
            
            fluorescentLamp2Switch.setOn(false, animated: true)
            fluorescentLamp2Switch.isEnabled = false
            
            ceilingFan1Switch.setOn(false, animated: true)
            ceilingFan1Switch.isEnabled = false
            
            ceilingFan2Switch.setOn(false, animated: true)
            ceilingFan2Switch.isEnabled = false
            
            projectorSwitch.setOn(false, animated: true)
            projectorSwitch.isEnabled = false
            
            airConditionerSwitch.setOn(false, animated: true)
            airConditionerSwitch.isEnabled = false
            
            cameraSwitch.setOn(false, animated: true)
            cameraSwitch.isEnabled = false
            
            speakerSwitch.setOn(false, animated: true)
            speakerSwitch.isEnabled = false
            
            switchConditionLbl.text = "Main Switch OFF so, every switch going to be OFF"
            switchConditionLbl.numberOfLines = 0
            
        } else {
            
            fluorescentLamp1Switch.setOn(false, animated: true)
            fluorescentLamp1Switch.isEnabled = true
            
            fluorescentLamp2Switch.setOn(false, animated: true)
            fluorescentLamp2Switch.isEnabled = true
            
            ceilingFan1Switch.setOn(false, animated: true)
            ceilingFan1Switch.isEnabled = true
            
            ceilingFan2Switch.setOn(false, animated: true)
            ceilingFan2Switch.isEnabled = true
            
            projectorSwitch.setOn(false, animated: true)
            projectorSwitch.isEnabled = true
            
            airConditionerSwitch.setOn(false, animated: true)
            airConditionerSwitch.isEnabled = true
            
            cameraSwitch.setOn(true, animated: true)
            cameraSwitch.isEnabled = true
            
            speakerSwitch.setOn(false, animated: true)
            speakerSwitch.isEnabled = true

            
            switchConditionLbl.text = "Main Switch ON so, Camera going to be ON and remaining things are in OFF state"
            switchConditionLbl.numberOfLines = 0

        }
}
    
    //    Creating Function to Projector switch conditions
    
    @objc func onSwitchChangingOfProjector(){
        
        if (projectorSwitch.isOn == false){
            
            fluorescentLamp1Switch.setOn(true, animated: true)
            fluorescentLamp2Switch.setOn(true, animated: true)
            speakerSwitch.setOn(false, animated: true)
            
            switchConditionLbl.text = "Projector is Switched OFF so, Lamps are going to be Switched ON and Speaker going to Switch OFF"
            switchConditionLbl.numberOfLines = 0
            
        } else {
            
            fluorescentLamp1Switch.setOn(false, animated: true)
            fluorescentLamp2Switch.setOn(false, animated: true)
            speakerSwitch.setOn(true, animated: true)
            
            switchConditionLbl.text = "Projector is Switched ON so, Lamps are going to be Switched OFF and Speaker going to be Switch ON"
            switchConditionLbl.numberOfLines = 0
            
        }
    }
    
    
    //    Creating Function to Fluorescent Lamps switch conditions
        
       @objc func onSwitchChaningLamps(){
            
            if (fluorescentLamp1Switch.isOn == true || fluorescentLamp2Switch.isOn == true){
                
                projectorSwitch.setOn(false, animated: true)
                speakerSwitch.setOn(false, animated: true)
                
                switchConditionLbl.text = "Lamps are switched ON so, Projector and Speakers are going to be OFF"
                switchConditionLbl.numberOfLines = 0
                
            } else {
                
                projectorSwitch.setOn(true, animated: true)
                speakerSwitch.setOn(true, animated: true)
                
                switchConditionLbl.text = "Lamps are switched OFF so, Projector and Speakers are going to be ON"
                switchConditionLbl.numberOfLines = 0
                
            }
            
            
        }

    //    Creating Function to Ceiling Fans switch conditions
    
    @objc func onSwitchChangingFans(){
        
        if (ceilingFan1Switch.isOn == true || ceilingFan2Switch.isOn == true){
            
            airConditionerSwitch.setOn(false, animated: true)
            
            switchConditionLbl.text = "Ceiling Fans are switched ON so, Air Conditioner is going to be OFF"
            switchConditionLbl.numberOfLines = 0
            
        } else {
            
            airConditionerSwitch.setOn(true, animated: true)
            
            switchConditionLbl.text = "Ceiling Fans are switched OFF so, Air Conditioner is going to be ON"
            switchConditionLbl.numberOfLines = 0
            
        }
    }
    
    //    Creating Function to Air Conditioner switch conditions
    
    @objc func onSwitchChangingAC(){
        
        if (airConditionerSwitch.isOn == true){
            
            ceilingFan1Switch.setOn(false, animated: true)
            ceilingFan2Switch.setOn(false, animated: true)
            
            switchConditionLbl.text = "Air Conditioner is Switched ON so, Fans are going to be Switch OFF"
            switchConditionLbl.numberOfLines = 0
            
        } else {
            
            ceilingFan1Switch.setOn(true, animated: true)
            ceilingFan2Switch.setOn(true, animated: true)
            
            switchConditionLbl.text = "Air Conditioner is Switched OFF so, Fans are going to be Switch ON"
            switchConditionLbl.numberOfLines = 0
            
        }
        
    }

}
