//
//  BtechQualification.swift
//  Data Passing through Present
//
//  Created by Vadde Narendra on 11/17/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class BtechQualification: UIViewController
{
    
    @IBOutlet weak var englishTF: UITextField!
    @IBOutlet weak var enggPhysicsTF: UITextField!
    @IBOutlet weak var enggChemistryTF: UITextField!
    @IBOutlet weak var maths1TF: UITextField!
    @IBOutlet weak var cDataTF: UITextField!
    @IBOutlet weak var maths2TF: UITextField!
    @IBOutlet weak var ECTF: UITextField!
    @IBOutlet weak var maths3TF: UITextField!
    @IBOutlet weak var ESTF: UITextField!
    @IBOutlet weak var FMHMTF: UITextField!
    @IBOutlet weak var EDCTF: UITextField!
    @IBOutlet weak var EC2TF: UITextField!
    @IBOutlet weak var EM1TF: UITextField!
    @IBOutlet weak var EMFTF: UITextField!
    @IBOutlet weak var GEPTF: UITextField!
    @IBOutlet weak var AECTF: UITextField!
    @IBOutlet weak var STLDTF: UITextField!
    @IBOutlet weak var NTTF: UITextField!
    @IBOutlet weak var EM2TF: UITextField!
    @IBOutlet weak var MEFATF: UITextField!
    @IBOutlet weak var EEMTF: UITextField!
    @IBOutlet weak var TEPTF: UITextField!
    @IBOutlet weak var CSTF: UITextField!
    @IBOutlet weak var PETF: UITextField!
    @IBOutlet weak var EM3TF: UITextField!
    @IBOutlet weak var MSTF: UITextField!
    @IBOutlet weak var PSDTF: UITextField!
    @IBOutlet weak var PSATF: UITextField!
    @IBOutlet weak var MPMCTF: UITextField!
    @IBOutlet weak var PSOCTF: UITextField!
    @IBOutlet weak var LDICATF: UITextField!
    @IBOutlet weak var DEPTF: UITextField!
    @IBOutlet weak var DSPTF: UITextField!
    @IBOutlet weak var HVDCTF: UITextField!
    @IBOutlet weak var SGPTF: UITextField!
    @IBOutlet weak var instrumentationTF: UITextField!
    @IBOutlet weak var OTTF: UITextField!
    @IBOutlet weak var PPQTF: UITextField!
    @IBOutlet weak var UEETF: UITextField!
    @IBOutlet weak var MCTTF: UITextField!
    @IBOutlet weak var EADSMTF: UITextField!
    @IBOutlet weak var seminarTF: UITextField!
    @IBOutlet weak var projectWorkTF: UITextField!
    
    @IBOutlet weak var scrollView: UIScrollView!
    
    var personalDetailsArray:[String] = []
    var interMarksArray:[String] = []
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
    }
    
    @IBAction func semistersSCValueChanged(_ sender: UISegmentedControl)
    {
        switch sender.selectedSegmentIndex
        {
        case 0:
            scrollView.setContentOffset(CGPoint(x: 0, y: 0), animated: true)
        case 1:
            scrollView.setContentOffset(CGPoint(x: 0, y: 750), animated: true)
        case 2:
            scrollView.setContentOffset(CGPoint(x: 0, y: 1500), animated: true)
        case 3:
            scrollView.setContentOffset(CGPoint(x: 0, y: 2150), animated: true)
        case 4:
            scrollView.setContentOffset(CGPoint(x: 0, y: 2900), animated: true)
        case 5:
            scrollView.setContentOffset(CGPoint(x: 0, y: 3650), animated: true)
        case 6:
            scrollView.setContentOffset(CGPoint(x: 0, y: 4400), animated: true)
        default:
            print("ok")
        }
        
    }
    
    @IBAction func submitBtnTapped(_ sender: UIButton)
    {
        let resultView = storyboard?.instantiateViewController(withIdentifier: "resultDetails") as! ResultsDetails
        
        present(resultView, animated: true) {
            resultView.firstNameLbl.text = self.personalDetailsArray[0]
            resultView.lastNameLbl.text = self.personalDetailsArray[1]
            resultView.ageLbl.text = self.personalDetailsArray[2]
            resultView.qualificationLbl.text = self.personalDetailsArray[3]
        }
    }
    
    
    
    
}
