//
//  InterQualification.swift
//  Data Passing through Present
//
//  Created by Vadde Narendra on 11/17/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class InterQualification: UIViewController
{

    @IBOutlet weak var sankritTF: UITextField!
    @IBOutlet weak var englishTF: UITextField!
    @IBOutlet weak var maths1ATF: UITextField!
    @IBOutlet weak var maths1BTF: UITextField!
    @IBOutlet weak var physicsTF: UITextField!
    @IBOutlet weak var chemistryTF: UITextField!
    
    @IBOutlet weak var sanskritSTF: UITextField!
    @IBOutlet weak var englishSTF: UITextField!
    @IBOutlet weak var maths2ATF: UITextField!
    @IBOutlet weak var maths2BTF: UITextField!
    @IBOutlet weak var physicsSTF: UITextField!
    @IBOutlet weak var chemistrySTF: UITextField!
    
    @IBOutlet weak var scrollView: UIScrollView!
    
    var personalDetails:[String] = []
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
    }
    
    @IBAction func segmentedSCValueChanged(_ sender: UISegmentedControl)
    {
        switch sender.selectedSegmentIndex {
        case 0:
            scrollView.setContentOffset(CGPoint(x: 0, y: 0), animated: true)
        case 1:
            scrollView.setContentOffset(CGPoint(x: 0, y: 700), animated: true)
        default:
            print("Ok")
        }
    }
    
    
    
    
    @IBAction func nextBtnTapped(_ sender: UIButton)
    {
        let btechView = storyboard?.instantiateViewController(withIdentifier: "btechDetails") as! BtechQualification
        present(btechView, animated: true) {
            
            btechView.personalDetailsArray = self.personalDetails
            
            btechView.interMarksArray.append(self.sankritTF.text!)
            btechView.interMarksArray.append(self.englishTF.text!)
            btechView.interMarksArray.append(self.maths1ATF.text!)
            btechView.interMarksArray.append(self.maths1BTF.text!)
            btechView.interMarksArray.append(self.physicsTF.text!)
            btechView.interMarksArray.append(self.chemistryTF.text!)
            
            btechView.interMarksArray.append(self.sanskritSTF.text!)
            btechView.interMarksArray.append(self.englishSTF.text!)
            btechView.interMarksArray.append(self.maths2ATF.text!)
            btechView.interMarksArray.append(self.maths2BTF.text!)
            btechView.interMarksArray.append(self.physicsSTF.text!)
            btechView.interMarksArray.append(self.chemistrySTF.text!)
        }
     
    }
  
}
