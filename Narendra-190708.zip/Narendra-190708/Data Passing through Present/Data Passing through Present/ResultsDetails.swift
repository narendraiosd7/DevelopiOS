//
//  ResultsDetails.swift
//  Data Passing through Present
//
//  Created by Vadde Narendra on 11/17/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ResultsDetails: UIViewController
{

    @IBOutlet weak var firstNameLbl: UILabel!
    @IBOutlet weak var lastNameLbl: UILabel!
    @IBOutlet weak var ageLbl: UILabel!
    @IBOutlet weak var qualificationLbl: UILabel!
    
    @IBOutlet weak var firstYearInterTotalMarksLbl: UILabel!
    @IBOutlet weak var firstYearInterPecentageLbl: UILabel!
    @IBOutlet weak var firstYearInterGradeLbl: UILabel!
    @IBOutlet weak var firstYearInterStatusLbl: UILabel!
    
    @IBOutlet weak var secondYearInterTotalMarksLbl: UILabel!
    @IBOutlet weak var secondYearInterPercentageLbl: UILabel!
    @IBOutlet weak var seconYearInterGradeLbl: UILabel!
    @IBOutlet weak var secondYearInterStatusLbl: UILabel!
    
    @IBOutlet weak var btech1stYearTotalMarksLbl: UILabel!
    @IBOutlet weak var btech1stYearPercentageLbl: UILabel!
    @IBOutlet weak var btech1stYearGradeLbl: UILabel!
    @IBOutlet weak var btech1stYearStatusLbl: UILabel!
    
    @IBOutlet weak var btech21TotalMarksLbl: UILabel!
    @IBOutlet weak var btech21PercentageLbl: UILabel!
    @IBOutlet weak var btech21GradeLbl: UILabel!
    @IBOutlet weak var btech21StatusLbl: UILabel!
    
    @IBOutlet weak var btech22TotalMarksLbl: UILabel!
    @IBOutlet weak var btech22PecentageLbl: UILabel!
    @IBOutlet weak var btech22GradeLbl: UILabel!
    @IBOutlet weak var btech22StatusLbl: UILabel!
    
    @IBOutlet weak var btech31TotalMarksLbl: UILabel!
    @IBOutlet weak var btech31PercentageLbl: UILabel!
    @IBOutlet weak var btech31GradeLbl: UILabel!
    @IBOutlet weak var btech31StatusLbl: UILabel!
    
    @IBOutlet weak var btech32TotalMarksLbl: UILabel!
    @IBOutlet weak var btech32PercentageLbl: UILabel!
    @IBOutlet weak var btech32GradeLbl: UILabel!
    @IBOutlet weak var btech32StatusLbl: UILabel!
    
    @IBOutlet weak var btech41TotalMarksLbl: UILabel!
    @IBOutlet weak var btech41PercentageLbl: UILabel!
    @IBOutlet weak var btech41GradeLbl: UILabel!
    @IBOutlet weak var btech41StatusLbl: UILabel!
    
    @IBOutlet weak var btech42TotalMarksLbl: UILabel!
    @IBOutlet weak var btech42PercentageLbl: UILabel!
    @IBOutlet weak var btech42GradeLbl: UILabel!
    @IBOutlet weak var btech42StatusLbl: UILabel!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
    }
    
}
