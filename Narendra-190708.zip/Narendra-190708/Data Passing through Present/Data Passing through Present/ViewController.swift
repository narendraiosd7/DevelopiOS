//
//  ViewController.swift
//  Data Passing through Present
//
//  Created by Vadde Narendra on 11/17/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{

    @IBOutlet weak var firstNameTF: UITextField!
    @IBOutlet weak var lastNameTF: UITextField!
    @IBOutlet weak var ageTF: UITextField!
    @IBOutlet weak var qualificationTf: UITextField!
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
    }

    @IBAction func nextBtnTapped(_ sender: UIButton)
    {
        let interView = storyboard?.instantiateViewController(withIdentifier: "interDetails") as! InterQualification
        
        present(interView, animated: true)
        {
            interView.personalDetails.append(self.firstNameTF.text!)
            interView.personalDetails.append(self.lastNameTF.text!)
            interView.personalDetails.append(self.ageTF.text!)
            interView.personalDetails.append(self.qualificationTf.text!)
        }
    }
}

