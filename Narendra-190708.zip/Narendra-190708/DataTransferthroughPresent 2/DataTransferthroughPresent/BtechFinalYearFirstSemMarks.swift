//
//  BtechFinalYearFirstSemMarks.swift
//  DataTransferthroughPresent
//
//  Created by Vadde Narendra on 11/11/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class BtechFinalYearFirstSemMarks: UIViewController, UITextFieldDelegate {

    
    @IBOutlet weak var DEPMarksTF: UITextField!
    @IBOutlet weak var DSPMarksTF: UITextField!
    @IBOutlet weak var HVDCMarksTF: UITextField!
    @IBOutlet weak var SGPMarksTF: UITextField!
    @IBOutlet weak var instrumentationsMarksTF: UITextField!
    @IBOutlet weak var OTMarksTF: UITextField!
    @IBOutlet weak var MPMCLabMarksTF: UITextField!
    @IBOutlet weak var PESLabMarksTF: UITextField!
    
    var btech41Marks = BtechQualificationDetails()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        DEPMarksTF.delegate = self
        DSPMarksTF.delegate = self
        HVDCMarksTF.delegate = self
        SGPMarksTF.delegate = self
        instrumentationsMarksTF.delegate = self
        OTMarksTF.delegate = self
        MPMCLabMarksTF.delegate = self
        PESLabMarksTF.delegate = self
        
        DEPMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        DSPMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        HVDCMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        SGPMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        instrumentationsMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        OTMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        MPMCLabMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        PESLabMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        
        DEPMarksTF.keyboardType = .numberPad
        DSPMarksTF.keyboardType = .numberPad
        HVDCMarksTF.keyboardType = .numberPad
        SGPMarksTF.keyboardType = .numberPad
        instrumentationsMarksTF.keyboardType = .numberPad
        OTMarksTF.keyboardType = .numberPad
        MPMCLabMarksTF.keyboardType = .numberPad
        PESLabMarksTF.keyboardType = .numberPad
        
        // Do any additional setup after loading the view.
    }
    

    func isValidMarks(marksStr:String) -> Bool
    {
        
        let marksRegEx = "[0-9]{1,3}"
        
        let marksPred = NSPredicate(format:"SELF MATCHES %@", marksRegEx)
        return marksPred.evaluate(with: marksStr)
    }
    
    
    var returValue = false
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool
    {
        if (textField == DEPMarksTF)
        {
            returValue = true
        }
        else if (textField == DSPMarksTF)
        {
            if (Int(DEPMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == HVDCMarksTF)
        {
            if (Int(DSPMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == SGPMarksTF)
        {
            if (Int(HVDCMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == instrumentationsMarksTF)
        {
            if (Int(SGPMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == OTMarksTF)
        {
            if (Int(instrumentationsMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == MPMCLabMarksTF)
        {
            if (Int(OTMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == PESLabMarksTF)
        {
            if (Int(MPMCLabMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        
        return returValue
    }
    
    
    
    func textFieldDidBeginEditing(_ textField: UITextField)
    {
        textField.backgroundColor = UIColor.red
    }
    
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool
    {
        if (textField == DEPMarksTF ||
            textField == DSPMarksTF ||
            textField == HVDCMarksTF ||
            textField == SGPMarksTF ||
            textField == instrumentationsMarksTF ||
            textField == OTMarksTF ||
            textField == MPMCLabMarksTF ||
            textField == PESLabMarksTF)
        {
            returValue = isValidMarks(marksStr: textField.text!)
        }
        
        return returValue
    }
    
    
    
    func textFieldDidEndEditing(_ textField: UITextField)
    {
        textField.backgroundColor = UIColor.white
    }
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool
    {
        return true
    }

    //event handler for marks
    
    @objc func marksValidation(obj:UITextField)
    {
        if(obj.text != "")
        {
            if(Int(obj.text!)!>100)
            {
                obj.text = ""
            }
        }
    }
    @IBAction func btnTap(_ sender: UIButton) {
        
        dismiss(animated: true) {
            
            self.btech41Marks.btech4thYear1stSemMarks.append(self.DEPMarksTF.text!)
            self.btech41Marks.btech4thYear1stSemMarks.append(self.DSPMarksTF.text!)
            self.btech41Marks.btech4thYear1stSemMarks.append(self.HVDCMarksTF.text!)
            self.btech41Marks.btech4thYear1stSemMarks.append(self.SGPMarksTF.text!)
            self.btech41Marks.btech4thYear1stSemMarks.append(self.instrumentationsMarksTF.text!)
                self.btech41Marks.btech4thYear1stSemMarks.append(self.OTMarksTF.text!)
            self.btech41Marks.btech4thYear1stSemMarks.append(self.MPMCLabMarksTF.text!)
            self.btech41Marks.btech4thYear1stSemMarks.append(self.PESLabMarksTF.text!)
            
        }
    }
    
}
