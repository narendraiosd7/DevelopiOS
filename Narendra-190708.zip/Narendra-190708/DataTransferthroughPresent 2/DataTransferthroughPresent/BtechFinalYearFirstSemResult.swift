//
//  BtechFinalYearFirstSemResult.swift
//  DataTransferthroughPresent
//
//  Created by Vadde Narendra on 11/12/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class BtechFinalYearFirstSemResult: UIViewController {

    @IBOutlet weak var DEPLbl: UILabel!
    @IBOutlet weak var DSPLbl: UILabel!
    @IBOutlet weak var HVDCFactsLbl: UILabel!
    @IBOutlet weak var SGPLbl: UILabel!
    @IBOutlet weak var instrumentationLbl: UILabel!
    @IBOutlet weak var OTLbl: UILabel!
    @IBOutlet weak var MPMCLabLbl: UILabel!
    @IBOutlet weak var PESimLabLbl: UILabel!
    @IBOutlet weak var totalMarksLbl: UILabel!
    @IBOutlet weak var statusLbl: UILabel!
    @IBOutlet weak var percentageLbl: UILabel!
    @IBOutlet weak var gradeLbl: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

//        cal4thYear1stSemBtechResults(DEPMarks: Int(DEPLbl.text!)!, DSPMarks: Int(DSPLbl.text!)!, fundametalsofHVDCFactsDevicesMarks: Int(HVDCFactsLbl.text!)!, SGPMarks: Int(SGPLbl.text!)!, instrumentationMarks: Int(instrumentationLbl.text!)!, OTMarks: Int(OTLbl.text!)!, MPMCLabMarks: Int(MPMCLabLbl.text!)!, PESimLabMarks: Int(PESimLabLbl.text!)!)
        
        // Do any additional setup after loading the view.
    }
    
    func cal4thYear1stSemBtechResults(DEPMarks:Int,DSPMarks:Int,fundametalsofHVDCFactsDevicesMarks:Int,SGPMarks:Int,instrumentationMarks:Int,OTMarks:Int,MPMCLabMarks:Int,PESimLabMarks:Int)
    {
        // Calculating Total Marks
        
        let fourthYear1stSemGainedMarks:Int = Int(DEPMarks)+Int(DSPMarks)+Int(fundametalsofHVDCFactsDevicesMarks)+Int(SGPMarks)+Int(instrumentationMarks)+Int(OTMarks)+Int(MPMCLabMarks)+Int(PESimLabMarks)
        
        totalMarksLbl.text = "\(fourthYear1stSemGainedMarks)"
        
        // Calculating Percentage
        
        let totalMarks1stSem:Float = 750
        
        let firstSemGainedMarks:Float = Float(fourthYear1stSemGainedMarks)
        
        let firstSemPercentage:Float = (firstSemGainedMarks/totalMarks1stSem)*100
        
        print("B-Tech 4th Year 1st Sem Percentage = \(firstSemPercentage)")
        
        // finding out subject wise pass or fail
        
        let subPassMarks:Int = 35
        let labPassMarks:Int = 27
        
        var distributionOfElectricalPower:Bool = false
        var digitalSignalProcessing:Bool = false
        var fundametalsOfHVDCFactsDevices:Bool = false
        var switchGearAndProtection:Bool = false
        var Instrumentation:Bool = false
        var optimizationTechniques:Bool = false
        var microprocessorsAndMicrocontrollersLab:Bool = false
        var powerElectronicsAndSimulationLab:Bool = false
        
        if DEPMarks >= subPassMarks
        {
            distributionOfElectricalPower = true
        } else {
            distributionOfElectricalPower = false
        }
        
        if DSPMarks >= subPassMarks
        {
            digitalSignalProcessing = true
        } else {
            digitalSignalProcessing = false
        }
        
        if fundametalsofHVDCFactsDevicesMarks >= subPassMarks
        {
            fundametalsOfHVDCFactsDevices = true
        } else {
            fundametalsOfHVDCFactsDevices = false
        }
        
        if SGPMarks >= subPassMarks
        {
            switchGearAndProtection = true
        } else {
            switchGearAndProtection = false
        }
        
        if instrumentationMarks >= subPassMarks
        {
            Instrumentation = true
        } else {
            Instrumentation = false
        }
        
        if OTMarks >= subPassMarks
        {
            optimizationTechniques = true
        } else {
            optimizationTechniques = false
        }
        
        if MPMCLabMarks >= labPassMarks
        {
            microprocessorsAndMicrocontrollersLab = true
        } else {
            microprocessorsAndMicrocontrollersLab = false
        }
        
        if  PESimLabMarks >= labPassMarks
        {
            powerElectronicsAndSimulationLab = true
        } else {
            powerElectronicsAndSimulationLab = false
        }
        
        // Total 3rd Year 1st Sem pass or fail with grade
        
        if (distributionOfElectricalPower == true && digitalSignalProcessing == true && fundametalsOfHVDCFactsDevices == true && switchGearAndProtection == true && Instrumentation == true && optimizationTechniques == true && microprocessorsAndMicrocontrollersLab == true && powerElectronicsAndSimulationLab == true)
        {
            switch firstSemPercentage
            {
            case 90...100:
                gradeLbl.text = "A"
            case 75..<90:
                gradeLbl.text = "B"
            case 50..<75:
                gradeLbl.text = "C"
            case 35..<50:
                gradeLbl.text = "D"
            default:
                gradeLbl.text = "E"
            }
            statusLbl.text = "PASSED"
        }
        else
        {
            statusLbl.text = "FAILED"
        }
        
    }

}
