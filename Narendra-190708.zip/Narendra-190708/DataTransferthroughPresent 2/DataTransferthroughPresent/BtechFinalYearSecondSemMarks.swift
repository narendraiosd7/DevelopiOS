//
//  BtechFinalYearSecondSemMarks.swift
//  DataTransferthroughPresent
//
//  Created by Vadde Narendra on 11/11/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class BtechFinalYearSecondSemMarks: UIViewController, UITextFieldDelegate {

    
    @IBOutlet weak var PPQMarksTF: UITextField!
    @IBOutlet weak var UEEMarksTF: UITextField!
    @IBOutlet weak var MCTMarksTF: UITextField!
    @IBOutlet weak var EADSMMarksTF: UITextField!
    @IBOutlet weak var seminarMarksTF: UITextField!
    @IBOutlet weak var projectWorkMarksTF: UITextField!
    
    var btech42Marks = BtechQualificationDetails()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        PPQMarksTF.delegate = self
        UEEMarksTF.delegate = self
        MCTMarksTF.delegate = self
        EADSMMarksTF.delegate = self
        seminarMarksTF.delegate = self
        projectWorkMarksTF.delegate = self
        
        PPQMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        UEEMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        MCTMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        EADSMMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        seminarMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        projectWorkMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        
        PPQMarksTF.keyboardType = .numberPad
        UEEMarksTF.keyboardType = .numberPad
        MCTMarksTF.keyboardType = .numberPad
        EADSMMarksTF.keyboardType = .numberPad
        seminarMarksTF.keyboardType = .numberPad
        projectWorkMarksTF.keyboardType = .numberPad
        
        // Do any additional setup after loading the view.
    }
    

    func isValidMarks(marksStr:String) -> Bool
    {
        
        let marksRegEx = "[0-9]{1,3}"
        
        let marksPred = NSPredicate(format:"SELF MATCHES %@", marksRegEx)
        return marksPred.evaluate(with: marksStr)
    }
    
    
    var returValue = false
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool
    {
        if (textField == PPQMarksTF)
        {
            returValue = true
        }
        else if (textField == UEEMarksTF)
        {
            if (Int(PPQMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == MCTMarksTF)
        {
            if (Int(UEEMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == EADSMMarksTF)
        {
            if (Int(MCTMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == seminarMarksTF)
        {
            if (Int(EADSMMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == projectWorkMarksTF)
        {
            if (Int(seminarMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        
        return returValue
    }
    
    
    
    func textFieldDidBeginEditing(_ textField: UITextField)
    {
        textField.backgroundColor = UIColor.red
    }
    
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool
    {
        if (textField == PPQMarksTF ||
            textField == UEEMarksTF ||
            textField == MCTMarksTF ||
            textField == EADSMMarksTF ||
            textField == seminarMarksTF ||
            textField == projectWorkMarksTF)
        {
            returValue = isValidMarks(marksStr: textField.text!)
        }
        
        return returValue
    }
    
    
    
    func textFieldDidEndEditing(_ textField: UITextField)
    {
        textField.backgroundColor = UIColor.white
    }
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool
    {
        return true
    }

    //event handler for marks
    
    @objc func marksValidation(obj:UITextField)
    {
        if(obj.text != "")
        {
            if(Int(obj.text!)!>100)
            {
                obj.text = ""
            }
        }
    }
    @IBAction func btnTap(_ sender: UIButton) {
        
        dismiss(animated: true) {
            
           self.btech42Marks.btech4thYear2ndSemMarks.append(self.PPQMarksTF.text!)
            self.btech42Marks.btech4thYear2ndSemMarks.append(self.UEEMarksTF.text!)
            self.btech42Marks.btech4thYear2ndSemMarks.append(self.MCTMarksTF.text!)
            self.btech42Marks.btech4thYear2ndSemMarks.append(self.EADSMMarksTF.text!)
            self.btech42Marks.btech4thYear2ndSemMarks.append(self.seminarMarksTF.text!)
            self.btech42Marks.btech4thYear2ndSemMarks.append(self.projectWorkMarksTF.text!)
        }
    }
}
