//
//  BtechFinalYearSecondSemResult.swift
//  DataTransferthroughPresent
//
//  Created by Vadde Narendra on 11/12/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class BtechFinalYearSecondSemResult: UIViewController {

    @IBOutlet weak var PPQLbl: UILabel!
    @IBOutlet weak var UEELbl: UILabel!
    @IBOutlet weak var MCTLbl: UILabel!
    @IBOutlet weak var EADSMLbl: UILabel!
    @IBOutlet weak var seminarLbl: UILabel!
    @IBOutlet weak var projectWorkLbl: UILabel!
    @IBOutlet weak var totalMarksLbl: UILabel!
    @IBOutlet weak var statusLbl: UILabel!
    @IBOutlet weak var percentageLbl: UILabel!
    @IBOutlet weak var gradeLbl: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

//        cal4thYear2ndSemBtechResults(PPQMarks: Int(PPQLbl.text!)!, UEEMarks: Int(UEELbl.text!)!, MCTMarks: Int(MCTLbl.text!)!, EADSMMarks: Int(EADSMLbl.text!)!, seminarMarks: Int(seminarLbl.text!)!, projectWorkMarks: Int(projectWorkLbl.text!)!)
        
        // Do any additional setup after loading the view.
    }
    
    func cal4thYear2ndSemBtechResults(PPQMarks:Int,UEEMarks:Int,MCTMarks:Int,EADSMMarks:Int,seminarMarks:Int,projectWorkMarks:Int)
    {
        // Calculating Total Marks
        
        let fourthYear2ndSemGainedMarks:Int = Int(PPQMarks)+Int(UEEMarks)+Int(MCTMarks)+Int(EADSMMarks)+Int(seminarMarks)+projectWorkMarks
        
        totalMarksLbl.text = "\(fourthYear2ndSemGainedMarks)"
        
        // Calculating Percentage
        
        let totalMarks2ndSem:Float = 750
        
        let secondSemGainedMarks:Float = Float(fourthYear2ndSemGainedMarks)
        
        let secondSemPercentage:Float = (secondSemGainedMarks/totalMarks2ndSem)*100
        
        percentageLbl.text = "\(secondSemPercentage)"
        
        // finding out subject wise pass or fail
        
        let subPassMarks:Int = 35
        let projectPassMarks:Int = 90
        let semibarPassMarks:Int = 15
        
        var principlesofPowerQuality:Bool = false
        var utilizationofElectricalEnergy:Bool = false
        var modernControlTheory:Bool = false
        var EnergyAuditingandDemandSideManagement:Bool = false
        var seminar:Bool = false
        var projectWork:Bool = false
        
        if PPQMarks >= subPassMarks
        {
            principlesofPowerQuality = true
        } else {
            principlesofPowerQuality = false
        }
        
        if UEEMarks >= subPassMarks
        {
            utilizationofElectricalEnergy = true
        } else {
            utilizationofElectricalEnergy = false
        }
        
        if MCTMarks >= subPassMarks
        {
            modernControlTheory = true
        } else {
            modernControlTheory = false
        }
        
        if EADSMMarks >= subPassMarks
        {
            EnergyAuditingandDemandSideManagement = true
        } else {
            EnergyAuditingandDemandSideManagement = false
        }
        
        if seminarMarks >= semibarPassMarks
        {
            seminar = true
        } else {
            seminar = false
        }
        
        if projectWorkMarks >= projectPassMarks
        {
            projectWork = true
        } else {
            projectWork = false
        }
        
        
        // Total 2nd Year 2nd Sem pass or fail with grade
        
        if (principlesofPowerQuality == true && utilizationofElectricalEnergy == true && modernControlTheory == true && EnergyAuditingandDemandSideManagement == true && seminar == true && projectWork == true)
        {
            switch secondSemPercentage
            {
            case 90...100:
                gradeLbl.text = "A"
            case 75..<90:
                gradeLbl.text = "B"
            case 50..<75:
                gradeLbl.text = "C"
            case 35..<50:
                gradeLbl.text = "D"
            default:
                gradeLbl.text = "E"
            }
            statusLbl.text = "PASSED"
        }
        else
        {
            statusLbl.text = "FAILED"
        }
        
    }

}
