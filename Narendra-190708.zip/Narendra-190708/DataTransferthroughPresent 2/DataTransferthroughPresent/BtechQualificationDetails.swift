//
//  BtechQualificationDetails.swift
//  DataTransferthroughPresent
//
//  Created by Vadde Narendra on 11/9/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class BtechQualificationDetails: UIViewController {

    @IBOutlet weak var firstYearMarksContainer: UIView!
    @IBOutlet weak var btechSecondYearFirstSemMarksContainer: UIView!
    @IBOutlet weak var btechSecondYearSecondSemMarksConatiner: UIView!
    @IBOutlet weak var btechThirdYearFirstSemMarksContainer: UIView!
    @IBOutlet weak var btechThirdYearSecondSemMarksContainer: UIView!
    @IBOutlet weak var btechFinalYearFirstSemMarksContainer: UIView!
    @IBOutlet weak var btechFinalYearSecondSemMarksContainer: UIView!
    
    @IBOutlet weak var secondYearSemsSC: UISegmentedControl!
    @IBOutlet weak var thirdYearSemsSC: UISegmentedControl!
    @IBOutlet weak var finalYearSemsSC: UISegmentedControl!
    
    var personalDetailsArray:[String] = []
    
    var diploma1stYearMarksArray:[String] = []
    var diploma2ndYear1tSemMarksArray:[String] = []
    var diploma2ndYear2ndSemMarksArray:[String] = []
    var diploma3rdYear1tSemMarksArray:[String] = []
    var diploma3rdYear2ndSemMarksArray:[String] = []
    
    var btech2ndYear1stSemMarks:[String] = []
    var btech2ndYear2ndSemMarks:[String] = []
    var btech3rdYear1stSemMarks:[String] = []
    var btech3rdYear2ndSemMarks:[String] = []
    var btech4thYear1stSemMarks:[String] = []
    var btech4thYear2ndSemMarks:[String] = []
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        btechSecondYearFirstSemMarksContainer.isHidden = true
        btechSecondYearSecondSemMarksConatiner.isHidden = true
        btechThirdYearFirstSemMarksContainer.isHidden = true
        btechThirdYearSecondSemMarksContainer.isHidden = true
        btechFinalYearFirstSemMarksContainer.isHidden = true
        btechFinalYearSecondSemMarksContainer.isHidden = true
        
//        print(diplomaEducationDetails.diploma1stYearMarks[0])
        // Do any additional setup after loading the view.
    }
    
    @IBAction func btechYearsSCTapped(_ sender: UISegmentedControl)
    {
        switch sender.selectedSegmentIndex {
        case 0:
            firstYearMarksContainer.isHidden = false
            secondYearSemsSC.isHidden = true
            thirdYearSemsSC.isHidden = true
            finalYearSemsSC.isHidden = true
            btechSecondYearFirstSemMarksContainer.isHidden = true
            btechSecondYearSecondSemMarksConatiner.isHidden = true
            btechThirdYearFirstSemMarksContainer.isHidden = true
            btechThirdYearSecondSemMarksContainer.isHidden = true
            btechFinalYearFirstSemMarksContainer.isHidden = true
            btechFinalYearSecondSemMarksContainer.isHidden = true
        case 1:
            secondYearSemsSC.isHidden = false
            btechSecondYearFirstSemMarksContainer.isHidden = true
            thirdYearSemsSC.isHidden = true
            finalYearSemsSC.isHidden = true
            btechThirdYearFirstSemMarksContainer.isHidden = true
            btechThirdYearSecondSemMarksContainer.isHidden = true
            btechFinalYearFirstSemMarksContainer.isHidden = true
            btechFinalYearSecondSemMarksContainer.isHidden = true
        case 2:
            secondYearSemsSC.isHidden = true
            thirdYearSemsSC.isHidden = false
            btechThirdYearFirstSemMarksContainer.isHidden = true
            finalYearSemsSC.isHidden = true
            btechSecondYearFirstSemMarksContainer.isHidden = true
            btechSecondYearSecondSemMarksConatiner.isHidden = true
            btechFinalYearFirstSemMarksContainer.isHidden = true
            btechFinalYearSecondSemMarksContainer.isHidden = true
        case 3:
            secondYearSemsSC.isHidden = true
            thirdYearSemsSC.isHidden = true
            finalYearSemsSC.isHidden = false
            btechFinalYearFirstSemMarksContainer.isHidden = true
            btechSecondYearFirstSemMarksContainer.isHidden = true
            btechSecondYearSecondSemMarksConatiner.isHidden = true
            btechThirdYearFirstSemMarksContainer.isHidden = true
            btechThirdYearSecondSemMarksContainer.isHidden = true
        default:
            print("Something went wrong")
        }
    }
    
    @IBAction func btechSecondYearSCTapped(_ sender: UISegmentedControl)
    {
        switch sender.selectedSegmentIndex {
        case 0:
            
            firstYearMarksContainer.isHidden = true
            
            let  btech21 = self.storyboard?.instantiateViewController(withIdentifier: "btech21st") as! BtechSecondYearFirstSemMarks
            
            btech21.btech21Marks = self
            present(btech21, animated: true, completion: nil)
            
        case 1:
            
            firstYearMarksContainer.isHidden = true
            
            let  btech22 = self.storyboard?.instantiateViewController(withIdentifier: "btech22nd") as! BtechSecondYearSecondSemMarks
            
            btech22.btech22Marks = self
            present(btech22, animated: true, completion: nil)
        default:
            print("Something went wrong")
        }
    }
    
    @IBAction func btechThirdYearSemsSCTapped(_ sender: UISegmentedControl)
    {
        switch sender.selectedSegmentIndex {
        case 0:
            
            firstYearMarksContainer.isHidden = true
            
            let  btech31 = self.storyboard?.instantiateViewController(withIdentifier: "btech31st") as! BtechThirdYearFirstSemMarks
            
            btech31.btech31Marks = self
            present(btech31, animated: true, completion: nil)
            
        case 1:
            
            firstYearMarksContainer.isHidden = true
            
            let  btech32 = self.storyboard?.instantiateViewController(withIdentifier: "btech32nd") as! BtechThirdYearSecondSemMarks
            
            btech32.btech32Marks = self
            present(btech32, animated: true, completion: nil)
        default:
            print("Something went wrong")
        }
    }
    
    @IBAction func btechFourthYearSemsSCTapped(_ sender: UISegmentedControl)
    {
        switch sender.selectedSegmentIndex {
        case 0:
            
            firstYearMarksContainer.isHidden = true
            
            let  btech41 = self.storyboard?.instantiateViewController(withIdentifier: "btech41st") as! BtechFinalYearFirstSemMarks
            
            btech41.btech41Marks = self
            present(btech41, animated: true, completion: nil)
        case 1:
            
            firstYearMarksContainer.isHidden = true
            
            let  btech42 = self.storyboard?.instantiateViewController(withIdentifier: "btech42nd") as! BtechFinalYearSecondSemMarks
            
            btech42.btech42Marks = self
            present(btech42, animated: true, completion: nil)
        default:
            print("Something went wrong")
        }
    }
    
    @IBAction func submitBtnTapped(_ sender: UIButton)
    {
        let resultView = storyboard?.instantiateViewController(withIdentifier: "resultDetails") as! EducationalResults
        
        present(resultView, animated: true)
        {
            resultView.firstNameLbl.text = self.personalDetailsArray[0]
            resultView.lastNameLbl.text = self.personalDetailsArray[1]
            resultView.qualificationLbl.text = self.personalDetailsArray[2]
            resultView.DOBLbl.text = self.personalDetailsArray[3]
            
            resultView.diploma1stYearResultCalculations(english1Marks: Int(self.diploma1stYearMarksArray[0])!, enggMathsMarks: Int(self.diploma1stYearMarksArray[1])!, enggPhysicsMarks: Int(self.diploma1stYearMarksArray[2])!, enggChemMarks: Int(self.diploma1stYearMarksArray[3])!, basicElecEnggMarks: Int(self.diploma1stYearMarksArray[4])!, mechWorkshopMarks: Int(self.diploma1stYearMarksArray[5])!, enggDrawingMarks: Int(self.diploma1stYearMarksArray[6])!, physicsLabMarks: Int(self.diploma1stYearMarksArray[7])!, chemistryLabMarks: Int(self.diploma1stYearMarksArray[8])!, ITLabMarks: Int(self.diploma1stYearMarksArray[9])!, elecWorkshopMarks: Int(self.diploma1stYearMarksArray[10])!)
            
            resultView.diploma2ndYear1stSemResultCalculations(english2Marks: Int(self.diploma2ndYear1tSemMarksArray[0])!, enggMaths2Marks: Int(self.diploma2ndYear1tSemMarksArray[1])!, ECMarks: Int(self.diploma2ndYear1tSemMarksArray[2])!, DCMCMarks: Int(self.diploma2ndYear1tSemMarksArray[3])!, EEMIMarks: Int(self.diploma2ndYear1tSemMarksArray[4])!, electronicsEnggMarks: Int(self.diploma2ndYear1tSemMarksArray[5])!, DCMCLabMarks: Int(self.diploma2ndYear1tSemMarksArray[6])!, EMILabMarks: Int(self.diploma2ndYear1tSemMarksArray[7])!, EWLabMarks: Int(self.diploma2ndYear1tSemMarksArray[8])!, electronicsLabMarks: Int(self.diploma2ndYear1tSemMarksArray[9])!)
            
            resultView.diploma2ndYear2ndSemResultcalculations(english3Marks: Int(self.diploma2ndYear1tSemMarksArray[0])!, ACMCMarks: Int(self.diploma2ndYear1tSemMarksArray[1])!, PSMarks: Int(self.diploma2ndYear1tSemMarksArray[2])!, EIEMarks: Int(self.diploma2ndYear1tSemMarksArray[3])!, DEMCMarks: Int(self.diploma2ndYear1tSemMarksArray[4])!, GMEMarks: Int(self.diploma2ndYear1tSemMarksArray[5])!, ACMCLabMarks: Int(self.diploma2ndYear1tSemMarksArray[6])!, EEDMarks: Int(self.diploma2ndYear1tSemMarksArray[7])!, DELabMarks: Int(self.diploma2ndYear1tSemMarksArray[8])!, MCLabMarks: Int(self.diploma2ndYear1tSemMarksArray[9])!)
            
            resultView.diploma3rdYear1stSemResultcalculations(firstAssigMarks: Int(self.diploma3rdYear1tSemMarksArray[0])!, secondAssignMarks: Int(self.diploma3rdYear1tSemMarksArray[1])!, logBookMarks: Int(self.diploma3rdYear1tSemMarksArray[2])!, recordMarks: Int(self.diploma3rdYear1tSemMarksArray[3])!, seminarMarks: Int(self.diploma3rdYear1tSemMarksArray[4])!)
            
            resultView.diploma3rdYear2ndSemResultcalculations(english4Marks: Int(self.diploma3rdYear2ndSemMarksArray[0])!, IMEMarks: Int(self.diploma3rdYear2ndSemMarksArray[1])!, ACMC3Marks: Int(self.diploma3rdYear2ndSemMarksArray[2])!, PEMarks: Int(self.diploma3rdYear2ndSemMarksArray[3])!, ETPLCMarks: Int(self.diploma3rdYear2ndSemMarksArray[4])!, PS2Marks: Int(self.diploma3rdYear2ndSemMarksArray[5])!, ACMC2LabMarks: Int(self.diploma3rdYear2ndSemMarksArray[6])!, PELabMarks: Int(self.diploma3rdYear2ndSemMarksArray[7])!, ECADLabMarks: Int(self.diploma3rdYear2ndSemMarksArray[8])!, automationLabMarks: Int(self.diploma3rdYear2ndSemMarksArray[9])!, projectWorkMarks: Int(self.diploma3rdYear2ndSemMarksArray[10])!)
            
            resultView.cal2ndYear1stSemBtechResults(mathematics3Marks: Int(self.btech2ndYear1stSemMarks[0])!, environmentalSciMarks: Int(self.btech2ndYear1stSemMarks[1])!, basicFMHMMarks: Int(self.btech2ndYear1stSemMarks[2])!, elecDevCirsMarks: Int(self.btech2ndYear1stSemMarks[3])!, elecMachines1Marks: Int(self.btech2ndYear1stSemMarks[4])!, elecCircuitsMarks: Int(self.btech2ndYear1stSemMarks[5])!, basicFMHMLabMarks: Int(self.btech2ndYear1stSemMarks[6])!, electronicDevCirsLabMarks: Int(self.btech2ndYear1stSemMarks[7])!)
            
            resultView.cal2ndYear2ndSemBtechResults(EMFMarks: Int(self.btech2ndYear2ndSemMarks[0])!, GEPMarks: Int(self.btech2ndYear2ndSemMarks[1])!, AECMarks: Int(self.btech2ndYear2ndSemMarks[2])!, STLDMarks: Int(self.btech2ndYear2ndSemMarks[3])!, NTMarks: Int(self.btech2ndYear2ndSemMarks[4])!, EM2Marks: Int(self.btech2ndYear2ndSemMarks[5])!, EM1LabMarks: Int(self.btech2ndYear2ndSemMarks[6])!, ECSLabMarks: Int(self.btech2ndYear2ndSemMarks[7])!)
            
            resultView.cal3rdYear1stSemBtechResults(MEFAMarks: Int(self.btech3rdYear1stSemMarks[0])!, EEMMarks: Int(self.btech3rdYear1stSemMarks[1])!, TEPMarks: Int(self.btech3rdYear1stSemMarks[2])!, CSMarks: Int(self.btech3rdYear1stSemMarks[3])!, PEMarks: Int(self.btech3rdYear1stSemMarks[4])!, EM3Marks: Int(self.btech3rdYear1stSemMarks[5])!, EMLab2Marks: Int(self.btech3rdYear1stSemMarks[6])!, CSSimLabMarks: Int(self.btech3rdYear1stSemMarks[7])!)
            
            resultView.cal3rdYear2ndSemBtechResults(MSMarks: Int(self.btech3rdYear2ndSemMarks[0])!, PSDMarks: Int(self.btech3rdYear2ndSemMarks[1])!, PSAMarks: Int(self.btech3rdYear2ndSemMarks[2])!, MPMCMarks: Int(self.btech3rdYear2ndSemMarks[3])!, PSOCMarks: Int(self.btech3rdYear2ndSemMarks[4])!, LDICAMarks: Int(self.btech3rdYear2ndSemMarks[5])!, AECSLLabMarks: Int(self.btech3rdYear2ndSemMarks[6])!, EMLabMarks: Int(self.btech3rdYear2ndSemMarks[7])!)
            
            resultView.cal4thYear1stSemBtechResults(DEPMarks: Int(self.btech4thYear1stSemMarks[0])!, DSPMarks: Int(self.btech4thYear1stSemMarks[1])!, fundametalsofHVDCFactsDevicesMarks: Int(self.btech4thYear1stSemMarks[2])!, SGPMarks: Int(self.btech4thYear1stSemMarks[3])!, instrumentationMarks: Int(self.btech4thYear1stSemMarks[4])!, OTMarks: Int(self.btech4thYear1stSemMarks[5])!, MPMCLabMarks: Int(self.btech4thYear1stSemMarks[6])!, PESimLabMarks: Int(self.btech4thYear1stSemMarks[7])!)
            
            resultView.cal4thYear2ndSemBtechResults(PPQMarks: Int(self.btech4thYear2ndSemMarks[0])!, UEEMarks: Int(self.btech4thYear2ndSemMarks[1])!, MCTMarks: Int(self.btech4thYear2ndSemMarks[2])!, EADSMMarks: Int(self.btech4thYear2ndSemMarks[3])!, seminarMarks: Int(self.btech4thYear2ndSemMarks[4])!, projectWorkMarks: Int(self.btech4thYear2ndSemMarks[5])!)
            
        }
        
        
    }
    
    
    
    
}
