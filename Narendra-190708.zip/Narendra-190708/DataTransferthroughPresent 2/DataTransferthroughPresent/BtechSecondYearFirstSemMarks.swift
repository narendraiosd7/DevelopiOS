//
//  btechSecondYearFirstSemMarks.swift
//  DataTransferthroughPresent
//
//  Created by Vadde Narendra on 11/11/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class BtechSecondYearFirstSemMarks: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var m3MarksTF: UITextField!
    @IBOutlet weak var ESMarksTF: UITextField!
    @IBOutlet weak var FMHMMarksTF: UITextField!
    @IBOutlet weak var EDCMarksTF: UITextField!
    @IBOutlet weak var ECMarksTF: UITextField!
    @IBOutlet weak var EM1MarksTF: UITextField!
    @IBOutlet weak var FMHMLabMarksTF: UITextField!
    @IBOutlet weak var EDCLabMarksTF: UITextField!
    
    var btech21Marks = BtechQualificationDetails()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        m3MarksTF.delegate = self
        ESMarksTF.delegate = self
        FMHMMarksTF.delegate = self
        EDCMarksTF.delegate = self
        ECMarksTF.delegate = self
        EM1MarksTF.delegate = self
        FMHMLabMarksTF.delegate = self
        EDCLabMarksTF.delegate = self
        
        m3MarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        ESMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        FMHMMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        EDCMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        ECMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        EM1MarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        FMHMLabMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        EDCLabMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        
        m3MarksTF.keyboardType = .numberPad
        ESMarksTF.keyboardType = .numberPad
        FMHMMarksTF.keyboardType = .numberPad
        EDCMarksTF.keyboardType = .numberPad
        ECMarksTF.keyboardType = .numberPad
        EM1MarksTF.keyboardType = .numberPad
        FMHMLabMarksTF.keyboardType = .numberPad
        EDCLabMarksTF.keyboardType = .numberPad
        
        // Do any additional setup after loading the view.
    }

    func isValidMarks(marksStr:String) -> Bool
    {
        
        let marksRegEx = "[0-9]{1,3}"
        
        let marksPred = NSPredicate(format:"SELF MATCHES %@", marksRegEx)
        return marksPred.evaluate(with: marksStr)
    }
    
    
    var returValue = false
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool
    {
        if (textField == m3MarksTF)
        {
            returValue = true
        }
        else if (textField == ESMarksTF)
        {
            if (Int(m3MarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == FMHMMarksTF)
        {
            if (Int(ESMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == EDCMarksTF)
        {
            if (Int(FMHMMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == ECMarksTF)
        {
            if (Int(EDCMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == EM1MarksTF)
        {
            if (Int(ECMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == FMHMLabMarksTF)
        {
            if (Int(EM1MarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == EDCLabMarksTF)
        {
            if (Int(FMHMLabMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        
        return returValue
    }
    
    
    
    func textFieldDidBeginEditing(_ textField: UITextField)
    {
        textField.backgroundColor = UIColor.red
    }
    
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool
    {
        if (textField == m3MarksTF ||
            textField == ESMarksTF ||
            textField == FMHMMarksTF ||
            textField == EDCMarksTF ||
            textField == ECMarksTF ||
            textField == EM1MarksTF ||
            textField == FMHMLabMarksTF ||
            textField == EDCLabMarksTF)
        {
            returValue = isValidMarks(marksStr: textField.text!)
        }
        
        return returValue
    }
    
    
    
    func textFieldDidEndEditing(_ textField: UITextField)
    {
        textField.backgroundColor = UIColor.white
    }
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool
    {
        return true
    }
    
    //event handler for marks
    
    @objc func marksValidation(obj:UITextField)
    {
        if(obj.text != "")
        {
            if(Int(obj.text!)!>100)
            {
                obj.text = ""
            }
        }
    }

    @IBAction func btnTapped(_ sender: UIButton) {
        
        dismiss(animated: true) {
            
            self.btech21Marks.btech2ndYear1stSemMarks.append(self.m3MarksTF.text!)
            self.btech21Marks.btech2ndYear1stSemMarks.append(self.ESMarksTF.text!)
            self.btech21Marks.btech2ndYear1stSemMarks.append(self.FMHMMarksTF.text!)
            self.btech21Marks.btech2ndYear1stSemMarks.append(self.EDCMarksTF.text!)
            self.btech21Marks.btech2ndYear1stSemMarks.append(self.ECMarksTF.text!)
            self.btech21Marks.btech2ndYear1stSemMarks.append(self.EM1MarksTF.text!)
            self.btech21Marks.btech2ndYear1stSemMarks.append(self.FMHMLabMarksTF.text!)
            self.btech21Marks.btech2ndYear1stSemMarks.append(self.EDCLabMarksTF.text!)
            
        }
    }
}
