//
//  BtechSecondYearFirstSemResult.swift
//  DataTransferthroughPresent
//
//  Created by Vadde Narendra on 11/12/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class BtechSecondYearFirstSemResult: UIViewController {

    @IBOutlet weak var m3Lbl: UILabel!
    @IBOutlet weak var ESLbl: UILabel!
    @IBOutlet weak var FMHMLbl: UILabel!
    @IBOutlet weak var EDCLbl: UILabel!
    @IBOutlet weak var ECLbl: UILabel!
    @IBOutlet weak var machines1Lbl: UILabel!
    @IBOutlet weak var FMHMLabLbl: UILabel!
    @IBOutlet weak var EDCLabLbl: UILabel!
    @IBOutlet weak var totalMarksLbl: UILabel!
    @IBOutlet weak var statusLbl: UILabel!
    @IBOutlet weak var percentageLbl: UILabel!
    @IBOutlet weak var gradeLbl: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

//        cal2ndYear1stSemBtechResults(mathematics3Marks: Int(m3Lbl.text!)!, environmentalSciMarks: Int(ESLbl.text!)!, basicFMHMMarks: Int(FMHMLbl.text!)!, elecDevCirsMarks: Int(EDCLbl.text!)!, elecMachines1Marks: Int(machines1Lbl.text!)!, elecCircuitsMarks: Int(ECLbl.text!)!, basicFMHMLabMarks: Int(FMHMLabLbl.text!)!, electronicDevCirsLabMarks: Int(EDCLabLbl.text!)!)
        
        // Do any additional setup after loading the view.
    }
    
    func cal2ndYear1stSemBtechResults(mathematics3Marks:Int,environmentalSciMarks:Int,basicFMHMMarks:Int,elecDevCirsMarks:Int,elecMachines1Marks:Int,elecCircuitsMarks:Int,basicFMHMLabMarks:Int,electronicDevCirsLabMarks:Int)
    {
        
        // Calculating Total Marks
        
        let secondYear1stSemGainedMarks:Int = Int(mathematics3Marks)+Int(environmentalSciMarks)+Int(basicFMHMMarks)+Int(elecDevCirsMarks)+Int(elecMachines1Marks)+Int(elecCircuitsMarks)+Int(basicFMHMLabMarks)+Int(electronicDevCirsLabMarks)
        
        totalMarksLbl.text = "\(secondYear1stSemGainedMarks)"
        
        // Calculating Percentage
        
        let totalMarks1stSem:Float = 750
        
        let firstSemGainedMarks:Float = Float(secondYear1stSemGainedMarks)
        
        let firstSemPercentage:Float = (firstSemGainedMarks/totalMarks1stSem)*100
        
        percentageLbl.text = "\(firstSemPercentage)"
        
        // finding out subject wise pass or fail
        
        let subPassMarks:UInt8 = 35
        let labPassMarks:UInt8 = 27
        
        var mathematics3:Bool = false
        var environmentalScience:Bool = false
        var basicFMHM:Bool = false
        var electronicDevicesAndCircuits:Bool = false
        var electricalMachines1:Bool = false
        var electricalCircuits:Bool = false
        var basicFMHMLab:Bool = false
        var electronicDevicesAndCircuitsLab:Bool = false
        
        if mathematics3Marks >= subPassMarks
        {
            mathematics3 = true
        } else {
            mathematics3 = false
        }
        
        if environmentalSciMarks >= subPassMarks
        {
            environmentalScience = true
        } else {
            environmentalScience = false
        }
        
        if basicFMHMMarks >= subPassMarks
        {
            basicFMHM = true
        } else {
            basicFMHM = false
        }
        
        if elecDevCirsMarks >= subPassMarks
        {
            electronicDevicesAndCircuits = true
        } else {
            electronicDevicesAndCircuits = false
        }
        
        if elecMachines1Marks >= subPassMarks
        {
            electricalMachines1 = true
        } else {
            electricalMachines1 = false
        }
        
        if elecCircuitsMarks >= subPassMarks
        {
            electricalCircuits = true
        } else {
            electricalCircuits = false
        }
        
        if basicFMHMLabMarks >= labPassMarks
        {
            basicFMHMLab = true
        } else {
            basicFMHMLab = false
        }
        
        if  electronicDevCirsLabMarks >= labPassMarks
        {
            electronicDevicesAndCircuitsLab = true
        } else {
            electronicDevicesAndCircuitsLab = false
        }
        
        // Total 2nd Year 1st Sem pass or fail with grade
        
        if (mathematics3 == true && environmentalScience == true && basicFMHM == true && electronicDevicesAndCircuits == true && electricalMachines1 == true && electricalCircuits == true && basicFMHMLab == true && electronicDevicesAndCircuitsLab == true)
        {
            switch firstSemPercentage
            {
            case 90...100:
                gradeLbl.text = "A"
            case 75..<90:
                gradeLbl.text = "B"
            case 50..<75:
                gradeLbl.text = "C"
            case 35..<50:
                gradeLbl.text = "D"
            default:
                gradeLbl.text = "E"
            }
            statusLbl.text = "PASSED"
            
        }
        else
        {
            statusLbl.text = "FAILED"
        }
        
        
    }
}
