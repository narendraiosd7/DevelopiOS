//
//  BtechSecondYearSecondSemMarks.swift
//  DataTransferthroughPresent
//
//  Created by Vadde Narendra on 11/11/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class BtechSecondYearSecondSemMarks: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var EMFMarksTF: UITextField!
    @IBOutlet weak var GEPMarksTF: UITextField!
    @IBOutlet weak var AECMarksTF: UITextField!
    @IBOutlet weak var STLDMarksTF: UITextField!
    @IBOutlet weak var NTMarksTF: UITextField!
    @IBOutlet weak var EM2MarksTF: UITextField!
    @IBOutlet weak var EM1LabMarksTF: UITextField!
    @IBOutlet weak var ECSLabMarksTF: UITextField!
    
    var btech22Marks = BtechQualificationDetails()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        EMFMarksTF.delegate = self
        GEPMarksTF.delegate = self
        AECMarksTF.delegate = self
        STLDMarksTF.delegate = self
        NTMarksTF.delegate = self
        EM2MarksTF.delegate = self
        EM1LabMarksTF.delegate = self
        ECSLabMarksTF.delegate = self

        EMFMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        GEPMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        AECMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        STLDMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        NTMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        EM2MarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        EM1LabMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        ECSLabMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        
        EMFMarksTF.keyboardType = .numberPad
        GEPMarksTF.keyboardType = .numberPad
        AECMarksTF.keyboardType = .numberPad
        STLDMarksTF.keyboardType = .numberPad
        NTMarksTF.keyboardType = .numberPad
        EM2MarksTF.keyboardType = .numberPad
        EM1LabMarksTF.keyboardType = .numberPad
        ECSLabMarksTF.keyboardType = .numberPad
        
        // Do any additional setup after loading the view.
    }
    
    func isValidMarks(marksStr:String) -> Bool
    {
        
        let marksRegEx = "[0-9]{1,3}"
        
        let marksPred = NSPredicate(format:"SELF MATCHES %@", marksRegEx)
        return marksPred.evaluate(with: marksStr)
    }
    
    
    var returValue = false
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool
    {
        if (textField == EMFMarksTF)
        {
            returValue = true
        }
        else if (textField == GEPMarksTF)
        {
            if (Int(EMFMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == AECMarksTF)
        {
            if (Int(GEPMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == STLDMarksTF)
        {
            if (Int(AECMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == NTMarksTF)
        {
            if (Int(STLDMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == EM2MarksTF)
        {
            if (Int(NTMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == EM1LabMarksTF)
        {
            if (Int(EM2MarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == ECSLabMarksTF)
        {
            if (Int(EM1LabMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        
        return returValue
    }
    
    
    
    func textFieldDidBeginEditing(_ textField: UITextField)
    {
        textField.backgroundColor = UIColor.red
    }
    
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool
    {
        if (textField == EMFMarksTF ||
            textField == GEPMarksTF ||
            textField == AECMarksTF ||
            textField == STLDMarksTF ||
            textField == NTMarksTF ||
            textField == EM2MarksTF ||
            textField == EM1LabMarksTF ||
            textField == ECSLabMarksTF)
        {
            returValue = isValidMarks(marksStr: textField.text!)
        }
        
        return returValue
    }
    
    
    
    func textFieldDidEndEditing(_ textField: UITextField)
    {
        textField.backgroundColor = UIColor.white
    }
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool
    {
        return true
    }

    //event handler for marks
    
    @objc func marksValidation(obj:UITextField)
    {
        if(obj.text != "")
        {
            if(Int(obj.text!)!>100)
            {
                obj.text = ""
            }
        }
    }
    @IBAction func btnTap(_ sender: UIButton) {
        
        dismiss(animated: true) {
            
            self.btech22Marks.btech2ndYear2ndSemMarks.append(self.EMFMarksTF.text!)
            self.btech22Marks.btech2ndYear2ndSemMarks.append(self.GEPMarksTF.text!)
            self.btech22Marks.btech2ndYear2ndSemMarks.append(self.AECMarksTF.text!)
            self.btech22Marks.btech2ndYear2ndSemMarks.append(self.STLDMarksTF.text!)
            self.btech22Marks.btech2ndYear2ndSemMarks.append(self.NTMarksTF.text!)
            self.btech22Marks.btech2ndYear2ndSemMarks.append(self.EM2MarksTF.text!)
            self.btech22Marks.btech2ndYear2ndSemMarks.append(self.EM1LabMarksTF.text!)
            self.btech22Marks.btech2ndYear2ndSemMarks.append(self.ECSLabMarksTF.text!)
          
        }
    }
    
}
