//
//  BtechSecondYearSecondSemResult.swift
//  DataTransferthroughPresent
//
//  Created by Vadde Narendra on 11/12/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class BtechSecondYearSecondSemResult: UIViewController {

    @IBOutlet weak var EMFLbl: UILabel!
    @IBOutlet weak var GEPLbl: UILabel!
    @IBOutlet weak var AECLbl: UILabel!
    @IBOutlet weak var STLDLbl: UILabel!
    @IBOutlet weak var NTLbl: UILabel!
    @IBOutlet weak var EM2Lbl: UILabel!
    @IBOutlet weak var EMLab1Lbl: UILabel!
    @IBOutlet weak var ECSimLabLbl: UILabel!
    @IBOutlet weak var totalMarksLbl: UILabel!
    @IBOutlet weak var statusLbl: UILabel!
    @IBOutlet weak var percentageLbl: UILabel!
    @IBOutlet weak var gradeLbl: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

//        cal2ndYear2ndSemBtechResults(EMFMarks: Int(EMFLbl.text!)!, GEPMarks: Int(GEPLbl.text!)!, AECMarks: Int(AECLbl.text!)!, STLDMarks: Int(STLDLbl.text!)!, NTMarks: Int(NTLbl.text!)!, EM2Marks: Int(EM2Lbl.text!)!, EM1LabMarks: Int(EMLab1Lbl.text!)!, ECSLabMarks: Int(ECSimLabLbl.text!)!)
        
        // Do any additional setup after loading the view.
    }
    

    func cal2ndYear2ndSemBtechResults(EMFMarks:Int,GEPMarks:Int,AECMarks:Int,STLDMarks:Int,NTMarks:Int,EM2Marks:Int,EM1LabMarks:Int,ECSLabMarks:Int)
    {
        // Calculating Total Marks
        
        let secondYear2ndSemGainedMarks:Int = Int(EMFMarks)+Int(GEPMarks)+Int(AECMarks)+Int(STLDMarks)+Int(EM2Marks)+Int(NTMarks)+Int(EM1LabMarks)+Int(ECSLabMarks)
        
        totalMarksLbl.text = "\(secondYear2ndSemGainedMarks)"
        
        // Calculating Percentage
        
        let totalMarks2ndSem:Float = 750
        
        let secondSemGainedMarks:Float = Float(secondYear2ndSemGainedMarks)
        
        let secondSemPercentage:Float = (secondSemGainedMarks/totalMarks2ndSem)*100
        
        percentageLbl.text = "\(secondSemPercentage)"
        
        // finding out subject wise pass or fail
        
        let subPassMarks:UInt8 = 35
        let labPassMarks:UInt8 = 27
        
        var electroMagneticField:Bool = false
        var generationofElectricalPower:Bool = false
        var analogElectroniccsAndCircuts:Bool = false
        var switchingThoeryAndLogicalDesign:Bool = false
        var electricalMachines2:Bool = false
        var NetworkTheory:Bool = false
        var electricalMachines1Lab:Bool = false
        var electricalCircuitsAndSimulationLab:Bool = false
        
        if EMFMarks >= subPassMarks
        {
            electroMagneticField = true
        } else {
            electroMagneticField = false
        }
        
        if GEPMarks >= subPassMarks
        {
            generationofElectricalPower = true
        } else {
            generationofElectricalPower = false
        }
        
        if AECMarks >= subPassMarks
        {
            analogElectroniccsAndCircuts = true
        } else {
            analogElectroniccsAndCircuts = false
        }
        
        if STLDMarks >= subPassMarks
        {
            switchingThoeryAndLogicalDesign = true
        } else {
            switchingThoeryAndLogicalDesign = false
        }
        
        if EM2Marks >= subPassMarks
        {
            electricalMachines2 = true
        } else {
            electricalMachines2 = false
        }
        
        if NTMarks >= subPassMarks
        {
            NetworkTheory = true
        } else {
            NetworkTheory = false
        }
        
        if EM1LabMarks >= labPassMarks
        {
            electricalMachines1Lab = true
        } else {
            electricalMachines1Lab = false
        }
        
        if  ECSLabMarks >= labPassMarks
        {
            electricalCircuitsAndSimulationLab = true
        } else {
            electricalCircuitsAndSimulationLab = false
        }
        
        // Total 2nd Year 2nd Sem pass or fail with grade
        
        
        if (electroMagneticField == true && generationofElectricalPower == true && switchingThoeryAndLogicalDesign == true && analogElectroniccsAndCircuts == true && electricalMachines2 == true && NetworkTheory == true && electricalMachines1Lab == true && electricalCircuitsAndSimulationLab == true)
        {
            switch secondSemPercentage
            {
            case 90...100:
                gradeLbl.text = "A"
            case 75..<90:
                gradeLbl.text = "B"
            case 50..<75:
                gradeLbl.text = "C"
            case 35..<50:
                gradeLbl.text = "D"
            default:
                gradeLbl.text = "E"
            }
            statusLbl.text = "PASSED"
        }
        else
        {
            statusLbl.text = "FAILED"
        }
        
    }

}
