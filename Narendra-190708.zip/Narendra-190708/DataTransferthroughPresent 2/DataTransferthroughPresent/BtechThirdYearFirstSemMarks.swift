//
//  BtechThirdYearFirstSemMarks.swift
//  DataTransferthroughPresent
//
//  Created by Vadde Narendra on 11/11/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class BtechThirdYearFirstSemMarks: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var MEFAMarksTF: UITextField!
    @IBOutlet weak var EEMMarksTF: UITextField!
    @IBOutlet weak var TEPMarksTF: UITextField!
    @IBOutlet weak var CSMarksTF: UITextField!
    @IBOutlet weak var EM3MarksTF: UITextField!
    @IBOutlet weak var PEMarksTF: UITextField!
    @IBOutlet weak var EM2LabMarksTF: UITextField!
    @IBOutlet weak var CSSLabMarksTF: UITextField!
    
    var btech31Marks = BtechQualificationDetails()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        MEFAMarksTF.delegate = self
        EEMMarksTF.delegate = self
        TEPMarksTF.delegate = self
        CSMarksTF.delegate = self
        EM3MarksTF.delegate = self
        PEMarksTF.delegate = self
        EM2LabMarksTF.delegate = self
        CSSLabMarksTF.delegate = self

        MEFAMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        EEMMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        TEPMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        CSMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        EM3MarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        PEMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        EM2LabMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        CSSLabMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        
        MEFAMarksTF.keyboardType = .numberPad
        EEMMarksTF.keyboardType = .numberPad
        TEPMarksTF.keyboardType = .numberPad
        CSMarksTF.keyboardType = .numberPad
        EM3MarksTF.keyboardType = .numberPad
        PEMarksTF.keyboardType = .numberPad
        EM2LabMarksTF.keyboardType = .numberPad
        CSSLabMarksTF.keyboardType = .numberPad
        // Do any additional setup after loading the view.
    }
    
    
    func isValidMarks(marksStr:String) -> Bool
    {
        
        let marksRegEx = "[0-9]{1,3}"
        
        let marksPred = NSPredicate(format:"SELF MATCHES %@", marksRegEx)
        return marksPred.evaluate(with: marksStr)
    }
    
    
    var returValue = false
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool
    {
        if (textField == MEFAMarksTF)
        {
            returValue = true
        }
        else if (textField == EEMMarksTF)
        {
            if (Int(MEFAMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == TEPMarksTF)
        {
            if (Int(EEMMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == CSMarksTF)
        {
            if (Int(TEPMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == EM3MarksTF)
        {
            if (Int(CSMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == PEMarksTF)
        {
            if (Int(EM3MarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == EM2LabMarksTF)
        {
            if (Int(PEMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == CSSLabMarksTF)
        {
            if (Int(EM2LabMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        
        return returValue
    }
    
    
    
    func textFieldDidBeginEditing(_ textField: UITextField)
    {
        textField.backgroundColor = UIColor.red
    }
    
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool
    {
        if (textField == MEFAMarksTF ||
            textField == EEMMarksTF ||
            textField == TEPMarksTF ||
            textField == CSMarksTF ||
            textField == EM3MarksTF ||
            textField == PEMarksTF ||
            textField == EM2LabMarksTF ||
            textField == CSSLabMarksTF)
        {
            returValue = isValidMarks(marksStr: textField.text!)
        }
        
        return returValue
    }
    
    
    
    func textFieldDidEndEditing(_ textField: UITextField)
    {
        textField.backgroundColor = UIColor.white
    }
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool
    {
        return true
    }

    //event handler for marks
    
    @objc func marksValidation(obj:UITextField)
    {
        if(obj.text != "")
        {
            if(Int(obj.text!)!>100)
            {
                obj.text = ""
            }
        }
    }
    @IBAction func btnTapped(_ sender: UIButton) {
        
        dismiss(animated: true) {
            
            self.btech31Marks.btech3rdYear1stSemMarks.append(self.MEFAMarksTF.text!)
            self.btech31Marks.btech3rdYear1stSemMarks.append(self.EEMMarksTF.text!)
            self.btech31Marks.btech3rdYear1stSemMarks.append(self.TEPMarksTF.text!)
            self.btech31Marks.btech3rdYear1stSemMarks.append(self.CSMarksTF.text!)
            self.btech31Marks.btech3rdYear1stSemMarks.append(self.EM3MarksTF.text!)
            self.btech31Marks.btech3rdYear1stSemMarks.append(self.PEMarksTF.text!)
            self.btech31Marks.btech3rdYear1stSemMarks.append(self.EM2LabMarksTF.text!)
            self.btech31Marks.btech3rdYear1stSemMarks.append(self.CSSLabMarksTF.text!)
            
        }
    }
    
}
