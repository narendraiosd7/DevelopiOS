//
//  BtechThirdYearFirstSemResult.swift
//  DataTransferthroughPresent
//
//  Created by Vadde Narendra on 11/12/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class BtechThirdYearFirstSemResult: UIViewController {

    @IBOutlet weak var MEFALbl: UILabel!
    @IBOutlet weak var EEMLbl: UILabel!
    @IBOutlet weak var TEPLbl: UILabel!
    @IBOutlet weak var CSLbl: UILabel!
    @IBOutlet weak var EM3Lbl: UILabel!
    @IBOutlet weak var PELbl: UILabel!
    @IBOutlet weak var EMLab2Lbl: UILabel!
    @IBOutlet weak var CSSimLabLbl: UILabel!
    @IBOutlet weak var totalMarksLbl: UILabel!
    @IBOutlet weak var statusLbl: UILabel!
    @IBOutlet weak var percentageLbl: UILabel!
    @IBOutlet weak var gradeLbl: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

//        cal3rdYear1stSemBtechResults(MEFAMarks: Int(MEFALbl.text!)!, EEMMarks: Int(EEMLbl.text!)!, TEPMarks: Int(TEPLbl.text!)!, CSMarks: Int(CSLbl.text!)!, PEMarks: Int(PELbl.text!)!, EM3Marks: Int(EM3Lbl.text!)!, EMLab2Marks: Int(EMLab2Lbl.text!)!, CSSimLabMarks: Int(CSSimLabLbl.text!)!)
        
        // Do any additional setup after loading the view.
    }
    
    func cal3rdYear1stSemBtechResults(MEFAMarks:Int,EEMMarks:Int,TEPMarks:Int,CSMarks:Int,PEMarks:Int,EM3Marks:Int,EMLab2Marks:Int,CSSimLabMarks:Int)
    {
        // Calculating Total Marks
        
        let thirdYear1stSemGainedMarks:Int = Int(MEFAMarks)+Int(EEMMarks)+Int(TEPMarks)+Int(CSMarks)+Int(PEMarks)+Int(EM3Marks)+Int(EMLab2Marks)+Int(CSSimLabMarks)
        
        totalMarksLbl.text = "\(thirdYear1stSemGainedMarks)"
        
        // Calculating Percentage
        
        let totalMarks1stSem:Float = 750
        
        let firstSemGainedMarks:Float = Float(thirdYear1stSemGainedMarks)
        
        let firstSemPercentage:Float = (firstSemGainedMarks/totalMarks1stSem)*100
        
        percentageLbl.text = "\(firstSemPercentage)"
        
        // finding out subject wise pass or fail
        
        let subPassMarks:Int = 35
        let labPassMarks:Int = 27
        
        var managerialEconomicsAndFinancialAnalysis:Bool = false
        var electricalAndElectronicsMeasurements:Bool = false
        var transmissionOfELectricalPower:Bool = false
        var controlSystems:Bool = false
        var powerElectronics:Bool = false
        var electricalMachines3:Bool = false
        var electricalMachinesLab2:Bool = false
        var controlSystemsAndSimulationLab:Bool = false
        
        if MEFAMarks >= subPassMarks
        {
            managerialEconomicsAndFinancialAnalysis = true
        } else {
            managerialEconomicsAndFinancialAnalysis = false
        }
        
        if EEMMarks >= subPassMarks
        {
            electricalAndElectronicsMeasurements = true
        } else {
            electricalAndElectronicsMeasurements = false
        }
        
        if TEPMarks >= subPassMarks
        {
            transmissionOfELectricalPower = true
        } else {
            transmissionOfELectricalPower = false
        }
        
        if CSMarks >= subPassMarks
        {
            controlSystems = true
        } else {
            controlSystems = false
        }
        
        if PEMarks >= subPassMarks
        {
            powerElectronics = true
        } else {
            powerElectronics = false
        }
        
        if EM3Marks >= subPassMarks
        {
            electricalMachines3 = true
        } else {
            electricalMachines3 = false
        }
        
        if EMLab2Marks >= labPassMarks
        {
            electricalMachinesLab2 = true
        } else {
            electricalMachinesLab2 = false
        }
        
        if  CSSimLabMarks >= labPassMarks
        {
            controlSystemsAndSimulationLab = true
        } else {
            controlSystemsAndSimulationLab = false
        }
        
        // Total 3rd Year 1st Sem pass or fail with grade
        
        if (managerialEconomicsAndFinancialAnalysis == true && electricalAndElectronicsMeasurements == true && transmissionOfELectricalPower == true && controlSystems == true && powerElectronics == true && electricalMachines3 == true && electricalMachinesLab2 == true && controlSystemsAndSimulationLab == true)
        {
            switch firstSemPercentage
            {
            case 90...100:
                gradeLbl.text = "A"
            case 75..<90:
                gradeLbl.text = "B"
            case 50..<75:
                gradeLbl.text = "C"
            case 35..<50:
                gradeLbl.text = "D"
            default:
                gradeLbl.text = "E"
            }
            statusLbl.text = "PASSED"
        }
        else
        {
            statusLbl.text = "FAILED"
        }
        
    }

}
