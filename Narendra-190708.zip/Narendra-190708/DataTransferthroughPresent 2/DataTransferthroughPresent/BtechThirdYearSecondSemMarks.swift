//
//  BtechThirdYearSecondSemMarks.swift
//  DataTransferthroughPresent
//
//  Created by Vadde Narendra on 11/11/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class BtechThirdYearSecondSemMarks: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var MSMarksTF: UITextField!
    @IBOutlet weak var PSDMarksTF: UITextField!
    @IBOutlet weak var PSAMarksTF: UITextField!
    @IBOutlet weak var MPMCMarksTF: UITextField!
    @IBOutlet weak var PSOCMarksTF: UITextField!
    @IBOutlet weak var LDICMarksTF: UITextField!
    @IBOutlet weak var AECSLabMarksTF: UITextField!
    @IBOutlet weak var EMLabMarksTF: UITextField!
    
    var btech32Marks = BtechQualificationDetails()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        MSMarksTF.delegate = self
        PSDMarksTF.delegate = self
        PSAMarksTF.delegate = self
        MPMCMarksTF.delegate = self
        PSOCMarksTF.delegate = self
        LDICMarksTF.delegate = self
        AECSLabMarksTF.delegate = self
        EMLabMarksTF.delegate = self

        MSMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        PSDMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        PSAMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        MPMCMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        PSOCMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        LDICMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        AECSLabMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        EMLabMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        
        MSMarksTF.keyboardType = .numberPad
        PSDMarksTF.keyboardType = .numberPad
        PSAMarksTF.keyboardType = .numberPad
        MPMCMarksTF.keyboardType = .numberPad
        PSOCMarksTF.keyboardType = .numberPad
        LDICMarksTF.keyboardType = .numberPad
        AECSLabMarksTF.keyboardType = .numberPad
        EMLabMarksTF.keyboardType = .numberPad
        // Do any additional setup after loading the view.
    }

    func isValidMarks(marksStr:String) -> Bool
    {
        
        let marksRegEx = "[0-9]{1,3}"
        
        let marksPred = NSPredicate(format:"SELF MATCHES %@", marksRegEx)
        return marksPred.evaluate(with: marksStr)
    }
    
    
    var returValue = false
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool
    {
        if (textField == MSMarksTF)
        {
            returValue = true
        }
        else if (textField == PSDMarksTF)
        {
            if (Int(MSMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == PSAMarksTF)
        {
            if (Int(PSDMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == MPMCMarksTF)
        {
            if (Int(PSAMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == PSOCMarksTF)
        {
            if (Int(MPMCMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == LDICMarksTF)
        {
            if (Int(PSOCMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == AECSLabMarksTF)
        {
            if (Int(LDICMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == EMLabMarksTF)
        {
            if (Int(AECSLabMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        
        return returValue
    }
    
    
    
    func textFieldDidBeginEditing(_ textField: UITextField)
    {
        textField.backgroundColor = UIColor.red
    }
    
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool
    {
        if (textField == MSMarksTF ||
            textField == PSDMarksTF ||
            textField == PSAMarksTF ||
            textField == MPMCMarksTF ||
            textField == PSOCMarksTF ||
            textField == LDICMarksTF ||
            textField == AECSLabMarksTF ||
            textField == EMLabMarksTF)
        {
            returValue = isValidMarks(marksStr: textField.text!)
        }
        
        return returValue
    }
    
    
    
    func textFieldDidEndEditing(_ textField: UITextField)
    {
        textField.backgroundColor = UIColor.white
    }
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool
    {
        return true
    }

    //event handler for marks
    
    @objc func marksValidation(obj:UITextField)
    {
        if(obj.text != "")
        {
            if(Int(obj.text!)!>100)
            {
                obj.text = ""
            }
        }
    }
    @IBAction func btnTap(_ sender: UIButton) {
        
        dismiss(animated: true) {
            
            self.btech32Marks.btech3rdYear2ndSemMarks.append(self.MSMarksTF.text!)
            self.btech32Marks.btech3rdYear2ndSemMarks.append(self.PSDMarksTF.text!)
            self.btech32Marks.btech3rdYear2ndSemMarks.append(self.PSAMarksTF.text!)
            self.btech32Marks.btech3rdYear2ndSemMarks.append(self.MPMCMarksTF.text!)
            self.btech32Marks.btech3rdYear2ndSemMarks.append(self.PSOCMarksTF.text!)
            self.btech32Marks.btech3rdYear2ndSemMarks.append(self.LDICMarksTF.text!)
            self.btech32Marks.btech3rdYear2ndSemMarks.append(self.AECSLabMarksTF.text!)
            self.btech32Marks.btech3rdYear2ndSemMarks.append(self.EMLabMarksTF.text!)
            
        }
    }
    
}
