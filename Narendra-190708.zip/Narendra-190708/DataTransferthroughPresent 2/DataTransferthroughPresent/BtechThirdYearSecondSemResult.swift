//
//  BtechThirdYearSecondSemResult.swift
//  DataTransferthroughPresent
//
//  Created by Vadde Narendra on 11/12/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class BtechThirdYearSecondSemResult: UIViewController {

    @IBOutlet weak var MSLbl: UILabel!
    @IBOutlet weak var PSDLbl: UILabel!
    @IBOutlet weak var PSALbl: UILabel!
    @IBOutlet weak var MPMCLbl: UILabel!
    @IBOutlet weak var PSOCLbl: UILabel!
    @IBOutlet weak var LDICALbl: UILabel!
    @IBOutlet weak var AECSLabLbl: UILabel!
    @IBOutlet weak var EMLabLbl: UILabel!
    @IBOutlet weak var totalMarksLbl: UILabel!
    @IBOutlet weak var statusLbl: UILabel!
    @IBOutlet weak var percentageLbl: UILabel!
    @IBOutlet weak var gradeLbl: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

//        cal3rdYear2ndSemBtechResults(MSMarks: Int(MSLbl.text!)!, PSDMarks: Int(PSDLbl.text!)!, PSAMarks: Int(PSALbl.text!)!, MPMCMarks: Int(MPMCLbl.text!)!, PSOCMarks: Int(PSOCLbl.text!)!, LDICAMarks: Int(LDICALbl.text!)!, AECSLLabMarks: Int(AECSLabLbl.text!)!, EMLabMarks: Int(EMLabLbl.text!)!)
        
        // Do any additional setup after loading the view.
    }
    

    func cal3rdYear2ndSemBtechResults(MSMarks:Int,PSDMarks:Int,PSAMarks:Int,MPMCMarks:Int,PSOCMarks:Int,LDICAMarks:Int,AECSLLabMarks:Int,EMLabMarks:Int)
    {
        // Calculating Total Marks
        
        let thirdYear2ndSemGainedMarks:Int = Int(MSMarks)+Int(PSDMarks)+Int(PSAMarks)+Int(MPMCMarks)+Int(PSOCMarks)+Int(LDICAMarks)+Int(AECSLLabMarks)+Int(EMLabMarks)
        
        totalMarksLbl.text = "\(thirdYear2ndSemGainedMarks)"
        
        // Calculating Percentage
        
        let totalMarks2ndSem:Float = 750
        
        let secondSemGainedMarks:Float = Float(thirdYear2ndSemGainedMarks)
        
        let secondSemPercentage:Float = (secondSemGainedMarks/totalMarks2ndSem)*100
        
        percentageLbl.text = "\(secondSemPercentage)"
        
        // finding out subject wise pass or fail
        
        let subPassMarks:Int = 35
        let labPassMarks:Int = 27
        
        var managementScience:Bool = false
        var powerSemiconductorDrives:Bool = false
        var powerSystemAnalysis:Bool = false
        var microprocessorsAndMicrocontrollers:Bool = false
        var powerOperationsAndControl:Bool = false
        var linearAndDigitalICApplications:Bool = false
        var advancedEnglishCommunicationSkillsLab:Bool = false
        var electricalMeasurementsLab:Bool = false
        
        if MSMarks >= subPassMarks
        {
            managementScience = true
        } else {
            managementScience = false
        }
        
        if PSDMarks >= subPassMarks
        {
            powerSemiconductorDrives = true
        } else {
            powerSemiconductorDrives = false
        }
        
        if PSAMarks >= subPassMarks
        {
            powerSystemAnalysis = true
        } else {
            powerSystemAnalysis = false
        }
        
        if MPMCMarks >= subPassMarks
        {
            microprocessorsAndMicrocontrollers = true
        } else {
            microprocessorsAndMicrocontrollers = false
        }
        
        if PSOCMarks >= subPassMarks
        {
            powerOperationsAndControl = true
        } else {
            powerOperationsAndControl = false
        }
        
        if LDICAMarks >= subPassMarks
        {
            linearAndDigitalICApplications = true
        } else {
            linearAndDigitalICApplications = false
        }
        
        if AECSLLabMarks >= labPassMarks
        {
            advancedEnglishCommunicationSkillsLab = true
        } else {
            advancedEnglishCommunicationSkillsLab = false
        }
        
        if  EMLabMarks >= labPassMarks
        {
            electricalMeasurementsLab = true
        } else {
            electricalMeasurementsLab = false
        }
        
        // Total 3rd Year 2nd Sem pass or fail with grade
        
        if (managementScience == true && powerSemiconductorDrives == true && powerSystemAnalysis == true && microprocessorsAndMicrocontrollers == true && powerOperationsAndControl == true && linearAndDigitalICApplications == true && electricalMeasurementsLab == true && advancedEnglishCommunicationSkillsLab == true)
        {
            switch secondSemPercentage
            {
            case 90...100:
                gradeLbl.text = "A"
            case 75..<90:
                gradeLbl.text = "B"
            case 50..<75:
                gradeLbl.text = "C"
            case 35..<50:
                gradeLbl.text = "D"
            default:
                gradeLbl.text = "E"
            }
            statusLbl.text = "PASSED"
        }
        else
        {
            statusLbl.text = "FAILED"
        }
    }
}
