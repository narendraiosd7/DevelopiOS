//
//  FinalYearFirstSemMarks.swift
//  DataTransferthroughPresent
//
//  Created by Vadde Narendra on 11/11/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class DiplomaFinalYearFirstSemMarks: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var firstAssigMarksTF: UITextField!
    @IBOutlet weak var secondAssignMarksTF: UITextField!
    @IBOutlet weak var logBookMarksTF: UITextField!
    @IBOutlet weak var recordMarksTF: UITextField!
    @IBOutlet weak var seminarMarksTF: UITextField!
    
    var diploma31Marks = DiplomaQualificationDetails()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        firstAssigMarksTF.delegate = self
        secondAssignMarksTF.delegate = self
        logBookMarksTF.delegate = self
        recordMarksTF.delegate = self
        seminarMarksTF.delegate = self
        
        firstAssigMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        secondAssignMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        logBookMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        recordMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        seminarMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        
        firstAssigMarksTF.keyboardType = .numberPad
        secondAssignMarksTF.keyboardType = .numberPad
        logBookMarksTF.keyboardType = .numberPad
        recordMarksTF.keyboardType = .numberPad
        seminarMarksTF.keyboardType = .numberPad
        
    }
    
    func isValidMarks(marksStr:String) -> Bool
    {
        
        let marksRegEx = "[0-9]{1,3}"
        
        let marksPred = NSPredicate(format:"SELF MATCHES %@", marksRegEx)
        return marksPred.evaluate(with: marksStr)
    }
    
    var returValue = false
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool
    {
        if (textField == firstAssigMarksTF)
        {
            returValue = true
        }
        else if (textField == secondAssignMarksTF)
        {
            if (Int(firstAssigMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == logBookMarksTF)
        {
            if (Int(secondAssignMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == recordMarksTF)
        {
            if (Int(logBookMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == seminarMarksTF)
        {
            if (Int(recordMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        
        return returValue
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField)
    {
        textField.backgroundColor = UIColor.red
    }
    
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool
    {
        if (textField == firstAssigMarksTF ||
            textField == secondAssignMarksTF ||
            textField == logBookMarksTF ||
            textField == recordMarksTF ||
            textField == seminarMarksTF)
        {
            returValue = isValidMarks(marksStr: textField.text!)
        }
        
        return returValue
    }
    
    
    
    func textFieldDidEndEditing(_ textField: UITextField)
    {
        textField.backgroundColor = UIColor.white
    }
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool
    {
        return true
    }

    //event handler for marks
    
    @objc func marksValidation(obj:UITextField)
    {
        if(obj.text != "")
        {
            if(Int(obj.text!)!>100)
            {
                obj.text = ""
            }
        }
    }

    @IBAction func subBtnTap(_ sender: UIButton)
    {
        dismiss(animated: true) {
            
            self.diploma31Marks.diploma3rdYear1tSemMarks.append(self.firstAssigMarksTF.text!)
            self.diploma31Marks.diploma3rdYear1tSemMarks.append(self.secondAssignMarksTF.text!)
            self.diploma31Marks.diploma3rdYear1tSemMarks.append(self.logBookMarksTF.text!)
            self.diploma31Marks.diploma3rdYear1tSemMarks.append(self.recordMarksTF.text!)
            self.diploma31Marks.diploma3rdYear1tSemMarks.append(self.seminarMarksTF.text!)
 
        }
    }
}
