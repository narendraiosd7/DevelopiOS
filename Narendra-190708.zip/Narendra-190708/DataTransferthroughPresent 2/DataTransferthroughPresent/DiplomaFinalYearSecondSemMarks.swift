//
//  DiplomaFinalYearSecondSemMarks.swift
//  DataTransferthroughPresent
//
//  Created by Vadde Narendra on 11/11/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class DiplomaFinalYearSecondSemMarks: UIViewController, UITextFieldDelegate {

    
    @IBOutlet weak var english4MarksTF: UITextField!
    @IBOutlet weak var IMEMarksTF: UITextField!
    @IBOutlet weak var ACMC2MarksTF: UITextField!
    @IBOutlet weak var PEMarksTF: UITextField!
    @IBOutlet weak var ETPLCMarksTF: UITextField!
    @IBOutlet weak var PS2MarksTF: UITextField!
    @IBOutlet weak var ACMC2LabMarksTF: UITextField!
    @IBOutlet weak var PELabMarksTF: UITextField!
    @IBOutlet weak var ECADLabMarksTF: UITextField!
    @IBOutlet weak var automationLabMarksTF: UITextField!
    @IBOutlet weak var projectWorkMarksTF: UITextField!
    
    var diploma32Marks = DiplomaQualificationDetails()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        english4MarksTF.delegate = self
        IMEMarksTF.delegate = self
        ACMC2MarksTF.delegate = self
        PEMarksTF.delegate = self
        ETPLCMarksTF.delegate = self
        PS2MarksTF.delegate = self
        ACMC2LabMarksTF.delegate = self
        ECADLabMarksTF.delegate = self
        automationLabMarksTF.delegate = self
        projectWorkMarksTF.delegate = self
        
        english4MarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        IMEMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        ACMC2MarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        PEMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        ETPLCMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        PS2MarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        ACMC2LabMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        ECADLabMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        automationLabMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        projectWorkMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        
        english4MarksTF.keyboardType = .numberPad
        IMEMarksTF.keyboardType = .numberPad
        ACMC2MarksTF.keyboardType = .numberPad
        PEMarksTF.keyboardType = .numberPad
        ETPLCMarksTF.keyboardType = .numberPad
        PS2MarksTF.keyboardType = .numberPad
        ACMC2LabMarksTF.keyboardType = .numberPad
        ECADLabMarksTF.keyboardType = .numberPad
        automationLabMarksTF.keyboardType = .numberPad
        projectWorkMarksTF.keyboardType = .numberPad
    }
    
    
    func isValidMarks(marksStr:String) -> Bool
    {
        
        let marksRegEx = "[0-9]{1,3}"
        
        let marksPred = NSPredicate(format:"SELF MATCHES %@", marksRegEx)
        return marksPred.evaluate(with: marksStr)
    }
    
    
    var returValue = false
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool
    {
        if (textField == english4MarksTF)
        {
            returValue = true
        }
        else if (textField == IMEMarksTF)
        {
            if (Int(english4MarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == ACMC2MarksTF)
        {
            if (Int(IMEMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == PEMarksTF)
        {
            if (Int(ACMC2MarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == ETPLCMarksTF)
        {
            if (Int(PEMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == PS2MarksTF)
        {
            if (Int(ETPLCMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == ACMC2LabMarksTF)
        {
            if (Int(PS2MarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == PELabMarksTF)
        {
            if (Int(ACMC2LabMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == ECADLabMarksTF)
        {
            if (Int(PELabMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == automationLabMarksTF)
        {
            if (Int(ECADLabMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == projectWorkMarksTF)
        {
            if (Int(automationLabMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        
        return returValue
    }
    
    
    
    func textFieldDidBeginEditing(_ textField: UITextField)
    {
        textField.backgroundColor = UIColor.red
    }
    
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool
    {
        if (textField == english4MarksTF ||
            textField == IMEMarksTF ||
            textField == ACMC2MarksTF ||
            textField == PEMarksTF ||
            textField == ETPLCMarksTF ||
            textField == PS2MarksTF ||
            textField == ACMC2LabMarksTF ||
            textField == PELabMarksTF ||
            textField == ECADLabMarksTF ||
            textField == automationLabMarksTF ||
            textField == projectWorkMarksTF)
        {
            returValue = isValidMarks(marksStr: textField.text!)
        }
        
        return returValue
    }
    
    
    
    func textFieldDidEndEditing(_ textField: UITextField)
    {
        textField.backgroundColor = UIColor.white
    }
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool
    {
        return true
    }

    //event handler for marks
    
    @objc func marksValidation(obj:UITextField)
    {
        if(obj.text != "")
        {
            if(Int(obj.text!)!>100)
            {
                obj.text = ""
            }
        }
    }
    
    @IBAction func subBtnTap(_ sender: UIButton)
    {
        dismiss(animated: true) {
            
            self.diploma32Marks.diploma3rdYear2ndSemMarks.append(self.english4MarksTF.text!)
            self.diploma32Marks.diploma3rdYear2ndSemMarks.append(self.IMEMarksTF.text!)
            self.diploma32Marks.diploma3rdYear2ndSemMarks.append(self.ACMC2MarksTF.text!)
            self.diploma32Marks.diploma3rdYear2ndSemMarks.append(self.PEMarksTF.text!)
            self.diploma32Marks.diploma3rdYear2ndSemMarks.append(self.ETPLCMarksTF.text!)
            self.diploma32Marks.diploma3rdYear2ndSemMarks.append(self.PS2MarksTF.text!)
            self.diploma32Marks.diploma3rdYear2ndSemMarks.append(self.ACMC2LabMarksTF.text!)
            self.diploma32Marks.diploma3rdYear2ndSemMarks.append(self.PELabMarksTF.text!)
            self.diploma32Marks.diploma3rdYear2ndSemMarks.append(self.ECADLabMarksTF.text!)
 
        }
    }
    
}
