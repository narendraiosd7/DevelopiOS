//
//  DiplomaFirstYearMarks.swift
//  DataTransferthroughPresent
//
//  Created by Vadde Narendra on 11/11/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class DiplomaFirstYearMarks: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var english1MarksTF: UITextField!
    @IBOutlet weak var enggMathsMarksTF: UITextField!
    @IBOutlet weak var enggPhysicsMarksTF: UITextField!
    @IBOutlet weak var enggChemMarksTF: UITextField!
    @IBOutlet weak var basicElecEnggMarksTF: UITextField!
    @IBOutlet weak var mechWorkshopMarksTF: UITextField!
    @IBOutlet weak var enggDrawingMarksTF: UITextField!
    @IBOutlet weak var physicsLabMarksTF: UITextField!
    @IBOutlet weak var chemistryLabMarksTF: UITextField!
    @IBOutlet weak var ITLabMarksTF: UITextField!
    @IBOutlet weak var elecWorkshopMarksTF: UITextField!
    
    
    var diploma1stYear = DiplomaQualificationDetails()

    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        english1MarksTF.delegate = self
        enggMathsMarksTF.delegate = self
        enggPhysicsMarksTF.delegate = self
        enggChemMarksTF.delegate = self
        basicElecEnggMarksTF.delegate = self
        mechWorkshopMarksTF.delegate = self
        enggDrawingMarksTF.delegate = self
        physicsLabMarksTF.delegate = self
        chemistryLabMarksTF.delegate = self
        ITLabMarksTF.delegate = self
        elecWorkshopMarksTF.delegate = self

        english1MarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        enggMathsMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        enggPhysicsMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        enggChemMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        basicElecEnggMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        mechWorkshopMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        enggDrawingMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        physicsLabMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        chemistryLabMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        ITLabMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        elecWorkshopMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
       
        
        english1MarksTF.keyboardType = .numberPad
        enggMathsMarksTF.keyboardType = .numberPad
        enggPhysicsMarksTF.keyboardType = .numberPad
        enggChemMarksTF.keyboardType = .numberPad
        basicElecEnggMarksTF.keyboardType = .numberPad
        mechWorkshopMarksTF.keyboardType = .numberPad
        enggDrawingMarksTF.keyboardType = .numberPad
        physicsLabMarksTF.keyboardType = .numberPad
        chemistryLabMarksTF.keyboardType = .numberPad
        ITLabMarksTF.keyboardType = .numberPad
        elecWorkshopMarksTF.keyboardType = .numberPad
        
    }
    
    // marks validation function
    
    func isValidMarks(marksStr:String) -> Bool
    {
        
        let marksRegEx = "[0-9]{1,3}"
        
        let marksPred = NSPredicate(format:"SELF MATCHES %@", marksRegEx)
        return marksPred.evaluate(with: marksStr)
    }
    
    
    var returValue = false
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool
    {
        if (textField == english1MarksTF)
        {
            returValue = true
        }
        else if (textField == enggMathsMarksTF)
        {
            if (Int(english1MarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == enggPhysicsMarksTF)
        {
            if (Int(enggMathsMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == enggChemMarksTF)
        {
            if (Int(enggPhysicsMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == basicElecEnggMarksTF)
        {
            if (Int(enggChemMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == mechWorkshopMarksTF)
        {
            if (Int(basicElecEnggMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == enggDrawingMarksTF)
        {
            if (Int(mechWorkshopMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == physicsLabMarksTF)
        {
            if (Int(enggDrawingMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == chemistryLabMarksTF)
        {
            if (Int(physicsLabMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == ITLabMarksTF)
        {
            if (Int(chemistryLabMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == elecWorkshopMarksTF)
        {
            if (Int(ITLabMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        
        return returValue
    }
    
    
    
    func textFieldDidBeginEditing(_ textField: UITextField)
    {
        textField.backgroundColor = UIColor.red
    }
    
    
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool
    {
        if (textField == english1MarksTF ||
            textField == enggMathsMarksTF ||
            textField == enggPhysicsMarksTF ||
            textField == enggChemMarksTF ||
            textField == basicElecEnggMarksTF ||
            textField == mechWorkshopMarksTF ||
            textField == enggDrawingMarksTF ||
            textField == physicsLabMarksTF ||
            textField == chemistryLabMarksTF ||
            textField == ITLabMarksTF ||
            textField == elecWorkshopMarksTF)
        {
            returValue = isValidMarks(marksStr: textField.text!)
        }
        
        return returValue
    }
    
    
    
    func textFieldDidEndEditing(_ textField: UITextField)
    {
        textField.backgroundColor = UIColor.white
        
//
        
    }
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool
    {
        return true
    }
    
    //event handler for marks
    
    @objc func marksValidation(obj:UITextField)
    {
        if(obj.text != "")
        {
            if(Int(obj.text!)!>100)
            {
                obj.text = ""
            }
        }
    }
    @IBAction func subBtnTapped(_ sender: UIButton)
    {
        dismiss(animated: true) {
            
            self.diploma1stYear.diploma1stYearMarks.append(self.english1MarksTF.text!)
            self.diploma1stYear.diploma1stYearMarks.append(self.enggMathsMarksTF.text!)
            self.diploma1stYear.diploma1stYearMarks.append(self.enggPhysicsMarksTF.text!)
            self.diploma1stYear.diploma1stYearMarks.append(self.enggChemMarksTF.text!)
            self.diploma1stYear.diploma1stYearMarks.append(self.basicElecEnggMarksTF.text!)
            self.diploma1stYear.diploma1stYearMarks.append(self.mechWorkshopMarksTF.text!)
            self.diploma1stYear.diploma1stYearMarks.append(self.enggDrawingMarksTF.text!)
            self.diploma1stYear.diploma1stYearMarks.append(self.physicsLabMarksTF.text!)
            self.diploma1stYear.diploma1stYearMarks.append(self.chemistryLabMarksTF.text!)
            self.diploma1stYear.diploma1stYearMarks.append(self.ITLabMarksTF.text!)
            self.diploma1stYear.diploma1stYearMarks.append(self.elecWorkshopMarksTF.text!)
            
        }
    }
    
}
