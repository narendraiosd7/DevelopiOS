//
//  DiplomaFirstYearResults.swift
//  DataTransferthroughPresent
//
//  Created by Vadde Narendra on 11/12/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class DiplomaFirstYearResults: UIViewController {

    @IBOutlet weak var eng1Lbl: UILabel!
    @IBOutlet weak var enggMaths1Lbl: UILabel!
    @IBOutlet weak var enggPhysicsLbl: UILabel!
    @IBOutlet weak var enggChemistryLb: UILabel!
    @IBOutlet weak var BEELbl: UILabel!
    @IBOutlet weak var MWLbl: UILabel!
    @IBOutlet weak var enggDrawingLbl: UILabel!
    @IBOutlet weak var physicsLabLbl: UILabel!
    @IBOutlet weak var chemistryLabLbl: UILabel!
    @IBOutlet weak var ITLabLbl: UILabel!
    @IBOutlet weak var EWLbl: UILabel!
    @IBOutlet weak var TMLbl: UILabel!
    @IBOutlet weak var statusLbl: UILabel!
    @IBOutlet weak var percentageLbl: UILabel!
    @IBOutlet weak var gradeLbl: UILabel!
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
