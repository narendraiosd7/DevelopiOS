//
//  DiplomaQualificationDetails.swift
//  DataTransferthroughPresent
//
//  Created by Vadde Narendra on 11/9/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class DiplomaQualificationDetails: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var firstYearMarksContainer: UIView!
    @IBOutlet weak var secondYearFirstSemMarksContainer: UIView!
    @IBOutlet weak var secondYearSecondSemMarksContainer: UIView!
    @IBOutlet weak var thirdYearFirstSemMarksContainer: UIView!
    @IBOutlet weak var thirdYearSecondSemMarksContainer: UIView!
  
    @IBOutlet weak var diplomaYearsSC: UISegmentedControl!
    @IBOutlet weak var secondYearSemSC: UISegmentedControl!
    @IBOutlet weak var thirdYearSemSC: UISegmentedControl!
    
    var personalDetails:[String] = []
    
    var diploma1stYearMarks:[String] = []
    var diploma2ndYear1tSemMarks:[String] = []
    var diploma2ndYear2ndSemMarks:[String] = []
    var diploma3rdYear1tSemMarks:[String] = []
    var diploma3rdYear2ndSemMarks:[String] = []
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
//        print(diploma2ndYear1tSemMarks[0])
        
    }
    
    
    @IBAction func diplomaYearWiseMarksSC(_ sender: UISegmentedControl)
    {
        
        switch sender.selectedSegmentIndex
        {
        case 0:
            
            let  diploma1 = self.storyboard?.instantiateViewController(withIdentifier: "diploma1st") as! DiplomaFirstYearMarks
            
            diploma1.diploma1stYear = self
            present(diploma1, animated: true, completion: nil)
            
        case 1:
            secondYearSemSC.isHidden = false
            secondYearFirstSemMarksContainer.isHidden = true
            firstYearMarksContainer.isHidden = true
            thirdYearFirstSemMarksContainer.isHidden = true
            thirdYearSecondSemMarksContainer.isHidden = true
            thirdYearSemSC.isHidden = true
        case 2:
            secondYearSemSC.isHidden = true
            thirdYearFirstSemMarksContainer.isHidden = true
            firstYearMarksContainer.isHidden = true
            secondYearFirstSemMarksContainer.isHidden = true
            secondYearSecondSemMarksContainer.isHidden = true
            thirdYearSemSC.isHidden = false
        default:
            print("Something went wrong")
        }
    }
    
    @IBAction func diplomaSecondYearSemisterWiseMarksSCTapped(_ sender: UISegmentedControl)
    {
        switch sender.selectedSegmentIndex
        {
        case 0:
            
            let  diploma21 = self.storyboard?.instantiateViewController(withIdentifier: "diploma21st") as! DiplomaSecondYearFirstSemMarks
            
            diploma21.diploma21marks = self
            present(diploma21, animated: true, completion: nil)
            
        case 1:
            
            let  diploma22 = self.storyboard?.instantiateViewController(withIdentifier: "diploma22nd") as! DiplomaSecondYearSecondSemMarks
            
            diploma22.diploma22Marks = self
            present(diploma22, animated: true, completion: nil)
            
        default:
            print("Something went wrong")
        }
    }
    
    @IBAction func diplomaThirdYearSemisterWiseMarksTapped(_ sender: UISegmentedControl)
    {
        switch sender.selectedSegmentIndex
        {
        case 0:
            
            let  diploma31 = self.storyboard?.instantiateViewController(withIdentifier: "diploma31st") as! DiplomaFinalYearFirstSemMarks
            
            diploma31.diploma31Marks = self
            present(diploma31, animated: true, completion: nil)
            
        case 1:
            
            let  diploma32 = self.storyboard?.instantiateViewController(withIdentifier: "diploma32nd") as! DiplomaFinalYearSecondSemMarks
            
            diploma32.diploma32Marks = self
            present(diploma32, animated: true, completion: nil)
            
        default:
            print("Something went wrong")
        }
    }
    
    @IBAction func diplomaNextBtnTapped(_ sender: UIButton)
    {
        let btechView = storyboard?.instantiateViewController(withIdentifier: "btechDetails") as! BtechQualificationDetails
        
        present(btechView, animated: true)
        {
            btechView.diploma1stYearMarksArray = self.diploma1stYearMarks
            btechView.personalDetailsArray = self.personalDetails
            btechView.diploma2ndYear1tSemMarksArray = self.diploma2ndYear1tSemMarks
            btechView.diploma2ndYear2ndSemMarksArray = self.diploma2ndYear2ndSemMarks
            btechView.diploma3rdYear1tSemMarksArray = self.diploma3rdYear1tSemMarks
            btechView.diploma3rdYear2ndSemMarksArray = self.diploma3rdYear2ndSemMarks
        }
        
      
//        btechView.btech2ndYear1stSemResult.m3Lbl.text = btechView.btech2ndYear1stSem.m3MarksTF.text
//        btechView.btech2ndYear1stSemResult.ESLbl.text =  btechView.btech2ndYear1stSem.ESMarksTF.text
//        btechView.btech2ndYear1stSemResult.FMHMLbl.text = btechView.btech2ndYear1stSem.FMHMMarksTF.text
//        btechView.btech2ndYear1stSemResult.EDCLbl.text =  btechView.btech2ndYear1stSem.EDCMarksTF.text
//        btechView.btech2ndYear1stSemResult.machines1Lbl.text = btechView.btech2ndYear1stSem.ECMarksTF.text
//        btechView.btech2ndYear1stSemResult.ECLbl.text = btechView.btech2ndYear1stSem.EM1MarksTF.text
//        btechView.btech2ndYear1stSemResult.FMHMLabLbl.text = btechView.btech2ndYear1stSem.FMHMLabMarksTF.text
//        btechView.btech2ndYear1stSemResult.EDCLabLbl.text = btechView.btech2ndYear1stSem.EDCLabMarksTF.text
//
//        btechView.btech2ndYear2ndSemResult.EMFLbl.text = btechView.btech2ndYear2ndSem.EMFMarksTF.text
//        btechView.btech2ndYear2ndSemResult.GEPLbl.text = btechView.btech2ndYear2ndSem.GEPMarksTF.text
//        btechView.btech2ndYear2ndSemResult.AECLbl.text = btechView.btech2ndYear2ndSem.AECMarksTF.text
//        btechView.btech2ndYear2ndSemResult.STLDLbl.text = btechView.btech2ndYear2ndSem.STLDMarksTF.text
//        btechView.btech2ndYear2ndSemResult.NTLbl.text = btechView.btech2ndYear2ndSem.NTMarksTF.text
//        btechView.btech2ndYear2ndSemResult.EM2Lbl.text = btechView.btech2ndYear2ndSem.EM2MarksTF.text
//        btechView.btech2ndYear2ndSemResult.EMLab1Lbl.text = btechView.btech2ndYear2ndSem.EM1LabMarksTF.text
//        btechView.btech2ndYear2ndSemResult.ECSimLabLbl.text = btechView.btech2ndYear2ndSem.ECSLabMarksTF.text
//
//
//        btechView.btech3rdYear1stSemResult.MEFALbl.text = btechView.btech3rdYear1stSem.MEFAMarksTF.text
//        btechView.btech3rdYear1stSemResult.EEMLbl.text = btechView.btech3rdYear1stSem.EEMMarksTF.text
//        btechView.btech3rdYear1stSemResult.TEPLbl.text = btechView.btech3rdYear1stSem.TEPMarksTF.text
//        btechView.btech3rdYear1stSemResult.CSLbl.text = btechView.btech3rdYear1stSem.CSMarksTF.text
//        btechView.btech3rdYear1stSemResult.EM3Lbl.text = btechView.btech3rdYear1stSem.EM3MarksTF.text
//        btechView.btech3rdYear1stSemResult.PELbl.text = btechView.btech3rdYear1stSem.PEMarksTF.text
//        btechView.btech3rdYear1stSemResult.EMLab2Lbl.text = btechView.btech3rdYear1stSem.EM2LabMarksTF.text
//        btechView.btech3rdYear1stSemResult.CSSimLabLbl.text = btechView.btech3rdYear1stSem.CSSLabMarksTF.text
//
//        btechView.btech3rdYear2ndSemResult.MSLbl.text = btechView.btech3rdYear2ndSem.MSMarksTF.text
//        btechView.btech3rdYear2ndSemResult.PSDLbl.text = btechView.btech3rdYear2ndSem.PSDMarksTF.text
//        btechView.btech3rdYear2ndSemResult.PSALbl.text = btechView.btech3rdYear2ndSem.PSAMarksTF.text
//        btechView.btech3rdYear2ndSemResult.MPMCLbl.text = btechView.btech3rdYear2ndSem.MPMCMarksTF.text
//        btechView.btech3rdYear2ndSemResult.PSOCLbl.text = btechView.btech3rdYear2ndSem.PSOCMarksTF.text
//        btechView.btech3rdYear2ndSemResult.LDICALbl.text = btechView.btech3rdYear2ndSem.LDICMarksTF.text
//        btechView.btech3rdYear2ndSemResult.AECSLabLbl.text = btechView.btech3rdYear2ndSem.AECSLabMarksTF.text
//        btechView.btech3rdYear2ndSemResult.EMLabLbl.text = btechView.btech3rdYear2ndSem.EMLabMarksTF.text
//
//        btechView.btech4thYear1stSemResult.DEPLbl.text = btechView.btech4thYear1stSem.DEPMarksTF.text
//        btechView.btech4thYear1stSemResult.DSPLbl.text = btechView.btech4thYear1stSem.DSPMarksTF.text
//        btechView.btech4thYear1stSemResult.HVDCFactsLbl.text = btechView.btech4thYear1stSem.HVDCMarksTF.text
//        btechView.btech4thYear1stSemResult.SGPLbl.text = btechView.btech4thYear1stSem.SGPMarksTF.text
//        btechView.btech4thYear1stSemResult.instrumentationLbl.text = btechView.btech4thYear1stSem.instrumentationsMarksTF.text
//        btechView.btech4thYear1stSemResult.OTLbl.text = btechView.btech4thYear1stSem.OTMarksTF.text
//        btechView.btech4thYear1stSemResult.MPMCLabLbl.text = btechView.btech4thYear1stSem.MPMCLabMarksTF.text
//        btechView.btech4thYear1stSemResult.PESimLabLbl.text = btechView.btech4thYear1stSem.PESLabMarksTF.text
//
//        btechView.btech4thYear2ndSemResult.PPQLbl.text = btechView.btech4thYear2ndSem.PPQMarksTF.text
//        btechView.btech4thYear2ndSemResult.UEELbl.text = btechView.btech4thYear2ndSem.UEEMarksTF.text
//        btechView.btech4thYear2ndSemResult.MCTLbl.text = btechView.btech4thYear2ndSem.MCTMarksTF.text
//        btechView.btech4thYear2ndSemResult.EADSMLbl.text = btechView.btech4thYear2ndSem.EADSMMarksTF.text
//        btechView.btech4thYear2ndSemResult.seminarLbl.text = btechView.btech4thYear2ndSem.seminarMarksTF.text
//        btechView.btech4thYear2ndSemResult.projectWorkLbl.text = btechView.btech4thYear2ndSem.projectWorkMarksTF.text
    }
    
}
