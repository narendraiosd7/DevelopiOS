//
//  DiplomaSecondYearFirstSemMarks.swift
//  DataTransferthroughPresent
//
//  Created by Vadde Narendra on 11/11/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class DiplomaSecondYearFirstSemMarks: UIViewController, UITextFieldDelegate
{

    @IBOutlet weak var english2MarksTF: UITextField!
    @IBOutlet weak var enggMaths2MarksTF: UITextField!
    @IBOutlet weak var ECMarksTF: UITextField!
    @IBOutlet weak var DCMCMarksTF: UITextField!
    @IBOutlet weak var EEMIMarksTF: UITextField!
    @IBOutlet weak var electronicsEnggMarksTF: UITextField!
    @IBOutlet weak var DCMCLabMarksTF: UITextField!
    @IBOutlet weak var EMILabMarksTF: UITextField!
    @IBOutlet weak var EWLabMarksTF: UITextField!
    @IBOutlet weak var electronicsLabMarksTF: UITextField!
    
    var diploma21marks = DiplomaQualificationDetails()
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        english2MarksTF.delegate = self
        enggMaths2MarksTF.delegate = self
        ECMarksTF.delegate = self
        DCMCMarksTF.delegate = self
        EEMIMarksTF.delegate = self
        electronicsEnggMarksTF.delegate = self
        DCMCLabMarksTF.delegate = self
        EMILabMarksTF.delegate = self
        EWLabMarksTF.delegate = self
        electronicsLabMarksTF.delegate = self
        
        english2MarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        enggMaths2MarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        ECMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        DCMCMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        EEMIMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        electronicsEnggMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        DCMCLabMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        EMILabMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        EWLabMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        electronicsLabMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
      
        
        english2MarksTF.keyboardType = .numberPad
        enggMaths2MarksTF.keyboardType = .numberPad
        ECMarksTF.keyboardType = .numberPad
        DCMCMarksTF.keyboardType = .numberPad
        EEMIMarksTF.keyboardType = .numberPad
        electronicsEnggMarksTF.keyboardType = .numberPad
        DCMCLabMarksTF.keyboardType = .numberPad
        EMILabMarksTF.keyboardType = .numberPad
        EWLabMarksTF.keyboardType = .numberPad
        electronicsLabMarksTF.keyboardType = .numberPad
    }
    
    
    func isValidMarks(marksStr:String) -> Bool
    {
        
        let marksRegEx = "[0-9]{1,3}"
        
        let marksPred = NSPredicate(format:"SELF MATCHES %@", marksRegEx)
        return marksPred.evaluate(with: marksStr)
    }
    
    
    var returValue = false
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool
    {
        if (textField == english2MarksTF)
        {
            returValue = true
        }
        else if (textField == enggMaths2MarksTF)
        {
            if (Int(english2MarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == ECMarksTF)
        {
            if (Int(enggMaths2MarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == DCMCMarksTF)
        {
            if (Int(ECMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == EEMIMarksTF)
        {
            if (Int(DCMCMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == electronicsEnggMarksTF)
        {
            if (Int(EEMIMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == DCMCLabMarksTF)
        {
            if (Int(electronicsEnggMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == EMILabMarksTF)
        {
            if (Int(DCMCLabMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == EWLabMarksTF)
        {
            if (Int(EMILabMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == electronicsLabMarksTF)
        {
            if (Int(EWLabMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        
        return returValue
    }
    
    
    
    func textFieldDidBeginEditing(_ textField: UITextField)
    {
        textField.backgroundColor = UIColor.red
    }
    
    
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool
    {
        if (textField == english2MarksTF ||
            textField == enggMaths2MarksTF ||
            textField == ECMarksTF ||
            textField == DCMCMarksTF ||
            textField == EEMIMarksTF ||
            textField == electronicsEnggMarksTF ||
            textField == DCMCLabMarksTF ||
            textField == EMILabMarksTF ||
            textField == EWLabMarksTF ||
            textField == electronicsLabMarksTF)
        {
            returValue = isValidMarks(marksStr: textField.text!)
        }
        
        return returValue
    }
    
    
    
    func textFieldDidEndEditing(_ textField: UITextField)
    {
        textField.backgroundColor = UIColor.white
    }
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool
    {
        return true
    }
    
    //event handler for marks
    
    @objc func marksValidation(obj:UITextField)
    {
        if(obj.text != "")
        {
            if(Int(obj.text!)!>100)
            {
                obj.text = ""
            }
        }
    }
    
    @IBAction func submitBtnTapped(_ sender: UIButton)
    {
        dismiss(animated: true) {
        
            self.diploma21marks.diploma2ndYear1tSemMarks.append(self.english2MarksTF.text!)
            self.diploma21marks.diploma2ndYear1tSemMarks.append(self.enggMaths2MarksTF.text!)
            self.diploma21marks.diploma2ndYear1tSemMarks.append(self.enggMaths2MarksTF.text!)
            self.diploma21marks.diploma2ndYear1tSemMarks.append(self.ECMarksTF.text!)
            self.diploma21marks.diploma2ndYear1tSemMarks.append(self.EEMIMarksTF.text!)
            self.diploma21marks.diploma2ndYear1tSemMarks.append(self.electronicsEnggMarksTF.text!)
            self.diploma21marks.diploma2ndYear1tSemMarks.append(self.DCMCLabMarksTF.text!)
            self.diploma21marks.diploma2ndYear1tSemMarks.append(self.EMILabMarksTF.text!)
            self.diploma21marks.diploma2ndYear1tSemMarks.append(self.EWLabMarksTF.text!)
            self.diploma21marks.diploma2ndYear1tSemMarks.append(self.electronicsLabMarksTF.text!)
            
        }
    }
}
