//
//  DiplomaSecondYearFirstSemResult.swift
//  DataTransferthroughPresent
//
//  Created by Vadde Narendra on 11/12/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class DiplomaSecondYearFirstSemResult: UIViewController {

    @IBOutlet weak var eng2Lbl: UILabel!
    @IBOutlet weak var m2Lbl: UILabel!
    @IBOutlet weak var ECLbl: UILabel!
    @IBOutlet weak var DCMCLbl: UILabel!
    @IBOutlet weak var EMILbl: UILabel!
    @IBOutlet weak var electronicsLbl: UILabel!
    @IBOutlet weak var DCMCLabLbl: UILabel!
    @IBOutlet weak var EMILabLbl: UILabel!
    @IBOutlet weak var EWLabLbl: UILabel!
    @IBOutlet weak var electronicsLabLbl: UILabel!
    @IBOutlet weak var totalMarksLbl: UILabel!
    @IBOutlet weak var statusLbl: UILabel!
    @IBOutlet weak var percentageLbl: UILabel!
    @IBOutlet weak var gradeLbl: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

//        calculateDiploma2ndYear1stSem(english2Marks: Int(eng2Lbl.text!)!, enggMaths2Marks: Int(m2Lbl.text!)!, ECMarks: Int(ECLbl.text!)!, DCMCMarks: Int(DCMCLbl.text!)!, EEMIMarks: Int(EMILbl.text!)!, electronicsEnggMarks: Int(electronicsLbl.text!)!, DCMCLabMarks: Int(DCMCLabLbl.text!)!, EMILabMarks: Int(EMILabLbl.text!)!, EWLabMarks: Int(EWLabLbl.text!)!, electronicsLabMarks: Int(electronicsLabLbl.text!)!)
        
        // Do any additional setup after loading the view.
    }
    
    
    
    
    
}
