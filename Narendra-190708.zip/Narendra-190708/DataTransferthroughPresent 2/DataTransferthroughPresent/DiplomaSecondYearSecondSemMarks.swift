//
//  DiplomaSecondYearSecondSemMarks.swift
//  DataTransferthroughPresent
//
//  Created by Vadde Narendra on 11/11/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class DiplomaSecondYearSecondSemMarks: UIViewController, UITextFieldDelegate
{

    @IBOutlet weak var english3MarksTF: UITextField!
    @IBOutlet weak var ACMCMarksTF: UITextField!
    @IBOutlet weak var PSMarksTF: UITextField!
    @IBOutlet weak var EIEMarksTF: UITextField!
    @IBOutlet weak var DEMCMarksTF: UITextField!
    @IBOutlet weak var GMEMarksTF: UITextField!
    @IBOutlet weak var ACMCLabMarksTF: UITextField!
    @IBOutlet weak var EEDMarksTF: UITextField!
    @IBOutlet weak var DELabTF: UITextField!
    @IBOutlet weak var MCLabMarksTF: UITextField!
    
    var diploma22Marks = DiplomaQualificationDetails()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        english3MarksTF.delegate = self
        ACMCMarksTF.delegate = self
        PSMarksTF.delegate = self
        EIEMarksTF.delegate = self
        DEMCMarksTF.delegate = self
        GMEMarksTF.delegate = self
        ACMCLabMarksTF.delegate = self
        EEDMarksTF.delegate = self
        DELabTF.delegate = self
        MCLabMarksTF.delegate = self
        
        english3MarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        ACMCMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        PSMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        EIEMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        DEMCMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        GMEMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        ACMCLabMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        EEDMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        DELabTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        MCLabMarksTF.addTarget(self, action: #selector(marksValidation(obj:)), for: UIControl.Event.editingChanged)
        
        english3MarksTF.keyboardType = .numberPad
        ACMCMarksTF.keyboardType = .numberPad
        PSMarksTF.keyboardType = .numberPad
        EIEMarksTF.keyboardType = .numberPad
        DEMCMarksTF.keyboardType = .numberPad
        GMEMarksTF.keyboardType = .numberPad
        ACMCLabMarksTF.keyboardType = .numberPad
        EEDMarksTF.keyboardType = .numberPad
        DELabTF.keyboardType = .numberPad
        MCLabMarksTF.keyboardType = .numberPad
    }
    
    
    func isValidMarks(marksStr:String) -> Bool
    {
        
        let marksRegEx = "[0-9]{1,3}"
        
        let marksPred = NSPredicate(format:"SELF MATCHES %@", marksRegEx)
        return marksPred.evaluate(with: marksStr)
    }
    
    
    var returValue = false
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool
    {
        if (textField == english3MarksTF)
        {
            returValue = true
        }
        else if (textField == ACMCMarksTF)
        {
            if (Int(english3MarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == PSMarksTF)
        {
            if (Int(ACMCMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == EIEMarksTF)
        {
            if (Int(PSMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == DEMCMarksTF)
        {
            if (Int(EIEMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == GMEMarksTF)
        {
            if (Int(DEMCMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == ACMCLabMarksTF)
        {
            if (Int(GMEMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == EEDMarksTF)
        {
            if (Int(ACMCLabMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == DELabTF)
        {
            if (Int(EEDMarksTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        else if (textField == MCLabMarksTF)
        {
            if (Int(DELabTF.text!)! < 100)
            {
                returValue = true
            }
            else
            {
                returValue = false
            }
        }
        
        return returValue
    }
    
    
    
    func textFieldDidBeginEditing(_ textField: UITextField)
    {
        textField.backgroundColor = UIColor.red
    }
    
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool
    {
        if (textField == english3MarksTF ||
            textField == ACMCMarksTF ||
            textField == PSMarksTF ||
            textField == EIEMarksTF ||
            textField == DEMCMarksTF ||
            textField == GMEMarksTF ||
            textField == ACMCLabMarksTF ||
            textField == EEDMarksTF ||
            textField == DELabTF ||
            textField == MCLabMarksTF)
        {
            returValue = isValidMarks(marksStr: textField.text!)
        }
        
        return returValue
    }
    
    
    
    func textFieldDidEndEditing(_ textField: UITextField)
    {
        textField.backgroundColor = UIColor.white
    }
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool
    {
        return true
    }
    
    //event handler for marks
    
    @objc func marksValidation(obj:UITextField)
    {
        if(obj.text != "")
        {
            if(Int(obj.text!)!>100)
            {
                obj.text = ""
            }
        }
    }
    
    @IBAction func subBtnTap(_ sender: UIButton)
    {
        dismiss(animated: true) {
            
            self.diploma22Marks.diploma2ndYear2ndSemMarks.append(self.english3MarksTF.text!)
            self.diploma22Marks.diploma2ndYear2ndSemMarks.append(self.ACMCMarksTF.text!)
            self.diploma22Marks.diploma2ndYear2ndSemMarks.append(self.PSMarksTF.text!)
            self.diploma22Marks.diploma2ndYear2ndSemMarks.append(self.EIEMarksTF.text!)
            self.diploma22Marks.diploma2ndYear2ndSemMarks.append(self.DEMCMarksTF.text!)
            self.diploma22Marks.diploma2ndYear2ndSemMarks.append(self.GMEMarksTF.text!)
            self.diploma22Marks.diploma2ndYear2ndSemMarks.append(self.ACMCLabMarksTF.text!)
            self.diploma22Marks.diploma2ndYear2ndSemMarks.append(self.EEDMarksTF.text!)
            self.diploma22Marks.diploma2ndYear2ndSemMarks.append(self.DELabTF.text!)
            self.diploma22Marks.diploma2ndYear2ndSemMarks.append(self.MCLabMarksTF.text!)
            
        }
    }

    
}
