//
//  DiplomaSecondYearSecondSemResult.swift
//  DataTransferthroughPresent
//
//  Created by Vadde Narendra on 11/12/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class DiplomaSecondYearSecondSemResult: UIViewController {

    @IBOutlet weak var eng3Lbl: UILabel!
    @IBOutlet weak var ACMC1Lbl: UILabel!
    @IBOutlet weak var PS1Lbl: UILabel!
    @IBOutlet weak var EIELbl: UILabel!
    @IBOutlet weak var DEMCLbl: UILabel!
    @IBOutlet weak var GEMLbl: UILabel!
    @IBOutlet weak var ACMC1LabLbl: UILabel!
    @IBOutlet weak var elecEnggDrawingLbl: UILabel!
    @IBOutlet weak var DELabLbl: UILabel!
    @IBOutlet weak var MCLabLbl: UILabel!
    @IBOutlet weak var totalMarksLbl: UILabel!
    @IBOutlet weak var statusLbl: UILabel!
    @IBOutlet weak var percentageLbl: UILabel!
    @IBOutlet weak var gradeLbl: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

//        calculateDiploma2ndYear2ndSem(english3Marks: Int(eng3Lbl.text!)!, ACMCMarks: Int(ACMC1Lbl.text!)!, PSMarks: Int(PS1Lbl.text!)!, EIEMarks: Int(EIELbl.text!)!, DEMCMarks: Int(DEMCLbl.text!)!, GMEMarks: Int(GEMLbl.text!)!, ACMCLabMarks: Int(ACMC1LabLbl.text!)!, EEDMarks: Int(elecEnggDrawingLbl.text!)!, DELabMarks: Int(DELabLbl.text!)!, MCLabMarks: Int(MCLabLbl.text!)!)
        
        // Do any additional setup after loading the view.
    }
    
    func calculateDiploma2ndYear2ndSem(english3Marks:Int, ACMCMarks:Int, PSMarks:Int, EIEMarks:Int, DEMCMarks:Int, GMEMarks:Int, ACMCLabMarks:Int, EEDMarks:Int, DELabMarks:Int, MCLabMarks:Int)
    {
        // Calculating Total Marks
        
        let diploma2ndYear2ndSemGainedMarks:Int = Int(english3Marks + ACMCMarks + PSMarks + EIEMarks + DEMCMarks + GMEMarks + ACMCLabMarks + EEDMarks + DELabMarks + MCLabMarks)
        
            totalMarksLbl.text = "\(diploma2ndYear2ndSemGainedMarks)"
        
        // Calculating Percentage
        
        let totalDiploma2ndYear2ndSem:Float = 750
        
        let diploma2ndYear2ndSemMarks:Float = Float(diploma2ndYear2ndSemGainedMarks)
        
        let diploma2ndYear2ndSemPercentage:Float = (diploma2ndYear2ndSemMarks/totalDiploma2ndYear2ndSem)*100
        
        percentageLbl.text = "\(diploma2ndYear2ndSemPercentage)"
        
        // finding out subject wise pass or fail
        
        let subPassMarks:Int = 35
        let labPassMarks:Int = 25
        
        var english3:Bool = false
        var ACMC:Bool = false
        var PS:Bool = false
        var EIE:Bool = false
        var DEMC:Bool = false
        var GME:Bool = false
        var ACMCLab:Bool = false
        var EED:Bool = false
        var DELab:Bool = false
        var MCLab:Bool = false
        
        if english3Marks >= subPassMarks
        {
            english3 = true
        } else {
            english3 = false
        }
        
        if ACMCMarks >= subPassMarks
        {
            ACMC = true
        } else {
            ACMC = false
        }
        
        if PSMarks >= subPassMarks
        {
            PS = true
        } else {
            PS = false
        }
        
        if EIEMarks >= subPassMarks
        {
            EIE = true
        } else {
            EIE = false
        }
        
        if DEMCMarks >= subPassMarks
        {
            DEMC = true
        } else {
            DEMC = false
        }
        
        if GMEMarks >= labPassMarks
        {
            GME = true
        } else {
            GME = false
        }
        
        if ACMCLabMarks >= labPassMarks
        {
            ACMCLab = true
        } else {
            ACMCLab = false
        }
        
        if EEDMarks >= labPassMarks
        {
            EED = true
        } else {
            EED = false
        }
        
        if DELabMarks >= labPassMarks
        {
            DELab = true
        } else {
            DELab = false
        }
        
        if DELabMarks >= labPassMarks
        {
            MCLab = true
        } else {
            MCLab = false
        }
        
        // Total 2nd Year 2nd Sem pass or fail with grade
        
        
        
        if (english3 == true && ACMC == true && PS == true && EIE == true && DEMC == true && GME == true && ACMCLab == true && EED == true && DELab == true && MCLab == true)
        {
            switch diploma2ndYear2ndSemPercentage
            {
            case 90...100:
                gradeLbl.text = "A"
            case 75..<90:
                gradeLbl.text = "B"
            case 50..<75:
                gradeLbl.text = "C"
            case 35..<50:
                gradeLbl.text = "D"
            default:
                gradeLbl.text = "E"
            }
            statusLbl.text = "PASSED"
        }
        else
        {
            statusLbl.text = "FAILED"
        }
        
    }

}
