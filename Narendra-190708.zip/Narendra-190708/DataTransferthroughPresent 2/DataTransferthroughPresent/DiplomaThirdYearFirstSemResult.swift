//
//  DiplomaThirdYearFirstSemResult.swift
//  DataTransferthroughPresent
//
//  Created by Vadde Narendra on 11/12/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class DiplomaThirdYearFirstSemResult: UIViewController {

    @IBOutlet weak var firstAssignmentLbl: UILabel!
    @IBOutlet weak var secondAssignmentLbl: UILabel!
    @IBOutlet weak var logBookLbl: UILabel!
    @IBOutlet weak var recordLbl: UILabel!
    @IBOutlet weak var seminarLbl: UILabel!
    @IBOutlet weak var totalMarksLbl: UILabel!
    @IBOutlet weak var statusLbl: UILabel!
    @IBOutlet weak var percentageLbl: UILabel!
    @IBOutlet weak var gradeLbl: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

//        calculateDiploma2ndYear2ndSem(firstAssigMarks: Int(firstAssignmentLbl.text!)!, secondAssignMarks: Int(secondAssignmentLbl.text!)!, logBookMarks: Int(logBookLbl.text!)!, recordMarks: Int(recordLbl.text!)!, seminarMarks: Int(seminarLbl.text!)!)
        
        // Do any additional setup after loading the view.
    }
    
    
    
    
    
}
