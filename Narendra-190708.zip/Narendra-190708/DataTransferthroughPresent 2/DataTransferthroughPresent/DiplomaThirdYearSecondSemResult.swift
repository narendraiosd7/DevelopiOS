//
//  DiplomaThirdYearSecondSemResult.swift
//  DataTransferthroughPresent
//
//  Created by Vadde Narendra on 11/12/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class DiplomaThirdYearSecondSemResult: UIViewController {

    @IBOutlet weak var eng4Lbl: UILabel!
    @IBOutlet weak var IMELbl: UILabel!
    @IBOutlet weak var ACMC2Lbl: UILabel!
    @IBOutlet weak var PELbl: UILabel!
    @IBOutlet weak var ETPLCLbl: UILabel!
    @IBOutlet weak var PS2Lbl: UILabel!
    @IBOutlet weak var ACMCLab2Lbl: UILabel!
    @IBOutlet weak var PELabLbl: UILabel!
    @IBOutlet weak var elecCADLabLbl: UILabel!
    @IBOutlet weak var projectWorkLbl: UILabel!
    @IBOutlet weak var automationLbl: UILabel!
    @IBOutlet weak var totalMarksLbl: UILabel!
    @IBOutlet weak var statusLbl: UILabel!
    @IBOutlet weak var percentageLbl: UILabel!
    @IBOutlet weak var gradeLbl: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()

//        cal1stYearDiplomaResults(english4Marks: Int(eng4Lbl.text!)!, IMEMarks: Int(IMELbl.text!)!, ACMC3Marks: Int(ACMC2Lbl.text!)!, PEMarks: Int(PELbl.text!)!, ETPLCMarks: Int(ETPLCLbl.text!)!, PS2Marks: Int(PS2Lbl.text!)!, ACMC2LabMarks: Int(ACMCLab2Lbl.text!)!, PELabMarks: Int(PELabLbl.text!)!, ECADLabMarks: Int(elecCADLabLbl.text!)!, automationLabMarks: Int(automationLbl.text!)!, projectWorkMarks: Int(projectWorkLbl.text!)!)
        
        // Do any additional setup after loading the view.
    }
    

    func cal1stYearDiplomaResults(english4Marks:Int,IMEMarks:Int,ACMC3Marks:Int,PEMarks:Int,ETPLCMarks:Int,PS2Marks:Int,ACMC2LabMarks:Int,PELabMarks:Int,ECADLabMarks:Int,automationLabMarks:Int,projectWorkMarks:Int)
    {
        // Calculating Total Marks
        
        let diploma3rdYear2ndSemGainedMarks:Int = Int(english4Marks + IMEMarks + ACMC3Marks + PEMarks + ETPLCMarks + PS2Marks + ACMC2LabMarks + PELabMarks + ECADLabMarks + automationLabMarks + projectWorkMarks)
        
        totalMarksLbl.text = "\(diploma3rdYear2ndSemGainedMarks)"
        
        // Calculating Percentage
        
        let totalDiploma3rdYear2ndSem:Float = 750
        
        let diploma3rdYear2ndSemMarks:Float = Float(diploma3rdYear2ndSemGainedMarks)
        
        let diploma3rdYear2ndSemPercentage:Float = (diploma3rdYear2ndSemMarks/totalDiploma3rdYear2ndSem)*100
        
        percentageLbl.text = "\(diploma3rdYear2ndSemPercentage)"
        
        // finding out subject wise pass or fail
        
        let subPassMarks:Int = 35
        let labPassMarks:Int = 25
        
        var english1:Bool = false
        var enggMaths:Bool = false
        var enggPhysics:Bool = false
        var enggChem:Bool = false
        var basicElecEngg:Bool = false
        var mechWorkshop:Bool = false
        var enggDrawing:Bool = false
        var physicsLab:Bool = false
        var chemistryLab:Bool = false
        var ITLab:Bool = false
        var elecWorkshop:Bool = false
        
        if english4Marks >= subPassMarks
        {
            english1 = true
        } else {
            english1 = false
        }
        
        if IMEMarks >= subPassMarks
        {
            enggMaths = true
        } else {
            enggMaths = false
        }
        
        if ACMC3Marks >= subPassMarks
        {
            enggPhysics = true
        } else {
            enggPhysics = false
        }
        
        if PEMarks >= subPassMarks
        {
            enggChem = true
        } else {
            enggChem = false
        }
        
        if ETPLCMarks >= subPassMarks
        {
            basicElecEngg = true
        } else {
            basicElecEngg = false
        }
        
        if PS2Marks >= labPassMarks
        {
            mechWorkshop = true
        } else {
            mechWorkshop = false
        }
        
        if ACMC2LabMarks >= labPassMarks
        {
            enggDrawing = true
        } else {
            enggDrawing = false
        }
        
        if PELabMarks >= labPassMarks
        {
            physicsLab = true
        } else {
            physicsLab = false
        }
        
        if ECADLabMarks >= labPassMarks
        {
            chemistryLab = true
        } else {
            chemistryLab = false
        }
        
        if automationLabMarks >= labPassMarks
        {
            ITLab = true
        } else {
            ITLab = false
        }
        
        if projectWorkMarks >= labPassMarks
        {
            elecWorkshop = true
        } else {
            elecWorkshop = false
        }
        
        // Total 2nd Year 2nd Sem pass or fail with grade
        
        
        
        if (english1 == true && enggMaths == true && enggPhysics == true && enggChem == true && basicElecEngg == true && mechWorkshop == true && enggDrawing == true && physicsLab == true && chemistryLab == true && ITLab == true && elecWorkshop == true)
        {
            switch diploma3rdYear2ndSemPercentage
            {
            case 90...100:
                gradeLbl.text = "A"
            case 75..<90:
                gradeLbl.text = "B"
            case 50..<75:
                gradeLbl.text = "C"
            case 35..<50:
                gradeLbl.text = "D"
            default:
                gradeLbl.text = "E"
            }
            statusLbl.text = "PASSED"
        }
        else
        {
            statusLbl.text = "FAILED"
        }
        
    }

}
