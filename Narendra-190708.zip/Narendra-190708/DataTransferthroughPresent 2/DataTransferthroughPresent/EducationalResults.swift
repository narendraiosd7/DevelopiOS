//
//  EducationalResults.swift
//  DataTransferthroughPresent
//
//  Created by Vadde Narendra on 11/13/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class EducationalResults: UIViewController {

        @IBOutlet weak var firstNameLbl: UILabel!
        @IBOutlet weak var lastNameLbl: UILabel!
        @IBOutlet weak var DOBLbl: UILabel!
        @IBOutlet weak var qualificationLbl: UILabel!
    
    @IBOutlet weak var diplomaFirstYearTotalLbl: UILabel!
    @IBOutlet weak var diplomaFirstYearStatusLbl: UILabel!
    @IBOutlet weak var diplomaFirstYearPercentageLbl: UILabel!
    @IBOutlet weak var diplomaFirstYearGradeLbl: UILabel!
    
    @IBOutlet weak var diploma21TotalLbl: UILabel!
    @IBOutlet weak var diploma21StatusLbl: UILabel!
    @IBOutlet weak var diploma21PercentageLbl: UILabel!
    @IBOutlet weak var diploma21GradeLbl: UILabel!
    
    @IBOutlet weak var diploma22TotalLbl: UILabel!
    @IBOutlet weak var diploma22StatusLbl: UILabel!
    @IBOutlet weak var diploma22PercentageLbl: UILabel!
    @IBOutlet weak var diploma22GradeLbl: UILabel!
    
    @IBOutlet weak var diploma31TotalLbl: UILabel!
    @IBOutlet weak var diploma31StatusLbl: UILabel!
    @IBOutlet weak var diploma31PercentageLbl: UILabel!
    @IBOutlet weak var diploma31GradeLbl: UILabel!
    
    @IBOutlet weak var diploma32TotalLbl: UILabel!
    @IBOutlet weak var diploma32StatusLbl: UILabel!
    @IBOutlet weak var diploma32PercentageLbl: UILabel!
    @IBOutlet weak var diploma32GradeLbl: UILabel!
    
    @IBOutlet weak var btech21TotalLbl: UILabel!
    @IBOutlet weak var btech21StatusLbl: UILabel!
    @IBOutlet weak var btech21PercentageLbl: UILabel!
    @IBOutlet weak var btech21GradeLbl: UILabel!
    
    @IBOutlet weak var btech22TotalLbl: UILabel!
    @IBOutlet weak var btech22StatusLbl: UILabel!
    @IBOutlet weak var btech22PercentageLbl: UILabel!
    @IBOutlet weak var btech22GradeLbl: UILabel!
    
    @IBOutlet weak var btech31TotalLbl: UILabel!
    @IBOutlet weak var btech31StatusLbl: UILabel!
    @IBOutlet weak var btech31PercentageLbl: UILabel!
    @IBOutlet weak var btech31GradeLbl: UILabel!
    
    @IBOutlet weak var btech32TotalLbl: UILabel!
    @IBOutlet weak var btech32StatusLbl: UILabel!
    @IBOutlet weak var btech32PercentageLbl: UILabel!
    @IBOutlet weak var btech32GradeLbl: UILabel!
    
    @IBOutlet weak var btech41TotalLbl: UILabel!
    @IBOutlet weak var btech41StatusLbl: UILabel!
    @IBOutlet weak var btech41PercentageLbl: UILabel!
    @IBOutlet weak var btech41GradeLbl: UILabel!
    
    @IBOutlet weak var btech42TotalLbl: UILabel!
    @IBOutlet weak var btech42StatusLbl: UILabel!
    @IBOutlet weak var btech42PercentageLbl: UILabel!
    @IBOutlet weak var btech42GradeLbl: UILabel!
    
    var btechDetails = BtechQualificationDetails()
    
//        var diploma1:[String] = []
    
        override func viewDidLoad() {
            super.viewDidLoad()
            
            // Do any additional setup after loading the view.
        }
    
    func diploma1stYearResultCalculations(english1Marks:Int,enggMathsMarks:Int,enggPhysicsMarks:Int,enggChemMarks:Int,basicElecEnggMarks:Int,mechWorkshopMarks:Int,enggDrawingMarks:Int,physicsLabMarks:Int,chemistryLabMarks:Int,ITLabMarks:Int,elecWorkshopMarks:Int)
    {
        // Calculating Total Marks
        
        let diploma1stYearGainedMarks:Int = Int(english1Marks + enggMathsMarks + enggPhysicsMarks + enggChemMarks + basicElecEnggMarks + mechWorkshopMarks + enggDrawingMarks + physicsLabMarks + chemistryLabMarks + ITLabMarks + elecWorkshopMarks)
        
        diplomaFirstYearTotalLbl.text = "\(diploma1stYearGainedMarks)"
        
        // Calculating Percentage
        
        let totalDiplomaFirstYear:Float = 1100
        
        let diploma1stYearMarks:Float = Float(diploma1stYearGainedMarks)
        
        let diploma1stYearPercentage:Float = (diploma1stYearMarks/totalDiplomaFirstYear)*100
        
        diplomaFirstYearPercentageLbl.text = "\(diploma1stYearPercentage)"
        
        // finding out subject wise pass or fail
        
        let subPassMarks:Int = 35
        let labPassMarks:Int = 35
        
        var english1:Bool = false
        var enggMaths:Bool = false
        var enggPhysics:Bool = false
        var enggChem:Bool = false
        var basicElecEngg:Bool = false
        var mechWorkshop:Bool = false
        var enggDrawing:Bool = false
        var physicsLab:Bool = false
        var chemistryLab:Bool = false
        var ITLab:Bool = false
        var elecWorkshop:Bool = false
        
        if english1Marks >= subPassMarks
        {
            english1 = true
        } else {
            english1 = false
        }
        
        if enggMathsMarks >= subPassMarks
        {
            enggMaths = true
        } else {
            enggMaths = false
        }
        
        if enggPhysicsMarks >= subPassMarks
        {
            enggPhysics = true
        } else {
            enggPhysics = false
        }
        
        if enggChemMarks >= subPassMarks
        {
            enggChem = true
        } else {
            enggChem = false
        }
        
        if basicElecEnggMarks >= subPassMarks
        {
            basicElecEngg = true
        } else {
            basicElecEngg = false
        }
        
        if mechWorkshopMarks >= labPassMarks
        {
            mechWorkshop = true
        } else {
            mechWorkshop = false
        }
        
        if enggDrawingMarks >= labPassMarks
        {
            enggDrawing = true
        } else {
            enggDrawing = false
        }
        
        if physicsLabMarks >= labPassMarks
        {
            physicsLab = true
        } else {
            physicsLab = false
        }
        
        if chemistryLabMarks >= labPassMarks
        {
            chemistryLab = true
        } else {
            chemistryLab = false
        }
        
        if ITLabMarks >= labPassMarks
        {
            ITLab = true
        } else {
            ITLab = false
        }
        
        if elecWorkshopMarks >= labPassMarks
        {
            elecWorkshop = true
        } else {
            elecWorkshop = false
        }
        
        // Total 2nd Year 2nd Sem pass or fail with grade
        
        
        
        if (english1 == true && enggMaths == true && enggPhysics == true && enggChem == true && basicElecEngg == true && mechWorkshop == true && enggDrawing == true && physicsLab == true && chemistryLab == true && ITLab == true && elecWorkshop == true)
        {
            switch diploma1stYearPercentage
            {
            case 90...100:
                diplomaFirstYearGradeLbl.text = "A"
            case 75..<90:
                diplomaFirstYearGradeLbl.text = "B"
            case 50..<75:
                diplomaFirstYearGradeLbl.text = "C"
            case 35..<50:
                diplomaFirstYearGradeLbl.text = "D"
            default:
                diplomaFirstYearGradeLbl.text = "E"
            }
            diplomaFirstYearStatusLbl.text = "PASSED"
        }
        else
        {
            diplomaFirstYearStatusLbl.text = "FAILED"
        }
        
    }
    
    func diploma2ndYear1stSemResultCalculations(english2Marks:Int, enggMaths2Marks:Int, ECMarks:Int, DCMCMarks:Int, EEMIMarks:Int, electronicsEnggMarks:Int, DCMCLabMarks:Int, EMILabMarks:Int, EWLabMarks:Int, electronicsLabMarks:Int)
    {
        // Calculating Total Marks
        
        let diploma2ndYear1stSemGainedMarks:Int = Int(english2Marks + enggMaths2Marks + ECMarks + DCMCMarks + EEMIMarks + electronicsEnggMarks + DCMCLabMarks + EMILabMarks + EWLabMarks + electronicsLabMarks)
        
        diploma21TotalLbl.text = "\(diploma2ndYear1stSemGainedMarks)"
        
        // Calculating Percentage
        
        let totalDiploma2ndYear1stSem:Float = 1000
        
        let diploma2ndYear1stSemMarks:Float = Float(diploma2ndYear1stSemGainedMarks)
        
        let diploma2ndYear1stSemPercentage:Float = (diploma2ndYear1stSemMarks/totalDiploma2ndYear1stSem)*100
        
        diploma21PercentageLbl.text = "\(diploma2ndYear1stSemPercentage)"
        
        // finding out subject wise pass or fail
        
        let subPassMarks:Int = 35
        let labPassMarks:Int = 35
        
        var english2:Bool = false
        var enggMaths2:Bool = false
        var EC:Bool = false
        var DCMC:Bool = false
        var EEMI:Bool = false
        var electronicsEngg:Bool = false
        var DCMCLab:Bool = false
        var EMILab:Bool = false
        var EWLab:Bool = false
        var electronicsLab:Bool = false
        
        if english2Marks >= subPassMarks
        {
            english2 = true
        } else {
            english2 = false
        }
        
        if enggMaths2Marks >= subPassMarks
        {
            enggMaths2 = true
        } else {
            enggMaths2 = false
        }
        
        if ECMarks >= subPassMarks
        {
            EC = true
        } else {
            EC = false
        }
        
        if DCMCMarks >= subPassMarks
        {
            DCMC = true
        } else {
            DCMC = false
        }
        
        if EEMIMarks >= subPassMarks
        {
            EEMI = true
        } else {
            EEMI = false
        }
        
        if electronicsEnggMarks >= labPassMarks
        {
            electronicsEngg = true
        } else {
            electronicsEngg = false
        }
        
        if DCMCLabMarks >= labPassMarks
        {
            DCMCLab = true
        } else {
            DCMCLab = false
        }
        
        if EMILabMarks >= labPassMarks
        {
            EMILab = true
        } else {
            EMILab = false
        }
        
        if EWLabMarks >= labPassMarks
        {
            EWLab = true
        } else {
            EWLab = false
        }
        
        if electronicsLabMarks >= labPassMarks
        {
            electronicsLab = true
        } else {
            electronicsLab = false
        }
        
        // Total 2nd Year 2nd Sem pass or fail with grade
        
        
        
        if (english2 == true && enggMaths2 == true && EC == true && DCMC == true && EEMI == true && electronicsEngg == true && DCMCLab == true && EMILab == true && EWLab == true && electronicsLab == true)
        {
            switch diploma2ndYear1stSemPercentage
            {
            case 90...100:
                diploma21GradeLbl.text = "A"
            case 75..<90:
                diploma21GradeLbl.text = "B"
            case 50..<75:
                diploma21GradeLbl.text = "C"
            case 35..<50:
                diploma21GradeLbl.text = "D"
            default:
                diploma21GradeLbl.text = "E"
            }
            diploma21StatusLbl.text = "PASSED"
        }
        else
        {
            diploma21StatusLbl.text = "FAILED"
        }
        
    }
    
    
    func diploma2ndYear2ndSemResultcalculations(english3Marks:Int, ACMCMarks:Int, PSMarks:Int, EIEMarks:Int, DEMCMarks:Int, GMEMarks:Int, ACMCLabMarks:Int, EEDMarks:Int, DELabMarks:Int, MCLabMarks:Int)
    {
        // Calculating Total Marks
        
        let diploma2ndYear2ndSemGainedMarks:Int = Int(english3Marks + ACMCMarks + PSMarks + EIEMarks + DEMCMarks + GMEMarks + ACMCLabMarks + EEDMarks + DELabMarks + MCLabMarks)
        
        diploma22TotalLbl.text = "\(diploma2ndYear2ndSemGainedMarks)"
        
        // Calculating Percentage
        
        let totalDiploma2ndYear2ndSem:Float = 1000
        
        let diploma2ndYear2ndSemMarks:Float = Float(diploma2ndYear2ndSemGainedMarks)
        
        let diploma2ndYear2ndSemPercentage:Float = (diploma2ndYear2ndSemMarks/totalDiploma2ndYear2ndSem)*100
        
        diploma22PercentageLbl.text = "\(diploma2ndYear2ndSemPercentage)"
        
        // finding out subject wise pass or fail
        
        let subPassMarks:Int = 35
        let labPassMarks:Int = 35
        
        var english3:Bool = false
        var ACMC:Bool = false
        var PS:Bool = false
        var EIE:Bool = false
        var DEMC:Bool = false
        var GME:Bool = false
        var ACMCLab:Bool = false
        var EED:Bool = false
        var DELab:Bool = false
        var MCLab:Bool = false
        
        if english3Marks >= subPassMarks
        {
            english3 = true
        } else {
            english3 = false
        }
        
        if ACMCMarks >= subPassMarks
        {
            ACMC = true
        } else {
            ACMC = false
        }
        
        if PSMarks >= subPassMarks
        {
            PS = true
        } else {
            PS = false
        }
        
        if EIEMarks >= subPassMarks
        {
            EIE = true
        } else {
            EIE = false
        }
        
        if DEMCMarks >= subPassMarks
        {
            DEMC = true
        } else {
            DEMC = false
        }
        
        if GMEMarks >= labPassMarks
        {
            GME = true
        } else {
            GME = false
        }
        
        if ACMCLabMarks >= labPassMarks
        {
            ACMCLab = true
        } else {
            ACMCLab = false
        }
        
        if EEDMarks >= labPassMarks
        {
            EED = true
        } else {
            EED = false
        }
        
        if DELabMarks >= labPassMarks
        {
            DELab = true
        } else {
            DELab = false
        }
        
        if DELabMarks >= labPassMarks
        {
            MCLab = true
        } else {
            MCLab = false
        }
        
        // Total 2nd Year 2nd Sem pass or fail with grade
        
        
        
        if (english3 == true && ACMC == true && PS == true && EIE == true && DEMC == true && GME == true && ACMCLab == true && EED == true && DELab == true && MCLab == true)
        {
            switch diploma2ndYear2ndSemPercentage
            {
            case 90...100:
                diploma22GradeLbl.text = "A"
            case 75..<90:
                diploma22GradeLbl.text = "B"
            case 50..<75:
                diploma22GradeLbl.text = "C"
            case 35..<50:
                diploma22GradeLbl.text = "D"
            default:
                diploma22GradeLbl.text = "E"
            }
            diploma22StatusLbl.text = "PASSED"
        }
        else
        {
            diploma22StatusLbl.text = "FAILED"
        }
        
    }
    
    func diploma3rdYear1stSemResultcalculations(firstAssigMarks:Int, secondAssignMarks:Int, logBookMarks:Int, recordMarks:Int, seminarMarks:Int)
    {
        // Calculating Total Marks
        
        let diploma3rdYear1stSemGainedMarks:Int = Int(firstAssigMarks + secondAssignMarks + logBookMarks + recordMarks + seminarMarks)
        
        diploma31TotalLbl.text = "\(diploma3rdYear1stSemGainedMarks)"
        
        // Calculating Percentage
        
        let totalDiploma3rdYear1stSem:Float = 500
        
        let diploma3rdYear1stSemMarks:Float = Float(diploma3rdYear1stSemGainedMarks)
        
        let diploma3rdYear1stSemPercentage:Float = (diploma3rdYear1stSemMarks/totalDiploma3rdYear1stSem)*100
        
        diploma31PercentageLbl.text = "\(diploma3rdYear1stSemPercentage)"
        
        // finding out subject wise pass or fail
        
        let subPassMarks:Int = 35
        let seminarPassMarks:Int = 35
        let recordPassMarks:Int = 35
        
        var firstAssig:Bool = false
        var secondAssign:Bool = false
        var logBook:Bool = false
        var record:Bool = false
        var seminar:Bool = false
        
        if firstAssigMarks >= subPassMarks
        {
            firstAssig = true
        } else {
            firstAssig = false
        }
        
        if secondAssignMarks >= subPassMarks
        {
            secondAssign = true
        } else {
            secondAssign = false
        }
        
        if logBookMarks >= subPassMarks
        {
            logBook = true
        } else {
            logBook = false
        }
        
        if recordMarks >= recordPassMarks
        {
            record = true
        } else {
            record = false
        }
        
        if seminarMarks >= seminarPassMarks
        {
            seminar = true
        } else {
            seminar = false
        }
        
        // Total 2nd Year 2nd Sem pass or fail with grade
        
        if (firstAssig == true && secondAssign == true && logBook == true && record == true && seminar == true)
        {
            switch diploma3rdYear1stSemPercentage
            {
            case 90...100:
                diploma31GradeLbl.text = "A"
            case 75..<90:
                diploma31GradeLbl.text = "B"
            case 50..<75:
                diploma31GradeLbl.text = "C"
            case 35..<50:
                diploma31GradeLbl.text = "D"
            default:
                diploma31GradeLbl.text = "E"
            }
            diploma31StatusLbl.text = "PASSED"
        }
        else
        {
            diploma31StatusLbl.text = "FAILED"
        }
        
    }
    
    
    func diploma3rdYear2ndSemResultcalculations(english4Marks:Int,IMEMarks:Int,ACMC3Marks:Int,PEMarks:Int,ETPLCMarks:Int,PS2Marks:Int,ACMC2LabMarks:Int,PELabMarks:Int,ECADLabMarks:Int,automationLabMarks:Int,projectWorkMarks:Int)
    {
        // Calculating Total Marks
        
        let diploma3rdYear2ndSemGainedMarks:Int = Int(english4Marks + IMEMarks + ACMC3Marks + PEMarks + ETPLCMarks + PS2Marks + ACMC2LabMarks + PELabMarks + ECADLabMarks + automationLabMarks + projectWorkMarks)
        
        diploma32TotalLbl.text = "\(diploma3rdYear2ndSemGainedMarks)"
        
        // Calculating Percentage
        
        let totalDiploma3rdYear2ndSem:Float = 1100
        
        let diploma3rdYear2ndSemMarks:Float = Float(diploma3rdYear2ndSemGainedMarks)
        
        let diploma3rdYear2ndSemPercentage:Float = (diploma3rdYear2ndSemMarks/totalDiploma3rdYear2ndSem)*100
        
        diploma32PercentageLbl.text = "\(diploma3rdYear2ndSemPercentage)"
        
        // finding out subject wise pass or fail
        
        let subPassMarks:Int = 35
        let labPassMarks:Int = 35
        
        var english1:Bool = false
        var enggMaths:Bool = false
        var enggPhysics:Bool = false
        var enggChem:Bool = false
        var basicElecEngg:Bool = false
        var mechWorkshop:Bool = false
        var enggDrawing:Bool = false
        var physicsLab:Bool = false
        var chemistryLab:Bool = false
        var ITLab:Bool = false
        var elecWorkshop:Bool = false
        
        if english4Marks >= subPassMarks
        {
            english1 = true
        } else {
            english1 = false
        }
        
        if IMEMarks >= subPassMarks
        {
            enggMaths = true
        } else {
            enggMaths = false
        }
        
        if ACMC3Marks >= subPassMarks
        {
            enggPhysics = true
        } else {
            enggPhysics = false
        }
        
        if PEMarks >= subPassMarks
        {
            enggChem = true
        } else {
            enggChem = false
        }
        
        if ETPLCMarks >= subPassMarks
        {
            basicElecEngg = true
        } else {
            basicElecEngg = false
        }
        
        if PS2Marks >= labPassMarks
        {
            mechWorkshop = true
        } else {
            mechWorkshop = false
        }
        
        if ACMC2LabMarks >= labPassMarks
        {
            enggDrawing = true
        } else {
            enggDrawing = false
        }
        
        if PELabMarks >= labPassMarks
        {
            physicsLab = true
        } else {
            physicsLab = false
        }
        
        if ECADLabMarks >= labPassMarks
        {
            chemistryLab = true
        } else {
            chemistryLab = false
        }
        
        if automationLabMarks >= labPassMarks
        {
            ITLab = true
        } else {
            ITLab = false
        }
        
        if projectWorkMarks >= labPassMarks
        {
            elecWorkshop = true
        } else {
            elecWorkshop = false
        }
        
        // Total 2nd Year 2nd Sem pass or fail with grade
        
        
        
        if (english1 == true && enggMaths == true && enggPhysics == true && enggChem == true && basicElecEngg == true && mechWorkshop == true && enggDrawing == true && physicsLab == true && chemistryLab == true && ITLab == true && elecWorkshop == true)
        {
            switch diploma3rdYear2ndSemPercentage
            {
            case 90...100:
                diploma32GradeLbl.text = "A"
            case 75..<90:
                diploma32GradeLbl.text = "B"
            case 50..<75:
                diploma32GradeLbl.text = "C"
            case 35..<50:
                diploma32GradeLbl.text = "D"
            default:
                diploma32GradeLbl.text = "E"
            }
            diploma32StatusLbl.text = "PASSED"
        }
        else
        {
            diploma32StatusLbl.text = "FAILED"
        }
        
    }

    func cal2ndYear1stSemBtechResults(mathematics3Marks:Int,environmentalSciMarks:Int,basicFMHMMarks:Int,elecDevCirsMarks:Int,elecMachines1Marks:Int,elecCircuitsMarks:Int,basicFMHMLabMarks:Int,electronicDevCirsLabMarks:Int)
    {
        
        // Calculating Total Marks
        
        let secondYear1stSemGainedMarks:Int = Int(mathematics3Marks)+Int(environmentalSciMarks)+Int(basicFMHMMarks)+Int(elecDevCirsMarks)+Int(elecMachines1Marks)+Int(elecCircuitsMarks)+Int(basicFMHMLabMarks)+Int(electronicDevCirsLabMarks)
        
        btech21TotalLbl.text = "\(secondYear1stSemGainedMarks)"
        
        // Calculating Percentage
        
        let totalMarks1stSem:Float = 800
        
        let firstSemGainedMarks:Float = Float(secondYear1stSemGainedMarks)
        
        let firstSemPercentage:Float = (firstSemGainedMarks/totalMarks1stSem)*100
        
        btech21PercentageLbl.text = "\(firstSemPercentage)"
        
        // finding out subject wise pass or fail
        
        let subPassMarks:UInt8 = 35
        let labPassMarks:UInt8 = 35
        
        var mathematics3:Bool = false
        var environmentalScience:Bool = false
        var basicFMHM:Bool = false
        var electronicDevicesAndCircuits:Bool = false
        var electricalMachines1:Bool = false
        var electricalCircuits:Bool = false
        var basicFMHMLab:Bool = false
        var electronicDevicesAndCircuitsLab:Bool = false
        
        if mathematics3Marks >= subPassMarks
        {
            mathematics3 = true
        } else {
            mathematics3 = false
        }
        
        if environmentalSciMarks >= subPassMarks
        {
            environmentalScience = true
        } else {
            environmentalScience = false
        }
        
        if basicFMHMMarks >= subPassMarks
        {
            basicFMHM = true
        } else {
            basicFMHM = false
        }
        
        if elecDevCirsMarks >= subPassMarks
        {
            electronicDevicesAndCircuits = true
        } else {
            electronicDevicesAndCircuits = false
        }
        
        if elecMachines1Marks >= subPassMarks
        {
            electricalMachines1 = true
        } else {
            electricalMachines1 = false
        }
        
        if elecCircuitsMarks >= subPassMarks
        {
            electricalCircuits = true
        } else {
            electricalCircuits = false
        }
        
        if basicFMHMLabMarks >= labPassMarks
        {
            basicFMHMLab = true
        } else {
            basicFMHMLab = false
        }
        
        if  electronicDevCirsLabMarks >= labPassMarks
        {
            electronicDevicesAndCircuitsLab = true
        } else {
            electronicDevicesAndCircuitsLab = false
        }
        
        // Total 2nd Year 1st Sem pass or fail with grade
        
        if (mathematics3 == true && environmentalScience == true && basicFMHM == true && electronicDevicesAndCircuits == true && electricalMachines1 == true && electricalCircuits == true && basicFMHMLab == true && electronicDevicesAndCircuitsLab == true)
        {
            switch firstSemPercentage
            {
            case 90...100:
                btech21GradeLbl.text = "A"
            case 75..<90:
                btech21GradeLbl.text = "B"
            case 50..<75:
                btech21GradeLbl.text = "C"
            case 35..<50:
                btech21GradeLbl.text = "D"
            default:
                btech21GradeLbl.text = "E"
            }
            btech21StatusLbl.text = "PASSED"
            
        }
        else
        {
            btech21StatusLbl.text = "FAILED"
        }
        
        
    }
    
    
    func cal2ndYear2ndSemBtechResults(EMFMarks:Int,GEPMarks:Int,AECMarks:Int,STLDMarks:Int,NTMarks:Int,EM2Marks:Int,EM1LabMarks:Int,ECSLabMarks:Int)
    {
        // Calculating Total Marks
        
        let secondYear2ndSemGainedMarks:Int = Int(EMFMarks)+Int(GEPMarks)+Int(AECMarks)+Int(STLDMarks)+Int(EM2Marks)+Int(NTMarks)+Int(EM1LabMarks)+Int(ECSLabMarks)
        
        btech22TotalLbl.text = "\(secondYear2ndSemGainedMarks)"
        
        // Calculating Percentage
        
        let totalMarks2ndSem:Float = 800
        
        let secondSemGainedMarks:Float = Float(secondYear2ndSemGainedMarks)
        
        let secondSemPercentage:Float = (secondSemGainedMarks/totalMarks2ndSem)*100
        
        btech22PercentageLbl.text = "\(secondSemPercentage)"
        
        // finding out subject wise pass or fail
        
        let subPassMarks:UInt8 = 35
        let labPassMarks:UInt8 = 27
        
        var electroMagneticField:Bool = false
        var generationofElectricalPower:Bool = false
        var analogElectroniccsAndCircuts:Bool = false
        var switchingThoeryAndLogicalDesign:Bool = false
        var electricalMachines2:Bool = false
        var NetworkTheory:Bool = false
        var electricalMachines1Lab:Bool = false
        var electricalCircuitsAndSimulationLab:Bool = false
        
        if EMFMarks >= subPassMarks
        {
            electroMagneticField = true
        } else {
            electroMagneticField = false
        }
        
        if GEPMarks >= subPassMarks
        {
            generationofElectricalPower = true
        } else {
            generationofElectricalPower = false
        }
        
        if AECMarks >= subPassMarks
        {
            analogElectroniccsAndCircuts = true
        } else {
            analogElectroniccsAndCircuts = false
        }
        
        if STLDMarks >= subPassMarks
        {
            switchingThoeryAndLogicalDesign = true
        } else {
            switchingThoeryAndLogicalDesign = false
        }
        
        if EM2Marks >= subPassMarks
        {
            electricalMachines2 = true
        } else {
            electricalMachines2 = false
        }
        
        if NTMarks >= subPassMarks
        {
            NetworkTheory = true
        } else {
            NetworkTheory = false
        }
        
        if EM1LabMarks >= labPassMarks
        {
            electricalMachines1Lab = true
        } else {
            electricalMachines1Lab = false
        }
        
        if  ECSLabMarks >= labPassMarks
        {
            electricalCircuitsAndSimulationLab = true
        } else {
            electricalCircuitsAndSimulationLab = false
        }
        
        // Total 2nd Year 2nd Sem pass or fail with grade
        
        
        if (electroMagneticField == true && generationofElectricalPower == true && switchingThoeryAndLogicalDesign == true && analogElectroniccsAndCircuts == true && electricalMachines2 == true && NetworkTheory == true && electricalMachines1Lab == true && electricalCircuitsAndSimulationLab == true)
        {
            switch secondSemPercentage
            {
            case 90...100:
                btech22GradeLbl.text = "A"
            case 75..<90:
                btech22GradeLbl.text = "B"
            case 50..<75:
                btech22GradeLbl.text = "C"
            case 35..<50:
                btech22GradeLbl.text = "D"
            default:
                btech22GradeLbl.text = "E"
            }
            btech22StatusLbl.text = "PASSED"
        }
        else
        {
            btech22StatusLbl.text = "FAILED"
        }
        
    }
    
    func cal3rdYear1stSemBtechResults(MEFAMarks:Int,EEMMarks:Int,TEPMarks:Int,CSMarks:Int,PEMarks:Int,EM3Marks:Int,EMLab2Marks:Int,CSSimLabMarks:Int)
    {
        // Calculating Total Marks
        
        let thirdYear1stSemGainedMarks:Int = Int(MEFAMarks)+Int(EEMMarks)+Int(TEPMarks)+Int(CSMarks)+Int(PEMarks)+Int(EM3Marks)+Int(EMLab2Marks)+Int(CSSimLabMarks)
        
        btech31TotalLbl.text = "\(thirdYear1stSemGainedMarks)"
        
        // Calculating Percentage
        
        let totalMarks1stSem:Float = 800
        
        let firstSemGainedMarks:Float = Float(thirdYear1stSemGainedMarks)
        
        let firstSemPercentage:Float = (firstSemGainedMarks/totalMarks1stSem)*100
        
        btech31PercentageLbl.text = "\(firstSemPercentage)"
        
        // finding out subject wise pass or fail
        
        let subPassMarks:Int = 35
        let labPassMarks:Int = 35
        
        var managerialEconomicsAndFinancialAnalysis:Bool = false
        var electricalAndElectronicsMeasurements:Bool = false
        var transmissionOfELectricalPower:Bool = false
        var controlSystems:Bool = false
        var powerElectronics:Bool = false
        var electricalMachines3:Bool = false
        var electricalMachinesLab2:Bool = false
        var controlSystemsAndSimulationLab:Bool = false
        
        if MEFAMarks >= subPassMarks
        {
            managerialEconomicsAndFinancialAnalysis = true
        } else {
            managerialEconomicsAndFinancialAnalysis = false
        }
        
        if EEMMarks >= subPassMarks
        {
            electricalAndElectronicsMeasurements = true
        } else {
            electricalAndElectronicsMeasurements = false
        }
        
        if TEPMarks >= subPassMarks
        {
            transmissionOfELectricalPower = true
        } else {
            transmissionOfELectricalPower = false
        }
        
        if CSMarks >= subPassMarks
        {
            controlSystems = true
        } else {
            controlSystems = false
        }
        
        if PEMarks >= subPassMarks
        {
            powerElectronics = true
        } else {
            powerElectronics = false
        }
        
        if EM3Marks >= subPassMarks
        {
            electricalMachines3 = true
        } else {
            electricalMachines3 = false
        }
        
        if EMLab2Marks >= labPassMarks
        {
            electricalMachinesLab2 = true
        } else {
            electricalMachinesLab2 = false
        }
        
        if  CSSimLabMarks >= labPassMarks
        {
            controlSystemsAndSimulationLab = true
        } else {
            controlSystemsAndSimulationLab = false
        }
        
        // Total 3rd Year 1st Sem pass or fail with grade
        
        if (managerialEconomicsAndFinancialAnalysis == true && electricalAndElectronicsMeasurements == true && transmissionOfELectricalPower == true && controlSystems == true && powerElectronics == true && electricalMachines3 == true && electricalMachinesLab2 == true && controlSystemsAndSimulationLab == true)
        {
            switch firstSemPercentage
            {
            case 90...100:
                btech31GradeLbl.text = "A"
            case 75..<90:
                btech31GradeLbl.text = "B"
            case 50..<75:
                btech31GradeLbl.text = "C"
            case 35..<50:
                btech31GradeLbl.text = "D"
            default:
                btech31GradeLbl.text = "E"
            }
            btech31StatusLbl.text = "PASSED"
        }
        else
        {
            btech31StatusLbl.text = "FAILED"
        }
        
    }
    
    
    func cal3rdYear2ndSemBtechResults(MSMarks:Int,PSDMarks:Int,PSAMarks:Int,MPMCMarks:Int,PSOCMarks:Int,LDICAMarks:Int,AECSLLabMarks:Int,EMLabMarks:Int)
    {
        // Calculating Total Marks
        
        let thirdYear2ndSemGainedMarks:Int = Int(MSMarks)+Int(PSDMarks)+Int(PSAMarks)+Int(MPMCMarks)+Int(PSOCMarks)+Int(LDICAMarks)+Int(AECSLLabMarks)+Int(EMLabMarks)
        
        btech32TotalLbl.text = "\(thirdYear2ndSemGainedMarks)"
        
        // Calculating Percentage
        
        let totalMarks2ndSem:Float = 800
        
        let secondSemGainedMarks:Float = Float(thirdYear2ndSemGainedMarks)
        
        let secondSemPercentage:Float = (secondSemGainedMarks/totalMarks2ndSem)*100
        
        btech32PercentageLbl.text = "\(secondSemPercentage)"
        
        // finding out subject wise pass or fail
        
        let subPassMarks:Int = 35
        let labPassMarks:Int = 27
        
        var managementScience:Bool = false
        var powerSemiconductorDrives:Bool = false
        var powerSystemAnalysis:Bool = false
        var microprocessorsAndMicrocontrollers:Bool = false
        var powerOperationsAndControl:Bool = false
        var linearAndDigitalICApplications:Bool = false
        var advancedEnglishCommunicationSkillsLab:Bool = false
        var electricalMeasurementsLab:Bool = false
        
        if MSMarks >= subPassMarks
        {
            managementScience = true
        } else {
            managementScience = false
        }
        
        if PSDMarks >= subPassMarks
        {
            powerSemiconductorDrives = true
        } else {
            powerSemiconductorDrives = false
        }
        
        if PSAMarks >= subPassMarks
        {
            powerSystemAnalysis = true
        } else {
            powerSystemAnalysis = false
        }
        
        if MPMCMarks >= subPassMarks
        {
            microprocessorsAndMicrocontrollers = true
        } else {
            microprocessorsAndMicrocontrollers = false
        }
        
        if PSOCMarks >= subPassMarks
        {
            powerOperationsAndControl = true
        } else {
            powerOperationsAndControl = false
        }
        
        if LDICAMarks >= subPassMarks
        {
            linearAndDigitalICApplications = true
        } else {
            linearAndDigitalICApplications = false
        }
        
        if AECSLLabMarks >= labPassMarks
        {
            advancedEnglishCommunicationSkillsLab = true
        } else {
            advancedEnglishCommunicationSkillsLab = false
        }
        
        if  EMLabMarks >= labPassMarks
        {
            electricalMeasurementsLab = true
        } else {
            electricalMeasurementsLab = false
        }
        
        // Total 3rd Year 2nd Sem pass or fail with grade
        
        if (managementScience == true && powerSemiconductorDrives == true && powerSystemAnalysis == true && microprocessorsAndMicrocontrollers == true && powerOperationsAndControl == true && linearAndDigitalICApplications == true && electricalMeasurementsLab == true && advancedEnglishCommunicationSkillsLab == true)
        {
            switch secondSemPercentage
            {
            case 90...100:
                btech32GradeLbl.text = "A"
            case 75..<90:
                btech32GradeLbl.text = "B"
            case 50..<75:
                btech32GradeLbl.text = "C"
            case 35..<50:
                btech32GradeLbl.text = "D"
            default:
                btech32GradeLbl.text = "E"
            }
            btech32StatusLbl.text = "PASSED"
        }
        else
        {
            btech32StatusLbl.text = "FAILED"
        }
    }
    
    
    
    func cal4thYear1stSemBtechResults(DEPMarks:Int,DSPMarks:Int,fundametalsofHVDCFactsDevicesMarks:Int,SGPMarks:Int,instrumentationMarks:Int,OTMarks:Int,MPMCLabMarks:Int,PESimLabMarks:Int)
    {
        // Calculating Total Marks
        
        let fourthYear1stSemGainedMarks:Int = Int(DEPMarks)+Int(DSPMarks)+Int(fundametalsofHVDCFactsDevicesMarks)+Int(SGPMarks)+Int(instrumentationMarks)+Int(OTMarks)+Int(MPMCLabMarks)+Int(PESimLabMarks)
        
        btech41TotalLbl.text = "\(fourthYear1stSemGainedMarks)"
        
        // Calculating Percentage
        
        let totalMarks1stSem:Float = 800
        
        let firstSemGainedMarks:Float = Float(fourthYear1stSemGainedMarks)
        
        let firstSemPercentage:Float = (firstSemGainedMarks/totalMarks1stSem)*100
        
        btech41PercentageLbl.text = "\(firstSemPercentage)"
        
        // finding out subject wise pass or fail
        
        let subPassMarks:Int = 35
        let labPassMarks:Int = 35
        
        var distributionOfElectricalPower:Bool = false
        var digitalSignalProcessing:Bool = false
        var fundametalsOfHVDCFactsDevices:Bool = false
        var switchGearAndProtection:Bool = false
        var Instrumentation:Bool = false
        var optimizationTechniques:Bool = false
        var microprocessorsAndMicrocontrollersLab:Bool = false
        var powerElectronicsAndSimulationLab:Bool = false
        
        if DEPMarks >= subPassMarks
        {
            distributionOfElectricalPower = true
        } else {
            distributionOfElectricalPower = false
        }
        
        if DSPMarks >= subPassMarks
        {
            digitalSignalProcessing = true
        } else {
            digitalSignalProcessing = false
        }
        
        if fundametalsofHVDCFactsDevicesMarks >= subPassMarks
        {
            fundametalsOfHVDCFactsDevices = true
        } else {
            fundametalsOfHVDCFactsDevices = false
        }
        
        if SGPMarks >= subPassMarks
        {
            switchGearAndProtection = true
        } else {
            switchGearAndProtection = false
        }
        
        if instrumentationMarks >= subPassMarks
        {
            Instrumentation = true
        } else {
            Instrumentation = false
        }
        
        if OTMarks >= subPassMarks
        {
            optimizationTechniques = true
        } else {
            optimizationTechniques = false
        }
        
        if MPMCLabMarks >= labPassMarks
        {
            microprocessorsAndMicrocontrollersLab = true
        } else {
            microprocessorsAndMicrocontrollersLab = false
        }
        
        if  PESimLabMarks >= labPassMarks
        {
            powerElectronicsAndSimulationLab = true
        } else {
            powerElectronicsAndSimulationLab = false
        }
        
        // Total 3rd Year 1st Sem pass or fail with grade
        
        if (distributionOfElectricalPower == true && digitalSignalProcessing == true && fundametalsOfHVDCFactsDevices == true && switchGearAndProtection == true && Instrumentation == true && optimizationTechniques == true && microprocessorsAndMicrocontrollersLab == true && powerElectronicsAndSimulationLab == true)
        {
            switch firstSemPercentage
            {
            case 90...100:
                btech41GradeLbl.text = "A"
            case 75..<90:
                btech41GradeLbl.text = "B"
            case 50..<75:
                btech41GradeLbl.text = "C"
            case 35..<50:
                btech41GradeLbl.text = "D"
            default:
                btech41GradeLbl.text = "E"
            }
            btech41StatusLbl.text = "PASSED"
        }
        else
        {
            btech41StatusLbl.text = "FAILED"
        }
        
    }
    
    func cal4thYear2ndSemBtechResults(PPQMarks:Int,UEEMarks:Int,MCTMarks:Int,EADSMMarks:Int,seminarMarks:Int,projectWorkMarks:Int)
    {
        // Calculating Total Marks
        
        let fourthYear2ndSemGainedMarks:Int = Int(PPQMarks)+Int(UEEMarks)+Int(MCTMarks)+Int(EADSMMarks)+Int(seminarMarks)+projectWorkMarks
        
        btech42TotalLbl.text = "\(fourthYear2ndSemGainedMarks)"
        
        // Calculating Percentage
        
        let totalMarks2ndSem:Float = 600
        
        let secondSemGainedMarks:Float = Float(fourthYear2ndSemGainedMarks)
        
        let secondSemPercentage:Float = (secondSemGainedMarks/totalMarks2ndSem)*100
        
        btech42PercentageLbl.text = "\(secondSemPercentage)"
        
        // finding out subject wise pass or fail
        
        let subPassMarks:Int = 35
        let projectPassMarks:Int = 35
        let semibarPassMarks:Int = 35
        
        var principlesofPowerQuality:Bool = false
        var utilizationofElectricalEnergy:Bool = false
        var modernControlTheory:Bool = false
        var EnergyAuditingandDemandSideManagement:Bool = false
        var seminar:Bool = false
        var projectWork:Bool = false
        
        if PPQMarks >= subPassMarks
        {
            principlesofPowerQuality = true
        } else {
            principlesofPowerQuality = false
        }
        
        if UEEMarks >= subPassMarks
        {
            utilizationofElectricalEnergy = true
        } else {
            utilizationofElectricalEnergy = false
        }
        
        if MCTMarks >= subPassMarks
        {
            modernControlTheory = true
        } else {
            modernControlTheory = false
        }
        
        if EADSMMarks >= subPassMarks
        {
            EnergyAuditingandDemandSideManagement = true
        } else {
            EnergyAuditingandDemandSideManagement = false
        }
        
        if seminarMarks >= semibarPassMarks
        {
            seminar = true
        } else {
            seminar = false
        }
        
        if projectWorkMarks >= projectPassMarks
        {
            projectWork = true
        } else {
            projectWork = false
        }
        
        
        // Total 2nd Year 2nd Sem pass or fail with grade
        
        if (principlesofPowerQuality == true && utilizationofElectricalEnergy == true && modernControlTheory == true && EnergyAuditingandDemandSideManagement == true && seminar == true && projectWork == true)
        {
            switch secondSemPercentage
            {
            case 90...100:
                btech42GradeLbl.text = "A"
            case 75..<90:
                btech42GradeLbl.text = "B"
            case 50..<75:
                btech42GradeLbl.text = "C"
            case 35..<50:
                btech42GradeLbl.text = "D"
            default:
                btech42GradeLbl.text = "E"
            }
            btech42StatusLbl.text = "PASSED"
        }
        else
        {
            btech42StatusLbl.text = "FAILED"
        }
        
    }

    
    }
