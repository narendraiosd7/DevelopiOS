//
//  ViewController.swift
//  Dictionary_16.08.19
//
//  Created by Vadde Narendra on 16/08/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // North region districts & States
        
        print("---------- North Region States ----------")
        
        print("---------- Delhi State Districts ----------")
        
        // Delhi region districts
        
        let newDelhi = District(districtName: "New Delhi", headquaters: "Connaught Place")
        
        let centralDelhi = District(districtName: "Central Delhi", headquaters: "Daryaganj")
        
        let shahdara = District(districtName: "Shahdara", headquaters: "Shahdara")
        
        // Array for Delhi State
        
        var delhi:Dictionary = ["ND":newDelhi,"CD":centralDelhi,"SD":shahdara]
        
        // Printing of Delhi districts details
        
        print(delhi["ND"]!.district)
        
        print("---------- Haryana State Districts ----------")

        // Haryana region districts

        let ambala = District(districtName: "Ambala", headquaters: "Ambala")

        let bhiwani = District(districtName: "Bhiwani", headquaters: "Bhiwani")

        let charkhiDadri = District(districtName: "Charkhi Dadri", headquaters: "Charkhi Dadri")

        // Array for Haryana State

          var haryana:Dictionary = ["AB":ambala,"BW":bhiwani,"CD":charkhiDadri]

        // Printing of Haryana districts details

        print(haryana["AB"]!.district["headquaters"]!)

        print("---------- Uttarpradesh State Districts ----------")

        // Uttarpradesh region districts

        let firozabad = District(districtName: "Firozabad", headquaters: "Agra")

        let agra = District(districtName: "Agra", headquaters: "Agra")

        let mainpuri = District(districtName: "Mainpuri", headquaters: "Agra")

        // Array for Uttarpradesh State

        var uttarpradesh:Dictionary = ["FB":firozabad,"agra":agra,"MP":mainpuri]

        // Printing of Uttarpradesh districts details

         print(uttarpradesh["MP"]!.district)

        print("---------- Punjab State Districts ----------")

        // Punjab region districts

        let barnala = District(districtName: "Barnala", headquaters: "Barnala")

        let bathinda = District(districtName: "Bathinda", headquaters: "Bathinda")

        let faridkot = District(districtName: "Faridkot", headquaters: "Faridkot")

        // Array for Punjab State

        var punjab:Dictionary = ["BN":barnala,"BD":bathinda,"FK":faridkot]

        // Printing of Punjab districts details

        print(punjab["BN"]!.district)

        // North region states Array

        var northRegionStates:Dictionary = ["DH":delhi,"HR":haryana,"PB":punjab]

        // States wise details printing

        print(northRegionStates["HR"]!["AB"]!.district["distrcit"]!)



        print("---------- South Region States ----------")

        // South region districts & States

        print("---------- Andhra Pradesh State Districts ----------")

        // Andhra Pradesh region districts

        let kurnool = District(districtName: "Kurnool", headquaters: "Kurnool")

        let chittoor = District(districtName: "Chittoor", headquaters: "Chittoor")

        let anantapur = District(districtName: "Anantapur", headquaters: "Anantapur")

        // Array for Andhra Pradesh State

        var andhraPradesh:Dictionary = ["KN":kurnool,"CT":chittoor,"ANP":anantapur]

        // Printing of Andhra Pradesh districts details

        print(andhraPradesh["ANP"]!.district)

        print("---------- Telangana State Districts ----------")

        // Telangana region districts

        let mancherial = District(districtName: "Mancherial", headquaters: "Mancherial")

        let hyderabad = District(districtName: "Hyderabad", headquaters: "Hyderabad")

        let medak = District(districtName: "Medak", headquaters: "Medak")

        // Array for Telangana State

        var telangana:Dictionary = ["MCR":mancherial,"HYD":hyderabad,"MDK":medak]

        // Printing of Telangana districts details

        print(telangana["MDK"]!.district["headquaters"]!)

        print("---------- Tamil Nadu State Districts ----------")

        // Tamil Nadu region districts

        let ariyalur = District(districtName: "Ariyalur", headquaters: "Ariyalur")

        let coimbatore = District(districtName: "Coimbatore", headquaters: "Coimbatore")

        let cuddalore = District(districtName: "Cuddalore", headquaters: "Cuddalore")

        // Array for Tamil Nadu State

        var tamilNadu:Dictionary = ["AYL":ariyalur,"CBT":coimbatore,"CL":cuddalore]

        // Printing of Tamil Nadu districts details

        print(tamilNadu["CBT"]!.district)

        // South region states Array

        let southRegionStates:Dictionary = ["AP":andhraPradesh,"TS":telangana,"TN":tamilNadu]



        print("---------- East Region States ----------")

        // East region districts & States

        print("---------- Bihar State Districts ----------")

        // Bihar region districts

        let araria = District(districtName: "Araria", headquaters: "Araria")

        let arwal = District(districtName: "Arwal", headquaters: "Arwal")

        let banka = District(districtName: "Banka", headquaters: "Banka")

        // Array for Bihar State

        var bihar:Dictionary = ["AR":araria,"AW":arwal,"BN":banka]

        // Printing of Tamil Nadu districts details

         print(bihar["AR"]!.district)

        print("---------- Odisha State Districts ----------")

        // Odisha region districts

        let angul = District(districtName: "Angul", headquaters: "Angul")

        let balangir = District(districtName: "Balangir", headquaters: "Balangir")

        let bhadrak = District(districtName: "Bhadrak", headquaters: "Bhadrak")

        // Array for Odisha State

        var odisha:Dictionary = ["AG":angul,"BNG":balangir,"BDK":bhadrak]

        // Printing of Odisha districts details

        print(odisha["BNG"]!.district)

        print("---------- Jharkhand State Districts ----------")

        // Jharkhand region districts

        let bokaro = District(districtName: "Bokaro", headquaters: "Bokaro")

        let chatra = District(districtName: "Chatra", headquaters: "Chatra")

        let deoghar = District(districtName: "Deoghar", headquaters: "Deoghar")

        // Array for Jharkhand State

        var jharkhand:Dictionary = ["BK":bokaro,"CT":chatra,"DGR":deoghar]

        // Printing of Jharkhand districts details

        print(jharkhand["BK"]!.district)

        // East region states Array

        let eastRegionStates:Dictionary = ["BH":bihar,"OD":odisha,"JK":jharkhand]



        // west region districts & States

        print("---------- Gujarat State Districts ----------")

        // Gujarat region districts

        let ahmedabad = District(districtName: "Ahmedabad", headquaters: "Ahmedabad")

        let amreli = District(districtName: "Amreli", headquaters: "Amreli")

        let anand = District(districtName: "Anand", headquaters: "Anand")

        // Array for Gujarat State

        var gujarat:Dictionary = ["AMB":ahmedabad,"ARL":amreli,"AN":anand]

        // Printing of Gujarat districts details

        print(gujarat["AMB"]!.district)

        print("---------- Maharashtra State Districts ----------")

        // Maharashtra region districts

        let amravati = District(districtName: "Amravati", headquaters: "Amravati")

        let akola = District(districtName: "Akola", headquaters: "Amravati")

        let washim = District(districtName: "Washim", headquaters: "Amravati")

        // Array for Maharashtra State

         var maharashtra:Dictionary = ["AMV":amravati,"AKL":akola,"WSM":washim]

        // Printing of Maharashtra districts details

        print(maharashtra["WSM"]!.district)

        print("---------- Rajasthan State Districts ----------")

        // Rajasthan region districts

        let ajmer = District(districtName: "Ajmer", headquaters: "Ajmer")

        let alwar = District(districtName: "Alwar", headquaters: "Alwar")

        let banswara = District(districtName: "Banswara", headquaters: "Banswara")

        // Array for Rajasthan State

        var rajasthan:Dictionary = ["AJR":ajmer,"ALR":alwar,"BSR":banswara]

        // Printing of Rajasthan districts details

        print(rajasthan["AJR"]!.district)

        // West region states Array

        var westRegionStates:Dictionary = ["GR":gujarat,"MH":maharashtra,"RJ":rajasthan]

        print(westRegionStates["RJ"]!["ALR"]!.district["headquaters"]!)

        // Array for Indian States

        let indiaStates: Dictionary = ["ERS":eastRegionStates, "WRS":westRegionStates, "NRS":northRegionStates, "SRS":southRegionStates]

        print(indiaStates["WRS"]!["RJ"]!["ALR"]!.district)

    }

}

