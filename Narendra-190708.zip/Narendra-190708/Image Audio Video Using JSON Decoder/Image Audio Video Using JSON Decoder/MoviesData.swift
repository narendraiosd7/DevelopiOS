//
//  MoviesData.swift
//  Image Audio Video Using JSON Decoder
//
//  Created by Vadde Narendra on 12/3/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class MoviesData: NSObject
{
    // MARK:- ServerData
    
    func gettingMoviesDetails()
    {
        
        var urlObj = URLRequest(url: URL(string: "https://www.brninfotech.com/tws/MovieDetails2.php?mediaType=movies")!)
        urlObj.httpMethod = "Get"
        let  taskObj = URLSession.shared.dataTask(with: urlObj)
        {
            (data, response, err) in
            do
            {
                let decoder = try Decoder.decode(Movie.self, from: data!)
            }
            catch
            {
                print("Something went wrong")
            }
        }
        taskObj.resume()
    
    }


}
