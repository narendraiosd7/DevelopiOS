//
//  ViewController.swift
//  Image Audio Video Using JSON Decoder
//
//  Created by Vadde Narendra on 12/3/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

