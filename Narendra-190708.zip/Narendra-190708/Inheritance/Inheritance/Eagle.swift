//
//  Eagle.swift
//  Inheritance
//
//  Created by Vadde Narendra on 07/08/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class Eagle: Pigeon {

    var noOfTails:String = "One"
    var flying:String = "High"
    
    func eagleDescription(){
        print("Number of wings = \(noOfWings)")
        print("Number of legs = \(noOfLegs)")
        print("Number of tails = \(noOfTails)")
        print("It can fly \(flying)")
    }
}
