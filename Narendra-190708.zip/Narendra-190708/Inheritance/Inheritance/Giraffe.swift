//
//  Giraffe.swift
//  Inheritance
//
//  Created by Vadde Narendra on 08/08/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class Giraffe: Elephant {

        var height:String = "compare to all animal it's height is more"
        
        func giraffeDescription(){
            
            print("Number of legs = \(noOfLegs)")
            print("Number of tails = \(noOfTails)")
            print("\(height)")
        }
        
    }
    
