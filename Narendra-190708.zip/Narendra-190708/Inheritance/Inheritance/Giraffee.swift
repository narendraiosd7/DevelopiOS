//
//  Giraffee.swift
//  Inheritance
//
//  Created by Vadde Narendra on 07/08/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class Giraffe: Elephant {

    var hight:String = "compare to all animal it's hight is high"
    
    func giraffeDescription(){
        
        print("Number of legs = \(noOfLegs)")
        print("Number of tails = \(noOfTails)")
        print("\(hight)")
    }
    
}
