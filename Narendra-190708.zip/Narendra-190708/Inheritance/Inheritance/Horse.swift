//
//  Horse.swift
//  Inheritance
//
//  Created by Vadde Narendra on 07/08/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class Horse: NSObject {

    var noOfLegs:UInt8 = 4
    
    func horseDescription(){
        
        print("Number of legs = \(noOfLegs)")
    }
    
}
