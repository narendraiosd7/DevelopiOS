//
//  Lion.swift
//  Inheritance
//
//  Created by Vadde Narendra on 07/08/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class Lion: NSObject {

    var numberOfTails:UInt8 = 1
    var numberOfEyes:UInt8 = 2
    var numberOfLegs:UInt8 = 4
    
    func lionDescription(){
        
        print("Number of tails = \(numberOfTails)")
         print("Number of eyes = \(numberOfEyes)")
         print("Number of legs = \(numberOfLegs)")
        
    }
    
}
