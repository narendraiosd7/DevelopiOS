//
//  Peacock.swift
//  Inheritance
//
//  Created by Vadde Narendra on 07/08/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class Peacock: Eagle {

    var lengthOfTail:String = "Long"
    
    func peacockDescription(){
        
        print("It's having \(lengthOfTail) tail")
        print("Number of wings = \(noOfWings)")
        print("Number of legs = \(noOfLegs)")
        print("Number of tails = \(noOfTails)")
        print("It can fly \(flying)")
        
    }
    
}
