//
//  AddingDetails.swift
//  Passing Data Using Delegate
//
//  Created by Vadde Narendra on 11/16/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

// MARK:- protocol declaration

protocol dataTransfer
{
    func passingData(values:[String])
}

// MARK:- Class declaration

class AddingDetails: UIViewController
{

    @IBOutlet weak var firstNameTF: UITextField!
    @IBOutlet weak var lastNameTF: UITextField!
    
    // MARK:- Delegate declaration
    
    var delegate : dataTransfer!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
    }
    
    //MARK:- save button tapping function
    
    @IBAction func saveBtnTapped(_ sender: UIButton)
    {
        var name  = [String]()
        
        name.append(firstNameTF.text!)
        name.append(lastNameTF.text!)
        
        delegate.passingData(values: name)
        
        dismiss(animated: true, completion: nil)
        
    }
    
    

}
