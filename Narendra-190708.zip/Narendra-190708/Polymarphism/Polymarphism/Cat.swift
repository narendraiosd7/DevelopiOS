//
//  Cat.swift
//  Polymarphism
//
//  Created by Vadde Narendra on 08/08/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class Cat: NSObject {

    var family:String?
    var sleepingHours:String?
    var eatingHabits:String?
    var sleepingHabits:String?
    var huntingHabits:String?
    
    func dailyActivities(){
        
        print("Cat belongs to \(family!) family")
        print("Cat sleeps approximately \(sleepingHours!)")
        print("Cat \(eatingHabits!)")
        print("Cat \(sleepingHabits!)")
        print("Cat hunts \(huntingHabits!)")
        
    }
    
    
    
}
