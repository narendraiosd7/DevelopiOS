//
//  Donkey.swift
//  Polymarphism
//
//  Created by Vadde Narendra on 08/08/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class Donkey: NSObject {

    var eatingHabit:String?
    var uses:String?
    
    func activities() {
        
        print("Donkey \(eatingHabit!)")
        print("Donkey is used to \(uses!)")
    }
}
