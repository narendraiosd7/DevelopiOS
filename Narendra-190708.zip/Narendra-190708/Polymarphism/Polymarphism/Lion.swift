//
//  Lion.swift
//  Polymarphism
//
//  Created by Vadde Narendra on 08/08/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class Lion: Tiger {
    
    var advantage:String?
    
    override func dailyActivities(){
        
        print("Lion belongs to \(family!) family")
        print("Lion sleeps approximately \(sleepingHours!)")
        print("Lion \(eatingHabits!)")
        print("Lion \(sleepingHabits!)")
        print("Lion hunts \(huntingHabits!)")
        print("Lion having \(advantage!)")
    }

}
