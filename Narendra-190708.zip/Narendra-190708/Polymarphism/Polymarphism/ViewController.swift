//
//  ViewController.swift
//  Polymarphism
//
//  Created by Vadde Narendra on 08/08/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let cat = Cat()
        
        cat.family = "Carnivorous"
        cat.sleepingHours = "10 Hrs to 12 Hrs"
        cat.eatingHabits = "Drinks Milk and Eating Non-Veg"
        cat.sleepingHabits = "Sleeps at corners of the room and top of the roofs"
        cat.huntingHabits = "rats and lizards"
        
        cat.dailyActivities()
        
        print("========= ***** ==========")
        
        let cheetah = Cheetah()
        
        cheetah.family = "Carnivorous"
        cheetah.sleepingHours = "10 Hrs to 12 Hrs"
        cheetah.eatingHabits = "eats only flesh"
        cheetah.sleepingHabits = "sleeps on Trees"
        cheetah.huntingHabits = "animals"
        cheetah.speed = "100 Kmph to  120 Kmph"
        
        cheetah.dailyActivities()
        
        print("========= ***** ==========")
        
        let tiger = Tiger()
        
        tiger.family = "Carnivorous"
        tiger.sleepingHours = "10 Hrs to 12 Hrs"
        tiger.eatingHabits = "eats only flesh"
        tiger.sleepingHabits = "sleeps in den"
        tiger.huntingHabits = "animals"
        tiger.find = "Asia"
        
        tiger.dailyActivities()
        
        print("========= ***** ==========")
        
        let lion = Lion()
        
        lion.family = "Felidae"
        lion.sleepingHours = "10 Hrs to 12 Hrs"
        lion.eatingHabits = "eats only flesh"
        lion.sleepingHabits = "sleeps in den"
        lion.huntingHabits = "animals"
        lion.advantage = "powerful forelegs and compact body"
        
        lion.dailyActivities()
        
        print("========= ***** ==========")
        
        let donkey = Donkey()
        
        donkey.eatingHabit = "eats grass and drinks water"
        donkey.uses = "carrying weights"
        
        donkey.activities()
        
        print("========= ***** ==========")
        
        let zebra = Zebra()
        
        zebra.eatingHabit = "eats grass and drinks water"
        zebra.staying = "forest"
        
        zebra.activities()
        
        print("========= ***** ==========")
        
        let horse = Horse()
        
        horse.eatingHabit = "eats grass and drinks water"
        horse.uses = "riding"
        horse.speed = "100 Kmph to 120 Kmph"
        
        horse.activities()
        
        print("========= ***** ==========")
        
        let dog = Dog()
        
        dog.eatingHabit = "eats veg and non-veg"
        
        dog.activities()
        
        print("========= ***** ==========")
        
        let fox = Fox()
        
        fox.eatingHabit = "eats flesh"
        fox.staying = "forest"
        
        fox.activities()

        
        
        
        
        
        
        
        
        
        
        
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }


}

