//
//  TenthCalculations.swift
//  Protocols,Extensions, Property Observers, Setters and Getters_22.08.19
//
//  Created by Vadde Narendra on 22/08/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class TenthCalculations: NSObject,TenthClass {
    
    var passMarks: UInt8 = 0{
        
        willSet(newValue){
            print("The pass marks are changed to \(newValue)")
        }
        didSet(oldValue) {
            print("from \(oldValue)")
        }
    } // Creating property observers to pass marks
    
//    var newPassMarks:UInt8 {
//
//        set (passMarks){
//            newPassMarks = passMarks
//        } get {
//            return newPassMarks
//        }
//
//    }
    
    var engMarks: UInt8 = 0
    
    var telMarks: UInt8 = 0
    
    var hindiMarks: UInt8 = 0
    
    var mathsMarks: UInt8 = 0
    
    var sciMarks: UInt8 = 0
    
    var socMarks: UInt8 = 0
    
    func tenthCalculations() {
        
        let tenthTotalMarks:UInt16 = UInt16(telMarks)+UInt16(engMarks)+UInt16(hindiMarks)+UInt16(mathsMarks)+UInt16(sciMarks)+UInt16(socMarks) // Total Marks Calculation
        
        let tenthPercentage:Float = (Float(tenthTotalMarks)/600)*100 // Percentage Calculation
        
        if (telMarks >= passMarks && engMarks >= passMarks && hindiMarks >= passMarks && mathsMarks >= passMarks && sciMarks >= passMarks && socMarks >= passMarks){
            
            switch tenthPercentage{
            case 90...100:
                print("Grade A")
            case 75..<90:
                print("Grade B")
            case 50..<75:
                print("Grade C")
            case 35..<50:
                print("Grade D")
            default:
                print("Grade E")
            }
            print("Total Marks = \(tenthTotalMarks)")
            print("Percentage = \(tenthPercentage)")
            print("Tenth Passed")
        } else {
            print("Total Marks = \(tenthTotalMarks)")
            print("Percentage = \(tenthPercentage)")
            print("Tenth Failed")
        }
    }                                                                                   // Calculating grade, Overall pass or fail and reading Percentage and Total Marks
}

extension String {
    
    func replace(target: String, withString: String) -> String {
        return self.replacingOccurrences(of: target, with: withString)
    }
}                                                                                      // creating extension for exsting String




