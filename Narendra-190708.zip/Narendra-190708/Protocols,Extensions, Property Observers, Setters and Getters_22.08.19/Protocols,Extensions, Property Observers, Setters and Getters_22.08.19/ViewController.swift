//
//  ViewController.swift
//  Protocols,Extensions, Property Observers, Setters and Getters_22.08.19
//
//  Created by Vadde Narendra on 22/08/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let narendra:TenthCalculations = TenthCalculations()

        narendra.engMarks = 95
        narendra.telMarks = 90
        narendra.hindiMarks = 85
        narendra.mathsMarks = 80
        narendra.sciMarks = 50
        narendra.socMarks = 70

        narendra.passMarks = 40

        narendra.tenthCalculations()

        // extensions

        let newString = "India is my country".replace(target: "my", withString: "our")

        print(newString)
        
        // getters and setters
        
        var a:String = ""
        var b:String = ""
        
        var c:String {
            
            set(newString){
                b = newString
                a = "Abhinav"
            } get {
                return "10";
            }
        }
        
        c = "Narendra"
        
        print("Name of person is \(b) \(a)")
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }


}

