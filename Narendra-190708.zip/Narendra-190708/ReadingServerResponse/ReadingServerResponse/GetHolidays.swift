//
//  GetHolidays.swift
//  ReadingServerResponse
//
//  Created by Vadde Narendra on 9/11/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class GetHolidays: NSObject {
    
    
