//
//  ViewController.swift
//  ScopeofVariables&FuncWithParameters
//
//  Created by BRN1907 on 30/07/19.
//  Copyright © 2019 BRN1907. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

// Tenth Pass Mars & Total Marks
    
        var passMarks:UInt8 = 35
        var totalMarks:Float = 600
    
    override func viewDidLoad() {
        super.viewDidLoad()

        calTenthMarks(telMarks:90,engMarks:99,hinMarks:92,mathsMarks:89,sciMarks:79,socMarks:75,studentName:"Narendra")
        calTenthMarks(telMarks:85,engMarks:75,hinMarks:65,mathsMarks:55,sciMarks:45,socMarks:35,studentName:"Avinash")
        calTenthMarks(telMarks:99,engMarks:89,hinMarks:69,mathsMarks:59,sciMarks:49,socMarks:39,studentName:"Arun")
        calTenthMarks(telMarks:47,engMarks:49,hinMarks:64,mathsMarks:58,sciMarks:38,socMarks:28,studentName:"Aditya")
        calTenthMarks(telMarks:75,engMarks:76,hinMarks:66,mathsMarks:57,sciMarks:47,socMarks:47,studentName:"Rakesh")
        calTenthMarks(telMarks:45,engMarks:49,hinMarks:67,mathsMarks:56,sciMarks:48,socMarks:38,studentName:"Nickel")
        calTenthMarks(telMarks:75,engMarks:38,hinMarks:62,mathsMarks:54,sciMarks:49,socMarks:39,studentName:"Monish")
        calTenthMarks(telMarks:45,engMarks:48,hinMarks:64,mathsMarks:53,sciMarks:40,socMarks:38,studentName:"kiran")
        calTenthMarks(telMarks:76,engMarks:76,hinMarks:69,mathsMarks:52,sciMarks:49,socMarks:37,studentName:"Sai")
        calTenthMarks(telMarks:65,engMarks:35,hinMarks:62,mathsMarks:51,sciMarks:48,socMarks:36,studentName:"Gopal")
        calTenthMarks(telMarks:48,engMarks:49,hinMarks:66,mathsMarks:50,sciMarks:47,socMarks:39,studentName:"Srinivas")
        calTenthMarks(telMarks:86,engMarks:76,hinMarks:68,mathsMarks:51,sciMarks:46,socMarks:30,studentName:"Babu")
        calTenthMarks(telMarks:79,engMarks:48,hinMarks:61,mathsMarks:52,sciMarks:45,socMarks:39,studentName:"Akbar")
        calTenthMarks(telMarks:48,engMarks:79,hinMarks:68,mathsMarks:53,sciMarks:44,socMarks:38,studentName:"Hazi")
        calTenthMarks(telMarks:76,engMarks:79,hinMarks:61,mathsMarks:54,sciMarks:43,socMarks:37,studentName:"Ashok")
        
        
// Inter 1st Year Results
        
        interFirstMarks(sanMarks:70,engMarks:99,mathsAMarks:100,mathsBMarks:71,physicsMarks:70,chemistryMarks:41,studentName:"Narendra")
        interFirstMarks(sanMarks:71,engMarks:98,mathsAMarks:99,mathsBMarks:72,physicsMarks:69,chemistryMarks:42,studentName:"Avinash")
        interFirstMarks(sanMarks:72,engMarks:97,mathsAMarks:98,mathsBMarks:73,physicsMarks:68,chemistryMarks:43,studentName:"Rakesh")
        interFirstMarks(sanMarks:73,engMarks:96,mathsAMarks:97,mathsBMarks:74,physicsMarks:67,chemistryMarks:44,studentName:"Aditya")
        interFirstMarks(sanMarks:74,engMarks:95,mathsAMarks:96,mathsBMarks:75,physicsMarks:66,chemistryMarks:45,studentName:"Monish")
        interFirstMarks(sanMarks:75,engMarks:94,mathsAMarks:95,mathsBMarks:76,physicsMarks:65,chemistryMarks:46,studentName:"Nickil")
        interFirstMarks(sanMarks:76,engMarks:93,mathsAMarks:94,mathsBMarks:77,physicsMarks:64,chemistryMarks:47,studentName:"Kiran")
        interFirstMarks(sanMarks:77,engMarks:92,mathsAMarks:93,mathsBMarks:78,physicsMarks:63,chemistryMarks:48,studentName:"Arun")
        interFirstMarks(sanMarks:78,engMarks:91,mathsAMarks:92,mathsBMarks:79,physicsMarks:62,chemistryMarks:49,studentName:"Varun")
        interFirstMarks(sanMarks:79,engMarks:90,mathsAMarks:91,mathsBMarks:80,physicsMarks:61,chemistryMarks:50,studentName:"Gopal")
        interFirstMarks(sanMarks:80,engMarks:89,mathsAMarks:90,mathsBMarks:81,physicsMarks:60,chemistryMarks:51,studentName:"Srinivas")
        interFirstMarks(sanMarks:81,engMarks:88,mathsAMarks:89,mathsBMarks:82,physicsMarks:59,chemistryMarks:52,studentName:"Punith")
        interFirstMarks(sanMarks:82,engMarks:87,mathsAMarks:88,mathsBMarks:83,physicsMarks:58,chemistryMarks:53,studentName:"Nikskhith")
        interFirstMarks(sanMarks:83,engMarks:86,mathsAMarks:87,mathsBMarks:84,physicsMarks:57,chemistryMarks:54,studentName:"Tej")
        interFirstMarks(sanMarks:84,engMarks:85,mathsAMarks:86,mathsBMarks:85,physicsMarks:56,chemistryMarks:55,studentName:"Abhinav")
        
// Inter 2nd Year Results
        
        inter2ndYear(sanMarks:99,engMarks:89,mathsAMarks:65,mathsBMarks:55,physicsMarks:50,chemistryMarks:40,physicsLab:30,chemistryLab:20,studentName:"Narendra")
        inter2ndYear(sanMarks:89,engMarks:79,mathsAMarks:55,mathsBMarks:45,physicsMarks:40,chemistryMarks:30,physicsLab:34,chemistryLab:10,studentName:"Avinash")
        inter2ndYear(sanMarks:79,engMarks:69,mathsAMarks:45,mathsBMarks:35,physicsMarks:30,chemistryMarks:46,physicsLab:37,chemistryLab:39,studentName:"Rakesh")
        inter2ndYear(sanMarks:99,engMarks:89,mathsAMarks:65,mathsBMarks:55,physicsMarks:50,chemistryMarks:40,physicsLab:30,chemistryLab:30,studentName:"Aditya")
        inter2ndYear(sanMarks:89,engMarks:59,mathsAMarks:55,mathsBMarks:45,physicsMarks:40,chemistryMarks:30,physicsLab:32,chemistryLab:35,studentName:"Monish")
        inter2ndYear(sanMarks:79,engMarks:69,mathsAMarks:45,mathsBMarks:35,physicsMarks:30,chemistryMarks:42,physicsLab:28,chemistryLab:28,studentName:"Nickil")
        inter2ndYear(sanMarks:99,engMarks:89,mathsAMarks:65,mathsBMarks:55,physicsMarks:50,chemistryMarks:42,physicsLab:30,chemistryLab:35,studentName:"Kiran")
        inter2ndYear(sanMarks:89,engMarks:77,mathsAMarks:55,mathsBMarks:45,physicsMarks:40,chemistryMarks:30,physicsLab:26,chemistryLab:15,studentName:"Arun")
        inter2ndYear(sanMarks:79,engMarks:61,mathsAMarks:45,mathsBMarks:35,physicsMarks:30,chemistryMarks:52,physicsLab:19,chemistryLab:38,studentName:"Gopal")
        inter2ndYear(sanMarks:99,engMarks:89,mathsAMarks:55,mathsBMarks:55,physicsMarks:50,chemistryMarks:40,physicsLab:34,chemistryLab:34,studentName:"Srinivas")
        inter2ndYear(sanMarks:89,engMarks:79,mathsAMarks:55,mathsBMarks:45,physicsMarks:40,chemistryMarks:30,physicsLab:26,chemistryLab:24,studentName:"Punith")
        inter2ndYear(sanMarks:79,engMarks:69,mathsAMarks:45,mathsBMarks:35,physicsMarks:30,chemistryMarks:48,physicsLab:34,chemistryLab:18,studentName:"Nikskhith")
        inter2ndYear(sanMarks:99,engMarks:89,mathsAMarks:65,mathsBMarks:55,physicsMarks:50,chemistryMarks:45,physicsLab:36,chemistryLab:29,studentName:"Narendra")
        inter2ndYear(sanMarks:89,engMarks:79,mathsAMarks:55,mathsBMarks:45,physicsMarks:40,chemistryMarks:54,physicsLab:40,chemistryLab:34,studentName:"Tej")
        inter2ndYear(sanMarks:79,engMarks:69,mathsAMarks:45,mathsBMarks:35,physicsMarks:30,chemistryMarks:34,physicsLab:34,chemistryLab:36,studentName:"Abhinav")
        
        
    
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
        func calTenthMarks(telMarks:UInt8,engMarks:UInt8,hinMarks:UInt8,mathsMarks:UInt8,sciMarks:UInt8,socMarks:UInt8,studentName:String){
        
        
// Subject wise marks
        
        print("Telugu = \(telMarks)")
        print("English = \(engMarks)")
        print("Hindhi = \(hinMarks)")
        print("Maths = \(mathsMarks)")
        print("Science = \(sciMarks)")
        print("Social = \(socMarks)")
        
// Total Marks Calculations
        
        let totalMarksGained:UInt16 = UInt16(telMarks)+UInt16(engMarks)+UInt16(hinMarks)+UInt16(mathsMarks)+UInt16(sciMarks)+UInt16(socMarks)
        print("\(studentName) Tenth Marks = \(totalMarksGained)")
        
// Percentage calculator
        
        let gainedMarks:Float = Float(totalMarksGained)
        let percentage:Float = (gainedMarks/totalMarks)*100
        
        print("\(studentName) Percentage = \(percentage)")
        
// Subject wise pass/fail
        
        
        var telugu:Bool = false
        var english:Bool = false
        var hindi:Bool = false
        var maths:Bool = false
        var social:Bool = false
        var science:Bool = false
        
        if telMarks >= passMarks{
            telugu = true
        } else {
            telugu = false
        }
        
        if engMarks >= passMarks{
            english = true
        } else {
            english = false
        }
        
        if hinMarks >= passMarks{
            hindi = true
        } else {
            hindi = false
        }
        
        if mathsMarks >= passMarks{
            maths = true
        } else {
            maths = false
        }
        
        if sciMarks >= passMarks{
            science = true
        } else {
            science = false
        }
        
        if socMarks >= passMarks{
            social = true
        } else {
            social = false
        }
        
// Tenth Pass/Fail
        
        if (telugu == true && english == true && hindi == true && maths == true && science == true && social == true){
            switch percentage{
            case 90...100:
                print("Grade = A")
            case 75..<90:
                print("Grade = B")
            case 50..<75:
                print("Grade = C")
            case 35..<50:
                print("Grade = D")
            default:
                print("Grade = E")}
                print("\(studentName) Tenth PASSED")
            
        }else {
                    print("\(studentName) Tenth FAILED")}
                
            }
    
}



// 1st Year Inter pass marks & Total marks

        var passMarks1:UInt8 = 35
        var passMarks2:UInt8 = 24
        var passmarks3:UInt8 = 18

// Inter 1st Year Percentage calculated below

        let total1stYearMarks:Float = 470

        var interFirstYearResults:Bool = false
        var interSecondYearResults:Bool = false



        func interFirstMarks(sanMarks:UInt8,engMarks:UInt8,mathsAMarks:UInt8,mathsBMarks:UInt8,physicsMarks:UInt8,chemistryMarks:UInt8,studentName:String){

            print("Sanskrit = \(sanMarks)")
            print("English = \(engMarks)")
            print("MathsA = \(mathsAMarks)")
            print("MathsB = \(mathsBMarks)")
            print("Physics = \(physicsMarks)")
            print("Chemistry = \(chemistryMarks)")
            
// Inters 1st Year Total Marks coding is available below
    
            let firsYearGainedMarks:UInt16 = UInt16(sanMarks)+UInt16(engMarks)+UInt16(mathsAMarks)+UInt16(physicsMarks)+UInt16(chemistryMarks)+UInt16(mathsBMarks)
    
// Inter Total Marks printing code is available below
    
            print("\(studentName) First Year Marks = \(firsYearGainedMarks)")
    
// Inter 1st Year Marks of Nandu converted in Float & Calculating Percentage
    
            let firsYearMarks:Float = Float(firsYearGainedMarks)
    
            let percentage:Float = (firsYearMarks/total1stYearMarks)*100
    
// Nandu's 1st Year Percentage is Printing below
    
            print("\(studentName) 1st Year Percentage = \(percentage)")
    
// Coding to the Nandu passed or failed in Inter subject-wise is given below
    
            var sanskrit:Bool = false
            var english:Bool = false
            var mathsA:Bool = false
            var mathsB:Bool = false
            var physics:Bool = false
            var chemistry:Bool = false
    
    
            if sanMarks >= passMarks1 {
                sanskrit = true
                } else {
                sanskrit = false
                }
            
            if engMarks >= passMarks1 {
                english = true
                } else {
                english = false
                }
    
            if mathsAMarks >= passMarks2 {
                mathsA = true
                } else {
                mathsA = false
                }
    
            if mathsBMarks >= passMarks2 {
                mathsB = true
                } else {
                mathsB = false
                }
    
            if physicsMarks >= passmarks3 {
                physics = true
                } else {
                physics = false
                }
    
            if chemistryMarks >= passmarks3 {
                chemistry = true
                } else {
                chemistry = false
                }
    
// Coding to the Nandu passed or failed in Inter is given below
    
            if (sanskrit == true && english == true && mathsA == true && mathsB == true && physics == true && chemistry == true){
                switch percentage{
                case 90...100:
                    print("Grade = A")
                case 75..<90:
                    print("Grade = B")
                case 50..<75:
                    print("Grade = C")
                case 35..<50:
                    print("Grade = D")
                default:
                    print("Grade = E")}
                interFirstYearResults = true
                print("\(studentName) Inter 1st Year PASSED")
                } else {
                interFirstYearResults = false
                print("\(studentName) Inter 1st Year FAILED")
                }
}



// Inter 2nd Year lab pass marks

            let labPassMarks:UInt8 = 18

// Inter 2nd Year Total Marks are available in Float below

            let total2ndYearMarks:Float = 530


            func inter2ndYear(sanMarks:UInt8,engMarks:UInt8,mathsAMarks:UInt8,mathsBMarks:UInt8,physicsMarks:UInt8,chemistryMarks:UInt8,physicsLab:UInt8,chemistryLab:UInt8,studentName:String){
                
                print("Sanskrit = \(sanMarks)")
                print("English = \(engMarks)")
                print("Maths2A = \(mathsAMarks)")
                print("Maths2B = \(mathsBMarks)")
                print("Physics = \(physicsMarks)")
                print("Chemistry = \(chemistryMarks)")
                print("Physics Lab = \(physicsLab)")
                print("Chemistry Lab = \(chemistryLab)")
                
// Inters 2nd Year Total Marks coding is available below
    
            let secondYearGainedMarks:UInt16 = UInt16(engMarks)+UInt16(sanMarks)+UInt16(mathsAMarks)+UInt16(mathsBMarks)+UInt16(physicsMarks)+UInt16(chemistryMarks)+UInt16(physicsLab)+UInt16(chemistryLab)
        
                print("\(studentName) 2nd Year Marks = \(secondYearGainedMarks)")
        
// Inter 2nd Year Marks of Nandu converted in Float
    
            let secondYearMarks:Float = Float(secondYearGainedMarks)
    
// Inter 2nd Year Percentage calculated below
    
            let percentage:Float = (secondYearMarks/total2ndYearMarks)*100
    
// Nandu's 2nd Year Percentage is Printing below
    
            print("\(studentName) 2nd Year Percentage = \(percentage)")
    
// Coding to the Nandu passed or failed in Inter 2nd Year is given below
    
            var sanskrit:Bool = false
            var english:Bool = false
            var mathsA:Bool = false
            var mathsB:Bool = false
            var physics:Bool = false
            var chemistry:Bool = false
            var physicsPracticals:Bool = false
            var chemistryPracticals:Bool = false
    
    
    
    
            if sanMarks >= passMarks1 {
                sanskrit = true
                } else {
                sanskrit = false
                }
    
            if engMarks >= passMarks1 {
                english = true
                } else {
                english = false
                }
    
            if mathsAMarks >= passMarks2 {
                mathsA = true
                } else {
                mathsA = false
                }
    
            if mathsBMarks >= passMarks2 {
                mathsB = true
                } else {
                mathsB = false
                }
    
            if physicsMarks >= passmarks3 {
                physics = true
                } else {
                physics = false
                }
    
            if chemistryMarks >= passmarks3 {
                chemistry = true
                } else {
                chemistry = false
                }
    
            if physicsLab >= labPassMarks {
                physicsPracticals = true
                } else {
                physicsPracticals = false
                }
    
            if chemistryLab >= labPassMarks {
                chemistryPracticals = true
                } else {
                chemistryPracticals = false
                }

    // Coding to the Nandu passed or failed in Inter is given below
    
            if (sanskrit == true && english == true && mathsA == true && mathsB == true && physics == true && chemistry == true && physicsPracticals == true && chemistryPracticals == true){
                switch percentage {
                case 90...100:
                    print("Grade = A")
                case 75...90:
                    print("Grade = B")
                case 50...75:
                    print("Grade = C")
                case 35...50:
                    print("Grade = D")
                default:
                    print("Grade = E")
                }
                interSecondYearResults = true
                print("\(studentName) Inter 2nd Year PASSED")
                } else {
                interSecondYearResults = false
                print("\(studentName) Inter 2nd Year FAILED")
                }

                if interFirstYearResults == true && interSecondYearResults == true{
                    print("\(studentName) Inter PASSED")
                } else {
                    print("\(studentName) Inter FAILED")
                }
                }

