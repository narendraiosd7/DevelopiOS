//
//  ViewController.swift
//  Sets
//
//  Created by Vadde Narendra on 20/08/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // cricketers set
        
        var cricketers:Set<String> = ["Gautam Gambhir","Mohammad Azharuddin","Navjot Singh Sidhu","Kirti Azad","Mansoor Ali Khan Pataudi","Mahendra Singh Dhoni","Yuraj Singh","Virat Kohli","V V S Laxman"]
        
        // Politicians set
        
        var politicians:Set<String> = ["Jayalalithaa","Smrithi Irani","Gautam Gambhir","Mohammad Azharuddin","Navjot Singh Sidhu","Kirti Azad","Mansoor Ali Khan Pataudi","Neelam Sanjeeva Reddy","Pawan Kalyan","Dr. Rajendra Prasad","Sardar Vallabhai Patel"]
        
        // Actors set
        
        var actors:Set<String> = ["Jayalalithaa","Smrithi Irani","Pawan Kalyan","Rajinikanth","Ajith","Amithab","Upendra","Mohanlal"]
        
        // Union of sets
        
        print("************* Union *************")
        
        print(cricketers.union(politicians))
        
        print(cricketers.union(actors))
        
        print(politicians.union(actors))
        
        // Intersection of sets
        
         print("************* Intersection *************")
        
        print(cricketers.intersection(politicians))
        
        print(politicians.intersection(actors))
        
        // Symmetric Difference of sets
        
        print("************* Symmetric Difference *************")
        
        print(cricketers.symmetricDifference(politicians))
        
        print(politicians.symmetricDifference(actors))
        
        // Substracting of sets
        
        print("************* Subtracting *************")
        
        print(cricketers.subtracting(politicians))
        
        print(politicians.subtracting(actors))
        
        // Do any additional setup after loading the view, typically from a nib.
    }


}

