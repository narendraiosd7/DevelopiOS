//
//  ViewController.swift
//  Structs_13.8.19
//
//  Created by Vadde Narendra on 13/08/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("***___*** Tenth calculations ***___***")
        
        print("========== Person - 1 ==========")
        
        let kiran:Tenthcalculations = Tenthcalculations(telMarks: 95, engMarks: 94, hindiMarks: 97, mathsMarks: 98, sciMarks: 96, socMarks: 96)
        
        print("========== Person - 2 ==========")
        
        let avinash:Tenthcalculations = Tenthcalculations(telMarks: 75, engMarks: 78, hindiMarks: 82, mathsMarks: 81, sciMarks: 84, socMarks: 75)
        
        print("========== Person - 3 ==========")
        
        let rakesh:Tenthcalculations = Tenthcalculations(telMarks: 95, engMarks: 94, hindiMarks: 97, mathsMarks: 81, sciMarks: 84, socMarks: 75)
        
        print("========== Person - 4 ==========")
        
        let sai:Tenthcalculations = Tenthcalculations(telMarks: 95, engMarks: 94, hindiMarks: 97, mathsMarks: 81, sciMarks: 84, socMarks: 75)
        
        print("========== Person - 5 ==========")
        
        let mounish:Tenthcalculations = Tenthcalculations(telMarks: 75, engMarks: 78, hindiMarks: 82, mathsMarks: 98, sciMarks: 96, socMarks: 96)
        
        
        print("***___*** Inter calculations ***___***")
        
        print("========== Person - 1 ==========")
        
        let narendra:InterCalculations = InterCalculations(san1stYearMarks: 72, eng1stYearMarks: 76, mathsA1stYearMarks: 71, mathsB1stYearMarks: 79, physics1stYearMarks: 76, chemistry1stYearMarks: 71, san2ndYearMarks: 75, eng2ndYearMarks: 69, mathsA2ndYearMarks: 64, mathsB2ndYearMarks: 67, physics2ndYearMarks: 62, chemistry2ndYearMarks: 66, physicsLab: 24, chemistryLab: 29)
        
        print("========== Person - 2 ==========")
        
        let Vinay:InterCalculations = InterCalculations(san1stYearMarks: 85, eng1stYearMarks: 59, mathsA1stYearMarks: 65, mathsB1stYearMarks: 79, physics1stYearMarks: 67, chemistry1stYearMarks: 95, san2ndYearMarks: 75, eng2ndYearMarks: 69, mathsA2ndYearMarks: 64, mathsB2ndYearMarks: 67, physics2ndYearMarks: 62, chemistry2ndYearMarks: 66, physicsLab: 24, chemistryLab: 29)
        
        print("========== Person - 3 ==========")
        
        let Udhay:InterCalculations = InterCalculations(san1stYearMarks: 72, eng1stYearMarks: 76, mathsA1stYearMarks: 71, mathsB1stYearMarks: 79, physics1stYearMarks: 76, chemistry1stYearMarks: 71, san2ndYearMarks: 48, eng2ndYearMarks: 58, mathsA2ndYearMarks: 74, mathsB2ndYearMarks: 67, physics2ndYearMarks: 62, chemistry2ndYearMarks: 79, physicsLab: 35, chemistryLab: 34)
        
        print("========== Person - 4 ==========")
        
        let ram:InterCalculations = InterCalculations(san1stYearMarks: 85, eng1stYearMarks: 59, mathsA1stYearMarks: 65, mathsB1stYearMarks: 79, physics1stYearMarks: 67, chemistry1stYearMarks: 95, san2ndYearMarks: 48, eng2ndYearMarks: 58, mathsA2ndYearMarks: 74, mathsB2ndYearMarks: 67, physics2ndYearMarks: 62, chemistry2ndYearMarks: 79, physicsLab: 35, chemistryLab: 34)
        
        print("========== Person - 5 ==========")
        
        let laxman:InterCalculations = InterCalculations(san1stYearMarks: 72, eng1stYearMarks: 76, mathsA1stYearMarks: 71, mathsB1stYearMarks: 79, physics1stYearMarks: 76, chemistry1stYearMarks: 71, san2ndYearMarks: 48, eng2ndYearMarks: 58, mathsA2ndYearMarks: 74, mathsB2ndYearMarks: 67, physics2ndYearMarks: 62, chemistry2ndYearMarks: 79, physicsLab: 35, chemistryLab: 34)
        
        // Do any additional setup after loading the view, typically from a nib.
    }


}

