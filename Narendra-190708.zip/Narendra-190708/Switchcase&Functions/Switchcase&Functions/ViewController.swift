//
//  ViewController.swift
//  Switchcase&Functions
//
//  Created by BRN1907 on 29/07/19.
//  Copyright © 2019 BRN1907. All rights reserved.
//

import UIKit
class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        calNarendraTenthscore()
        calTeenaTenthscore()
        calReenaTenthscore()
        calSonaTenthscore()
        calMeenaTenthscore()
        
        calNanduInterReslts()
        calBadraInterReslts()
        calKiranInterReslts()
        calAvinashInterReslts()
        calRakeshInterReslts()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    
    func calNarendraTenthscore(){
        
        // Narendra 10th Marks
        
        let engMarks:UInt8 = 31
        let telMarks:UInt8 = 84
        let hinMarks:UInt8 = 75
        let mathsMarks:UInt8 = 96
        let sciMarks:UInt8 = 87
        let socMarks:UInt8 = 94
        
        
        // Bool values for subjects to for or fail
        
        var english:Bool = false
        var telugu:Bool = false
        var hindi:Bool = false
        var maths:Bool = false
        var science:Bool = false
        var social:Bool = false
        
        // Pass Marks of 10th Class
        
        let passMarks = 35
        
        // Calculations of Total Marks
        
        let gainedMarks:UInt16 = UInt16(engMarks+telMarks)+UInt16(mathsMarks+hinMarks)+UInt16(socMarks+sciMarks)
        
        print("Narendra's Total Marks are \(gainedMarks)")
        
        // Calclations of Percentage
        
        let totalGainedMarks:Float = Float(gainedMarks)
        let totalMarks:Float = 600
        
        let percentage:Float = (totalGainedMarks/totalMarks)*100
        
        print("Narendra's Percentage is \(percentage)")
        
        // Subject wise pass or failed
        
       
        
        if engMarks >= passMarks {
            english = true
        } else {
            english = false
        }
        
        if telMarks >= passMarks {
            telugu = true
        } else {
            telugu = false
        }
        
        if hinMarks >= passMarks {
            hindi = true
        } else {
            hindi = false
        }
        
        if mathsMarks >= passMarks {
            maths = true
        } else {
            maths = false
        }
        
        if sciMarks >= passMarks {
            science = true
        } else {
            science = false
        }
        
        if socMarks >= passMarks {
            social = true
        } else {
            social = false
        }
        
        // Calculating Grade and Overall 10th passed failed
        
        if (english == true && telugu == true && hindi == true && maths == true && science == true && social == true){
            switch percentage {
            case 90...100:
                print("Grade = A")
            case 75...90:
                print("Grade = B")
            case 50...75:
                print("Grade = C")
            case 35...50:
                print("Grade = D")
            default:
                print("Grade = E")
            }
            print("Narendra Passed")
        } else {
            print("Narendra Failed")
        }
}

    func calTeenaTenthscore(){
        
        // teena 10th Marks
        
        let engMarks:UInt8 = 46
        let telMarks:UInt8 = 84
        let hinMarks:UInt8 = 75
        let mathsMarks:UInt8 = 96
        let sciMarks:UInt8 = 87
        let socMarks:UInt8 = 94
        
        // Pass Marks of 10th Class
        
        let passMarks = 35
        
        // Bool values for subjects to for or fail
        
        var english:Bool = false
        var telugu:Bool = false
        var hindi:Bool = false
        var maths:Bool = false
        var science:Bool = false
        var social:Bool = false
        
        // Calculations of Total Marks
        
        let gainedMarks:UInt16 = UInt16(engMarks+telMarks)+UInt16(mathsMarks+hinMarks)+UInt16(socMarks+sciMarks)
        
        print("Teena's Total Marks are \(gainedMarks)")
        
        // Calclations of Percentage
        
        let totalGainedMarks:Float = Float(gainedMarks)
        let totalMarks:Float = 600
        
        let percentage:Float = (totalGainedMarks/totalMarks)*100
        
        print("Teena's Percentage is \(percentage)")
        
        // Subject wise pass or failed
        
        
        
        if engMarks >= passMarks {
            english = true
        } else {
            english = false
        }
        
        if telMarks >= passMarks {
            telugu = true
        } else {
            telugu = false
        }
        
        if hinMarks >= passMarks {
            hindi = true
        } else {
            hindi = false
        }
        
        if mathsMarks >= passMarks {
            maths = true
        } else {
            maths = false
        }
        
        if sciMarks >= passMarks {
            science = true
        } else {
            science = false
        }
        
        if socMarks >= passMarks {
            social = true
        } else {
            social = false
        }
        
        // Calculating Grade and Overall 10th passed failed
        
        if (english == true && telugu == true && hindi == true && maths == true && science == true && social == true){
            switch percentage {
            case 90...100:
                print("Grade = A")
            case 75...90:
                print("Grade = B")
            case 50...75:
                print("Grade = C")
            case 35...50:
                print("Grade = D")
            default:
                print("Grade = E")
            }
            print("Teena Passed")
        } else {
            print("Teena Failed")
        }
    }
    
    
    func calReenaTenthscore(){
        
        // reena 10th Marks
        
        let engMarks:UInt8 = 56
        let telMarks:UInt8 = 84
        let hinMarks:UInt8 = 75
        let mathsMarks:UInt8 = 48
        let sciMarks:UInt8 = 87
        let socMarks:UInt8 = 94
        
        // Pass Marks of 10th Class
        
        let passMarks = 35
        
        // Bool values for subjects to for or fail
        
        var english:Bool = false
        var telugu:Bool = false
        var hindi:Bool = false
        var maths:Bool = false
        var science:Bool = false
        var social:Bool = false
        

        // Calculations of Total Marks
        
        let gainedMarks:UInt16 = UInt16(engMarks+telMarks)+UInt16(mathsMarks+hinMarks)+UInt16(socMarks+sciMarks)
        
        print("Reena's Total Marks are \(gainedMarks)")
        
        // Calclations of Percentage
        
        let totalGainedMarks:Float = Float(gainedMarks)
        let totalMarks:Float = 600
        
        let percentage:Float = (totalGainedMarks/totalMarks)*100
        
        print("Reena's Percentage is \(percentage)")
        
        // Subject wise pass or failed
        
        if engMarks >= passMarks {
            english = true
        } else {
            english = false
        }
        
        if telMarks >= passMarks {
            telugu = true
        } else {
            telugu = false
        }
        
        if hinMarks >= passMarks {
            hindi = true
        } else {
            hindi = false
        }
        
        if mathsMarks >= passMarks {
            maths = true
        } else {
            maths = false
        }
        
        if sciMarks >= passMarks {
            science = true
        } else {
            science = false
        }
        
        if socMarks >= passMarks {
            social = true
        } else {
            social = false
        }
        
        // Calculating Grade and Overall 10th passed failed
        
        if (english == true && telugu == true && hindi == true && maths == true && science == true && social == true){
            switch percentage {
            case 90...100:
                print("Grade = A")
            case 75...90:
                print("Grade = B")
            case 50...75:
                print("Grade = C")
            case 35...50:
                print("Grade = D")
            default:
                print("Grade = E")
            }
            print("Reena Passed")
        } else {
            print("Reena Failed")
        }
    }
    
    func calSonaTenthscore(){
        
        // sona 10th Marks
        
        let engMarks:UInt8 = 35
        let telMarks:UInt8 = 84
        let hinMarks:UInt8 = 75
        let mathsMarks:UInt8 = 95
        let sciMarks:UInt8 = 87
        let socMarks:UInt8 = 94
        
        // Pass Marks of 10th Class
        
        let passMarks = 35
        
        // Bool values for subjects to for or fail
        
        var english:Bool = false
        var telugu:Bool = false
        var hindi:Bool = false
        var maths:Bool = false
        var science:Bool = false
        var social:Bool = false

        
        // Calculations of Total Marks
        
        let gainedMarks:UInt16 = UInt16(engMarks+telMarks)+UInt16(mathsMarks+hinMarks)+UInt16(socMarks+sciMarks)
        
        print("Sona's Total Marks are \(gainedMarks)")
        
        // Calclations of Percentage
        
        let totalGainedMarks:Float = Float(gainedMarks)
        let totalMarks:Float = 600
        
        let percentage:Float = (totalGainedMarks/totalMarks)*100
        
        print("Sona's Percentage is \(percentage)")
        
        // Subject wise pass or failed
        
        
        if engMarks >= passMarks {
            english = true
        } else {
            english = false
        }
        
        if telMarks >= passMarks {
            telugu = true
        } else {
            telugu = false
        }
        
        if hinMarks >= passMarks {
            hindi = true
        } else {
            hindi = false
        }
        
        if mathsMarks >= passMarks {
            maths = true
        } else {
            maths = false
        }
        
        if sciMarks >= passMarks {
            science = true
        } else {
            science = false
        }
        
        if socMarks >= passMarks {
            social = true
        } else {
            social = false
        }
        
        // Calculating Grade and Overall 10th passed failed
        
        if (english == true && telugu == true && hindi == true && maths == true && science == true && social == true){
            switch percentage {
            case 90...100:
                print("Grade = A")
            case 75...90:
                print("Grade = B")
            case 50...75:
                print("Grade = C")
            case 35...50:
                print("Grade = D")
            default:
                print("Grade = E")
            }
            print("Sona Passed")
        } else {
            print("Sona Failed")
        }
    }
    
    func calMeenaTenthscore(){
        
        // meena 10th Marks
        
        let engMarks:UInt8 = 85
        let telMarks:UInt8 = 84
        let hinMarks:UInt8 = 75
        let mathsMarks:UInt8 = 96
        let sciMarks:UInt8 = 87
        let socMarks:UInt8 = 94
        
        // Pass Marks of 10th Class
        
        let passMarks = 35
        
        // Bool values for subjects to for or fail
        
        var english:Bool = false
        var telugu:Bool = false
        var hindi:Bool = false
        var maths:Bool = false
        var science:Bool = false
        var social:Bool = false
        
        // Calculations of Total Marks
        
        let gainedMarks:UInt16 = UInt16(engMarks+telMarks)+UInt16(mathsMarks+hinMarks)+UInt16(socMarks+sciMarks)
        
        print("Meena's Total Marks are \(gainedMarks)")
        
        // Calclations of Percentage
        
        let totalGainedMarks:Float = Float(gainedMarks)
        let totalMarks:Float = 600
        
        let percentage:Float = (totalGainedMarks/totalMarks)*100
        
        print("Meena's Percentage is \(percentage)")
        
        // Subject wise pass or failed
        
        if engMarks >= passMarks {
            english = true
        } else {
            english = false
        }
        
        if telMarks >= passMarks {
            telugu = true
        } else {
            telugu = false
        }
        
        if hinMarks >= passMarks {
            hindi = true
        } else {
            hindi = false
        }
        
        if mathsMarks >= passMarks {
            maths = true
        } else {
            maths = false
        }
        
        if sciMarks >= passMarks {
            science = true
        } else {
            science = false
        }
        
        if socMarks >= passMarks {
            social = true
        } else {
            social = false
        }

        // Calculating Grade and Overall 10th passed failed
        
        if (english == true && telugu == true && hindi == true && maths == true && science == true && social == true){
            switch percentage {
            case 90...100:
                print("Grade = A")
            case 75...90:
                print("Grade = B")
            case 50...75:
                print("Grade = C")
            case 35...50:
                print("Grade = D")
            default:
                print("Grade = E")
            }
            print("Meena Passed")
        } else {
            print("Meena Failed")
        }
    }
    
    
    func calNanduInterReslts(){
        
    // Inter 1st Year Marks
    
    let firstYearSanMarks:UInt8 = 62
    let firsYearEngMarks:UInt8 = 49
    let firsYearMathsAMarks:UInt8 = 65
    let firsYearMathsBMarks:UInt8 = 53
    let firsYearPhysicsMarks:UInt8 = 57
    let firsYearChemistryMarks:UInt8 = 54
    
    // Inter 1st Year Pass marks available below
    
    let passMarks1:UInt8 = 35
    let passMarks2:UInt8 = 26
    let passMarks3:UInt8 = 24
    
    // Inter Results storing in Bool in below
    
    var inter1stYearResults:Bool = false
    var inter2ndYearResults:Bool = false
    
    // Inters 1st Year Total Marks coding is available below
    
        let firsYearGainedMarks:UInt16 = UInt16(firsYearEngMarks)+UInt16(firstYearSanMarks)+UInt16(firsYearMathsAMarks)+UInt16(firsYearMathsBMarks)+UInt16(firsYearPhysicsMarks)+UInt16(firsYearChemistryMarks)
    
    // Inter Total Marks printing code is available below
    
        print("Nandu's 1st Year Marks = \(firsYearGainedMarks)")
    
    // Inter 1st Year Total Marks are available in Float below
    
    let total1stYearMarks:Float = 470
    
    // Inter 1st Year Marks of Nandu converted in Float
    
    let firsYearMarks:Float = Float(firsYearGainedMarks)
    
    // Inter 1st Year Percentage calculated below
    
    let firsYearPercentage:Float = (firsYearMarks/total1stYearMarks)*100
    
    // Nandu's 1st Year Percentage is Printing below
    
    print("Nandu's 1st Year Percentage = \(firsYearPercentage)")
    
    // Coding to the Nandu passed or failed in Inter subject-wise is given below
    
        var firstYearSanskrit:Bool = false
        var firstYearEnglish:Bool = false
        var firstYearMathsA:Bool = false
        var firstYearMathsB:Bool = false
        var firstYearPhysics:Bool = false
        var firstYearChemistry:Bool = false

        
        if firstYearSanMarks >= passMarks1 {
    firstYearSanskrit = true
    } else {
    firstYearSanskrit = false
    }
    
    if firsYearEngMarks >= passMarks1 {
    firstYearEnglish = true
    } else {
    firstYearEnglish = false
    }
    
    if firsYearMathsAMarks >= passMarks2 {
    firstYearMathsA = true
    } else {
    firstYearMathsA = false
    }
    
    if firsYearMathsBMarks >= passMarks2 {
    firstYearMathsB = true
    } else {
    firstYearMathsB = false
    }
    
    if firsYearPhysicsMarks >= passMarks3 {
    firstYearPhysics = true
    } else {
    firstYearPhysics = false
    }
    
    if firsYearChemistryMarks >= passMarks3 {
    firstYearChemistry = true
    } else {
    firstYearChemistry = false
    }
    
    // Coding to the Nandu passed or failed in Inter is given below
    
        if (firstYearSanskrit == true && firstYearEnglish == true && firstYearMathsA == true && firstYearMathsB == true && firstYearPhysics == true && firstYearChemistry == true){
    inter1stYearResults = true
    } else {
    inter1stYearResults = false
    }
    
    // Inter 2nd Year Nandu's Marks available below
    
    let secondYearSanMarks:UInt8 = 10
    let secondYearEngMarks:UInt8 = 75
    let secondYearMathsAMarks:UInt8 = 55
    let secondYearMathsBMarks:UInt8 = 62
    let secondYearPhysicsMarks:UInt8 = 45
    let secondYearChemistryMarks:UInt8 = 54
    let physicsLab:UInt8 = 35
    let chemistryLab:UInt8 = 38
    
    // Lab Pass Marks are given below
    
    let labPassMarks:UInt8 = 18
    
    // Inters 2nd Year Total Marks coding is available below
    
    let secondYearGainedMarks:UInt16 = UInt16(secondYearEngMarks)+UInt16(secondYearSanMarks)+UInt16(secondYearMathsAMarks)+UInt16(secondYearMathsBMarks)+UInt16(secondYearPhysicsMarks)+UInt16(secondYearChemistryMarks)+UInt16(physicsLab)+UInt16(chemistryLab)
    
    // Inter Total Marks printing code is available below
    
        print("Nandu's 2nd Year Marks = \(secondYearGainedMarks)")
    
    // Inter 2nd Year Total Marks are available in Float below
    
    let total2ndYearMarks:Float = 530
    
    // Inter 2nd Year Marks of Nandu converted in Float
    
        let secondYearMarks:Float = Float(secondYearGainedMarks)
    
    // Inter 2nd Year Percentage calculated below
    
    let secondYearPercentage:Float = (secondYearMarks/total2ndYearMarks)*100
    
    // Nandu's 2nd Year Percentage is Printing below
    
    print("Nandu's 2nd Year Percentage = \(secondYearPercentage)")
    
    // Coding to the Nandu passed or failed in Inter 2nd Year is given below
    
        var secondYearSanskrit:Bool = false
        var secondYearEnglish:Bool = false
        var secondYearMathsA:Bool = false
        var secondYearMathsB:Bool = false
        var secondYearPhysics:Bool = false
        var secondYearChemistry:Bool = false
        var physicsPracticals:Bool = false
        var chemistryPracticals:Bool = false
        
        
        
        
        if secondYearSanMarks >= passMarks1 {
            secondYearSanskrit = true
        } else {
            secondYearSanskrit = false
        }
        
        if secondYearEngMarks >= passMarks1 {
            secondYearEnglish = true
        } else {
            secondYearEnglish = false
        }
        
        if secondYearMathsAMarks >= passMarks2 {
            secondYearMathsA = true
        } else {
            secondYearMathsA = false
        }
        
        if secondYearMathsBMarks >= passMarks2 {
            firstYearMathsB = true
        } else {
            secondYearMathsB = false
        }
        
        if secondYearPhysicsMarks >= passMarks3 {
            secondYearPhysics = true
        } else {
            secondYearPhysics = false
        }
        
        if secondYearChemistryMarks >= passMarks3 {
            secondYearChemistry = true
        } else {
            secondYearChemistry = false
        }
    
    if physicsLab >= labPassMarks {
    physicsPracticals = true
    } else {
    physicsPracticals = false
    }
    
    if chemistryLab >= labPassMarks {
    chemistryPracticals = true
    } else {
    chemistryPracticals = false
    }
    
    // Calculating Nandu's Total Inter Marks in Float
    
        let intergainedMarks:Float = firsYearMarks + secondYearMarks
        
    // Total Inter Marks
        
        let totalMarks:Float = 1000
        
    // Inter Percentage
        
        let percentage:Float = (intergainedMarks/totalMarks)*100
    
    // Coding to the Nandu passed or failed in Inter is given below
    
    if (secondYearSanskrit == true && secondYearEnglish == true && secondYearMathsA == true && secondYearMathsB == true && secondYearPhysics == true && secondYearChemistry == true && physicsPracticals == true && chemistryPracticals == true){
    inter2ndYearResults = true
    } else {
    inter2ndYearResults = false
    }
    
    // Coding to the Nandu passed or failed in Inter and Grade is given below
    
    if (inter1stYearResults == true) && (inter2ndYearResults == true)
    {
        switch percentage {
    case 90...100:
        print("Grade = A")
    case 75...90:
        print("Grade = B")
    case 50...75:
        print("Grade = C")
    case 35...50:
        print("Grade = D")
    default:
        print("Grade = E")
        }
    print("Nandu PASSED Intermediate")
    } else {
    print("Nandu FAILED Intermediate")
    }

}
    
    
    func calBadraInterReslts(){
        
        // Inter 1st Year Marks
        
        let firstYearSanMarks:UInt8 = 62
        let firsYearEngMarks:UInt8 = 49
        let firsYearMathsAMarks:UInt8 = 65
        let firsYearMathsBMarks:UInt8 = 53
        let firsYearPhysicsMarks:UInt8 = 57
        let firsYearChemistryMarks:UInt8 = 54
        
        // Inter 1st Year Pass marks available below
        
        let passMarks1:UInt8 = 35
        let passMarks2:UInt8 = 26
        let passMarks3:UInt8 = 24
        
        // Inter Results storing in Bool in below
        
        var inter1stYearResults:Bool = false
        var inter2ndYearResults:Bool = false
        
        // Inters 1st Year Total Marks coding is available below
        
        let firsYearGainedMarks:UInt16 = UInt16(firsYearEngMarks)+UInt16(firstYearSanMarks)+UInt16(firsYearMathsAMarks)+UInt16(firsYearMathsBMarks)+UInt16(firsYearPhysicsMarks)+UInt16(firsYearChemistryMarks)
        
        // Inter Total Marks printing code is available below
        
        print("Badra's 1st Year Marks = \(firsYearGainedMarks)")
        
        // Inter 1st Year Total Marks are available in Float below
        
        let total1stYearMarks:Float = 470
        
        // Inter 1st Year Marks of badra converted in Float
        
        let firsYearMarks:Float = Float(firsYearGainedMarks)
        
        // Inter 1st Year Percentage calculated below
        
        let firsYearPercentage:Float = (firsYearMarks/total1stYearMarks)*100
        
        // badra's 1st Year Percentage is Printing below
        
        print("Badra's 1st Year Percentage = \(firsYearPercentage)")
        
        // Coding to the badra passed or failed in Inter subject-wise is given below
        
        var firstYearSanskrit:Bool = false
        var firstYearEnglish:Bool = false
        var firstYearMathsA:Bool = false
        var firstYearMathsB:Bool = false
        var firstYearPhysics:Bool = false
        var firstYearChemistry:Bool = false
        
        
        if firstYearSanMarks >= passMarks1 {
            firstYearSanskrit = true
        } else {
            firstYearSanskrit = false
        }
        
        if firsYearEngMarks >= passMarks1 {
            firstYearEnglish = true
        } else {
            firstYearEnglish = false
        }
        
        if firsYearMathsAMarks >= passMarks2 {
            firstYearMathsA = true
        } else {
            firstYearMathsA = false
        }
        
        if firsYearMathsBMarks >= passMarks2 {
            firstYearMathsB = true
        } else {
            firstYearMathsB = false
        }
        
        if firsYearPhysicsMarks >= passMarks3 {
            firstYearPhysics = true
        } else {
            firstYearPhysics = false
        }
        
        if firsYearChemistryMarks >= passMarks3 {
            firstYearChemistry = true
        } else {
            firstYearChemistry = false
        }
        
        // Coding to the Nandu passed or failed in Inter is given below
        
        if (firstYearSanskrit == true && firstYearEnglish == true && firstYearMathsA == true && firstYearMathsB == true && firstYearPhysics == true && firstYearChemistry == true){
            inter1stYearResults = true
        } else {
            inter1stYearResults = false
        }
        
        // Inter 2nd Year badra's Marks available below
        
        let secondYearSanMarks:UInt8 = 10
        let secondYearEngMarks:UInt8 = 75
        let secondYearMathsAMarks:UInt8 = 55
        let secondYearMathsBMarks:UInt8 = 62
        let secondYearPhysicsMarks:UInt8 = 45
        let secondYearChemistryMarks:UInt8 = 54
        let physicsLab:UInt8 = 35
        let chemistryLab:UInt8 = 38
        
        // Lab Pass Marks are given below
        
        let labPassMarks:UInt8 = 18
        
        // Inters 2nd Year Total Marks coding is available below
        
        let secondYearGainedMarks:UInt16 = UInt16(secondYearEngMarks)+UInt16(secondYearSanMarks)+UInt16(secondYearMathsAMarks)+UInt16(secondYearMathsBMarks)+UInt16(secondYearPhysicsMarks)+UInt16(secondYearChemistryMarks)+UInt16(physicsLab)+UInt16(chemistryLab)
        
        // Inter Total Marks printing code is available below
        
        print("Badra's 2nd Year Marks = \(secondYearGainedMarks)")
        
        // Inter 2nd Year Total Marks are available in Float below
        
        let total2ndYearMarks:Float = 530
        
        // Inter 2nd Year Marks of badra converted in Float
        
        let secondYearMarks:Float = Float(secondYearGainedMarks)
        
        // Inter 2nd Year Percentage calculated below
        
        let secondYearPercentage:Float = (secondYearMarks/total2ndYearMarks)*100
        
        // badra's 2nd Year Percentage is Printing below
        
        print("Badra's 2nd Year Percentage = \(secondYearPercentage)")
        
        // Coding to the badra passed or failed in Inter 2nd Year is given below
        
        var secondYearSanskrit:Bool = false
        var secondYearEnglish:Bool = false
        var secondYearMathsA:Bool = false
        var secondYearMathsB:Bool = false
        var secondYearPhysics:Bool = false
        var secondYearChemistry:Bool = false
        var physicsPracticals:Bool = false
        var chemistryPracticals:Bool = false
        
        
        
        
        if secondYearSanMarks >= passMarks1 {
            secondYearSanskrit = true
        } else {
            secondYearSanskrit = false
        }
        
        if secondYearEngMarks >= passMarks1 {
            secondYearEnglish = true
        } else {
            secondYearEnglish = false
        }
        
        if secondYearMathsAMarks >= passMarks2 {
            secondYearMathsA = true
        } else {
            secondYearMathsA = false
        }
        
        if secondYearMathsBMarks >= passMarks2 {
            firstYearMathsB = true
        } else {
            secondYearMathsB = false
        }
        
        if secondYearPhysicsMarks >= passMarks3 {
            secondYearPhysics = true
        } else {
            secondYearPhysics = false
        }
        
        if secondYearChemistryMarks >= passMarks3 {
            secondYearChemistry = true
        } else {
            secondYearChemistry = false
        }
        
        if physicsLab >= labPassMarks {
            physicsPracticals = true
        } else {
            physicsPracticals = false
        }
        
        if chemistryLab >= labPassMarks {
            chemistryPracticals = true
        } else {
            chemistryPracticals = false
        }
        
        // Calculating badra's Total Inter Marks in Float
        
        let intergainedMarks:Float = firsYearMarks + secondYearMarks
        
        // Total Inter Marks
        
        let totalMarks:Float = 1000
        
        // Inter Percentage
        
        let percentage:Float = (intergainedMarks/totalMarks)*100
        
        // Coding to the badra passed or failed in Inter is given below
        
        if (secondYearSanskrit == true && secondYearEnglish == true && secondYearMathsA == true && secondYearMathsB == true && secondYearPhysics == true && secondYearChemistry == true && physicsPracticals == true && chemistryPracticals == true){
            inter2ndYearResults = true
        } else {
            inter2ndYearResults = false
        }
        
        // Coding to the badra passed or failed in Inter and Grade is given below
        
        if (inter1stYearResults == true) && (inter2ndYearResults == true)
        {
            switch percentage {
            case 90...100:
                print("Grade = A")
            case 75...90:
                print("Grade = B")
            case 50...75:
                print("Grade = C")
            case 35...50:
                print("Grade = D")
            default:
                print("Grade = E")
            }
            print("Badra PASSED Intermediate")
        } else {
            print("Badra FAILED Intermediate")
        }
        
    }
    
    func calKiranInterReslts(){
        
        // Inter 1st Year Marks
        
        let firstYearSanMarks:UInt8 = 62
        let firsYearEngMarks:UInt8 = 49
        let firsYearMathsAMarks:UInt8 = 65
        let firsYearMathsBMarks:UInt8 = 53
        let firsYearPhysicsMarks:UInt8 = 57
        let firsYearChemistryMarks:UInt8 = 54
        
        // Inter 1st Year Pass marks available below
        
        let passMarks1:UInt8 = 35
        let passMarks2:UInt8 = 26
        let passMarks3:UInt8 = 24
        
        // Inter Results storing in Bool in below
        
        var inter1stYearResults:Bool = false
        var inter2ndYearResults:Bool = false
        
        // Inters 1st Year Total Marks coding is available below
        
        let firsYearGainedMarks:UInt16 = UInt16(firsYearEngMarks)+UInt16(firstYearSanMarks)+UInt16(firsYearMathsAMarks)+UInt16(firsYearMathsBMarks)+UInt16(firsYearPhysicsMarks)+UInt16(firsYearChemistryMarks)
        
        // Inter Total Marks printing code is available below
        
        print("Kiran's 1st Year Marks = \(firsYearGainedMarks)")
        
        // Inter 1st Year Total Marks are available in Float below
        
        let total1stYearMarks:Float = 470
        
        // Inter 1st Year Marks of kiran converted in Float
        
        let firsYearMarks:Float = Float(firsYearGainedMarks)
        
        // Inter 1st Year Percentage calculated below
        
        let firsYearPercentage:Float = (firsYearMarks/total1stYearMarks)*100
        
        // kiran's 1st Year Percentage is Printing below
        
        print("Kiran's 1st Year Percentage = \(firsYearPercentage)")
        
        // Coding to the badra passed or failed in Inter subject-wise is given below
        
        var firstYearSanskrit:Bool = false
        var firstYearEnglish:Bool = false
        var firstYearMathsA:Bool = false
        var firstYearMathsB:Bool = false
        var firstYearPhysics:Bool = false
        var firstYearChemistry:Bool = false
        
        
        if firstYearSanMarks >= passMarks1 {
            firstYearSanskrit = true
        } else {
            firstYearSanskrit = false
        }
        
        if firsYearEngMarks >= passMarks1 {
            firstYearEnglish = true
        } else {
            firstYearEnglish = false
        }
        
        if firsYearMathsAMarks >= passMarks2 {
            firstYearMathsA = true
        } else {
            firstYearMathsA = false
        }
        
        if firsYearMathsBMarks >= passMarks2 {
            firstYearMathsB = true
        } else {
            firstYearMathsB = false
        }
        
        if firsYearPhysicsMarks >= passMarks3 {
            firstYearPhysics = true
        } else {
            firstYearPhysics = false
        }
        
        if firsYearChemistryMarks >= passMarks3 {
            firstYearChemistry = true
        } else {
            firstYearChemistry = false
        }
        
        // Coding to the Nandu passed or failed in Inter is given below
        
        if (firstYearSanskrit == true && firstYearEnglish == true && firstYearMathsA == true && firstYearMathsB == true && firstYearPhysics == true && firstYearChemistry == true){
            inter1stYearResults = true
        } else {
            inter1stYearResults = false
        }
        // Inter 2nd Year kiran's Marks available below
        
        let secondYearSanMarks:UInt8 = 10
        let secondYearEngMarks:UInt8 = 75
        let secondYearMathsAMarks:UInt8 = 55
        let secondYearMathsBMarks:UInt8 = 62
        let secondYearPhysicsMarks:UInt8 = 45
        let secondYearChemistryMarks:UInt8 = 54
        let physicsLab:UInt8 = 35
        let chemistryLab:UInt8 = 38
        
        // Lab Pass Marks are given below
        
        let labPassMarks:UInt8 = 18
        
        // Inters 2nd Year Total Marks coding is available below
        
        let secondYearGainedMarks:UInt16 = UInt16(secondYearEngMarks)+UInt16(secondYearSanMarks)+UInt16(secondYearMathsAMarks)+UInt16(secondYearMathsBMarks)+UInt16(secondYearPhysicsMarks)+UInt16(secondYearChemistryMarks)+UInt16(physicsLab)+UInt16(chemistryLab)
        
        // Inter Total Marks printing code is available below
        
        print("Kiran's 2nd Year Marks = \(secondYearGainedMarks)")
        
        // Inter 2nd Year Total Marks are available in Float below
        
        let total2ndYearMarks:Float = 530
        
        // Inter 2nd Year Marks of kiran converted in Float
        
        let secondYearMarks:Float = Float(secondYearGainedMarks)
        
        // Inter 2nd Year Percentage calculated below
        
        let secondYearPercentage:Float = (secondYearMarks/total2ndYearMarks)*100
        
        // kiran's 2nd Year Percentage is Printing below
        
        print("Kiran's 2nd Year Percentage = \(secondYearPercentage)")
        
        // Coding to the kiran passed or failed in Inter 2nd Year is given below
        
        var secondYearSanskrit:Bool = false
        var secondYearEnglish:Bool = false
        var secondYearMathsA:Bool = false
        var secondYearMathsB:Bool = false
        var secondYearPhysics:Bool = false
        var secondYearChemistry:Bool = false
        var physicsPracticals:Bool = false
        var chemistryPracticals:Bool = false
        
        
        
        
        if secondYearSanMarks >= passMarks1 {
            secondYearSanskrit = true
        } else {
            secondYearSanskrit = false
        }
        
        if secondYearEngMarks >= passMarks1 {
            secondYearEnglish = true
        } else {
            secondYearEnglish = false
        }
        
        if secondYearMathsAMarks >= passMarks2 {
            secondYearMathsA = true
        } else {
            secondYearMathsA = false
        }
        
        if secondYearMathsBMarks >= passMarks2 {
            firstYearMathsB = true
        } else {
            secondYearMathsB = false
        }
        
        if secondYearPhysicsMarks >= passMarks3 {
            secondYearPhysics = true
        } else {
            secondYearPhysics = false
        }
        
        if secondYearChemistryMarks >= passMarks3 {
            secondYearChemistry = true
        } else {
            secondYearChemistry = false
        }
        
        if physicsLab >= labPassMarks {
            physicsPracticals = true
        } else {
            physicsPracticals = false
        }
        
        if chemistryLab >= labPassMarks {
            chemistryPracticals = true
        } else {
            chemistryPracticals = false
        }
        
        // Calculating kiran's Total Inter Marks in Float
        
        let intergainedMarks:Float = firsYearMarks + secondYearMarks
        
        // Total Inter Marks
        
        let totalMarks:Float = 1000
        
        // Inter Percentage
        
        let percentage:Float = (intergainedMarks/totalMarks)*100
        
        // Coding to the kiran passed or failed in Inter is given below
        
        if (secondYearSanskrit == true && secondYearEnglish == true && secondYearMathsA == true && secondYearMathsB == true && secondYearPhysics == true && secondYearChemistry == true && physicsPracticals == true && chemistryPracticals == true){
            inter2ndYearResults = true
        } else {
            inter2ndYearResults = false
        }
        
        // Coding to the kiran passed or failed in Inter and Grade is given below
        
        if (inter1stYearResults == true) && (inter2ndYearResults == true)
        {
            switch percentage {
            case 90...100:
                print("Grade = A")
            case 75...90:
                print("Grade = B")
            case 50...75:
                print("Grade = C")
            case 35...50:
                print("Grade = D")
            default:
                print("Grade = E")
            }
            print("Kiran PASSED Intermediate")
        } else {
            print("Kiran FAILED Intermediate")
        }
        
    }
    
    func calAvinashInterReslts(){
        
        // Inter 1st Year Marks
        
        let firstYearSanMarks:UInt8 = 62
        let firsYearEngMarks:UInt8 = 49
        let firsYearMathsAMarks:UInt8 = 65
        let firsYearMathsBMarks:UInt8 = 53
        let firsYearPhysicsMarks:UInt8 = 57
        let firsYearChemistryMarks:UInt8 = 54
        
        // Inter 1st Year Pass marks available below
        
        let passMarks1:UInt8 = 35
        let passMarks2:UInt8 = 26
        let passMarks3:UInt8 = 24
        
        // Inter Results storing in Bool in below
        
        var inter1stYearResults:Bool = false
        var inter2ndYearResults:Bool = false
        
        // Inters 1st Year Total Marks coding is available below
        
        let firsYearGainedMarks:UInt16 = UInt16(firsYearEngMarks)+UInt16(firstYearSanMarks)+UInt16(firsYearMathsAMarks)+UInt16(firsYearMathsBMarks)+UInt16(firsYearPhysicsMarks)+UInt16(firsYearChemistryMarks)
        
        // Inter Total Marks printing code is available below
        
        print("Avinash's 1st Year Marks = \(firsYearGainedMarks)")
        
        // Inter 1st Year Total Marks are available in Float below
        
        let total1stYearMarks:Float = 470
        
        // Inter 1st Year Marks of avinash converted in Float
        
        let firsYearMarks:Float = Float(firsYearGainedMarks)
        
        // Inter 1st Year Percentage calculated below
        
        let firsYearPercentage:Float = (firsYearMarks/total1stYearMarks)*100
        
        // avinash's 1st Year Percentage is Printing below
        
        print("Avinash's 1st Year Percentage = \(firsYearPercentage)")
        
        // Coding to the avinash passed or failed in Inter subject-wise is given below
        
        var firstYearSanskrit:Bool = false
        var firstYearEnglish:Bool = false
        var firstYearMathsA:Bool = false
        var firstYearMathsB:Bool = false
        var firstYearPhysics:Bool = false
        var firstYearChemistry:Bool = false
        
        
        if firstYearSanMarks >= passMarks1 {
            firstYearSanskrit = true
        } else {
            firstYearSanskrit = false
        }
        
        if firsYearEngMarks >= passMarks1 {
            firstYearEnglish = true
        } else {
            firstYearEnglish = false
        }
        
        if firsYearMathsAMarks >= passMarks2 {
            firstYearMathsA = true
        } else {
            firstYearMathsA = false
        }
        
        if firsYearMathsBMarks >= passMarks2 {
            firstYearMathsB = true
        } else {
            firstYearMathsB = false
        }
        
        if firsYearPhysicsMarks >= passMarks3 {
            firstYearPhysics = true
        } else {
            firstYearPhysics = false
        }
        
        if firsYearChemistryMarks >= passMarks3 {
            firstYearChemistry = true
        } else {
            firstYearChemistry = false
        }
        
        // Coding to the Nandu passed or failed in Inter is given below
        
        if (firstYearSanskrit == true && firstYearEnglish == true && firstYearMathsA == true && firstYearMathsB == true && firstYearPhysics == true && firstYearChemistry == true){
            inter1stYearResults = true
        } else {
            inter1stYearResults = false
        }
        
        // Inter 2nd Year avinash's Marks available below
        
        let secondYearSanMarks:UInt8 = 10
        let secondYearEngMarks:UInt8 = 75
        let secondYearMathsAMarks:UInt8 = 55
        let secondYearMathsBMarks:UInt8 = 62
        let secondYearPhysicsMarks:UInt8 = 45
        let secondYearChemistryMarks:UInt8 = 54
        let physicsLab:UInt8 = 35
        let chemistryLab:UInt8 = 38
        
        // Lab Pass Marks are given below
        
        let labPassMarks:UInt8 = 18
        
        // Inters 2nd Year Total Marks coding is available below
        
        let secondYearGainedMarks:UInt16 = UInt16(secondYearEngMarks)+UInt16(secondYearSanMarks)+UInt16(secondYearMathsAMarks)+UInt16(secondYearMathsBMarks)+UInt16(secondYearPhysicsMarks)+UInt16(secondYearChemistryMarks)+UInt16(physicsLab)+UInt16(chemistryLab)
        
        // Inter Total Marks printing code is available below
        
        print("Avinash's 2nd Year Marks = \(secondYearGainedMarks)")
        
        // Inter 2nd Year Total Marks are available in Float below
        
        let total2ndYearMarks:Float = 530
        
        // Inter 2nd Year Marks of avinash converted in Float
        
        let secondYearMarks:Float = Float(secondYearGainedMarks)
        
        // Inter 2nd Year Percentage calculated below
        
        let secondYearPercentage:Float = (secondYearMarks/total2ndYearMarks)*100
        
        // avinash's 2nd Year Percentage is Printing below
        
        print("Avinash's 2nd Year Percentage = \(secondYearPercentage)")
        
        // Coding to the avinash passed or failed in Inter 2nd Year is given below
        
        var secondYearSanskrit:Bool = false
        var secondYearEnglish:Bool = false
        var secondYearMathsA:Bool = false
        var secondYearMathsB:Bool = false
        var secondYearPhysics:Bool = false
        var secondYearChemistry:Bool = false
        var physicsPracticals:Bool = false
        var chemistryPracticals:Bool = false
        
        
        
        
        if secondYearSanMarks >= passMarks1 {
            secondYearSanskrit = true
        } else {
            secondYearSanskrit = false
        }
        
        if secondYearEngMarks >= passMarks1 {
            secondYearEnglish = true
        } else {
            secondYearEnglish = false
        }
        
        if secondYearMathsAMarks >= passMarks2 {
            secondYearMathsA = true
        } else {
            secondYearMathsA = false
        }
        
        if secondYearMathsBMarks >= passMarks2 {
            firstYearMathsB = true
        } else {
            secondYearMathsB = false
        }
        
        if secondYearPhysicsMarks >= passMarks3 {
            secondYearPhysics = true
        } else {
            secondYearPhysics = false
        }
        
        if secondYearChemistryMarks >= passMarks3 {
            secondYearChemistry = true
        } else {
            secondYearChemistry = false
        }
        
        if physicsLab >= labPassMarks {
            physicsPracticals = true
        } else {
            physicsPracticals = false
        }
        
        if chemistryLab >= labPassMarks {
            chemistryPracticals = true
        } else {
            chemistryPracticals = false
        }
        
        // Calculating avinash's Total Inter Marks in Float
        
        let intergainedMarks:Float = firsYearMarks + secondYearMarks
        
        // Total Inter Marks
        
        let totalMarks:Float = 1000
        
        // Inter Percentage
        
        let percentage:Float = (intergainedMarks/totalMarks)*100
        
        // Coding to the avinash passed or failed in Inter is given below
        
        if (secondYearSanskrit == true && secondYearEnglish == true && secondYearMathsA == true && secondYearMathsB == true && secondYearPhysics == true && secondYearChemistry == true && physicsPracticals == true && chemistryPracticals == true){
            inter2ndYearResults = true
        } else {
            inter2ndYearResults = false
        }
        
        // Coding to the avinash passed or failed in Inter and Grade is given below
        
        if (inter1stYearResults == true) && (inter2ndYearResults == true)
        {
            switch percentage {
            case 90...100:
                print("Grade = A")
            case 75...90:
                print("Grade = B")
            case 50...75:
                print("Grade = C")
            case 35...50:
                print("Grade = D")
            default:
                print("Grade = E")
            }
            print("Avinash PASSED Intermediate")
        } else {
            print("Avinash FAILED Intermediate")
        }
        
    }
    
    func calRakeshInterReslts(){
        
        // Inter 1st Year Marks
        
        let firstYearSanMarks:UInt8 = 62
        let firsYearEngMarks:UInt8 = 49
        let firsYearMathsAMarks:UInt8 = 65
        let firsYearMathsBMarks:UInt8 = 53
        let firsYearPhysicsMarks:UInt8 = 57
        let firsYearChemistryMarks:UInt8 = 54
        
        // Inter 1st Year Pass marks available below
        
        let passMarks1:UInt8 = 35
        let passMarks2:UInt8 = 26
        let passMarks3:UInt8 = 24
        
        // Inter Results storing in Bool in below
        
        var inter1stYearResults:Bool = false
        var inter2ndYearResults:Bool = false
        
        // Inters 1st Year Total Marks coding is available below
        
        let firsYearGainedMarks:UInt16 = UInt16(firsYearEngMarks)+UInt16(firstYearSanMarks)+UInt16(firsYearMathsAMarks)+UInt16(firsYearMathsBMarks)+UInt16(firsYearPhysicsMarks)+UInt16(firsYearChemistryMarks)
        
        // Inter Total Marks printing code is available below
        
        print("Rakesh's 1st Year Marks = \(firsYearGainedMarks)")
        
        // Inter 1st Year Total Marks are available in Float below
        
        let total1stYearMarks:Float = 470
        
        // Inter 1st Year Marks of rakesh converted in Float
        
        let firsYearMarks:Float = Float(firsYearGainedMarks)
        
        // Inter 1st Year Percentage calculated below
        
        let firsYearPercentage:Float = (firsYearMarks/total1stYearMarks)*100
        
        // rakesh's 1st Year Percentage is Printing below
        
        print("Rakesh's 1st Year Percentage = \(firsYearPercentage)")
        
        // Coding to the rakesh passed or failed in Inter subject-wise is given below
        
        var firstYearSanskrit:Bool = false
        var firstYearEnglish:Bool = false
        var firstYearMathsA:Bool = false
        var firstYearMathsB:Bool = false
        var firstYearPhysics:Bool = false
        var firstYearChemistry:Bool = false
        
        
        if firstYearSanMarks >= passMarks1 {
            firstYearSanskrit = true
        } else {
            firstYearSanskrit = false
        }
        
        if firsYearEngMarks >= passMarks1 {
            firstYearEnglish = true
        } else {
            firstYearEnglish = false
        }
        
        if firsYearMathsAMarks >= passMarks2 {
            firstYearMathsA = true
        } else {
            firstYearMathsA = false
        }
        
        if firsYearMathsBMarks >= passMarks2 {
            firstYearMathsB = true
        } else {
            firstYearMathsB = false
        }
        
        if firsYearPhysicsMarks >= passMarks3 {
            firstYearPhysics = true
        } else {
            firstYearPhysics = false
        }
        
        if firsYearChemistryMarks >= passMarks3 {
            firstYearChemistry = true
        } else {
            firstYearChemistry = false
        }
        
        // Coding to the Nandu passed or failed in Inter is given below
        
        if (firstYearSanskrit == true && firstYearEnglish == true && firstYearMathsA == true && firstYearMathsB == true && firstYearPhysics == true && firstYearChemistry == true){
            inter1stYearResults = true
        } else {
            inter1stYearResults = false
        }
        // Coding to the rakesh passed or failed in Inter is given below
        
        if (firstYearSanMarks >= passMarks1 && firsYearEngMarks >= passMarks1 && firsYearMathsAMarks >= passMarks2 && firsYearMathsBMarks >= passMarks2 && firsYearPhysicsMarks >= passMarks3 && firsYearChemistryMarks >= passMarks3)
        {
            inter1stYearResults = true
        } else {
            inter1stYearResults = false
        }
        
        // Inter 2nd Year rakesh's Marks available below
        
        let secondYearSanMarks:UInt8 = 10
        let secondYearEngMarks:UInt8 = 75
        let secondYearMathsAMarks:UInt8 = 55
        let secondYearMathsBMarks:UInt8 = 62
        let secondYearPhysicsMarks:UInt8 = 45
        let secondYearChemistryMarks:UInt8 = 54
        let physicsLab:UInt8 = 35
        let chemistryLab:UInt8 = 38
        
        // Lab Pass Marks are given below
        
        let labPassMarks:UInt8 = 18
        
        // Inters 2nd Year Total Marks coding is available below
        
        let secondYearGainedMarks:UInt16 = UInt16(secondYearEngMarks)+UInt16(secondYearSanMarks)+UInt16(secondYearMathsAMarks)+UInt16(secondYearMathsBMarks)+UInt16(secondYearPhysicsMarks)+UInt16(secondYearChemistryMarks)+UInt16(physicsLab)+UInt16(chemistryLab)
        
        // Inter Total Marks printing code is available below
        
        print("Rakesh's 2nd Year Marks = \(secondYearGainedMarks)")
        
        // Inter 2nd Year Total Marks are available in Float below
        
        let total2ndYearMarks:Float = 530
        
        // Inter 2nd Year Marks of rakesh converted in Float
        
        let secondYearMarks:Float = Float(secondYearGainedMarks)
        
        // Inter 2nd Year Percentage calculated below
        
        let secondYearPercentage:Float = (secondYearMarks/total2ndYearMarks)*100
        
        // rakesh's 2nd Year Percentage is Printing below
        
        print("Rakesh's 2nd Year Percentage = \(secondYearPercentage)")
        
        // Coding to the rakesh passed or failed in Inter 2nd Year is given below
        
        var secondYearSanskrit:Bool = false
        var secondYearEnglish:Bool = false
        var secondYearMathsA:Bool = false
        var secondYearMathsB:Bool = false
        var secondYearPhysics:Bool = false
        var secondYearChemistry:Bool = false
        var physicsPracticals:Bool = false
        var chemistryPracticals:Bool = false
        
        
        
        
        if secondYearSanMarks >= passMarks1 {
            secondYearSanskrit = true
        } else {
            secondYearSanskrit = false
        }
        
        if secondYearEngMarks >= passMarks1 {
            secondYearEnglish = true
        } else {
            secondYearEnglish = false
        }
        
        if secondYearMathsAMarks >= passMarks2 {
            secondYearMathsA = true
        } else {
            secondYearMathsA = false
        }
        
        if secondYearMathsBMarks >= passMarks2 {
            secondYearMathsB = true
        } else {
            secondYearMathsB = false
        }
        
        if secondYearPhysicsMarks >= passMarks3 {
            secondYearPhysics = true
        } else {
            secondYearPhysics = false
        }
        
        if secondYearChemistryMarks >= passMarks3 {
            secondYearChemistry = true
        } else {
            secondYearChemistry = false
        }
        
        if physicsLab >= labPassMarks {
            physicsPracticals = true
        } else {
            physicsPracticals = false
        }
        
        if chemistryLab >= labPassMarks {
            chemistryPracticals = true
        } else {
            chemistryPracticals = false
        }
        
        // Calculating rakesh's Total Inter Marks in Float
        
        let intergainedMarks:Float = firsYearMarks + secondYearMarks
        
        // Total Inter Marks
        
        let totalMarks:Float = 1000
        
        // Inter Percentage
        
        let percentage:Float = (intergainedMarks/totalMarks)*100
        
        // Coding to the rakesh passed or failed in Inter is given below
        
        if (secondYearSanskrit == true && secondYearEnglish == true && secondYearMathsA == true && secondYearMathsB == true && secondYearPhysics == true && secondYearChemistry == true && physicsPracticals == true && chemistryPracticals == true){
            inter2ndYearResults = true
        } else {
            inter2ndYearResults = false
        }
        
        // Coding to the rakesh passed or failed in Inter and Grade is given below
        
        if (inter1stYearResults == true) && (inter2ndYearResults == true)
        {
            switch percentage {
            case 90...100:
                print("Grade = A")
            case 75...90:
                print("Grade = B")
            case 50...75:
                print("Grade = C")
            case 35...50:
                print("Grade = D")
            default:
                print("Grade = E")
            }
            print("Rakesh PASSED Intermediate")
        } else {
            print("Rakesh FAILED Intermediate")
        }
        
    }
}
