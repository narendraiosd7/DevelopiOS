//
//  ViewController.swift
//  UIStepperAndUISlider
//
//  Created by Vadde Narendra on 9/18/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    // Creating Switches, Labels, Stepper & Slider
    
    @IBOutlet weak var creatingLbls: UISwitch!
    
    @IBOutlet weak var creatingButtons: UISwitch!
    
    @IBOutlet weak var creatingSwitches: UISwitch!
    
    @IBOutlet weak var horizontalViewSwitch: UISwitch!
    
    @IBOutlet weak var verticalViewSwitch: UISwitch!
    
    @IBOutlet weak var countSlider: UISlider!
    
    @IBOutlet weak var countStepper: UIStepper!
    
    @IBOutlet weak var countLbl: UILabel!
    
    // Creating Array for Labels, Buttons and Switches
    
    var labelArray:[UILabel] = []
    
    var buttonArray:[UIButton] = []
    
    var switchArray:[UISwitch] = []

    //Declaration of X-Axis and Y-Axis positions
    
    var xPos = 0
    
    var yPos = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Caling addtarget methods using switches, buttons, labels, slider and stepper
        
        creatingLbls.addTarget(self, action: #selector(onSwitchingLbls), for: UIControl.Event.valueChanged)
        
        creatingButtons.addTarget(self, action: #selector(onSwitchingButtons), for: UIControl.Event.valueChanged)

        creatingSwitches.addTarget(self, action: #selector(onChaningSwitches), for: UIControl.Event.valueChanged)
     
        horizontalViewSwitch.addTarget(self, action: #selector(onChangeHorizontalSwitch), for: UIControl.Event.valueChanged)
        
        verticalViewSwitch.addTarget(self, action: #selector(onChangingVerticalSwitch), for: UIControl.Event.valueChanged)
        
        countStepper.addTarget(self, action: #selector(stepperValues), for: UIControl.Event.valueChanged)
        countStepper.addTarget(self, action: #selector(frameViewOfLables), for: UIControl.Event.valueChanged)
        countStepper.addTarget(self, action: #selector(frameViewOfButtons), for: UIControl.Event.valueChanged)
        countStepper.addTarget(self, action: #selector(frameViewOfSwitches), for: UIControl.Event.valueChanged)
        
//        countStepper.addTarget(self, action: #selector(stepperValues), for: UIControl.Event.valueChanged)
        countSlider.isContinuous = false
        
        countSlider.addTarget(self, action: #selector(sliderValues), for: UIControl.Event.valueChanged)
        
        countSlider.value = Float(countStepper.value)
        
        
    }
    
    // creating a function for creating label switch condition
    
    @objc func onSwitchingLbls(){
        
        if (creatingLbls.isOn == true){
            
            creatingButtons.setOn(false, animated: true)
            creatingSwitches.setOn(false, animated: true)
            
        }
    }
    
    // creating a function for creating button switch condition
    
    @objc func onSwitchingButtons(){
            
        if (creatingButtons.isOn == true){
            
            creatingLbls.setOn(false, animated: true)
            creatingSwitches.setOn(false, animated: true)

        }
    }
    
    // creating a function for creating switches switch condition
        
    @objc func onChaningSwitches(){
        
        if (creatingSwitches.isOn == true){
            
            creatingLbls.setOn(false, animated: true)
            creatingButtons.setOn(false, animated: true)
            
        }
    }
    
    // creating a function for on switch changing of horizontal view condition
    
    @objc func onChangeHorizontalSwitch(){
        
        if (horizontalViewSwitch.isOn == true){
            verticalViewSwitch.setOn(false, animated: true)
        }
        
    }
    
    // creating a function for on switch changing of vertical view condition
    
    @objc func onChangingVerticalSwitch(){
        
        if (verticalViewSwitch.isOn == true){
            horizontalViewSwitch.setOn(false, animated: true)
        }
        
    }
    
    // creating function for on changing of stepper
    
    @objc func stepperValues(){
        
        for val in labelArray{
            val.removeFromSuperview()
        }
        for val in buttonArray{
            val.removeFromSuperview()
        }
        for val in switchArray{
            val.removeFromSuperview()
        }
        
        countSlider.setValue(Float(countStepper.value), animated: true)
        countLbl.text = "\(Int(countSlider.value))"
        
    }
    
    // creating function for on changing of slider

    @objc func sliderValues(){

        countStepper.value = Double(countSlider.value)
        countLbl.text = "\(Int(countSlider.value))"

    }
    
    // creating function for tappped btton for creating components
    
    @IBAction func createComponents(_ sender: Any) {
        
        for val in labelArray{
            val.removeFromSuperview()
        }
        for val in buttonArray{
            val.removeFromSuperview()
        }
        for val in switchArray{
            val.removeFromSuperview()
        }
        
            frameViewOfLables()

            frameViewOfButtons()

            frameViewOfSwitches()
    }

    // function for creatation of Labels
    
    @objc func frameViewOfLables(){
        
        if (creatingLbls.isOn == true && horizontalViewSwitch.isOn == true){
            
        var xPos = 10
        var yPos = 400
        var lableCount = 1
        var loopCount = 1
        
        for _ in 1...(Int(countSlider.value)){
            
            for _ in 1...8 {
                
                if (loopCount <= (Int(countSlider.value))){
                
                let myLable = UILabel(frame: CGRect(x: xPos, y: yPos+10, width: 25, height: 20))
                myLable.text = "\(lableCount)"
                myLable.backgroundColor = UIColor.green
                myLable.textColor = UIColor.black
        
                    lableCount += 1
                    loopCount += 1
                    xPos += 50
                view.addSubview(myLable)
                    labelArray.append(myLable)
                }
            }
            xPos = 10
            yPos += 30
        }
        }
            
        if (creatingLbls.isOn == true && verticalViewSwitch.isOn == true){
            
            var xPos = 10
            var yPos = 400
            var lableCount = 1
            var loopCount = 1
            
            for _ in 1...(Int(countSlider.value)){
                
                for _ in 1...10 {
                    
                    if (loopCount <= (Int(countSlider.value))){
                        
                        let myLable = UILabel(frame: CGRect(x: xPos+10, y: yPos, width: 30, height: 20))
                        myLable.text = "\(lableCount)"
                        myLable.textColor = UIColor.black
                        myLable.backgroundColor = UIColor.green
                        lableCount += 1
                        loopCount += 1
                        yPos += 40
                        view.addSubview(myLable)
                        labelArray.append(myLable)
                    }
                }
                yPos = 400
                xPos += 40
            }
            
        }
        
    }
    
    // function for creatation of Buttons
    
    @objc func frameViewOfButtons(){
        
        if (creatingButtons.isOn == true && horizontalViewSwitch.isOn == true){
        
        var xPos = 10
        var yPos = 400
        var lableCount = 1
        var loopCount = 1
        
        for _ in 1...(Int(countSlider.value)){
            
            for _ in 1...10 {
                
                if (loopCount <= (Int(countSlider.value))){
                    
                    let myButton = UIButton(frame: CGRect(x: xPos, y: yPos+10, width: 30, height: 30))
                    myButton.backgroundColor = UIColor.yellow
                    
                    lableCount += 1
                    loopCount += 1
                    xPos += 35
                    
                    view.addSubview(myButton)
                buttonArray.append(myButton)
                }
            }
            xPos = 10
            yPos += 40
        }
        }
        
        if (creatingButtons.isOn == true && verticalViewSwitch.isOn == true){
            
            var xPos = 10
            var yPos = 400
            var lableCount = 1
            var loopCount = 1
            
            for _ in 1...(Int(countSlider.value)){
                
                for _ in 1...10 {
                    
                    if (loopCount <= (Int(countSlider.value))){
                        
                        let myButton = UIButton(frame: CGRect(x: xPos+10, y: yPos, width: 30, height: 30))
                        myButton.backgroundColor = UIColor.yellow
                        
                        lableCount += 1
                        loopCount += 1
                        yPos += 35
                        
                        view.addSubview(myButton)
                        buttonArray.append(myButton)
                    }
                }
                xPos += 40
                yPos = 400
            }
        }
        
    }
    
    // function for creatation of Switches
    
    @objc func frameViewOfSwitches(){
        
         if (creatingSwitches.isOn == true && horizontalViewSwitch.isOn == true){
        
        var xPos = 20
        var yPos = 400
        var lableCount = 1
        var loopCount = 1
        
        for _ in 1...(Int(countSlider.value)){
            
            for _ in 1...6 {
                
                if (loopCount <= (Int(countSlider.value))){
                    
                    let mySwitch = UISwitch(frame: CGRect(x: xPos, y: yPos+10, width: 60, height: 10))
                    mySwitch.isOn = false
                    
                    lableCount += 1
                    loopCount += 1
                    xPos += 60
                    
                    view.addSubview(mySwitch)
                    switchArray.append(mySwitch)
                }
            }
            xPos = 20
            yPos += 40
        }
    }
        
        if (creatingSwitches.isOn == true && verticalViewSwitch.isOn == true){
            
            var xPos = 20
            var yPos = 400
            var lableCount = 1
            var loopCount = 1
            
            for _ in 1...(Int(countSlider.value)){
                
                for _ in 1...8 {
                    
                    if (loopCount <= (Int(countSlider.value))){
                        
                        let mySwitch = UISwitch(frame: CGRect(x: xPos+10, y: yPos, width: 60, height: 10))
                        mySwitch.isOn = false
                        
                        lableCount += 1
                        loopCount += 1
                        yPos += 60
                        
                        view.addSubview(mySwitch)
                        switchArray.append(mySwitch)
                    }
                }
                xPos += 60
                yPos = 400
            }
        }
    }
}
