//
//  ViewController.swift
//  UITextFieldDelegatesWithRegEx
//
//  Created by Vadde Narendra on 10/18/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate, UITextViewDelegate {
    
    var firstNameLbl = UILabel()
    var lastNameLbl = UILabel()
    var ageLbl = UILabel()
    var emailLbl = UILabel()
    var mobieNoLbl = UILabel()
    var addressLbl = UILabel()
    var stateNameLbl = UILabel()
    var countryNameLbl = UILabel()
    
    var firstNameTF = UITextField()
    var lastNameTF = UITextField()
    var ageTF = UITextField()
    var emailTF = UITextField()
    var mobileNumberTF = UITextField()
    var addressTV = UITextView()
    var stateNameTF = UITextField()
    var countryNameTF = UITextField()
    
    var submitBtn = UIButton()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        creatingComponents()                            // Creating components function calling
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    //creating function for labels, TextFields and TextViews
    
    func creatingComponents(){
        
        // Creating First Name label
        
        firstNameLbl = UILabel(frame: CGRect(x: 20, y: 74, width: 115, height: 25))
        firstNameLbl.textColor = UIColor.black
        firstNameLbl.text = "First Name:"
        view.addSubview(firstNameLbl)
        
        // Creating Last Name label
        
        lastNameLbl = UILabel(frame: CGRect(x: 20, y: 146, width: 115, height: 25))
        lastNameLbl.textColor = UIColor.black
        lastNameLbl.text = "Last Name:"
        view.addSubview(lastNameLbl)
        
        // Creating Age label
        
        ageLbl = UILabel(frame: CGRect(x: 20, y: 219, width: 115, height: 25))
        ageLbl.textColor = UIColor.black
        ageLbl.text = "Age:"
        view.addSubview(ageLbl)
        
        // Creating E-mail label
        
        emailLbl = UILabel(frame: CGRect(x: 20, y: 298, width: 115, height: 25))
        emailLbl.textColor = UIColor.black
        emailLbl.text = "E-Mail:"
        view.addSubview(emailLbl)
        
        // Creating Mobile No label
        
        mobieNoLbl = UILabel(frame: CGRect(x: 20, y: 373, width: 115, height: 25))
        mobieNoLbl.textColor = UIColor.black
        mobieNoLbl.text = "Mobile No:"
        view.addSubview(mobieNoLbl)
        
        // Creating address label
        
        addressLbl = UILabel(frame: CGRect(x: 20, y: 449, width: 115, height: 25))
        addressLbl.textColor = UIColor.black
        addressLbl.text = "Address:"
        view.addSubview(addressLbl)
        
        // Creating state label
        
        stateNameLbl = UILabel(frame: CGRect(x: 20, y: 633, width: 115, height: 25))
        stateNameLbl.textColor = UIColor.black
        stateNameLbl.text = "State Name:"
        view.addSubview(stateNameLbl)
        
        // Creating country label
        
        countryNameLbl = UILabel(frame: CGRect(x: 20, y: 703, width: 120, height: 25))
        countryNameLbl.textColor = UIColor.black
        countryNameLbl.text = "Country Name:"
        view.addSubview(countryNameLbl)
        
        // Creating First name text field
        
        firstNameTF = UITextField(frame: CGRect(x: 169, y: 71, width: 210, height: 30))
        firstNameTF.placeholder = "Enter First Name"
        firstNameTF.textColor = UIColor.blue
        firstNameTF.backgroundColor = UIColor.white
        firstNameTF.keyboardType = UIKeyboardType.namePhonePad
        firstNameTF.clearButtonMode = UITextField.ViewMode.whileEditing
        
        firstNameTF.delegate = self
        
        let firstNameImg = UIImage(named: "firstName")
        addLeftImage(txtField: firstNameTF, img: firstNameImg!)
        view.addSubview(firstNameTF)
        
        // Creating last name text field
        
        lastNameTF = UITextField(frame: CGRect(x: 169, y: 143, width: 210, height: 30))
        lastNameTF.placeholder = "Enter Last Name"
        lastNameTF.textColor = UIColor.blue
        lastNameTF.backgroundColor = UIColor.white
        lastNameTF.minimumFontSize = 5
        lastNameTF.keyboardType = UIKeyboardType.asciiCapable
        lastNameTF.clearButtonMode = UITextField.ViewMode.whileEditing
        
        lastNameTF.delegate = self
        
        let lastNameImg = UIImage(named: "lastName")
        addRightImage(txtField: lastNameTF, img: lastNameImg!)
        view.addSubview(lastNameTF)
        
        // Creating age text field
        
        ageTF = UITextField(frame: CGRect(x: 169, y: 216, width: 210, height: 30))
        ageTF.placeholder = "Enter your age"
        ageTF.textColor = UIColor.blue
        ageTF.backgroundColor = UIColor.white
        ageTF.keyboardType = UIKeyboardType.decimalPad
        ageTF.clearButtonMode = UITextField.ViewMode.whileEditing
        
        ageTF.delegate = self
        
        let ageImg = UIImage(named: "age")
        addLeftImage(txtField: ageTF, img: ageImg!)
        view.addSubview(ageTF)
        
        // Creating email text field
        
        emailTF = UITextField(frame: CGRect(x: 169, y: 295, width: 210, height: 30))
        emailTF.placeholder = "Enter E-Mail Address"
        emailTF.textColor = UIColor.blue
        emailTF.backgroundColor = UIColor.white
        emailTF.minimumFontSize = 5
        emailTF.keyboardType = UIKeyboardType.emailAddress
        emailTF.clearButtonMode = UITextField.ViewMode.whileEditing
        
        emailTF.delegate = self
        
        let emailImg = UIImage(named: "email")
        addLeftImage(txtField: emailTF, img: emailImg!)
        view.addSubview(emailTF)
        
        // Creating mobile number text field
        
        mobileNumberTF = UITextField(frame: CGRect(x: 169, y: 370, width: 210, height: 30))
        mobileNumberTF.placeholder = "Enter Mobile Number"
        mobileNumberTF.textColor = UIColor.blue
        mobileNumberTF.backgroundColor = UIColor.white
        mobileNumberTF.minimumFontSize = 5
        mobileNumberTF.keyboardType = UIKeyboardType.phonePad
        mobileNumberTF.clearButtonMode = UITextField.ViewMode.whileEditing
        
        mobileNumberTF.delegate = self
        
        let mobileNoImg = UIImage(named: "mobileno")
        addLeftImage(txtField: mobileNumberTF, img: mobileNoImg!)
        view.addSubview(mobileNumberTF)
        
        // Creating address text View
        
        addressTV = UITextView(frame: CGRect(x: 169, y: 449, width: 210, height: 105))
        addressTV.textColor = UIColor.blue
        addressTV.keyboardType = UIKeyboardType.default
        
        addressTV.delegate = self
        
        view.addSubview(addressTV)
        
        // Creating submit button
        
        submitBtn = UIButton(frame: CGRect(x: 150, y: 793, width: 114, height: 30))
        submitBtn.setTitle("SUBMIT", for: UIControl.State.normal)
        submitBtn.backgroundColor = UIColor.brown
        view.addSubview(submitBtn)
        
        // Creating state name text field
        
        stateNameTF = UITextField(frame: CGRect(x: 169, y: 627, width: 210, height: 30))
        stateNameTF.placeholder = "Enter State Name"
        stateNameTF.textColor = UIColor.blue
        stateNameTF.backgroundColor = UIColor.white
        stateNameTF.minimumFontSize = 5
        stateNameTF.keyboardType = UIKeyboardType.asciiCapable
        stateNameTF.clearButtonMode = UITextField.ViewMode.whileEditing
        
        stateNameTF.delegate = self
        
        let stateImg = UIImage(named: "state")
        addLeftImage(txtField: stateNameTF, img: stateImg!)
        view.addSubview(stateNameTF)
        
        // Creating country name text field
        
        countryNameTF = UITextField(frame: CGRect(x: 169, y: 700, width: 210, height: 30))
        countryNameTF.placeholder = "Enter Country Name"
        countryNameTF.textColor = UIColor.blue
        countryNameTF.backgroundColor = UIColor.white
        countryNameTF.keyboardType = UIKeyboardType.asciiCapable
        countryNameTF.clearButtonMode = UITextField.ViewMode.whileEditing
        
        countryNameTF.delegate = self
        
        let countryImg = UIImage(named: "country")
        addLeftImage(txtField: countryNameTF, img: countryImg!)
        view.addSubview(countryNameTF)
    }
    
    // Creating function for leftview image in text field
    
    func addLeftImage(txtField:UITextField, img:UIImage){
        
        let leftViewImage = UIImageView(frame: CGRect(x: 0, y: 0, width: 30, height:30))
        leftViewImage.image = img
        txtField.leftView = leftViewImage
        txtField.leftViewMode = UITextField.ViewMode.always
        
    }
    
    // Creating function for rightview image in text field
    
    func addRightImage(txtField:UITextField, img:UIImage)
    {
        
        let rightViewImage = UIImageView(frame: CGRect(x: 0, y: 0, width: 30, height:30))
        rightViewImage.image = img
        txtField.rightView = rightViewImage
        txtField.rightViewMode = UITextField.ViewMode.always
        
    }
    
    // keyboard Control
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?)
    {
        view.endEditing(true)
    }
    
    var returnValue:Bool = false
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool
    {
        
        
        if(textField == firstNameTF)
        {
            returnValue = true
            
        } else if (textField == lastNameTF) {
            
            if((firstNameTF.text?.count)! > 2)
            {
                returnValue = true
                
            } else {
                
                returnValue = false
                
            }
            
        } else if (textField == ageTF){
            
            if((lastNameTF.text?.count)! > 2)
            {
                returnValue = true
                
            } else {
                
                returnValue = false
                
            }
            
        } else if (textField == emailTF) {
            
            if(Int((ageTF.text)!)!<120)
            {
                returnValue = true
                
            } else {
                
                returnValue = false
                
            }
            
        } else if (textField == mobileNumberTF){
            
            if((emailTF.text?.count)! > 2)
            {
                returnValue = true
                
            } else {
                
                returnValue = false
                
            }
            
        }else if (textField == stateNameTF) {
            
            if((addressTV.text?.count)! > 2)
            {
                returnValue = true
                
            } else {
                
                returnValue = false
                
            }
            
        } else if (textField == countryNameTF){
            
            if((stateNameTF.text?.count)! > 2)
            {
                returnValue = true
                
            } else {
                
                returnValue = false
                
            }
            
        }
        
        return returnValue
        
    }
    
    func textViewShouldBeginEditing(_ textView: UITextView) -> Bool
    {
        if((mobileNumberTF.text?.count)! < 16)
        {
            returnValue = true
            
        } else {
            
            returnValue = false
            
        }
        
        return returnValue
    }// return NO to disallow editing.
    
    
    
    func textFieldDidBeginEditing(_ textField: UITextField)
    {
        textField.backgroundColor = UIColor.red
    } // became first responder
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool
    {
        if (textField == firstNameTF || textField == lastNameTF || textField == stateNameTF || textField == countryNameTF)
        {
            returnValue = isValidNames(nameStr: textField.text!)
        }
        
        if (textField == ageTF)
        {
            returnValue = isValidAge(ageStr: textField.text!)
        }
        
        if(textField == emailTF)
        {
            returnValue = isValidEmail(emailStr: textField.text!)
        }
        
        if(textField == mobileNumberTF)
        {
            returnValue = isValidMobileNo(mobileNoStr: textField.text!)
        }
        
        return returnValue
        
    }// return YES to allow editing to stop and to resign first responder status. NO to disallow the editing session to end
    
    func textFieldDidEndEditing(_ textField: UITextField)
    {
        textField.backgroundColor = UIColor.white
    }// may be called if forced even if shouldEndEditing returns NO (e.g. view removed from window) or endEditing:YES called
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool
    {
        return true
    }// return NO to not change text
    
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool
    {
        return true
    }// called when clear button pressed. return NO to ignore (no notifications)
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        return true
    }// called when 'return' key pressed. return NO to ignore.
    
    // E-mail validation function
    
    func isValidEmail(emailStr:String) -> Bool {
        
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        
        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: emailStr)
    }
    
    // Name validation function
    
    func isValidNames(nameStr:String) -> Bool {
        
        let nameRegEx = "[A-Za-z ]{2,64}"
        
        let namePred = NSPredicate(format:"SELF MATCHES %@", nameRegEx)
        return namePred.evaluate(with: nameStr)
    }
    
    // Age validation function
    
    func isValidAge(ageStr:String) -> Bool {
        
        let ageRegEx = "[0-9]{1,3}"
        
        let agePred = NSPredicate(format:"SELF MATCHES %@", ageRegEx)
        return agePred.evaluate(with: ageStr)
    }
    
    // Mobile Number validation function
    
    func isValidMobileNo(mobileNoStr:String) -> Bool {
        
        let mobileNoRegEx = "^[0-9+]{0,1}+[0-9]{5,16}$"
        
        let mobileNoPred = NSPredicate(format:"SELF MATCHES %@", mobileNoRegEx)
        return mobileNoPred.evaluate(with: mobileNoStr)
    }
    
}
