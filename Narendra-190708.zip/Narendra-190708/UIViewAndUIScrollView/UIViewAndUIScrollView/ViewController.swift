//
//  ViewController.swift
//  UIViewAndUIScrollView
//
//  Created by Vadde Narendra on 9/21/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var creatingLblSwitch: UISwitch!
    @IBOutlet weak var creatingBtnSwitch: UISwitch!
    @IBOutlet weak var creatingSwitchesSwitch: UISwitch!
    @IBOutlet weak var HVSwitch: UISwitch!
    @IBOutlet weak var VVSwitch: UISwitch!
    @IBOutlet weak var countViewLbl: UILabel!
    @IBOutlet weak var countSlider: UISlider!
    @IBOutlet weak var countStepper: UIStepper!
    
    var xPos = 10.0
    var yPos = 20.0
    var loopCount = 1
    var selectedValue = 0
    
    var labelArray:[UILabel] = []
    var buttonArray:[UIButton] = []
    var switchArray:[UISwitch] = []
    
    var components:[(UILabel,UIButton,UISwitch)] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        creatingLblSwitch.addTarget(self, action: #selector(onSwitchChangeCreateComponents(objectSwitch:)), for: UIControl.Event.valueChanged)
        
        creatingBtnSwitch.addTarget(self, action: #selector(onSwitchChangeCreateComponents(objectSwitch:)), for: UIControl.Event.valueChanged)
        
        creatingSwitchesSwitch.addTarget(self, action: #selector(onSwitchChangeCreateComponents(objectSwitch:)), for: UIControl.Event.valueChanged)
        
        HVSwitch.addTarget(self, action: #selector(onSwitchChangeViewComponents(viewControlObj:)), for: UIControl.Event.valueChanged)
        
        VVSwitch.addTarget(self, action: #selector(onSwitchChangeViewComponents(viewControlObj:)), for: UIControl.Event.valueChanged)
        
        countStepper.addTarget(self, action: #selector(stepperValues), for: UIControl.Event.valueChanged)
        
//        countStepper.addTarget(self, action: #selector(getComponentsTappedButton(_:)), for: UIControl.Event.valueChanged)
        
        countStepper.addTarget(self, action: #selector(viewControlling), for: UIControl.Event.valueChanged)
    
        countSlider.isContinuous = false
        
        countSlider.addTarget(self, action: #selector(sliderValues), for: UIControl.Event.valueChanged)
        
        countSlider.value = Float(countStepper.value)
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    // creating function for on contrlling of creating component switches
    
    @objc func onSwitchChangeCreateComponents(objectSwitch:UISwitch){
        
        if (objectSwitch == creatingLblSwitch){
            
            creatingBtnSwitch.setOn(false, animated: true)
            creatingSwitchesSwitch.setOn(false, animated: true)
            
        } else if (objectSwitch == creatingBtnSwitch){
            
            creatingLblSwitch.setOn(false, animated: true)
            creatingSwitchesSwitch.setOn(false, animated: true)
            
        } else {
            creatingLblSwitch.setOn(false, animated: true)
            creatingBtnSwitch.setOn(false, animated: true)
            
        }
        
    }
    
    
    // creating function for on contrlling of view
    
    @objc func onSwitchChangeViewComponents(viewControlObj:UISwitch){
        
        if (viewControlObj == HVSwitch){
            
            VVSwitch.setOn(false, animated: true)
            
        } else if (viewControlObj == VVSwitch){
            
            HVSwitch.setOn(false, animated: true)
            
        } else {
            
            
        }
    }
    
    // creating function for on changing of slider
    
    @objc func sliderValues(){
        
        countStepper.value = Double(countSlider.value)
        countViewLbl.text = "\(Int(countSlider.value))"
        
    }
    
    // creating function for tapped button
    
    @IBAction func getComponentsTappedButton(_ sender: Any) {
        
        for val in labelArray{
            val.removeFromSuperview()
        }
        for val in buttonArray{
            val.removeFromSuperview()
        }
        for val in switchArray{
            val.removeFromSuperview()
        }
    
        onSwitchCondition()
        viewControlling()
    
    }
    
    // creating function for on changing of stepper
    
    @objc func stepperValues(){
        
        for val in labelArray{
            val.removeFromSuperview()
        }
        for val in buttonArray{
            val.removeFromSuperview()
        }
        for val in switchArray{
            val.removeFromSuperview()
        }
        
        countSlider.setValue(Float(countStepper.value), animated: true)
        countViewLbl.text = "\(Int(countSlider.value))"
        
    }
    
    // creating function for components switch control

    @objc func onSwitchCondition(){

        if (creatingLblSwitch.isOn == true) {
            selectedValue = 1
        }

        if (creatingBtnSwitch.isOn == true) {
            selectedValue = 2
        }

        if (creatingSwitchesSwitch.isOn == true) {
            selectedValue = 3
        }

    }
    
    // creating function for x & y axis positions control
    
    @objc func viewControlling(){
        
        for _ in 1...(Int(countSlider.value)){
            
            for _ in 1...100 {
                
                if (loopCount <= (Int(countSlider.value))){
                    
                    creatingComponents()
                    
                    loopCount += 1
                    
                    if(HVSwitch.isOn == true){
                        
                        xPos += 50
                        
                    }
                    
                    if(VVSwitch.isOn == true){
                        
                        yPos += 40
                        
                    }
                }

            }
            if (HVSwitch.isOn == true){
                
                xPos = 10
                yPos += 30
                
            }
            
            if (VVSwitch.isOn == true){
                
                yPos = 20
                xPos += 50
            }
        
        }
        loopCount = 1
        xPos = 10.0
        yPos = 20.0
    }
    
    // creating function for components creation
    
    var scrollView = UIScrollView()
    
    @objc func creatingComponents(){
            
            scrollView.frame = CGRect(x: 20.0, y: 410.0, width: 374, height: 400)
            scrollView.backgroundColor = UIColor.yellow
            
            DispatchQueue.main.async {
                var contentRect = CGRect.zero

                for view in self.scrollView.subviews {
                    contentRect = contentRect.union(view.frame)
                }

                self.scrollView.contentSize = contentRect.size
            }
        
        
        view.addSubview(scrollView)

        switch selectedValue {
            
        case 1:
            
            let myLabel = UILabel(frame: CGRect(x: xPos, y: yPos, width: 40, height: 20))
            myLabel.text = "\(loopCount)"
            myLabel.textColor = UIColor.black
            myLabel.textAlignment = .center
            myLabel.backgroundColor = UIColor.green
            
            scrollView.addSubview(myLabel)
            
            labelArray.append(myLabel)
            
        case 2:
            
            let myBtn = UIButton(frame: CGRect(x: xPos, y: yPos, width: 40, height: 20))
            myBtn.backgroundColor = UIColor.red
            myBtn.setTitle("B.\(loopCount)", for: UIControl.State.normal)
            
            scrollView.addSubview(myBtn)
            
            buttonArray.append(myBtn)
            
        case 3:
            
            let mySwitch = UISwitch(frame: CGRect(x: xPos, y: yPos, width: 40, height: 20))
            scrollView.addSubview(mySwitch)
            switchArray.append(mySwitch)
            
        default:
            print("Welcome to BRN Infotech")
        }
        
    }
    
    @IBAction func clearContentOfScrollView(_ sender: Any) {
        
        scrollView.subviews.forEach({$0.removeFromSuperview()})
        
    }
}
