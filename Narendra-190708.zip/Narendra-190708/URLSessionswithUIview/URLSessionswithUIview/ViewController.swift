//
//  ViewController.swift
//  URLSessionswithUIview
//
//  Created by Vadde Narendra on 9/5/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var URLReqObj:URLRequest!
    var dataTaskObj:URLSessionDataTask!
    
    var lable:UILabel!
    var submit:UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
                
        // to get state details
        
        
        
        
        
        let state = UILabel(frame: CGRect(x: 10, y: 75, width: 200, height: 30))
        state.textColor = UIColor.yellow
        view.addSubview(state)
        indiaStateAndCitiesDetails(lable: state, type: "states", quantity: 10)
        
        // to get Cities details
        
        let city = UILabel(frame: CGRect(x: 10, y: 125, width: 200, height: 30))
        city.textColor = UIColor.yellow
        view.addSubview(city)
        indiaStateAndCitiesDetails(lable: city, type: "cities", quantity: 10)
        
        // to get Actors details
        
        let actor = UILabel(frame: CGRect(x: 10, y: 175, width: 300, height: 30))
        actor.textColor = UIColor.yellow
        view.addSubview(actor)
        actorsAndQuotesDetails(lable: actor, type: "actors", quantity: 10)
        
        // to get Quotes details
        
        let actorQuote = UILabel(frame: CGRect(x: 10, y: 225, width: 500, height: 100))
        actorQuote.numberOfLines = 0
        actorQuote.textColor = UIColor.yellow
        view.addSubview(actorQuote)
        actorsAndQuotesDetails(lable: actorQuote, type: "quotes", quantity: 12)
        
        // Submit Button creation
        
        submit = UIButton(frame: CGRect(x: 150, y: 800, width: 120, height: 60))
        submit.backgroundColor = UIColor.black
        submit.setTitle("SUBMIT", for: UIControl.State.normal)
        view.addSubview(submit)
        
        // Lable Creation for First name

        let firstName = UILabel(frame: CGRect(x: 20, y: 360, width: 300, height: 20))
        firstName.textColor = UIColor.yellow
        firstName.text = "First Name"
        view.addSubview(firstName)
        
        
        // Creating Text Field
        
        let firstNameTextField = UITextField(frame: CGRect(x: 40, y: 380, width: 250, height: 40))
        firstNameTextField.borderStyle = UITextField.BorderStyle.roundedRect
        firstNameTextField.placeholder = "First Name"
        firstNameTextField.backgroundColor = UIColor.white
        view.addSubview(firstNameTextField)
        
        // Lable Creation for Second name
        
        let secondName = UILabel(frame: CGRect(x: 20, y: 420, width: 400, height: 20))
        secondName.textColor = UIColor.yellow
        secondName.text = "Second Name"
        view.addSubview(secondName)
        
        // Creating Text Field
        
        let secondNameTextField = UITextField(frame: CGRect(x: 40, y: 450, width: 250, height: 40))
        secondNameTextField.borderStyle = UITextField.BorderStyle.roundedRect
        secondNameTextField.placeholder = "First Name"
        secondNameTextField.backgroundColor = UIColor.white
        view.addSubview(secondNameTextField)
        
        // Lable Creation for Gender
        
        let gender = UILabel(frame: CGRect(x: 20, y: 500, width: 150, height: 20))
        gender.textColor = UIColor.yellow
        gender.text = "Gender"
        view.addSubview(gender)
        
        // Creating segment
        
        let segment = UISegmentedControl(items: ["Male","Female"])
        segment.tintColor = UIColor.yellow
        segment.frame = CGRect(x: 260, y: 500, width: 120, height: 30)
        view.addSubview(segment)
        
        // Lable Creation for Gender
        
        let age = UILabel(frame: CGRect(x: 20, y: 550, width: 150, height: 20))
        age.textColor = UIColor.yellow
        age.text = "Age"
        view.addSubview(age)
        
        // Creating Slider
        
        let slider = UISlider(frame: CGRect(x: 260, y: 550, width: 120, height: 30))
        slider.minimumValue = 0
        slider.maximumValue = 100
        slider.tintColor = UIColor.yellow
        slider.thumbTintColor = UIColor.white
        view.addSubview(slider)

        // creating lable for Marital Status
        
        let maritalStatus = UILabel(frame: CGRect(x: 20, y: 620, width: 120, height: 30))
        maritalStatus.textColor = UIColor.yellow
        maritalStatus.text = "Marital Status"
        view.addSubview(maritalStatus)
        
        // creating Switch
        
        let switchBtn = UISwitch(frame: CGRect(x: 290, y: 610, width: 90, height: 30))
        switchBtn.tintColor = UIColor.black
        switchBtn.thumbTintColor = UIColor.yellow
        switchBtn.onTintColor = UIColor.orange
        view.addSubview(switchBtn)
        
        // creating lable for No of Mobiles
        
        let noOfMobiles = UILabel(frame: CGRect(x: 20, y: 680, width: 200, height: 20))
        noOfMobiles.textColor = UIColor.yellow
        noOfMobiles.text = "No of Mobile"
        view.addSubview(noOfMobiles)
        
        // Creating Stepper
        
        let stepper = UIStepper(frame: CGRect(x: 270, y: 670, width: 100, height: 30))
        stepper.tintColor = UIColor.black
        view.addSubview(stepper)
        


        // Do any additional setup after loading the view, typically from a nib.
    }

    
    // function creation to get India's states and cities deatils

    func indiaStateAndCitiesDetails(lable:UILabel,type:String,quantity:Int){
        
        URLReqObj = URLRequest(url: URL(string: "https://brninfotech.com/tws/IndiaDetails.php?type=\(type)&quantity=\(quantity)")!)
        
        URLReqObj.httpMethod = "GET"
        
        dataTaskObj = URLSession.shared.dataTask(with: URLReqObj, completionHandler: { (Data, URLResponse, Error) in
            do{
                let convertedData = try JSONSerialization.jsonObject(with: Data!, options: JSONSerialization.ReadingOptions.allowFragments) as! [String]
                
                print(convertedData)
                
                DispatchQueue.main.async {
                    lable.text = "\(type) : \(convertedData[4])"
                }
            } catch {
                print("the error is \(String(describing: Error))")
            }
        })
        dataTaskObj.resume()
    }
    

    // function creation to get actors and quotes deatils
    
    func actorsAndQuotesDetails(lable:UILabel,type:String,quantity:Int){
        
        URLReqObj = URLRequest(url: URL(string: "https://brninfotech.com/tws/Quotes.php?")!)
        
        URLReqObj.httpMethod = "POST"
        
        var dataToSend = "type=\(type)&quantity=\(quantity)"
        
        URLReqObj.httpBody = dataToSend.data(using: String.Encoding.utf8)
        
        dataTaskObj = URLSession.shared.dataTask(with: URLReqObj, completionHandler: { (Data, URLResponse, Error) in
            do{
                let convertedData = try JSONSerialization.jsonObject(with: Data!, options: JSONSerialization.ReadingOptions.allowFragments) as! [String]
                
                print(convertedData)
                
                DispatchQueue.main.async {
                    lable.text = "\(type) : \(convertedData[4])"
                }
            } catch {
                print("the error is \(String(describing: Error))")
            }
        })
        dataTaskObj.resume()
    }
}

