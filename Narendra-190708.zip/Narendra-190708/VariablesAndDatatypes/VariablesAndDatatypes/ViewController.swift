//
//  ViewController.swift
//  VariablesAndDatatypes
//
//  Created by BRN1907 on 7/24/19.
//  Copyright © 2019 BRN1907. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let varA:String = "Narendra"
        
        var varAEngMarks:UInt8 = 31
        var varATelMarks:UInt8 = 84
        var varAHinMarks:UInt8 = 75
        var varAMatMarks:UInt8 = 96
        var varASciMarks:UInt8 = 87
        var varASocMarks:UInt8 = 94
        
        
        let NarendraMarks:UInt16 = UInt16(varAEngMarks+varATelMarks)+UInt16(varAMatMarks+varAHinMarks)+UInt16(varASocMarks+varASciMarks)
        
        print("Narendra's Total Marks are \(NarendraMarks)")
        
        var TotalMarksA:Float = Float(NarendraMarks)
        var TotalMarks:Float = 600
        
        let percentageA:Float = (TotalMarksA/TotalMarks)*100
        
        print("Narendra's Percentage is \(percentageA)")
        
    if varAEngMarks >= 35 {
            print("Narendra passed English")
        } else {
            print("Narendra failed English")
        }
        
        if varATelMarks > 35 {
            print("Narendra passed Telugu")
        } else {
            print("Narendra failed Telugu")
        }
        
        if varAHinMarks > 35 {
            print("Narendra passed Hindi")
        } else {
            print("Narendra failed Hindi")
        }
        
        if varAMatMarks > 35 {
            print("Narendra passed Maths")
        } else {
            print("Narendra failed Maths")
        }
        
        if varASciMarks > 35 {
            print("Narendra passed Science")
        } else {
            print("Narendra failed Science")
        }
        
        if varASocMarks > 35 {
            print("Narendra passed Social")
        } else {
            print("Narendra failed Social")
        }
        
        
        
        
            var varB:String = "Kalyan"
            
            
            var varBEngMarks:UInt8 = 65
            var varBTelMarks:UInt8 = 56
            var varBHinMarks:UInt8 = 96
            var varBMatMarks:UInt8 = 78
            var varBSciMarks:UInt8 = 98
            var varBSocMarks:UInt8 = 82
            
        let KalyanMarks:UInt16 = UInt16(varBEngMarks+varBTelMarks)+UInt16(varBMatMarks+varBHinMarks)+UInt16(varBSocMarks+varBSciMarks)
        
        print("Kalyan's Total Marks are \(KalyanMarks)")
        
        
        var TotalMarksB:Float = Float(KalyanMarks)
        
        let percentageB:Float = (TotalMarksB/TotalMarks)*100
        
        print("Kalyan's Percentage is \(percentageB)")
        
        if varBEngMarks > 35 {
            print("Kalyan passed English")
        } else {
            print("Kalyan failed English")
        }
        
        if varBTelMarks > 35 {
            print("Kalyan passed Telugu")
        } else {
            print("Kalyan failed Telugu")
        }
        
        if varBHinMarks > 35 {
            print("Kalyan passed Hindi")
        } else {
            print("Kalyan failed Hindi")
        }
        
        if varBMatMarks > 35 {
            print("Kalyan passed Maths")
        } else {
            print("Kalyan failed Maths")
        }
        
        if varBSciMarks > 35 {
            print("Kalyan passed Science")
        } else {
            print("Kalyan failed Science")
        }
        
        if varBSocMarks > 35 {
            print("Kalyan passed Social")
        } else {
            print("Kalyan failed Social")
        }
        
        
            var varC:String = "Manohar"
            
            var varCEngMarks:UInt8 = 35
            var varCTelMarks:UInt8 = 45
            var varCHinMarks:UInt8 = 52
            var varCMatMarks:UInt8 = 65
            var varCSciMarks:UInt8 = 25
            var varCSocMarks:UInt8 = 50
            
        let ManoharMarks:UInt16 = UInt16(varCEngMarks+varCTelMarks)+UInt16(varCMatMarks+varCHinMarks)+UInt16(varCSocMarks+varCSciMarks)
        
        print("Manohar's Total Marks are \(ManoharMarks)")
        
       
        var TotalMarksC:Float = Float(ManoharMarks)
        
        let percentageC:Float = (TotalMarksC/TotalMarks)*100
        
        print("Manohar's Percentage is \(percentageC)")
        
        if varCEngMarks > 35 {
            print("Manohar passed English")
        } else {
            print("Manohar failed English")
        }
        
        if varCTelMarks > 35 {
            print("Manohar passed Telugu")
        } else {
            print("Manohar failed Telugu")
        }
        
        if varCHinMarks > 35 {
            print("Manohar passed Hindi")
        } else {
            print("Manohar failed Hindi")
        }
        
        if varCMatMarks > 35 {
            print("Manohar passed Maths")
        } else {
            print("Manohar failed Maths")
        }
        
        if varCSciMarks > 35 {
            print("Manohar passed Science")
        } else {
            print("Manohar failed Science")
        }
        
        if varCSocMarks > 35 {
            print("Manohar passed Socail")
        } else {
            print("Manohar failed Social")
        }
        
        
            var varD:String = "Savithri"
            
            var varDEngMarks:UInt8 = 57
            var varDTelMarks:UInt8 = 75
            var varDHinMarks:UInt8 = 65
            var varDMatMarks:UInt8 = 77
            var varDSciMarks:UInt8 = 45
            var varDSocMarks:UInt8 = 95
            
            var SavithriMarks:UInt16 = UInt16(varDEngMarks+varDTelMarks)+UInt16(varDMatMarks+varDHinMarks)+UInt16(varDSocMarks+varDSciMarks)
            
            print("Savithri's Total Marks are \(SavithriMarks)")
        
        
        var TotalMarksD:Float = Float(SavithriMarks)
        
        let percentageD:Float = (TotalMarksD/TotalMarks)*100
        
        print("Savithri's Percentage is \(percentageD)")
        
        
        if varDEngMarks > 35 {
            print("Savithri passed English")
        } else {
            print("Savthri failed English")
        }
        
        if varDTelMarks > 35 {
            print("Savithri passed Telugu")
        } else {
            print("Savthri failed Telugu")
        }
        
        if varDHinMarks > 35 {
            print("Savithri passed Hindi")
        } else {
            print("Savthri failed Hindi")
        }
        
        if varDMatMarks > 35 {
            print("Savithri passed Maths")
        } else {
            print("Savthri failed Maths")
        }
        
        if varDSciMarks > 35 {
            print("Savithri passed Science")
        } else {
            print("Savthri failed Science")
        }
        
        if varDSocMarks > 35 {
            print("Savithri passed Social")
        } else {
            print("Savthri failed Social")
        }
        
        
        
            var varE:String = "Ramya"
            
            var varEEngMarks:UInt8 = 99
            var varETelMarks:UInt8 = 86
            var varEHinMarks:UInt8 = 57
            var varEMatMarks:UInt8 = 85
            var varESciMarks:UInt8 = 81
            var varESocMarks:UInt8 = 76
            
        let RamyaMarks:UInt16 = UInt16(varEEngMarks+varETelMarks)+UInt16(varEMatMarks+varEHinMarks)+UInt16(varESocMarks+varESciMarks)
        
        print("Ramya's Total Marks are \(RamyaMarks)")
        
        var TotalMarksE:Float = Float(RamyaMarks)
        
        let percentageE:Float = (TotalMarksE/TotalMarks)*100
        
        print("Ramya's Percentage is \(percentageE)")
        
        if varEEngMarks > 35 {
            print("Ramya passed English")
        } else {
            print("Ramya failed English")
        }
        
        if varETelMarks > 35 {
            print("Ramya passed Telugu")
        } else {
            print("Ramya failed Telugu")
        }
        
        if varEHinMarks > 35 {
            print("Ramya passed Hindi")
        } else {
            print("Ramya failed Hindi")
        }
        
        if varEMatMarks > 35 {
            print("Ramya passed Maths")
        } else {
            print("Ramya failed Maths")
        }
        
        if varESciMarks > 35 {
            print("Ramya passed Science")
        } else {
            print("Ramya failed Science")
        }
        
        if varESocMarks > 35 {
            print("Ramya passed Social")
        } else {
            print("Ramya failed Social")
        }
        
        
        
            var varF:String = "Sanjay"
            
            var varFEngMarks:UInt8 = 72
            var varFTelMarks:UInt8 = 77
            var varFHinMarks:UInt8 = 45
            var varFMatMarks:UInt8 = 76
            var varFSciMarks:UInt8 = 71
            var varFSocMarks:UInt8 = 65
            
        let SanjayMarks:UInt16 = UInt16(varFEngMarks+varFTelMarks)+UInt16(varFMatMarks+varFHinMarks)+UInt16(varFSocMarks+varFSciMarks)
        
        print("Sanjay's Total Marks are \(SanjayMarks)")
        
        

        var TotalMarksF:Float = Float(SanjayMarks)
        
        let percentageF:Float = (TotalMarksF/TotalMarks)*100
        
        print("Sanjay's Percentage is \(percentageF)")
        
        if varFEngMarks > 35 {
            print("Sanjay passed English")
        } else {
            print("Sanjay failed English")
        }
        
        if varFTelMarks > 35 {
            print("Sanjay passed Telugu")
        } else {
            print("Sanjay failed Telugu")
        }
        
        if varFHinMarks > 35 {
            print("Sanjay passed Hindi")
        } else {
            print("Sanjay failed Hindi")
        }
        
        if varFMatMarks > 35 {
            print("Sanjay passed Maths")
        } else {
            print("Sanjay failed Maths")
        }
        
        if varFSciMarks > 35 {
            print("Sanjay passed Science")
        } else {
            print("Sanjay failed Science")
        }
        
        if varFSocMarks > 35 {
            print("Sanjay passed Social")
        } else {
            print("Sanjay failed Socail")
        }
        
        
        
            var varG:String = "Jeevana"
            
            var varGEngMarks:UInt8 = 78
            var varGTelMarks:UInt8 = 72
            var varGHinMarks:UInt8 = 82
            var varGMatMarks:UInt8 = 81
            var varGSciMarks:UInt8 = 84
            var varGSocMarks:UInt8 = 68
            
        let JeevanMarks:UInt16 = UInt16(varGEngMarks+varGTelMarks)+UInt16(varGMatMarks+varGHinMarks)+UInt16(varGSocMarks+varGSciMarks)
        
        print("Jeevan's Total Marks are \(JeevanMarks)")
        
        var TotalMarksG:Float = Float(JeevanMarks)
        
        let percentageG:Float = (TotalMarksG/TotalMarks)*100
        
        print("Jeevan's Percentage is \(percentageG)")
            
        if varGEngMarks > 35 {
            print("Jeevan passed English")
        } else {
            print("Jeevan failed English")
        }
        
        if varGTelMarks > 35 {
            print("Jeevan passed Telugu")
        } else {
            print("Jeevan failed Telugu")
        }
        
        if varGHinMarks > 35 {
            print("Jeevan passed Hindi")
        } else {
            print("Jeevan failed Hindi")
        }
        
        if varGMatMarks > 35 {
            print("Jeevan passed Maths")
        } else {
            print("Jeevan failed Maths")
        }
        
        if varGSciMarks > 35 {
            print("Jeevan passed Science")
        } else {
            print("Jeevan failed Science")
        }
        
        if varGSocMarks > 35 {
            print("Jeevan passed Social")
        } else {
            print("Jeevan failed Social")
        }
        
        
        
        var varH:String = "Kavya"
            
            var varHEngMarks:UInt8 = 92
            var varHTelMarks:UInt8 = 82
            var varHHinMarks:UInt8 = 84
            var varHMatMarks:UInt8 = 75
            var varHSciMarks:UInt8 = 65
            var varHSocMarks:UInt8 = 95
            
        let KavyaMarks:UInt16 = UInt16(varHEngMarks+varHTelMarks)+UInt16(varHMatMarks+varHHinMarks)+UInt16(varHSocMarks+varHSciMarks)
        
        print("Kavya's Total Marks are \(KavyaMarks)")
        
        var TotalMarksH:Float = Float(KavyaMarks)
        
        let percentageH:Float = (TotalMarksH/TotalMarks)*100
        
        print("Kavya's Percentage is \(percentageH)")
        
        if varHEngMarks > 35 {
            print("Kavya passed English")
        } else {
            print("Kavya failed English")
        }
        
        if varHTelMarks > 35 {
            print("Kavya passed Telugu")
        } else {
            print("Kavya failed Telugu")
        }
        
        if varHHinMarks > 35 {
            print("Kavya passed Hndi")
        } else {
            print("Kavya failed Hindi")
        }
        
        if varHMatMarks > 35 {
            print("Kavya passed Maths")
        } else {
            print("Kavya failed Maths")
        }
        
        if varHSciMarks > 35 {
            print("Kavya passed Science")
        } else {
            print("Kavya failed Science")
        }
        
        if varHSocMarks > 35 {
            print("Kavya passed Social")
        } else {
            print("Kavya failed Social")
        }
        
        
        
        var varI:String = "Arjun"
            
            var varIEngMarks:UInt8 = 45
            var varITelMarks:UInt8 = 56
            var varIHinMarks:UInt8 = 76
            var varIMatMarks:UInt8 = 65
            var varISciMarks:UInt8 = 54
            var varISocMarks:UInt8 = 34
            
        let ArjunMarks:UInt16 = UInt16(varIEngMarks+varITelMarks)+UInt16(varIMatMarks+varIHinMarks)+UInt16(varISocMarks+varISciMarks)
        
        print("Arjun's Total Marks are \(ArjunMarks)")
        
        
        var TotalMarksI:Float = Float(ArjunMarks)
        
        let percentageI:Float = (TotalMarksI/TotalMarks)*100
        
        print("Arjun's Percentage is \(percentageI)")
            
        if varIEngMarks > 35 {
            print("Arjun passed English")
        } else {
            print("Arjun failed English")
        }
        
        if varITelMarks > 35 {
            print("Arjun passed Telugu")
        } else {
            print("Arjun failed Telugu")
        }
        
        if varIHinMarks > 35 {
            print("Arjun passed Hndi")
        } else {
            print("Arjun failed Hindi")
        }
        
        if varIMatMarks > 35 {
            print("Arjun passed Maths")
        } else {
            print("Arjun failed Maths")
        }
        
        if varISciMarks > 35 {
            print("Arjun passed Science")
        } else {
            print("Arjun failed Science")
        }
        
        if varISocMarks > 35 {
            print("Arjun passed Social")
        } else {
            print("Arjun failed Social")
        }
        
        
        var varJ:String = "Gopal"
            
            var varJEngMarks:UInt8 = 92
            var varJTelMarks:UInt8 = 81
            var varJHinMarks:UInt8 = 76
            var varJMatMarks:UInt8 = 69
            var varJSciMarks:UInt8 = 57
            var varJSocMarks:UInt8 = 48
            
        let GopalMarks:UInt16 = UInt16(varJEngMarks+varJTelMarks)+UInt16(varJMatMarks+varJHinMarks)+UInt16(varJSocMarks+varJSciMarks)
        
        print("Gopal's Total Marks are \(GopalMarks)")

        
        var TotalMarksJ:Float = Float(GopalMarks)
        
        let percentageJ:Float = (TotalMarksJ/TotalMarks)*100
        
        print("Gopal's Percentage is \(percentageJ)")
        
        if varJEngMarks > 35 {
            print("Gopal passed English")
        } else {
            print("Gopal failed English")
        }
        
        if varJTelMarks > 35 {
            print("Gopal passed Telugu")
        } else {
            print("Gopal failed Telugu")
        }
        
        if varJHinMarks > 35 {
            print("Gopal passed Hndi")
        } else {
            print("Gopal failed Hindi")
        }
        
        if varJMatMarks > 35 {
            print("Gopal passed Maths")
        } else {
            print("Gopal failed Maths")
        }
        
        if varJSciMarks > 35 {
            print("Gopal passed Science")
        } else {
            print("Gopal failed Science")
        }
        
        if varJSocMarks > 35 {
            print("Gopal passed Social")
        } else {
            print("Gopal failed Social")
        }
        
        // Do any additional setup after loading the view, typically from a nib.
    }
}
