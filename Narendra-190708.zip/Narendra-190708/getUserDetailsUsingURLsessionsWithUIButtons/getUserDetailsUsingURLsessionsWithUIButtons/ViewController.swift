//
//  ViewController.swift
//  getUserDetailsUsingURLsessionsWithUIButtons
//
//  Created by Vadde Narendra on 9/14/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var holidayDate: UITextView!
    @IBOutlet weak var holidayReason: UITextView!
    @IBOutlet weak var leaveDate: UITextView!
    @IBOutlet weak var leaveRaeson: UITextView!
    @IBOutlet weak var lateComeDate: UITextView!
    @IBOutlet weak var lateComeTime: UITextView!
    @IBOutlet weak var workingDayDate: UITextView!
    @IBOutlet weak var spendingTime: UITextView!
    
    let getUserDeatils:UserDetails = UserDetails()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        getUserDeatils.getValidateLogin()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func getHolidayDetails(_ sender: Any) {
        
        getUserDeatils.getUserHolidays(holidayDates: holidayDate, holidayReason: holidayReason)
        
    }
    
    @IBAction func getUserLeavesDetails(_ sender: Any) {
        
        getUserDeatils.getUserLeaves(leaveDay: leaveDate, leavesReason: leaveRaeson)
        
    }
    
    @IBAction func getUserLateCommingDaysDetails(_ sender: Any) {
        
        getUserDeatils.getUserLateTimings(lateCommingDay: lateComeDate, lateCommingTime: lateComeTime)
        
    }
    @IBAction func getUserWorkingTimeDetails(_ sender: Any) {
        
        getUserDeatils.getUserWorkingHours(workingDay: workingDayDate, workingTime: spendingTime)
        
        
    }
}

