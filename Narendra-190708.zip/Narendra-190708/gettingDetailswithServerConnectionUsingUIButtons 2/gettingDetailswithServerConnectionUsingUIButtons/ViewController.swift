//
//  ViewController.swift
//  gettingDetailswithServerConnectionUsingUIButtons
//
//  Created by Vadde Narendra on 9/6/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var URLReqObj:URLRequest!
    
    var dataTaskObj:URLSessionDataTask!
    
    // Creating lables
    
    @IBOutlet weak var getStateNameLbl: UILabel!
    
    @IBOutlet weak var getCityNameLbl: UILabel!
    
    @IBOutlet weak var getActorNameLbl: UILabel!
    
    @IBOutlet weak var getActorsQuoteLbl: UILabel!
    
    @IBOutlet weak var gerUserDeatilsLbl: UILabel!
    
    @IBOutlet weak var batchIDLbl: UILabel!
    
    @IBOutlet weak var studentIDLbl: UILabel!
    
    @IBOutlet weak var fisrtNameLbl: UILabel!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    // Creating button for getting State Name
    
    @IBAction func getStateName(_ sender: Any) {
        
        getStateName()
        
    }
    
    // Creating button for getting City Name
    
    @IBAction func getCityName(_ sender: Any) {
        
        getCityName()
        
    }
    
    // Creating button for getting Actor Name
    
    @IBAction func getActorName(_ sender: Any) {
        
        getActorName()
        
    }
    
    // Creating button for getting Actor's quote Name
    
    @IBAction func getActorsQuote(_ sender: Any) {
        
        getActorsQuoteName()
        
    }
    
    // Creating button for getting user details
    
    @IBAction func gerUserDetails(_ sender: Any) {
        
    getValidateLogin()
        
    }
    
    // Creating function for getting State Name
    
    func getStateName(){
        
        URLReqObj = URLRequest(url: URL(string: "https://brninfotech.com/tws/IndiaDetails.php?type=state&quantity=10")!)
        
        URLReqObj.httpMethod = "GET"
        
        dataTaskObj = URLSession.shared.dataTask(with: URLReqObj, completionHandler: { (Data, URLResponse, Error) in
            do{
                let convertedData = try JSONSerialization.jsonObject(with: Data!, options: JSONSerialization.ReadingOptions.allowFragments) as! [String]
                
                print(convertedData)
                
                DispatchQueue.main.async {
                    self.getStateNameLbl.text = convertedData[0]
                }
            } catch {
                print("the error is \(String(describing: Error))")
            }
        })
        dataTaskObj.resume()
    }
    
    // Creating function for getting City Name
    
    func getCityName(){
        
        URLReqObj = URLRequest(url: URL(string: "https://brninfotech.com/tws/IndiaDetails.php?type=city&quantity=10")!)
        
        URLReqObj.httpMethod = "GET"
        
        dataTaskObj = URLSession.shared.dataTask(with: URLReqObj, completionHandler: { (Data, URLResponse, Error) in
            do{
                let convertedData = try JSONSerialization.jsonObject(with: Data!, options: JSONSerialization.ReadingOptions.allowFragments) as! [String]
                
                print(convertedData)
                
                DispatchQueue.main.async {
                    self.getCityNameLbl.text = convertedData[0]
                }
            } catch {
                print("the error is \(String(describing: Error))")
            }
        })
        dataTaskObj.resume()
    }
    
    
    // function creation to get actor name
    
    func getActorName(){
        
        URLReqObj = URLRequest(url: URL(string: "https://brninfotech.com/tws/Quotes.php")!)
        
        URLReqObj.httpMethod = "POST"
        
        let dataToSend = "type=actor&quantity=10"
        
        URLReqObj.httpBody = dataToSend.data(using: String.Encoding.utf8)
        
        dataTaskObj = URLSession.shared.dataTask(with: URLReqObj, completionHandler: { (Data, URLResponse, Error) in
            do{
                let convertedData = try JSONSerialization.jsonObject(with: Data!, options: JSONSerialization.ReadingOptions.allowFragments) as! [String]
                
                print(convertedData)
                
                DispatchQueue.main.async {
                    self.getActorNameLbl.text = convertedData[0]
                }
            } catch {
                print("the error is \(String(describing: Error))")
            }
        })
        dataTaskObj.resume()
    }
    
    // Creating function for getting actor's quote details
    
    func getActorsQuoteName(){
        
        URLReqObj = URLRequest(url: URL(string: "https://brninfotech.com/tws/Quotes.php?")!)
        
        URLReqObj.httpMethod = "POST"
        
        let dataToSend = "type=quote&quantity=10"
        
        URLReqObj.httpBody = dataToSend.data(using: String.Encoding.utf8)
        
        dataTaskObj = URLSession.shared.dataTask(with: URLReqObj, completionHandler: { (Data, URLResponse, Error) in
            do{
                let convertedData = try JSONSerialization.jsonObject(with: Data!, options: JSONSerialization.ReadingOptions.allowFragments) as! [String]
                
                print(convertedData)
                
                DispatchQueue.main.async {
                    self.getActorsQuoteLbl.text = convertedData[0]
                }
            } catch {
                print("the error is \(String(describing: Error))")
            }
        })
        dataTaskObj.resume()
    }
    
    // Creating function for getting User Details
    
    func getValidateLogin()
    {
        URLReqObj = URLRequest(url: URL(string: "https://www.brninfotech.com/pulse/modules/admin/ValidateLogin.php?")!)
        
        URLReqObj.httpMethod = "POST"
        
        let dataToSend = "registeredEmail=narendraiosd@gmail.com&registeredPassword=nanda143&funcName=verifyLogin"
        URLReqObj.httpBody = dataToSend.data(using: String.Encoding.utf8)
        
        dataTaskObj = URLSession.shared.dataTask(with: URLReqObj, completionHandler: { (Data, URLResponse, Error) in
            
            do {
                let convertedData = try JSONSerialization.jsonObject(with: Data!, options: JSONSerialization.ReadingOptions.allowFragments)  as! [String:String]
                
                print(convertedData)
                
                DispatchQueue.main.async {
                    
                    self.fisrtNameLbl.text = "First Name : \(convertedData["firstName"]!)"
                    
                    self.batchIDLbl.text = "Batch ID : \(convertedData["batchID"]!)"
                    
                    self.studentIDLbl.text = "Student ID : \(convertedData["studentID"]!)"
                    
                    self.gerUserDeatilsLbl.text = "Email ID: \(convertedData["registeredEmail"]!)"
                    
                }
                
            } catch {
                
                print("the error is \(String(describing: Error))")
                
            }
        })
        dataTaskObj.resume()
        
    }

}

