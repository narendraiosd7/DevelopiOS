//
//  ViewController.swift
//  logicoperators
//
//  Created by BRN1907 on 26/07/19.
//  Copyright © 2019 BRN1907. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Inter 1st Year Nandu's Marks available below
        
        let nandu1stYearSanMarks:UInt8 = 62
        let nandu1stYearEngMarks:UInt8 = 49
        let nandu1stYearMathsAMarks:UInt8 = 65
        let nandu1stYearMathsBMarks:UInt8 = 53
        let nandu1stYearPhysicsMarks:UInt8 = 57
        let nandu1stYearChemistryMarks:UInt8 = 54
        
        // Inter 1st Year Pass marks available below
        
        let passMarks1:UInt8 = 35
        let passMarks2:UInt8 = 26
        let passMarks3:UInt8 = 24
        
        // Inters 1st Year Total Marks coding is available below
        
        let nandu1stYearGainedMarks:UInt16 = UInt16(nandu1stYearEngMarks)+UInt16(nandu1stYearSanMarks)+UInt16(nandu1stYearMathsAMarks)+UInt16(nandu1stYearMathsBMarks)+UInt16(nandu1stYearPhysicsMarks)+UInt16(nandu1stYearChemistryMarks)
        
        // Inter Total Marks printing code is available below
        
        print("Nandu's 1st Year Marks = \(nandu1stYearGainedMarks)")
        
        // Inter 1st Year Total Marks are available in Float below
        
        let total1stYearMarks:Float = 470
        
        // Inter 1st Year Marks of Nandu converted in Float
        
        let nandu1stYearMarks:Float = Float(nandu1stYearGainedMarks)
        
        // Inter 1st Year Percentage calculated below
        
        let nandu1stYearPercentage:Float = (nandu1stYearMarks/total1stYearMarks)*100
        
        // Nandu's 1st Year Percentage is Printing below
        
        print("Nandu's 1st Year Percentage = \(nandu1stYearPercentage)")
        
        // Coding to the Nandu passed or failed in Inter subject-wise is given below
        
        if nandu1stYearSanMarks >= passMarks1 {
            print("Nandu Passed Sanskrit")
        } else {
            print("Nandu Failed Sanskrit")
        }
        
        if nandu1stYearEngMarks >= passMarks1 {
            print("Nandu Passed English")
        } else {
            print("Nandu Failed English")
        }
        
        if nandu1stYearMathsAMarks >= passMarks2 {
            print("Nandu Passed MathsA")
        } else {
            print("Nandu Failed MathsA")
        }
        
        if nandu1stYearMathsBMarks >= passMarks2 {
            print("Nandu Passed MathsB")
        } else {
            print("Nandu Failed MathsB")
        }
        
        if nandu1stYearPhysicsMarks >= passMarks3 {
            print("Nandu Passed Physics")
        } else {
            print("Nandu Failed Physics")
        }
        
        if nandu1stYearChemistryMarks >= passMarks3 {
            print("Nandu Passed Chemistry")
        } else {
            print("Nandu Failed Chemistry")
        }
        
        // Coding to the Nandu passed or failed in Inter is given below
        
        if (nandu1stYearSanMarks >= passMarks1 && nandu1stYearEngMarks >= passMarks1 && nandu1stYearMathsAMarks >= passMarks2 && nandu1stYearMathsBMarks >= passMarks2 && nandu1stYearPhysicsMarks >= passMarks3 && nandu1stYearChemistryMarks >= passMarks3) {
            print("Nandu PASSED 1st Year")
        } else {
            print("Nandu FAILED 1st Year")
        }
        
        // Inter 2nd Year Nandu's Marks available below
        
        let nandu2ndYearSanMarks:UInt8 = 58
        let nandu2ndYearEngMarks:UInt8 = 64
        let nandu2ndYearMathsAMarks:UInt8 = 55
        let nandu2ndYearMathsBMarks:UInt8 = 62
        let nandu2ndYearPhysicsMarks:UInt8 = 45
        let nandu2ndYearChemistryMarks:UInt8 = 54
        let nanduPhysicsLab:UInt8 = 35
        let nanduChemistryLab:UInt8 = 38
        
        // Lab Pass Marks are given below
        
        let labPassMarks:UInt8 = 18
        
        // Inters 2nd Year Total Marks coding is available below
        
        let nandu2ndYearGainedMarks:UInt16 = UInt16(nandu2ndYearEngMarks)+UInt16(nandu2ndYearSanMarks)+UInt16(nandu2ndYearMathsAMarks)+UInt16(nandu2ndYearMathsBMarks)+UInt16(nandu2ndYearPhysicsMarks)+UInt16(nandu2ndYearChemistryMarks)+UInt16(nanduPhysicsLab)+UInt16(nanduChemistryLab)
        
        // Inter Total Marks printing code is available below
        
        print("Nandu's 2nd Year Marks = \(nandu2ndYearGainedMarks)")
        
        // Inter 2nd Year Total Marks are available in Float below
        
        let total2ndYearMarks:Float = 530
        
        // Inter 2nd Year Marks of Nandu converted in Float
        
        let nandu2ndYearMarks:Float = Float(nandu2ndYearGainedMarks)
        
        // Inter 2nd Year Percentage calculated below
        
        let nandu2ndYearPercentage:Float = (nandu2ndYearMarks/total2ndYearMarks)*100
        
        // Nandu's 2nd Year Percentage is Printing below
        
        print("Nandu's 2nd Year Percentage = \(nandu2ndYearPercentage)")
        
        // Coding to the Nandu passed or failed in Inter 2nd Year is given below
        
        if nandu2ndYearSanMarks >= passMarks1 {
            print("Nandu Passed Sanskrit")
        } else {
            print("Nandu Failed Sanskrit")
        }
        
        if nandu2ndYearEngMarks >= passMarks1 {
            print("Nandu Passed English")
        } else {
            print("Nandu Failed English")
        }
        
        if nandu2ndYearMathsAMarks >= passMarks2 {
            print("Nandu Passed Maths2A")
        } else {
            print("Nandu Failed Maths2A")
        }
        
        if nandu2ndYearMathsBMarks >= passMarks2 {
            print("Nandu Passed Maths2B")
        } else {
            print("Nandu Failed Maths2B")
        }
        
        if nandu2ndYearPhysicsMarks >= passMarks3 {
            print("Nandu Passed Physics")
        } else {
            print("Nandu Failed Physics")
        }
        
        if nandu2ndYearChemistryMarks >= passMarks3 {
            print("Nandu Passed Chemistry")
        } else {
            print("Nandu Failed Chemistry")
        }
        
        if nanduPhysicsLab >= labPassMarks {
            print("Nandu Passed Physics Lab")
        } else {
            print("Nandu Failed Physics Lab")
        }
        
        if nanduChemistryLab >= labPassMarks {
            print("Nandu Passed Chemistry Lab")
        } else {
            print("Nandu Failed Chemistry Lab")
        }
        
        
        // Coding to the Nandu passed or failed in Inter is given below
        
        if (nandu2ndYearSanMarks >= passMarks1 && nandu2ndYearEngMarks >= passMarks1 && nandu2ndYearMathsAMarks >= passMarks2 && nandu2ndYearMathsBMarks >= passMarks2 && nandu2ndYearPhysicsMarks >= passMarks3 && nandu2ndYearChemistryMarks >= passMarks3 && nanduPhysicsLab >= labPassMarks && nanduChemistryLab >= labPassMarks) {
            print("Nandu PASSED 2nd Year")
        } else {
            print("Nandu FAILED 2nd Year")
        }
        
        // Coding to the Nandu passed or failed in Inter is given below
        
        if (nandu1stYearSanMarks >= passMarks1 && nandu1stYearEngMarks >= passMarks1 && nandu1stYearMathsAMarks >= passMarks2 && nandu1stYearMathsBMarks >= passMarks2 && nandu1stYearPhysicsMarks >= passMarks2 && nandu1stYearChemistryMarks >= passMarks2) && (nandu2ndYearSanMarks >= passMarks1 && nandu2ndYearEngMarks >= passMarks1 && nandu2ndYearMathsAMarks >= passMarks2 && nandu2ndYearMathsBMarks >= passMarks2 && nandu2ndYearPhysicsMarks >= passMarks3 && nandu2ndYearChemistryMarks >= passMarks3 && nanduPhysicsLab >= labPassMarks && nanduChemistryLab >= labPassMarks)
        {
            print("Nandu PASSED Intermediate")
        } else {
            print("Nandu FAILED Intermediate")
        }
    
    
        // Calculating Nandu's Total Inter Marks in Float
        
        let nanduInterMarks:Float = nandu1stYearMarks + nandu2ndYearMarks
        
        // Printing Total Marks of Nandu
        
        print("Nandu's Inter Total Marks = \(nanduInterMarks)")
        
        
        let intergradeA:Float = 900
        let intergradeB:Float = 650
        let intergradeC:Float = 450
        let intergradeD:Float = 350
        
        let gradeA:Character = "A"
        let gradeB:Character = "B"
        let gradeC:Character = "C"
        let gradeD:Character = "D"
        
        
        if (nanduInterMarks >= intergradeA){
            print("Nandu's 1st Year grade = \(gradeA)")
        } else if (nanduInterMarks >= intergradeB){
            print("Nandu's grade = \(gradeB)")
        } else if (nanduInterMarks >= intergradeC){
            print("Nandu's grade = \(gradeC)")
        } else {
            print("Nandu's grade = \(gradeD)")
        }
        
        
        // Inter 1st Year Gopal's Marks available below
        
        let gopal1stYearSanMarks:UInt8 = 86
        let gopal1stYearEngMarks:UInt8 = 78
        let gopal1stYearMathsAMarks:UInt8 = 65
        let gopal1stYearMathsBMarks:UInt8 = 53
        let gopal1stYearPhysicsMarks:UInt8 = 57
        let gopal1stYearChemistryMarks:UInt8 = 54
        
        // Inters 1st Year Total Marks coding is available below
        
        let gopal1stYearGainedMarks:UInt16 = UInt16(gopal1stYearEngMarks)+UInt16(gopal1stYearSanMarks)+UInt16(gopal1stYearMathsAMarks)+UInt16(gopal1stYearMathsBMarks)+UInt16(gopal1stYearPhysicsMarks)+UInt16(gopal1stYearChemistryMarks)
        
        // Inter Total Marks printing code is available below
        
        print("Gopal's 1st Year Marks = \(gopal1stYearGainedMarks)")
        
        // Inter 1st Year Marks of Gopal converted in Float
        
        let gopal1stYearMarks:Float = Float(gopal1stYearGainedMarks)
        
        // Inter 1st Year Percentage calculated below
        
        let gopal1stYearPercentage:Float = (gopal1stYearMarks/total1stYearMarks)*100
        
        // Gopal's 1st Year Percentage is Printing below
        
        print("Gopal's 1st Year Percentage = \(gopal1stYearPercentage)")
        
        // Coding to the Gopal passed or failed in Inter subject wise is given below
        
        if gopal1stYearSanMarks >= passMarks1 {
            print("Gopal Passed Sanskrit")
        } else {
            print("Gopal Failed Sanskrit")
        }
        
        if gopal1stYearEngMarks >= passMarks1 {
            print("Gopal Passed English")
        } else {
            print("Gopal Failed English")
        }
        
        if gopal1stYearMathsAMarks >= passMarks2 {
            print("Gopal Passed MathsA")
        } else {
            print("Gopal Failed MathsA")
        }
        
        if gopal1stYearMathsBMarks >= passMarks2 {
            print("Gopal Passed MathsB")
        } else {
            print("Gopal Failed MathsB")
        }
        
        if gopal1stYearPhysicsMarks >= passMarks3 {
            print("Gopal Passed Physics")
        } else {
            print("Gopal Failed Physics")
        }
        
        if gopal1stYearChemistryMarks >= passMarks3 {
            print("Gopal Passed Chemistry")
        } else {
            print("Gopal Failed Chemistry")
        }
        
        // Coding to the Gopal passed or failed in Inter 1st Year is given below
        
        if (gopal1stYearSanMarks >= passMarks1 && gopal1stYearEngMarks >= passMarks1 && gopal1stYearMathsAMarks >= passMarks2 && gopal1stYearMathsBMarks >= passMarks2 && gopal1stYearPhysicsMarks >= passMarks3 && gopal1stYearChemistryMarks >= passMarks3) {
            print("Gopal PASSED 1st Year")
        } else {
            print("Gopal FAILED 1st Year")
        }
        
        
        
        // Inter 2nd Year Gopal's Marks available below
        
        let gopal2ndYearSanMarks:UInt8 = 89
        let gopal2ndYearEngMarks:UInt8 = 91
        let gopal2ndYearMathsAMarks:UInt8 = 71
        let gopal2ndYearMathsBMarks:UInt8 = 72
        let gopal2ndYearPhysicsMarks:UInt8 = 48
        let gopal2ndYearChemistryMarks:UInt8 = 56
        let gopalPhysicsLab:UInt8 = 40
        let gopalChemistryLab:UInt8 = 40
        
        // Inters 2nd Year Total Marks coding is available below
        
        let gopal2ndYearGainedMarks:UInt16 = UInt16(gopal2ndYearEngMarks)+UInt16(gopal2ndYearSanMarks)+UInt16(gopal2ndYearMathsAMarks)+UInt16(gopal2ndYearMathsBMarks)+UInt16(gopal2ndYearPhysicsMarks)+UInt16(gopal2ndYearChemistryMarks)+UInt16(gopalPhysicsLab)+UInt16(gopalChemistryLab)
        
        // Inter Total Marks printing code is available below
        
        print("Gopal's 2nd Year Marks = \(gopal2ndYearGainedMarks)")
        
        // Inter 2nd Year Marks of Gopal converted in Float
        
        let gopal2ndYearMarks:Float = Float(gopal2ndYearGainedMarks)
        
        // Inter 2nd Year Percentage calculated below
        
        let gopal2ndYearPercentage:Float = (gopal2ndYearMarks/total2ndYearMarks)*100
        
        // Gopal's 2nd Year Percentage is Printing below
        
        print("Gopal's 2nd Year Percentage = \(gopal2ndYearPercentage)")
        
        // Coding to the Gopal passed or failed in Inter 2nd Year is given below
        
        if gopal2ndYearSanMarks >= passMarks1 {
            print("Gopal Passed Sanskrit")
        } else {
            print("Gopal Failed Sanskrit")
        }
        
        if gopal2ndYearEngMarks >= passMarks1 {
            print("Gopal Passed English")
        } else {
            print("Gopal Failed English")
        }
        
        if gopal2ndYearMathsAMarks >= passMarks2 {
            print("Gopal Passed Maths2A")
        } else {
            print("Gopal Failed Maths2A")
        }
        
        if gopal2ndYearMathsBMarks >= passMarks2 {
            print("Gopal Passed Maths2B")
        } else {
            print("Gopal Failed Maths2B")
        }
        
        if gopal2ndYearPhysicsMarks >= passMarks3 {
            print("Gopal Passed Physics")
        } else {
            print("Gopal Failed Physics")
        }
        
        if gopal2ndYearChemistryMarks >= passMarks3 {
            print("Gopal Passed Chemistry")
        } else {
            print("Gopal Failed Chemistry")
        }
        
        if gopalPhysicsLab >= labPassMarks {
            print("Gopal Passed Physics Lab")
        } else {
            print("Gopal Failed Physics Lab")
        }
        
        if gopalChemistryLab >= labPassMarks {
            print("Gopal Passed Chemistry Lab")
        } else {
            print("Gopal Failed Chemistry Lab")
        }
        
        
        // Coding to the Gopal passed or failed in Inter 2nd Year is given below
        
        if (gopal2ndYearSanMarks >= passMarks1 && gopal2ndYearEngMarks >= passMarks1 && gopal2ndYearMathsAMarks >= passMarks2 && gopal2ndYearMathsBMarks >= passMarks2 && gopal2ndYearPhysicsMarks >= passMarks3 && gopal2ndYearChemistryMarks >= passMarks3 && gopalPhysicsLab >= labPassMarks && gopalChemistryLab >= labPassMarks) {
            print("Gopal PASSED 2nd Year")
        } else {
            print("Gopal FAILED 2nd Year")
        }
        
        // Coding to the Gopal passed or failed in Inter is given below
        
        if (gopal1stYearSanMarks >= passMarks1 && gopal1stYearEngMarks >= passMarks1 && gopal1stYearMathsAMarks >= passMarks2 && gopal1stYearMathsBMarks >= passMarks2 && gopal1stYearPhysicsMarks >= passMarks2 && gopal1stYearChemistryMarks >= passMarks2) && (gopal2ndYearSanMarks >= passMarks1 && gopal2ndYearEngMarks >= passMarks1 && gopal2ndYearMathsAMarks >= passMarks2 && gopal2ndYearMathsBMarks >= passMarks2 && gopal2ndYearPhysicsMarks >= passMarks3 && gopal2ndYearChemistryMarks >= passMarks3 && gopalPhysicsLab >= labPassMarks && gopalChemistryLab >= labPassMarks)
        {
            print("Gopal PASSED Intermediate")
        } else {
            print("Gopal FAILED Intermediate")
        }
    
        // Calculating Gopal's Total Inter Marks in Float
        
        let gopalInterMarks:Float = gopal1stYearMarks + gopal2ndYearMarks
        
        // Printing Total Marks of Gopal
        
        print("Gopal's Inter Total Marks = \(gopalInterMarks)")
        
        // Giving grade to Gopal according to his marks
        
        if (gopalInterMarks >= intergradeA){
            print("Gopal's 1st Year grade = \(gradeA)")
        } else if (gopalInterMarks >= intergradeB){
            print("Gopal's grade = \(gradeB)")
        } else if (gopalInterMarks >= intergradeC){
            print("Gopal's grade = \(gradeC)")
        } else {
            print("Gopal's grade = \(gradeD)")
        }
        
        
        // Inter 1st Year Sreenivasulu's Marks available below
        
        let sreenivasulu1stYearSanMarks:UInt8 = 58
        let sreenivasulu1stYearEngMarks:UInt8 = 65
        let sreenivasulu1stYearMathsAMarks:UInt8 = 65
        let sreenivasulu1stYearMathsBMarks:UInt8 = 53
        let sreenivasulu1stYearPhysicsMarks:UInt8 = 57
        let sreenivasulu1stYearChemistryMarks:UInt8 = 54
        
        // Inters 1st Year Total Marks coding is available below
        
        let sreenivasulu1stYearGainedMarks:UInt16 = UInt16(sreenivasulu1stYearEngMarks)+UInt16(sreenivasulu1stYearSanMarks)+UInt16(sreenivasulu1stYearMathsAMarks)+UInt16(sreenivasulu1stYearMathsBMarks)+UInt16(sreenivasulu1stYearPhysicsMarks)+UInt16(sreenivasulu1stYearChemistryMarks)
        
        // Inter Total Marks printing code is available below
        
        print("Sreenivasulu's 1st Year Marks = \(sreenivasulu1stYearGainedMarks)")
        
        // Inter 1st Year Marks of Sreenivasulu converted in Float
        
        let sreenivasulu1stYearMarks:Float = Float(sreenivasulu1stYearGainedMarks)
        
        // Inter 1st Year Percentage calculated below
        
        let sreenivasulu1stYearPercentage:Float = (sreenivasulu1stYearMarks/total1stYearMarks)*100
        
        // Sreenivasulu's 1st Year Percentage is Printing below
        
        print("Sreenivasulu's 1st Year Percentage = \(sreenivasulu1stYearPercentage)")
        
        // Coding to the Sreenivasulu passed or failed in Inter subject wise is given below
        
        if sreenivasulu1stYearSanMarks >= passMarks1 {
            print("Sreenivasulu Passed Sanskrit")
        } else {
            print("Sreenivasulu Failed Sanskrit")
        }
        
        if sreenivasulu1stYearEngMarks >= passMarks1 {
            print("Sreenivasulu Passed English")
        } else {
            print("Sreenivasulu Failed English")
        }
        
        if sreenivasulu1stYearMathsAMarks >= passMarks2 {
            print("Sreenivasulu Passed MathsA")
        } else {
            print("Sreenivasulu Failed MathsA")
        }
        
        if sreenivasulu1stYearMathsBMarks >= passMarks2 {
            print("Sreenivasulu Passed MathsB")
        } else {
            print("Sreenivasulu Failed MathsB")
        }
        
        if sreenivasulu1stYearPhysicsMarks >= passMarks3 {
            print("Sreenivasulu Passed Physics")
        } else {
            print("Sreenivasulu Failed Physics")
        }
        
        if sreenivasulu1stYearChemistryMarks >= passMarks3 {
            print("Sreenivasulu Passed Chemistry")
        } else {
            print("Sreenivasulu Failed Chemistry")
        }
        
        // Coding to the Sreenivasulu passed or failed in Inter 1st Year is given below
        
        if (sreenivasulu1stYearSanMarks >= passMarks1 && sreenivasulu1stYearEngMarks >= passMarks1 && sreenivasulu1stYearMathsAMarks >= passMarks2 && sreenivasulu1stYearMathsBMarks >= passMarks2 && sreenivasulu1stYearPhysicsMarks >= passMarks3 && sreenivasulu1stYearChemistryMarks >= passMarks3) {
            print("Sreenivasulu PASSED 1st Year")
        } else {
            print("Sreenivasulu FAILED 1st Year")
        }
        
        
        
        // Inter 2nd Year Sreenivasulu's Marks available below
        
        let sreenivasulu2ndYearSanMarks:UInt8 = 65
        let sreenivasulu2ndYearEngMarks:UInt8 = 72
        let sreenivasulu2ndYearMathsAMarks:UInt8 = 55
        let sreenivasulu2ndYearMathsBMarks:UInt8 = 62
        let sreenivasulu2ndYearPhysicsMarks:UInt8 = 45
        let sreenivasulu2ndYearChemistryMarks:UInt8 = 54
        let sreenivasuluPhysicsLab:UInt8 = 35
        let sreenivasuluChemistryLab:UInt8 = 38
        
        // Inters 2nd Year Total Marks coding is available below
        
        let sreenivasulu2ndYearGainedMarks:UInt16 = UInt16(sreenivasulu2ndYearEngMarks)+UInt16(sreenivasulu2ndYearSanMarks)+UInt16(sreenivasulu2ndYearMathsAMarks)+UInt16(sreenivasulu2ndYearMathsBMarks)+UInt16(sreenivasulu2ndYearPhysicsMarks)+UInt16(sreenivasulu2ndYearChemistryMarks)+UInt16(sreenivasuluPhysicsLab)+UInt16(sreenivasuluChemistryLab)
        
        // Inter Total Marks printing code is available below
        
        print("Sreenivasulu's 2nd Year Marks = \(sreenivasulu2ndYearGainedMarks)")
        
        // Inter 2nd Year Marks of Sreenivasulu converted in Float
        
        let sreenivasulu2ndYearMarks:Float = Float(sreenivasulu2ndYearGainedMarks)
        
        // Inter 2nd Year Percentage calculated below
        
        let sreenivasulu2ndYearPercentage:Float = (sreenivasulu2ndYearMarks/total2ndYearMarks)*100
        
        // Sreenivasulu's 2nd Year Percentage is Printing below
        
        print("Sreenivasulu's 2nd Year Percentage = \(sreenivasulu2ndYearPercentage)")
        
        // Coding to the Sreenivasulu passed or failed in Inter 2nd Year is given below
        
        if sreenivasulu2ndYearSanMarks >= passMarks1 {
            print("Sreenivasulu Passed Sanskrit")
        } else {
            print("Sreenivasulu Failed Sanskrit")
        }
        
        if sreenivasulu2ndYearEngMarks >= passMarks1 {
            print("Sreenivasulu Passed English")
        } else {
            print("Sreenivasulu Failed English")
        }
        
        if sreenivasulu2ndYearMathsAMarks >= passMarks2 {
            print("Sreenivasulu Passed Maths2A")
        } else {
            print("Sreenivasulu Failed Maths2A")
        }
        
        if sreenivasulu2ndYearMathsBMarks >= passMarks2 {
            print("Sreenivasulu Passed Maths2B")
        } else {
            print("Sreenivasulu Failed Maths2B")
        }
        
        if sreenivasulu2ndYearPhysicsMarks >= passMarks3 {
            print("Sreenivasulu Passed Physics")
        } else {
            print("Sreenivasulu Failed Physics")
        }
        
        if sreenivasulu2ndYearChemistryMarks >= passMarks3 {
            print("Sreenivasulu Passed Chemistry")
        } else {
            print("Sreenivasulu Failed Chemistry")
        }
        
        if sreenivasuluPhysicsLab >= labPassMarks {
            print("Sreenivasulu Passed Physics Lab")
        } else {
            print("Sreenivasulu Failed Physics Lab")
        }
        
        if sreenivasuluChemistryLab >= labPassMarks {
            print("Sreenivasulu Passed Chemistry Lab")
        } else {
            print("Sreenivasulu Failed Chemistry Lab")
        }
        
        
        // Coding to the Sreenivasulu passed or failed in Inter 2nd Year is given below
        
        if (sreenivasulu2ndYearSanMarks >= passMarks1 && sreenivasulu2ndYearEngMarks >= passMarks1 && sreenivasulu2ndYearMathsAMarks >= passMarks2 && sreenivasulu2ndYearMathsBMarks >= passMarks2 && sreenivasulu2ndYearPhysicsMarks >= passMarks3 && sreenivasulu2ndYearChemistryMarks >= passMarks3 && sreenivasuluPhysicsLab >= labPassMarks && sreenivasuluChemistryLab >= labPassMarks) {
            print("Sreenivasulu PASSED 2nd Year")
        } else {
            print("Sreenivasulu FAILED 2nd Year")
        }
        
        // Coding to the Sreenivasulu passed or failed in Inter is given below
        
        if (sreenivasulu1stYearSanMarks >= passMarks1 && sreenivasulu1stYearEngMarks >= passMarks1 && sreenivasulu1stYearMathsAMarks >= passMarks2 && sreenivasulu1stYearMathsBMarks >= passMarks2 && sreenivasulu1stYearPhysicsMarks >= passMarks2 && sreenivasulu1stYearChemistryMarks >= passMarks2) && (sreenivasulu2ndYearSanMarks >= passMarks1 && sreenivasulu2ndYearEngMarks >= passMarks1 && sreenivasulu2ndYearMathsAMarks >= passMarks2 && sreenivasulu2ndYearMathsBMarks >= passMarks2 && sreenivasulu2ndYearPhysicsMarks >= passMarks3 && sreenivasulu2ndYearChemistryMarks >= passMarks3 && sreenivasuluPhysicsLab >= labPassMarks && sreenivasuluChemistryLab >= labPassMarks)
        {
            print("Sreenivasulu PASSED Intermediate")
        } else {
            print("Sreenivasulu FAILED Intermediate")
        }
    
    
        // Calculating Sreenivasulu Total Inter Marks in Float
        
        let sreenivasuluInterMarks:Float = sreenivasulu1stYearMarks + sreenivasulu2ndYearMarks
        
        // Printing Total Marks of Sreenivasulu
        
        print("Sreenivasulu Inter Total Marks = \(sreenivasuluInterMarks)")
        
        // Giving grade to Sreenivasulu according to his marks
        
        if (sreenivasuluInterMarks >= intergradeA){
            print("Sreenivasulu's 1st Year grade = \(gradeA)")
        } else if (sreenivasuluInterMarks >= intergradeB){
            print("Sreenivasulu's grade = \(gradeB)")
        } else if (sreenivasuluInterMarks >= intergradeC){
            print("Sreenivasulu's grade = \(gradeC)")
        } else {
            print("Sreenivasulu's grade = \(gradeD)")
        }
        

    
        // Inter 1st Year Narendra's Marks available below
        
        let narendra1stYearSanMarks:UInt8 = 70
        let narendra1stYearEngMarks:UInt8 = 49
        let narendra1stYearMathsAMarks:UInt8 = 65
        let narendra1stYearMathsBMarks:UInt8 = 53
        let narendra1stYearPhysicsMarks:UInt8 = 57
        let narendra1stYearChemistryMarks:UInt8 = 54
        
        // Inters 1st Year Total Marks coding is available below
        
        let narendra1stYearGainedMarks:UInt16 = UInt16(narendra1stYearEngMarks)+UInt16(narendra1stYearSanMarks)+UInt16(narendra1stYearMathsAMarks)+UInt16(narendra1stYearMathsBMarks)+UInt16(narendra1stYearPhysicsMarks)+UInt16(narendra1stYearChemistryMarks)
        
        // Inter Total Marks printing code is available below
        
        print("Narendra's 1st Year Marks = \(narendra1stYearGainedMarks)")
        
        // Inter 1st Year Marks of Narendra converted in Float
        
        let narendra1stYearMarks:Float = Float(narendra1stYearGainedMarks)
        
        // Inter 1st Year Percentage calculated below
        
        let narendra1stYearPercentage:Float = (narendra1stYearMarks/total1stYearMarks)*100
        
        // Narendra's 1st Year Percentage is Printing below
        
        print("Narendra's 1st Year Percentage = \(narendra1stYearPercentage)")
        
        // Coding to the Narendra passed or failed in Inter subject wise is given below
        
        if narendra1stYearSanMarks >= passMarks1 {
            print("Narendra Passed Sanskrit")
        } else {
            print("Narendra Failed Sanskrit")
        }
        
        if narendra1stYearEngMarks >= passMarks1 {
            print("Narendra Passed English")
        } else {
            print("Narendra Failed English")
        }
        
        if narendra1stYearMathsAMarks >= passMarks2 {
            print("Narendra Passed MathsA")
        } else {
            print("Narendra Failed MathsA")
        }
        
        if narendra1stYearMathsBMarks >= passMarks2 {
            print("Narendra Passed MathsB")
        } else {
            print("Narendra Failed MathsB")
        }
        
        if narendra1stYearPhysicsMarks >= passMarks3 {
            print("Narendra Passed Physics")
        } else {
            print("Narendra Failed Physics")
        }
        
        if narendra1stYearChemistryMarks >= passMarks3 {
            print("Narendra Passed Chemistry")
        } else {
            print("Narendra Failed Chemistry")
        }
        
        // Coding to the Narendra passed or failed in Inter 1st Year is given below
        
        if (narendra1stYearSanMarks >= passMarks1 && narendra1stYearEngMarks >= passMarks1 && narendra1stYearMathsAMarks >= passMarks2 && narendra1stYearMathsBMarks >= passMarks2 && narendra1stYearPhysicsMarks >= passMarks3 && narendra1stYearChemistryMarks >= passMarks3) {
            print("Narendra PASSED 1st Year")
        } else {
            print("Narendra FAILED 1st Year")
        }
        
        
        
        // Inter 2nd Year Narendra's Marks available below
        
        let narendra2ndYearSanMarks:UInt8 = 58
        let narendra2ndYearEngMarks:UInt8 = 25
        let narendra2ndYearMathsAMarks:UInt8 = 55
        let narendra2ndYearMathsBMarks:UInt8 = 62
        let narendra2ndYearPhysicsMarks:UInt8 = 45
        let narendra2ndYearChemistryMarks:UInt8 = 54
        let narendraPhysicsLab:UInt8 = 35
        let narendraChemistryLab:UInt8 = 38
        
        // Inters 2nd Year Total Marks coding is available below
        
        let narendra2ndYearGainedMarks:UInt16 = UInt16(narendra2ndYearEngMarks)+UInt16(narendra2ndYearSanMarks)+UInt16(narendra2ndYearMathsAMarks)+UInt16(narendra2ndYearMathsBMarks)+UInt16(narendra2ndYearPhysicsMarks)+UInt16(narendra2ndYearChemistryMarks)+UInt16(narendraPhysicsLab)+UInt16(narendraChemistryLab)
        
        // Inter Total Marks printing code is available below
        
        print("Narendra's 2nd Year Marks = \(narendra2ndYearGainedMarks)")
        
        // Inter 2nd Year Marks of Narendra converted in Float
        
        let narendra2ndYearMarks:Float = Float(narendra2ndYearGainedMarks)
        
        // Inter 2nd Year Percentage calculated below
        
        let narendra2ndYearPercentage:Float = (narendra2ndYearMarks/total2ndYearMarks)*100
        
        // Narendra's 2nd Year Percentage is Printing below
        
        print("Narendra's 2nd Year Percentage = \(narendra2ndYearPercentage)")
        
        // Coding to the Narendra passed or failed in Inter 2nd Year is given below
        
        if narendra2ndYearSanMarks >= passMarks1 {
            print("Narendra Passed Sanskrit")
        } else {
            print("Narendra Failed Sanskrit")
        }
        
        if narendra2ndYearEngMarks >= passMarks1 {
            print("Narendra Passed English")
        } else {
            print("Narendra Failed English")
        }
        
        if narendra2ndYearMathsAMarks >= passMarks2 {
            print("Narendra Passed Maths2A")
        } else {
            print("Narendra Failed Maths2A")
        }
        
        if narendra2ndYearMathsBMarks >= passMarks2 {
            print("Narendra Passed Maths2B")
        } else {
            print("Narendra Failed Maths2B")
        }
        
        if narendra2ndYearPhysicsMarks >= passMarks3 {
            print("Narendra Passed Physics")
        } else {
            print("Narendra Failed Physics")
        }
        
        if narendra2ndYearChemistryMarks >= passMarks3 {
            print("Narendra Passed Chemistry")
        } else {
            print("Narendra Failed Chemistry")
        }
        
        if narendraPhysicsLab >= labPassMarks {
            print("Narendra Passed Physics Lab")
        } else {
            print("Narendra Failed Physics Lab")
        }
        
        if narendraChemistryLab >= labPassMarks {
            print("Narendra Passed Chemistry Lab")
        } else {
            print("Narendra Failed Chemistry Lab")
        }
        
        
        // Coding to the Narendra passed or failed in Inter 2nd Year is given below
        
        if (narendra2ndYearSanMarks >= passMarks1 && narendra2ndYearEngMarks >= passMarks1 && narendra2ndYearMathsAMarks >= passMarks2 && narendra2ndYearMathsBMarks >= passMarks2 && narendra2ndYearPhysicsMarks >= passMarks3 && narendra2ndYearChemistryMarks >= passMarks3 && narendraPhysicsLab >= labPassMarks && narendraChemistryLab >= labPassMarks) {
            print("Narendra PASSED 2nd Year")
        } else {
            print("Narendra FAILED 2nd Year")
        }
        
        // Coding to the Narendra passed or failed in Inter is given below
        
        if (narendra1stYearSanMarks >= passMarks1 && narendra1stYearEngMarks >= passMarks1 && narendra1stYearMathsAMarks >= passMarks2 && narendra1stYearMathsBMarks >= passMarks2 && narendra1stYearPhysicsMarks >= passMarks2 && narendra1stYearChemistryMarks >= passMarks2) && (narendra2ndYearSanMarks >= passMarks1 && narendra2ndYearEngMarks >= passMarks1 && narendra2ndYearMathsAMarks >= passMarks2 && narendra2ndYearMathsBMarks >= passMarks2 && narendra2ndYearPhysicsMarks >= passMarks3 && narendra2ndYearChemistryMarks >= passMarks3 && narendraPhysicsLab >= labPassMarks && narendraChemistryLab >= labPassMarks)
        {
            print("Narendra PASSED Intermediate")
        } else {
            print("Narendra FAILED Intermediate")
        }
        
        
        // Calculating narendra Total Inter Marks in Float
        
        let narendraInterMarks:Float = narendra1stYearMarks + narendra2ndYearMarks
        
        // Printing Total Marks of narendra
        
        print("narendra Inter Total Marks = \(narendraInterMarks)")
        
        // Giving grade to narendra according to his marks
        
        if (narendraInterMarks >= intergradeA){
            print("narendra's 1st Year grade = \(gradeA)")
        } else if (narendraInterMarks >= intergradeB){
            print("narendra's grade = \(gradeB)")
        } else if (narendraInterMarks >= intergradeC){
            print("narendra's grade = \(gradeC)")
        } else {
            print("narendra's grade = \(gradeD)")
        }
        
        

        
        // Inter 1st Year Padmavathi's Marks available below
        
        let padmavathi1stYearSanMarks:UInt8 = 92
        let padmavathi1stYearEngMarks:UInt8 = 85
        let padmavathi1stYearMathsAMarks:UInt8 = 65
        let padmavathi1stYearMathsBMarks:UInt8 = 53
        let padmavathi1stYearPhysicsMarks:UInt8 = 57
        let padmavathi1stYearChemistryMarks:UInt8 = 54
        
        // Inters 1st Year Total Marks coding is available below
        
        let padmavathi1stYearGainedMarks:UInt16 = UInt16(padmavathi1stYearEngMarks)+UInt16(padmavathi1stYearSanMarks)+UInt16(padmavathi1stYearMathsAMarks)+UInt16(padmavathi1stYearMathsBMarks)+UInt16(padmavathi1stYearPhysicsMarks)+UInt16(padmavathi1stYearChemistryMarks)
        
        // Inter Total Marks printing code is available below
        
        print("Padmavathi's 1st Year Marks = \(padmavathi1stYearGainedMarks)")
        
        // Inter 1st Year Marks of Padmavathi converted in Float
        
        let padmavathi1stYearMarks:Float = Float(padmavathi1stYearGainedMarks)
        
        // Inter 1st Year Percentage calculated below
        
        let padmavathi1stYearPercentage:Float = (padmavathi1stYearMarks/total1stYearMarks)*100
        
        // Padmavathi's 1st Year Percentage is Printing below
        
        print("Padmavathi's 1st Year Percentage = \(padmavathi1stYearPercentage)")
        
        // Coding to the Padmavathi passed or failed in Inter subject wise is given below
        
        if padmavathi1stYearSanMarks >= passMarks1 {
            print("Padmavathi Passed Sanskrit")
        } else {
            print("Padmavathi Failed Sanskrit")
        }
        
        if padmavathi1stYearEngMarks >= passMarks1 {
            print("Padmavathi Passed English")
        } else {
            print("Padmavathi Failed English")
        }
        
        if padmavathi1stYearMathsAMarks >= passMarks2 {
            print("Padmavathi Passed MathsA")
        } else {
            print("Padmavathi Failed MathsA")
        }
        
        if padmavathi1stYearMathsBMarks >= passMarks2 {
            print("Padmavathi Passed MathsB")
        } else {
            print("Padmavathi Failed MathsB")
        }
        
        if padmavathi1stYearPhysicsMarks >= passMarks3 {
            print("Padmavathi Passed Physics")
        } else {
            print("Padmavathi Failed Physics")
        }
        
        if padmavathi1stYearChemistryMarks >= passMarks3 {
            print("Padmavathi Passed Chemistry")
        } else {
            print("Padmavathi Failed Chemistry")
        }
        
        // Coding to the Padmavathi passed or failed in Inter 1st Year is given below
        
        if (padmavathi1stYearSanMarks >= passMarks1 && padmavathi1stYearEngMarks >= passMarks1 && padmavathi1stYearMathsAMarks >= passMarks2 && padmavathi1stYearMathsBMarks >= passMarks2 && padmavathi1stYearPhysicsMarks >= passMarks3 && padmavathi1stYearChemistryMarks >= passMarks3) {
            print("Padmavathi PASSED 1st Year")
        } else {
            print("Padmavathi FAILED 1st Year")
        }
        
        
        
        // Inter 2nd Year Padmavathi's Marks available below
        
        let padmavathi2ndYearSanMarks:UInt8 = 75
        let padmavathi2ndYearEngMarks:UInt8 = 82
        let padmavathi2ndYearMathsAMarks:UInt8 = 55
        let padmavathi2ndYearMathsBMarks:UInt8 = 62
        let padmavathi2ndYearPhysicsMarks:UInt8 = 45
        let padmavathi2ndYearChemistryMarks:UInt8 = 54
        let padmavathiPhysicsLab:UInt8 = 35
        let padmavathiChemistryLab:UInt8 = 38
        
        // Inters 2nd Year Total Marks coding is available below
        
        let padmavathi2ndYearGainedMarks:UInt16 = UInt16(padmavathi2ndYearEngMarks)+UInt16(padmavathi2ndYearSanMarks)+UInt16(padmavathi2ndYearMathsAMarks)+UInt16(padmavathi2ndYearMathsBMarks)+UInt16(padmavathi2ndYearPhysicsMarks)+UInt16(padmavathi2ndYearChemistryMarks)+UInt16(padmavathiPhysicsLab)+UInt16(padmavathiChemistryLab)
        
        // Inter Total Marks printing code is available below
        
        print("Padmavathi's 2nd Year Marks = \(padmavathi2ndYearGainedMarks)")
        
        // Inter 2nd Year Marks of Padmavathi converted in Float
        
        let padmavathi2ndYearMarks:Float = Float(padmavathi2ndYearGainedMarks)
        
        // Inter 2nd Year Percentage calculated below
        
        let padmavathi2ndYearPercentage:Float = (padmavathi2ndYearMarks/total2ndYearMarks)*100
        
        // Padmavathi's 2nd Year Percentage is Printing below
        
        print("Padmavathi's 2nd Year Percentage = \(padmavathi2ndYearPercentage)")
        
        // Coding to the Padmavathi passed or failed in Inter 2nd Year is given below
        
        if padmavathi2ndYearSanMarks >= passMarks1 {
            print("Padmavathi Passed Sanskrit")
        } else {
            print("Padmavathi Failed Sanskrit")
        }
        
        if padmavathi2ndYearEngMarks >= passMarks1 {
            print("Padmavathi Passed English")
        } else {
            print("Padmavathi Failed English")
        }
        
        if padmavathi2ndYearMathsAMarks >= passMarks2 {
            print("Padmavathi Passed Maths2A")
        } else {
            print("Padmavathi Failed Maths2A")
        }
        
        if padmavathi2ndYearMathsBMarks >= passMarks2 {
            print("Padmavathi Passed Maths2B")
        } else {
            print("Padmavathi Failed Maths2B")
        }
        
        if padmavathi2ndYearPhysicsMarks >= passMarks3 {
            print("Padmavathi Passed Physics")
        } else {
            print("Padmavathi Failed Physics")
        }
        
        if padmavathi2ndYearChemistryMarks >= passMarks3 {
            print("Padmavathi Passed Chemistry")
        } else {
            print("Padmavathi Failed Chemistry")
        }
        
        if padmavathiPhysicsLab >= labPassMarks {
            print("Padmavathi Passed Physics Lab")
        } else {
            print("Padmavathi Failed Physics Lab")
        }
        
        if padmavathiChemistryLab >= labPassMarks {
            print("Padmavathi Passed Chemistry Lab")
        } else {
            print("Padmavathi Failed Chemistry Lab")
        }
        
        
        // Coding to the Padmavathi passed or failed in Inter 2nd Year is given below
        
        if (padmavathi2ndYearSanMarks >= passMarks1 && padmavathi2ndYearEngMarks >= passMarks1 && padmavathi2ndYearMathsAMarks >= passMarks2 && padmavathi2ndYearMathsBMarks >= passMarks2 && padmavathi2ndYearPhysicsMarks >= passMarks3 && padmavathi2ndYearChemistryMarks >= passMarks3 && padmavathiPhysicsLab >= labPassMarks && padmavathiChemistryLab >= labPassMarks) {
            print("Padmavathi PASSED 2nd Year")
        } else {
            print("Padmavathi FAILED 2nd Year")
        }
        
        // Coding to the Padmavathi passed or failed in Inter is given below
        
        if (padmavathi1stYearSanMarks >= passMarks1 && padmavathi1stYearEngMarks >= passMarks1 && padmavathi1stYearMathsAMarks >= passMarks2 && padmavathi1stYearMathsBMarks >= passMarks2 && padmavathi1stYearPhysicsMarks >= passMarks2 && padmavathi1stYearChemistryMarks >= passMarks2) && (padmavathi2ndYearSanMarks >= passMarks1 && padmavathi2ndYearEngMarks >= passMarks1 && padmavathi2ndYearMathsAMarks >= passMarks2 && padmavathi2ndYearMathsBMarks >= passMarks2 && padmavathi2ndYearPhysicsMarks >= passMarks3 && padmavathi2ndYearChemistryMarks >= passMarks3 && padmavathiPhysicsLab >= labPassMarks && padmavathiChemistryLab >= labPassMarks)
        {
            print("Padmavathi PASSED Intermediate")
        } else {
            print("Padmavathi FAILED Intermediate")
        }
        
        
        // Calculating padmavathi Total Inter Marks in Float
        
        let padmavathiInterMarks:Float = padmavathi1stYearMarks + padmavathi2ndYearMarks
        
        // Printing Total Marks of padmavathi
        
        print("padmavathi Inter Total Marks = \(padmavathiInterMarks)")
        
        // Giving grade to padmavathi according to his marks
        
        if (padmavathiInterMarks >= intergradeA){
            print("padmavathi's 1st Year grade = \(gradeA)")
        } else if (padmavathiInterMarks >= intergradeB){
            print("padmavathi's grade = \(gradeB)")
        } else if (padmavathiInterMarks >= intergradeC){
            print("padmavathi's grade = \(gradeC)")
        } else {
            print("padmavathi's grade = \(gradeD)")
        }
        
        

        
        // Inter 1st Year Janaki's Marks available below
        
        let janaki1stYearSanMarks:UInt8 = 32
        let janaki1stYearEngMarks:UInt8 = 49
        let janaki1stYearMathsAMarks:UInt8 = 65
        let janaki1stYearMathsBMarks:UInt8 = 53
        let janaki1stYearPhysicsMarks:UInt8 = 57
        let janaki1stYearChemistryMarks:UInt8 = 54
        
        // Inters 1st Year Total Marks coding is available below
        
        let janaki1stYearGainedMarks:UInt16 = UInt16(janaki1stYearEngMarks)+UInt16(janaki1stYearSanMarks)+UInt16(janaki1stYearMathsAMarks)+UInt16(janaki1stYearMathsBMarks)+UInt16(janaki1stYearPhysicsMarks)+UInt16(janaki1stYearChemistryMarks)
        
        // Inter Total Marks printing code is available below
        
        print("Janaki's 1st Year Marks = \(janaki1stYearGainedMarks)")
        
        // Inter 1st Year Marks of Janaki converted in Float
        
        let janaki1stYearMarks:Float = Float(janaki1stYearGainedMarks)
        
        // Inter 1st Year Percentage calculated below
        
        let janaki1stYearPercentage:Float = (janaki1stYearMarks/total1stYearMarks)*100
        
        // Janaki's 1st Year Percentage is Printing below
        
        print("Janaki's 1st Year Percentage = \(janaki1stYearPercentage)")
        
        // Coding to the Janaki passed or failed in Inter subject wise is given below
        
        if janaki1stYearSanMarks >= passMarks1 {
            print("Janaki Passed Sanskrit")
        } else {
            print("Janaki Failed Sanskrit")
        }
        
        if janaki1stYearEngMarks >= passMarks1 {
            print("Janaki Passed English")
        } else {
            print("Janaki Failed English")
        }
        
        if janaki1stYearMathsAMarks >= passMarks2 {
            print("Janaki Passed MathsA")
        } else {
            print("Janaki Failed MathsA")
        }
        
        if janaki1stYearMathsBMarks >= passMarks2 {
            print("Janaki Passed MathsB")
        } else {
            print("Janaki Failed MathsB")
        }
        
        if janaki1stYearPhysicsMarks >= passMarks3 {
            print("Janaki Passed Physics")
        } else {
            print("Janaki Failed Physics")
        }
        
        if janaki1stYearChemistryMarks >= passMarks3 {
            print("Janaki Passed Chemistry")
        } else {
            print("Janaki Failed Chemistry")
        }
        
        // Coding to the Janaki passed or failed in Inter 1st Year is given below
        
        if (janaki1stYearSanMarks >= passMarks1 && janaki1stYearEngMarks >= passMarks1 && janaki1stYearMathsAMarks >= passMarks2 && janaki1stYearMathsBMarks >= passMarks2 && janaki1stYearPhysicsMarks >= passMarks3 && janaki1stYearChemistryMarks >= passMarks3) {
            print("Janaki PASSED 1st Year")
        } else {
            print("Janaki FAILED 1st Year")
        }
        
        
        
        // Inter 2nd Year Janaki's Marks available below
        
        let janaki2ndYearSanMarks:UInt8 = 58
        let janaki2ndYearEngMarks:UInt8 = 64
        let janaki2ndYearMathsAMarks:UInt8 = 68
        let janaki2ndYearMathsBMarks:UInt8 = 62
        let janaki2ndYearPhysicsMarks:UInt8 = 45
        let janaki2ndYearChemistryMarks:UInt8 = 54
        let janakiPhysicsLab:UInt8 = 35
        let janakiChemistryLab:UInt8 = 38
        
        // Inters 2nd Year Total Marks coding is available below
        
        let janaki2ndYearGainedMarks:UInt16 = UInt16(janaki2ndYearEngMarks)+UInt16(janaki2ndYearSanMarks)+UInt16(janaki2ndYearMathsAMarks)+UInt16(janaki2ndYearMathsBMarks)+UInt16(janaki2ndYearPhysicsMarks)+UInt16(janaki2ndYearChemistryMarks)+UInt16(janakiPhysicsLab)+UInt16(janakiChemistryLab)
        
        // Inter Total Marks printing code is available below
        
        print("Janaki's 2nd Year Marks = \(janaki2ndYearGainedMarks)")
        
        // Inter 2nd Year Marks of Janaki converted in Float
        
        let janaki2ndYearMarks:Float = Float(janaki2ndYearGainedMarks)
        
        // Inter 2nd Year Percentage calculated below
        
        let janaki2ndYearPercentage:Float = (janaki2ndYearMarks/total2ndYearMarks)*100
        
        // Janaki's 2nd Year Percentage is Printing below
        
        print("Janaki's 2nd Year Percentage = \(janaki2ndYearPercentage)")
        
        // Coding to the Janaki passed or failed in Inter 2nd Year is given below
        
        if janaki2ndYearSanMarks >= passMarks1 {
            print("Janaki Passed Sanskrit")
        } else {
            print("Janaki Failed Sanskrit")
        }
        
        if janaki2ndYearEngMarks >= passMarks1 {
            print("Janaki Passed English")
        } else {
            print("Janaki Failed English")
        }
        
        if janaki2ndYearMathsAMarks >= passMarks2 {
            print("Janaki Passed Maths2A")
        } else {
            print("Janaki Failed Maths2A")
        }
        
        if janaki2ndYearMathsBMarks >= passMarks2 {
            print("Janaki Passed Maths2B")
        } else {
            print("Janaki Failed Maths2B")
        }
        
        if janaki2ndYearPhysicsMarks >= passMarks3 {
            print("Janaki Passed Physics")
        } else {
            print("Janaki Failed Physics")
        }
        
        if janaki2ndYearChemistryMarks >= passMarks3 {
            print("Janaki Passed Chemistry")
        } else {
            print("Janaki Failed Chemistry")
        }
        
        if janakiPhysicsLab >= labPassMarks {
            print("Janaki Passed Physics Lab")
        } else {
            print("Janaki Failed Physics Lab")
        }
        
        if janakiChemistryLab >= labPassMarks {
            print("Janaki Passed Chemistry Lab")
        } else {
            print("Janaki Failed Chemistry Lab")
        }
        
        
        // Coding to the Janaki passed or failed in Inter 2nd Year is given below
        
        if (janaki2ndYearSanMarks >= passMarks1 && janaki2ndYearEngMarks >= passMarks1 && janaki2ndYearMathsAMarks >= passMarks2 && janaki2ndYearMathsBMarks >= passMarks2 && janaki2ndYearPhysicsMarks >= passMarks3 && janaki2ndYearChemistryMarks >= passMarks3 && janakiPhysicsLab >= labPassMarks && janakiChemistryLab >= labPassMarks) {
            print("Janaki PASSED 2nd Year")
        } else {
            print("Janaki FAILED 2nd Year")
        }
        
        // Coding to the Janaki passed or failed in Inter is given below
        
        if (janaki1stYearSanMarks >= passMarks1 && janaki1stYearEngMarks >= passMarks1 && janaki1stYearMathsAMarks >= passMarks2 && janaki1stYearMathsBMarks >= passMarks2 && janaki1stYearPhysicsMarks >= passMarks2 && janaki1stYearChemistryMarks >= passMarks2) && (janaki2ndYearSanMarks >= passMarks1 && janaki2ndYearEngMarks >= passMarks1 && janaki2ndYearMathsAMarks >= passMarks2 && janaki2ndYearMathsBMarks >= passMarks2 && janaki2ndYearPhysicsMarks >= passMarks3 && janaki2ndYearChemistryMarks >= passMarks3 && janakiPhysicsLab >= labPassMarks && janakiChemistryLab >= labPassMarks)
        {
            print("Janaki PASSED Intermediate")
        } else {
            print("Janaki FAILED Intermediate")
        }
        
        // Calculating janaki Total Inter Marks in Float
        
        let janakiInterMarks:Float = janaki1stYearMarks + janaki2ndYearMarks
        
        // Printing Total Marks of janaki
        
        print("janaki Inter Total Marks = \(janakiInterMarks)")
        
        // Giving grade to janaki according to his marks
        
        if (janakiInterMarks >= intergradeA){
            print("janaki's 1st Year grade = \(gradeA)")
        } else if (janakiInterMarks >= intergradeB){
            print("janaki's grade = \(gradeB)")
        } else if (janakiInterMarks >= intergradeC){
            print("janaki's grade = \(gradeC)")
        } else {
            print("janaki's grade = \(gradeD)")
        }
        
        

        
        
        // Inter 1st Year Madhulikha's Marks available below
        
        let madhulikha1stYearSanMarks:UInt8 = 62
        let madhulikha1stYearEngMarks:UInt8 = 49
        let madhulikha1stYearMathsAMarks:UInt8 = 65
        let madhulikha1stYearMathsBMarks:UInt8 = 65
        let madhulikha1stYearPhysicsMarks:UInt8 = 57
        let madhulikha1stYearChemistryMarks:UInt8 = 54
        
        // Inters 1st Year Total Marks coding is available below
        
        let madhulikha1stYearGainedMarks:UInt16 = UInt16(madhulikha1stYearEngMarks)+UInt16(madhulikha1stYearSanMarks)+UInt16(madhulikha1stYearMathsAMarks)+UInt16(madhulikha1stYearMathsBMarks)+UInt16(madhulikha1stYearPhysicsMarks)+UInt16(madhulikha1stYearChemistryMarks)
        
        // Inter Total Marks printing code is available below
        
        print("Madhulikha's 1st Year Marks = \(madhulikha1stYearGainedMarks)")
        
        // Inter 1st Year Marks of Madhulikha converted in Float
        
        let madhulikha1stYearMarks:Float = Float(madhulikha1stYearGainedMarks)
        
        // Inter 1st Year Percentage calculated below
        
        let madhulikha1stYearPercentage:Float = (madhulikha1stYearMarks/total1stYearMarks)*100
        
        // Madhulikha's 1st Year Percentage is Printing below
        
        print("Madhulikha's 1st Year Percentage = \(madhulikha1stYearPercentage)")
        
        // Coding to the Madhulikha passed or failed in Inter subject wise is given below
        
        if madhulikha1stYearSanMarks >= passMarks1 {
            print("Madhulikha Passed Sanskrit")
        } else {
            print("Madhulikha Failed Sanskrit")
        }
        
        if madhulikha1stYearEngMarks >= passMarks1 {
            print("Madhulikha Passed English")
        } else {
            print("Madhulikha Failed English")
        }
        
        if madhulikha1stYearMathsAMarks >= passMarks2 {
            print("Madhulikha Passed MathsA")
        } else {
            print("Madhulikha Failed MathsA")
        }
        
        if madhulikha1stYearMathsBMarks >= passMarks2 {
            print("Madhulikha Passed MathsB")
        } else {
            print("Madhulikha Failed MathsB")
        }
        
        if madhulikha1stYearPhysicsMarks >= passMarks3 {
            print("Madhulikha Passed Physics")
        } else {
            print("Madhulikha Failed Physics")
        }
        
        if madhulikha1stYearChemistryMarks >= passMarks3 {
            print("Madhulikha Passed Chemistry")
        } else {
            print("Madhulikha Failed Chemistry")
        }
        
        // Coding to the Madhulikha passed or failed in Inter 1st Year is given below
        
        if (madhulikha1stYearSanMarks >= passMarks1 && madhulikha1stYearEngMarks >= passMarks1 && madhulikha1stYearMathsAMarks >= passMarks2 && madhulikha1stYearMathsBMarks >= passMarks2 && madhulikha1stYearPhysicsMarks >= passMarks3 && madhulikha1stYearChemistryMarks >= passMarks3) {
            print("Madhulikha PASSED 1st Year")
        } else {
            print("Madhulikha FAILED 1st Year")
        }
        
        
        
        // Inter 2nd Year Madhulikha's Marks available below
        
        let madhulikha2ndYearSanMarks:UInt8 = 75
        let madhulikha2ndYearEngMarks:UInt8 = 64
        let madhulikha2ndYearMathsAMarks:UInt8 = 55
        let madhulikha2ndYearMathsBMarks:UInt8 = 62
        let madhulikha2ndYearPhysicsMarks:UInt8 = 45
        let madhulikha2ndYearChemistryMarks:UInt8 = 54
        let madhulikhaPhysicsLab:UInt8 = 15
        let madhulikhaChemistryLab:UInt8 = 38
        
        // Inters 2nd Year Total Marks coding is available below
        
        let madhulikha2ndYearGainedMarks:UInt16 = UInt16(madhulikha2ndYearEngMarks)+UInt16(madhulikha2ndYearSanMarks)+UInt16(madhulikha2ndYearMathsAMarks)+UInt16(madhulikha2ndYearMathsBMarks)+UInt16(madhulikha2ndYearPhysicsMarks)+UInt16(madhulikha2ndYearChemistryMarks)+UInt16(madhulikhaPhysicsLab)+UInt16(madhulikhaChemistryLab)
        
        // Inter Total Marks printing code is available below
        
        print("Madhulikha's 2nd Year Marks = \(madhulikha2ndYearGainedMarks)")
        
        // Inter 2nd Year Marks of Madhulikha converted in Float
        
        let madhulikha2ndYearMarks:Float = Float(madhulikha2ndYearGainedMarks)
        
        // Inter 2nd Year Percentage calculated below
        
        let madhulikha2ndYearPercentage:Float = (madhulikha2ndYearMarks/total2ndYearMarks)*100
        
        // Madhulikha's 2nd Year Percentage is Printing below
        
        print("Madhulikha's 2nd Year Percentage = \(madhulikha2ndYearPercentage)")
        
        // Coding to the Madhulikha passed or failed in Inter 2nd Year is given below
        
        if madhulikha2ndYearSanMarks >= passMarks1 {
            print("Madhulikha Passed Sanskrit")
        } else {
            print("Madhulikha Failed Sanskrit")
        }
        
        if madhulikha2ndYearEngMarks >= passMarks1 {
            print("Madhulikha Passed English")
        } else {
            print("Madhulikha Failed English")
        }
        
        if madhulikha2ndYearMathsAMarks >= passMarks2 {
            print("Madhulikha Passed Maths2A")
        } else {
            print("Madhulikha Failed Maths2A")
        }
        
        if madhulikha2ndYearMathsBMarks >= passMarks2 {
            print("Madhulikha Passed Maths2B")
        } else {
            print("Madhulikha Failed Maths2B")
        }
        
        if madhulikha2ndYearPhysicsMarks >= passMarks3 {
            print("Madhulikha Passed Physics")
        } else {
            print("Madhulikha Failed Physics")
        }
        
        if madhulikha2ndYearChemistryMarks >= passMarks3 {
            print("Madhulikha Passed Chemistry")
        } else {
            print("Madhulikha Failed Chemistry")
        }
        
        if madhulikhaPhysicsLab >= labPassMarks {
            print("Madhulikha Passed Physics Lab")
        } else {
            print("Madhulikha Failed Physics Lab")
        }
        
        if madhulikhaChemistryLab >= labPassMarks {
            print("Madhulikha Passed Chemistry Lab")
        } else {
            print("Madhulikha Failed Chemistry Lab")
        }
        
        
        // Coding to the Madhulikha passed or failed in Inter 2nd Year is given below
        
        if (madhulikha2ndYearSanMarks >= passMarks1 && madhulikha2ndYearEngMarks >= passMarks1 && madhulikha2ndYearMathsAMarks >= passMarks2 && madhulikha2ndYearMathsBMarks >= passMarks2 && madhulikha2ndYearPhysicsMarks >= passMarks3 && madhulikha2ndYearChemistryMarks >= passMarks3 && madhulikhaPhysicsLab >= labPassMarks && madhulikhaChemistryLab >= labPassMarks) {
            print("Madhulikha PASSED 2nd Year")
        } else {
            print("Madhulikha FAILED 2nd Year")
        }
        
        // Coding to the Madhulikha passed or failed in Inter is given below
        
        if (madhulikha1stYearSanMarks >= passMarks1 && madhulikha1stYearEngMarks >= passMarks1 && madhulikha1stYearMathsAMarks >= passMarks2 && madhulikha1stYearMathsBMarks >= passMarks2 && madhulikha1stYearPhysicsMarks >= passMarks2 && madhulikha1stYearChemistryMarks >= passMarks2) && (madhulikha2ndYearSanMarks >= passMarks1 && madhulikha2ndYearEngMarks >= passMarks1 && madhulikha2ndYearMathsAMarks >= passMarks2 && madhulikha2ndYearMathsBMarks >= passMarks2 && madhulikha2ndYearPhysicsMarks >= passMarks3 && madhulikha2ndYearChemistryMarks >= passMarks3 && madhulikhaPhysicsLab >= labPassMarks && madhulikhaChemistryLab >= labPassMarks)
        {
            print("Madhulikha PASSED Intermediate")
        } else {
            print("Madhulikha FAILED Intermediate")
        }
        
        
        // Calculating madhulikha Total Inter Marks in Float
        
        let madhulikhaInterMarks:Float = madhulikha1stYearMarks + madhulikha2ndYearMarks
        
        // Printing Total Marks of madhulikha
        
        print("madhulikha Inter Total Marks = \(madhulikhaInterMarks)")
        
        // Giving grade to madhulikha according to his marks
        
        if (madhulikhaInterMarks >= intergradeA){
            print("madhulikha's 1st Year grade = \(gradeA)")
        } else if (madhulikhaInterMarks >= intergradeB){
            print("madhulikha's grade = \(gradeB)")
        } else if (madhulikhaInterMarks >= intergradeC){
            print("madhulikha's grade = \(gradeC)")
        } else {
            print("madhulikha's grade = \(gradeD)")
        }
        
        

        
        // Inter 1st Year Punith's Marks available below
        
        let punith1stYearSanMarks:UInt8 = 86
        let punith1stYearEngMarks:UInt8 = 72
        let punith1stYearMathsAMarks:UInt8 = 65
        let punith1stYearMathsBMarks:UInt8 = 53
        let punith1stYearPhysicsMarks:UInt8 = 57
        let punith1stYearChemistryMarks:UInt8 = 54
        
        // Inters 1st Year Total Marks coding is available below
        
        let punith1stYearGainedMarks:UInt16 = UInt16(punith1stYearEngMarks)+UInt16(punith1stYearSanMarks)+UInt16(punith1stYearMathsAMarks)+UInt16(punith1stYearMathsBMarks)+UInt16(punith1stYearPhysicsMarks)+UInt16(punith1stYearChemistryMarks)
        
        // Inter Total Marks printing code is available below
        
        print("Punith's 1st Year Marks = \(punith1stYearGainedMarks)")
        
        // Inter 1st Year Marks of Punith converted in Float
        
        let punith1stYearMarks:Float = Float(punith1stYearGainedMarks)
        
        // Inter 1st Year Percentage calculated below
        
        let punith1stYearPercentage:Float = (punith1stYearMarks/total1stYearMarks)*100
        
        // Punith's 1st Year Percentage is Printing below
        
        print("Punith's 1st Year Percentage = \(punith1stYearPercentage)")
        
        // Coding to the Punith passed or failed in Inter subject wise is given below
        
        if punith1stYearSanMarks >= passMarks1 {
            print("Punith Passed Sanskrit")
        } else {
            print("Punith Failed Sanskrit")
        }
        
        if punith1stYearEngMarks >= passMarks1 {
            print("Punith Passed English")
        } else {
            print("Punith Failed English")
        }
        
        if punith1stYearMathsAMarks >= passMarks2 {
            print("Punith Passed MathsA")
        } else {
            print("Punith Failed MathsA")
        }
        
        if punith1stYearMathsBMarks >= passMarks2 {
            print("Punith Passed MathsB")
        } else {
            print("Punith Failed MathsB")
        }
        
        if punith1stYearPhysicsMarks >= passMarks3 {
            print("Punith Passed Physics")
        } else {
            print("Punith Failed Physics")
        }
        
        if punith1stYearChemistryMarks >= passMarks3 {
            print("Punith Passed Chemistry")
        } else {
            print("Punith Failed Chemistry")
        }
        
        // Coding to the Punith passed or failed in Inter 1st Year is given below
        
        if (punith1stYearSanMarks >= passMarks1 && punith1stYearEngMarks >= passMarks1 && punith1stYearMathsAMarks >= passMarks2 && punith1stYearMathsBMarks >= passMarks2 && punith1stYearPhysicsMarks >= passMarks3 && punith1stYearChemistryMarks >= passMarks3) {
            print("Punith PASSED 1st Year")
        } else {
            print("Punith FAILED 1st Year")
        }
        
        
        
        // Inter 2nd Year Punith's Marks available below
        
        let punith2ndYearSanMarks:UInt8 = 92
        let punith2ndYearEngMarks:UInt8 = 78
        let punith2ndYearMathsAMarks:UInt8 = 55
        let punith2ndYearMathsBMarks:UInt8 = 62
        let punith2ndYearPhysicsMarks:UInt8 = 45
        let punith2ndYearChemistryMarks:UInt8 = 54
        let punithPhysicsLab:UInt8 = 35
        let punithChemistryLab:UInt8 = 38
        
        // Inters 2nd Year Total Marks coding is available below
        
        let punith2ndYearGainedMarks:UInt16 = UInt16(punith2ndYearEngMarks)+UInt16(punith2ndYearSanMarks)+UInt16(punith2ndYearMathsAMarks)+UInt16(punith2ndYearMathsBMarks)+UInt16(punith2ndYearPhysicsMarks)+UInt16(punith2ndYearChemistryMarks)+UInt16(punithPhysicsLab)+UInt16(punithChemistryLab)
        
        // Inter Total Marks printing code is available below
        
        print("Punith's 2nd Year Marks = \(punith2ndYearGainedMarks)")
        
        // Inter 2nd Year Marks of Punith converted in Float
        
        let punith2ndYearMarks:Float = Float(punith2ndYearGainedMarks)
        
        // Inter 2nd Year Percentage calculated below
        
        let punith2ndYearPercentage:Float = (punith2ndYearMarks/total2ndYearMarks)*100
        
        // Punith's 2nd Year Percentage is Printing below
        
        print("Punith's 2nd Year Percentage = \(punith2ndYearPercentage)")
        
        // Coding to the Punith passed or failed in Inter 2nd Year is given below
        
        if punith2ndYearSanMarks >= passMarks1 {
            print("Punith Passed Sanskrit")
        } else {
            print("Punith Failed Sanskrit")
        }
        
        if punith2ndYearEngMarks >= passMarks1 {
            print("Punith Passed English")
        } else {
            print("Punith Failed English")
        }
        
        if punith2ndYearMathsAMarks >= passMarks2 {
            print("Punith Passed Maths2A")
        } else {
            print("Punith Failed Maths2A")
        }
        
        if punith2ndYearMathsBMarks >= passMarks2 {
            print("Punith Passed Maths2B")
        } else {
            print("Punith Failed Maths2B")
        }
        
        if punith2ndYearPhysicsMarks >= passMarks3 {
            print("Punith Passed Physics")
        } else {
            print("Punith Failed Physics")
        }
        
        if punith2ndYearChemistryMarks >= passMarks3 {
            print("Punith Passed Chemistry")
        } else {
            print("Punith Failed Chemistry")
        }
        
        if punithPhysicsLab >= labPassMarks {
            print("Punith Passed Physics Lab")
        } else {
            print("Punith Failed Physics Lab")
        }
        
        if punithChemistryLab >= labPassMarks {
            print("Punith Passed Chemistry Lab")
        } else {
            print("Punith Failed Chemistry Lab")
        }
        
        
        // Coding to the Punith passed or failed in Inter 2nd Year is given below
        
        if (punith2ndYearSanMarks >= passMarks1 && punith2ndYearEngMarks >= passMarks1 && punith2ndYearMathsAMarks >= passMarks2 && punith2ndYearMathsBMarks >= passMarks2 && punith2ndYearPhysicsMarks >= passMarks3 && punith2ndYearChemistryMarks >= passMarks3 && punithPhysicsLab >= labPassMarks && punithChemistryLab >= labPassMarks) {
            print("Punith PASSED 2nd Year")
        } else {
            print("Punith FAILED 2nd Year")
        }
        
        // Coding to the Punith passed or failed in Inter is given below
        
        if (punith1stYearSanMarks >= passMarks1 && punith1stYearEngMarks >= passMarks1 && punith1stYearMathsAMarks >= passMarks2 && punith1stYearMathsBMarks >= passMarks2 && punith1stYearPhysicsMarks >= passMarks2 && punith1stYearChemistryMarks >= passMarks2) && (punith2ndYearSanMarks >= passMarks1 && punith2ndYearEngMarks >= passMarks1 && punith2ndYearMathsAMarks >= passMarks2 && punith2ndYearMathsBMarks >= passMarks2 && punith2ndYearPhysicsMarks >= passMarks3 && punith2ndYearChemistryMarks >= passMarks3 && punithPhysicsLab >= labPassMarks && punithChemistryLab >= labPassMarks)
        {
            print("Punith PASSED Intermediate")
        } else {
            print("Punith FAILED Intermediate")
        }
        
        
        // Calculating punith Total Inter Marks in Float
        
        let punithInterMarks:Float = punith1stYearMarks + punith2ndYearMarks
        
        // Printing Total Marks of punith
        
        print("punith Inter Total Marks = \(punithInterMarks)")
        
        // Giving grade to punith according to his marks
        
        if (punithInterMarks >= intergradeA){
            print("punith's 1st Year grade = \(gradeA)")
        } else if (punithInterMarks >= intergradeB){
            print("punith's grade = \(gradeB)")
        } else if (punithInterMarks >= intergradeC){
            print("punith's grade = \(gradeC)")
        } else {
            print("punith's grade = \(gradeD)")
        }
        
        

        
        // Inter 1st Year Nikshith's Marks available below
        
        let nikshith1stYearSanMarks:UInt8 = 78
        let nikshith1stYearEngMarks:UInt8 = 82
        let nikshith1stYearMathsAMarks:UInt8 = 65
        let nikshith1stYearMathsBMarks:UInt8 = 53
        let nikshith1stYearPhysicsMarks:UInt8 = 57
        let nikshith1stYearChemistryMarks:UInt8 = 54
        
        // Inters 1st Year Total Marks coding is available below
        
        let nikshith1stYearGainedMarks:UInt16 = UInt16(nikshith1stYearEngMarks)+UInt16(nikshith1stYearSanMarks)+UInt16(nikshith1stYearMathsAMarks)+UInt16(nikshith1stYearMathsBMarks)+UInt16(nikshith1stYearPhysicsMarks)+UInt16(nikshith1stYearChemistryMarks)
        
        // Inter Total Marks printing code is available below
        
        print("Nikshith's 1st Year Marks = \(nikshith1stYearGainedMarks)")
        
        // Inter 1st Year Marks of Nikshith converted in Float
        
        let nikshith1stYearMarks:Float = Float(nikshith1stYearGainedMarks)
        
        // Inter 1st Year Percentage calculated below
        
        let nikshith1stYearPercentage:Float = (nikshith1stYearMarks/total1stYearMarks)*100
        
        // Nikshith's 1st Year Percentage is Printing below
        
        print("Nikshith's 1st Year Percentage = \(nikshith1stYearPercentage)")
        
        // Coding to the Nikshith passed or failed in Inter subject wise is given below
        
        if nikshith1stYearSanMarks >= passMarks1 {
            print("Nikshith Passed Sanskrit")
        } else {
            print("Nikshith Failed Sanskrit")
        }
        
        if nikshith1stYearEngMarks >= passMarks1 {
            print("Nikshith Passed English")
        } else {
            print("Nikshith Failed English")
        }
        
        if nikshith1stYearMathsAMarks >= passMarks2 {
            print("Nikshith Passed MathsA")
        } else {
            print("Nikshith Failed MathsA")
        }
        
        if nikshith1stYearMathsBMarks >= passMarks2 {
            print("Nikshith Passed MathsB")
        } else {
            print("Nikshith Failed MathsB")
        }
        
        if nikshith1stYearPhysicsMarks >= passMarks3 {
            print("Nikshith Passed Physics")
        } else {
            print("Nikshith Failed Physics")
        }
        
        if nikshith1stYearChemistryMarks >= passMarks3 {
            print("Nikshith Passed Chemistry")
        } else {
            print("Nikshith Failed Chemistry")
        }
        
        // Coding to the Nikshith passed or failed in Inter 1st Year is given below
        
        if (nikshith1stYearSanMarks >= passMarks1 && nikshith1stYearEngMarks >= passMarks1 && nikshith1stYearMathsAMarks >= passMarks2 && nikshith1stYearMathsBMarks >= passMarks2 && nikshith1stYearPhysicsMarks >= passMarks3 && nikshith1stYearChemistryMarks >= passMarks3) {
            print("Nikshith PASSED 1st Year")
        } else {
            print("Nikshith FAILED 1st Year")
        }
        
        
        
        // Inter 2nd Year Nikshith's Marks available below
        
        let nikshith2ndYearSanMarks:UInt8 = 58
        let nikshith2ndYearEngMarks:UInt8 = 64
        let nikshith2ndYearMathsAMarks:UInt8 = 55
        let nikshith2ndYearMathsBMarks:UInt8 = 48
        let nikshith2ndYearPhysicsMarks:UInt8 = 45
        let nikshith2ndYearChemistryMarks:UInt8 = 54
        let nikshithPhysicsLab:UInt8 = 24
        let nikshithChemistryLab:UInt8 = 38
        
        // Inters 2nd Year Total Marks coding is available below
        
        let nikshith2ndYearGainedMarks:UInt16 = UInt16(nikshith2ndYearEngMarks)+UInt16(nikshith2ndYearSanMarks)+UInt16(nikshith2ndYearMathsAMarks)+UInt16(nikshith2ndYearMathsBMarks)+UInt16(nikshith2ndYearPhysicsMarks)+UInt16(nikshith2ndYearChemistryMarks)+UInt16(nikshithPhysicsLab)+UInt16(nikshithChemistryLab)
        
        // Inter Total Marks printing code is available below
        
        print("Nikshith's 2nd Year Marks = \(nikshith2ndYearGainedMarks)")
        
        // Inter 2nd Year Marks of Nikshith converted in Float
        
        let nikshith2ndYearMarks:Float = Float(nikshith2ndYearGainedMarks)
        
        // Inter 2nd Year Percentage calculated below
        
        let nikshith2ndYearPercentage:Float = (nikshith2ndYearMarks/total2ndYearMarks)*100
        
        // Nikshith's 2nd Year Percentage is Printing below
        
        print("Nikshith's 2nd Year Percentage = \(nikshith2ndYearPercentage)")
        
        // Coding to the Nikshith passed or failed in Inter 2nd Year is given below
        
        if nikshith2ndYearSanMarks >= passMarks1 {
            print("Nikshith Passed Sanskrit")
        } else {
            print("Nikshith Failed Sanskrit")
        }
        
        if nikshith2ndYearEngMarks >= passMarks1 {
            print("Nikshith Passed English")
        } else {
            print("Nikshith Failed English")
        }
        
        if nikshith2ndYearMathsAMarks >= passMarks2 {
            print("Nikshith Passed Maths2A")
        } else {
            print("Nikshith Failed Maths2A")
        }
        
        if nikshith2ndYearMathsBMarks >= passMarks2 {
            print("Nikshith Passed Maths2B")
        } else {
            print("Nikshith Failed Maths2B")
        }
        
        if nikshith2ndYearPhysicsMarks >= passMarks3 {
            print("Nikshith Passed Physics")
        } else {
            print("Nikshith Failed Physics")
        }
        
        if nikshith2ndYearChemistryMarks >= passMarks3 {
            print("Nikshith Passed Chemistry")
        } else {
            print("Nikshith Failed Chemistry")
        }
        
        if nikshithPhysicsLab >= labPassMarks {
            print("Nikshith Passed Physics Lab")
        } else {
            print("Nikshith Failed Physics Lab")
        }
        
        if nikshithChemistryLab >= labPassMarks {
            print("Nikshith Passed Chemistry Lab")
        } else {
            print("Nikshith Failed Chemistry Lab")
        }
        
        
        // Coding to the Nikshith passed or failed in Inter 2nd Year is given below
        
        if (nikshith2ndYearSanMarks >= passMarks1 && nikshith2ndYearEngMarks >= passMarks1 && nikshith2ndYearMathsAMarks >= passMarks2 && nikshith2ndYearMathsBMarks >= passMarks2 && nikshith2ndYearPhysicsMarks >= passMarks3 && nikshith2ndYearChemistryMarks >= passMarks3 && nikshithPhysicsLab >= labPassMarks && nikshithChemistryLab >= labPassMarks) {
            print("Nikshith PASSED 2nd Year")
        } else {
            print("Nikshith FAILED 2nd Year")
        }
        
        // Coding to the Nikshith passed or failed in Inter is given below
        
        if (nikshith1stYearSanMarks >= passMarks1 && nikshith1stYearEngMarks >= passMarks1 && nikshith1stYearMathsAMarks >= passMarks2 && nikshith1stYearMathsBMarks >= passMarks2 && nikshith1stYearPhysicsMarks >= passMarks2 && nikshith1stYearChemistryMarks >= passMarks2) && (nikshith2ndYearSanMarks >= passMarks1 && nikshith2ndYearEngMarks >= passMarks1 && nikshith2ndYearMathsAMarks >= passMarks2 && nikshith2ndYearMathsBMarks >= passMarks2 && nikshith2ndYearPhysicsMarks >= passMarks3 && nikshith2ndYearChemistryMarks >= passMarks3 && nikshithPhysicsLab >= labPassMarks && nikshithChemistryLab >= labPassMarks)
        {
            print("Nikshith PASSED Intermediate")
        } else {
            print("Nikshith FAILED Intermediate")
        }
        
        
        // Calculating nikshith Total Inter Marks in Float
        
        let nikshithInterMarks:Float = nikshith1stYearMarks + nikshith2ndYearMarks
        
        // Printing Total Marks of nikshith
        
        print("nikshith Inter Total Marks = \(nikshithInterMarks)")
        
        // Giving grade to nikshith according to his marks
        
        if (nikshithInterMarks >= intergradeA){
            print("nikshith's 1st Year grade = \(gradeA)")
        } else if (nikshithInterMarks >= intergradeB){
            print("nikshith's grade = \(gradeB)")
        } else if (nikshithInterMarks >= intergradeC){
            print("nikshith's grade = \(gradeC)")
        } else {
            print("nikshith's grade = \(gradeD)")
        }
        
        

        
        // Inter 1st Year Deekshitha's Marks available below
        
        let deekshitha1stYearSanMarks:UInt8 = 62
        let deekshitha1stYearEngMarks:UInt8 = 49
        let deekshitha1stYearMathsAMarks:UInt8 = 72
        let deekshitha1stYearMathsBMarks:UInt8 = 53
        let deekshitha1stYearPhysicsMarks:UInt8 = 57
        let deekshitha1stYearChemistryMarks:UInt8 = 54
        
        // Inters 1st Year Total Marks coding is available below
        
        let deekshitha1stYearGainedMarks:UInt16 = UInt16(deekshitha1stYearEngMarks)+UInt16(deekshitha1stYearSanMarks)+UInt16(deekshitha1stYearMathsAMarks)+UInt16(deekshitha1stYearMathsBMarks)+UInt16(deekshitha1stYearPhysicsMarks)+UInt16(deekshitha1stYearChemistryMarks)
        
        // Inter Total Marks printing code is available below
        
        print("Deekshitha's 1st Year Marks = \(deekshitha1stYearGainedMarks)")
        
        // Inter 1st Year Marks of Deekshitha converted in Float
        
        let deekshitha1stYearMarks:Float = Float(deekshitha1stYearGainedMarks)
        
        // Inter 1st Year Percentage calculated below
        
        let deekshitha1stYearPercentage:Float = (deekshitha1stYearMarks/total1stYearMarks)*100
        
        // Deekshitha's 1st Year Percentage is Printing below
        
        print("Deekshitha's 1st Year Percentage = \(deekshitha1stYearPercentage)")
        
        // Coding to the Deekshitha passed or failed in Inter subject wise is given below
        
        if deekshitha1stYearSanMarks >= passMarks1 {
            print("Deekshitha Passed Sanskrit")
        } else {
            print("Deekshitha Failed Sanskrit")
        }
        
        if deekshitha1stYearEngMarks >= passMarks1 {
            print("Deekshitha Passed English")
        } else {
            print("Deekshitha Failed English")
        }
        
        if deekshitha1stYearMathsAMarks >= passMarks2 {
            print("Deekshitha Passed MathsA")
        } else {
            print("Deekshitha Failed MathsA")
        }
        
        if deekshitha1stYearMathsBMarks >= passMarks2 {
            print("Deekshitha Passed MathsB")
        } else {
            print("Deekshitha Failed MathsB")
        }
        
        if deekshitha1stYearPhysicsMarks >= passMarks3 {
            print("Deekshitha Passed Physics")
        } else {
            print("Deekshitha Failed Physics")
        }
        
        if deekshitha1stYearChemistryMarks >= passMarks3 {
            print("Deekshitha Passed Chemistry")
        } else {
            print("Deekshitha Failed Chemistry")
        }
        
        // Coding to the Deekshitha passed or failed in Inter 1st Year is given below
        
        if (deekshitha1stYearSanMarks >= passMarks1 && deekshitha1stYearEngMarks >= passMarks1 && deekshitha1stYearMathsAMarks >= passMarks2 && deekshitha1stYearMathsBMarks >= passMarks2 && deekshitha1stYearPhysicsMarks >= passMarks3 && deekshitha1stYearChemistryMarks >= passMarks3) {
            print("Deekshitha PASSED 1st Year")
        } else {
            print("Deekshitha FAILED 1st Year")
        }
        
        
        
        // Inter 2nd Year Deekshitha's Marks available below
        
        let deekshitha2ndYearSanMarks:UInt8 = 58
        let deekshitha2ndYearEngMarks:UInt8 = 64
        let deekshitha2ndYearMathsAMarks:UInt8 = 55
        let deekshitha2ndYearMathsBMarks:UInt8 = 20
        let deekshitha2ndYearPhysicsMarks:UInt8 = 45
        let deekshitha2ndYearChemistryMarks:UInt8 = 54
        let deekshithaPhysicsLab:UInt8 = 35
        let deekshithaChemistryLab:UInt8 = 38
        
        // Inters 2nd Year Total Marks coding is available below
        
        let deekshitha2ndYearGainedMarks:UInt16 = UInt16(deekshitha2ndYearEngMarks)+UInt16(deekshitha2ndYearSanMarks)+UInt16(deekshitha2ndYearMathsAMarks)+UInt16(deekshitha2ndYearMathsBMarks)+UInt16(deekshitha2ndYearPhysicsMarks)+UInt16(deekshitha2ndYearChemistryMarks)+UInt16(deekshithaPhysicsLab)+UInt16(deekshithaChemistryLab)
        
        // Inter Total Marks printing code is available below
        
        print("Deekshitha's 2nd Year Marks = \(deekshitha2ndYearGainedMarks)")
        
        // Inter 2nd Year Marks of Deekshitha converted in Float
        
        let deekshitha2ndYearMarks:Float = Float(deekshitha2ndYearGainedMarks)
        
        // Inter 2nd Year Percentage calculated below
        
        let deekshitha2ndYearPercentage:Float = (deekshitha2ndYearMarks/total2ndYearMarks)*100
        
        // Deekshitha's 2nd Year Percentage is Printing below
        
        print("Deekshitha's 2nd Year Percentage = \(deekshitha2ndYearPercentage)")
        
        // Coding to the Deekshitha passed or failed in Inter 2nd Year is given below
        
        if deekshitha2ndYearSanMarks >= passMarks1 {
            print("Deekshitha Passed Sanskrit")
        } else {
            print("Deekshitha Failed Sanskrit")
        }
        
        if deekshitha2ndYearEngMarks >= passMarks1 {
            print("Deekshitha Passed English")
        } else {
            print("Deekshitha Failed English")
        }
        
        if deekshitha2ndYearMathsAMarks >= passMarks2 {
            print("Deekshitha Passed Maths2A")
        } else {
            print("Deekshitha Failed Maths2A")
        }
        
        if deekshitha2ndYearMathsBMarks >= passMarks2 {
            print("Deekshitha Passed Maths2B")
        } else {
            print("Deekshitha Failed Maths2B")
        }
        
        if deekshitha2ndYearPhysicsMarks >= passMarks3 {
            print("Deekshitha Passed Physics")
        } else {
            print("Deekshitha Failed Physics")
        }
        
        if deekshitha2ndYearChemistryMarks >= passMarks3 {
            print("Deekshitha Passed Chemistry")
        } else {
            print("Deekshitha Failed Chemistry")
        }
        
        if deekshithaPhysicsLab >= labPassMarks {
            print("Deekshitha Passed Physics Lab")
        } else {
            print("Deekshitha Failed Physics Lab")
        }
        
        if deekshithaChemistryLab >= labPassMarks {
            print("Deekshitha Passed Chemistry Lab")
        } else {
            print("Deekshitha Failed Chemistry Lab")
        }
        
        
        // Coding to the Deekshitha passed or failed in Inter 2nd Year is given below
        
        if (deekshitha2ndYearSanMarks >= passMarks1 && deekshitha2ndYearEngMarks >= passMarks1 && deekshitha2ndYearMathsAMarks >= passMarks2 && deekshitha2ndYearMathsBMarks >= passMarks2 && deekshitha2ndYearPhysicsMarks >= passMarks3 && deekshitha2ndYearChemistryMarks >= passMarks3 && deekshithaPhysicsLab >= labPassMarks && deekshithaChemistryLab >= labPassMarks) {
            print("Deekshitha PASSED 2nd Year")
        } else {
            print("Deekshitha FAILED 2nd Year")
        }
        
        // Coding to the Deekshitha passed or failed in Inter is given below
        
        if (deekshitha1stYearSanMarks >= passMarks1 && deekshitha1stYearEngMarks >= passMarks1 && deekshitha1stYearMathsAMarks >= passMarks2 && deekshitha1stYearMathsBMarks >= passMarks2 && deekshitha1stYearPhysicsMarks >= passMarks2 && deekshitha1stYearChemistryMarks >= passMarks2) && (deekshitha2ndYearSanMarks >= passMarks1 && deekshitha2ndYearEngMarks >= passMarks1 && deekshitha2ndYearMathsAMarks >= passMarks2 && deekshitha2ndYearMathsBMarks >= passMarks2 && deekshitha2ndYearPhysicsMarks >= passMarks3 && deekshitha2ndYearChemistryMarks >= passMarks3 && deekshithaPhysicsLab >= labPassMarks && deekshithaChemistryLab >= labPassMarks)
        {
            print("Deekshitha PASSED Intermediate")
        } else {
            print("Deekshitha FAILED Intermediate")
        }
        
        // Calculating deekshitha Total Inter Marks in Float
        
        let deekshithaInterMarks:Float = deekshitha1stYearMarks + deekshitha2ndYearMarks
        
        // Printing Total Marks of deekshitha
        
        print("deekshitha Inter Total Marks = \(deekshithaInterMarks)")
        
        // Giving grade to deekshitha according to his marks
        
        if (deekshithaInterMarks >= intergradeA){
            print("deekshitha's 1st Year grade = \(gradeA)")
        } else if (deekshithaInterMarks >= intergradeB){
            print("deekshitha's grade = \(gradeB)")
        } else if (deekshithaInterMarks >= intergradeC){
            print("deekshitha's grade = \(gradeC)")
        } else {
            print("deekshitha's grade = \(gradeD)")
        }
        
        

    
        // Do any additional setup after loading the view, typically from a nib.
    }

}

