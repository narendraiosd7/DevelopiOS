//
//  ViewController.swift
//  loops
//
//  Created by Vadde Narendra on 02/08/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    
// Multiplication Tables creating using For in loop
        
      for i in 1...5000{
            if (i == 7||i == 6||i == 325||i == 425||i == 751||i == 891||i == 5000||i == 643||i == 3349||i == 4356||i == 2112||i == 2000)
            {
                continue
            }
            for j in 1...100{
                if (j == 9||j == 8||j == 76||j == 15||j == 17||j == 21||j == 53||j == 45||j == 67||j == 88||j == 93||j == 97||j == 12||j == 23||j == 98||j == 99)
                {
                continue
                }
                print("\(i)*\(j) = \(i*j)")
            }
        }
        
       
// Multiplication Tables creating using while loop
        
    var n = 0
        
    while (n <= 4999)
    {
        n += 1
        if (n == 7||n == 6||n == 325||n == 425||n == 751||n == 891||n == 5000||n == 643||n == 3349||n == 4356||n == 2112||n == 2000){
            continue
        }
        
        var j = 0
        while (j <= 99)
        {
           j += 1
            if (j == 9||j == 8||j == 76||j == 15||j == 17||j == 21||j == 53||j == 45||j == 67||j == 88||j == 93||j == 97||j == 12||j == 23||j == 98||j == 99){
                continue
            }
        
        print("\(n)*\(j) = \(n*j)")
        
    }
}
        
  // Multiplication Tables creating using repeat while loop
        
        var i:UInt32 = 0
 
        repeat {
            i += 1
            if (i == 7||i == 6||i == 325||i == 425||i == 751||i == 891||i == 5000||i == 643||i == 3349||i == 4356||i == 2112||i == 2000){
                continue
            }
            var j:UInt32 = 0
            repeat {
            
                j += 1
                if (j == 9||j == 8||j == 76||j == 15||j == 17||j == 21||j == 53||j == 45||j == 67||j == 88||j == 93||j == 97||j == 12||j == 23||j == 98||j == 99){
                    continue
                }
                
                print("\(i)*\(j) = \(i*j)")
                
            } while j < 100
            
        } while i < 5000
        
       
        
// Multiplication Tables creating using For in stride loop
        
        for i in stride(from: 1, to: 5001, by: 1)
        {
            if (i == 7||i == 6||i == 325||i == 425||i == 751||i == 891||i == 5000||i == 643||i == 3349||i == 4356||i == 2112||i == 2000){
                continue
            }
            for j in stride(from: 1, to: 101, by: 1)
            {
                if (j == 9||j == 8||j == 76||j == 15||j == 17||j == 21||j == 53||j == 45||j == 67||j == 88||j == 93||j == 97||j == 12||j == 23||j == 98||j == 99){
                    continue
                }
                
                print("\(i)*\(j) = \(i*j)")
                
            }
        }
        
        // Do any additional setup after loading the view, typically from a nib.
    }
}
