//
//  ViewController.swift
//  Passing Data Using Delegate
//
//  Created by Vadde Narendra on 11/16/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController, dataTransfer
{
    //MARK:- Variables declaration
    
    @IBOutlet weak var contectView: UIView!
    
    var xPos = 50
    var yPos = 100
    
    var names = [[String]]()
    
    var allLbls = [UILabel]()

    override func viewDidLoad()
    {
        super.viewDidLoad()
    
    }

    //MARK:- Calling function of creating labels & removing existed label components
    
    override func viewWillAppear(_ animated: Bool)
    {
        xPos = 50
        yPos = 100
        
        for x in allLbls
        {
            x.removeFromSuperview()
        }
        createComponents()
    }
    
    // MARK:- Creating "n" No. of labels using loops and giving positions to them
    
    func createComponents()
    {
        var nameLbl = UILabel()
        
        for x in names {
            
            var i = 0
            
            for m in x
            {
                nameLbl = UILabel(frame: CGRect(x: xPos, y: yPos, width: 150, height: 40))
                
                allLbls.append(nameLbl)
                
                if (i == 0)
                {
                    nameLbl.text = m
                    contectView.addSubview(nameLbl)
                    
                    i += 1
                    
                    xPos += 150
                    
                }
                else
                {
                    nameLbl.text = m
                    contectView.addSubview(nameLbl)
                    
                    xPos = 50
                    
                    yPos += 50
                }
                
            }
        }
    }
    
    // MARK:- Calling the protocal function and stroing data
    
    func passingData(values: [String]) {
        names.append(values)
    }
    
    // MARK:- Add button tapping function
    
    @IBAction func addDetailsBtnTapped(_ sender: UIButton)
    {
        let addDetailsVC = storyboard?.instantiateViewController(withIdentifier: "addDetails") as! AddingDetails
        
        addDetailsVC.delegate = self
        
        self.present(addDetailsVC, animated: true, completion: nil)
        
    }
    

}

