//
//  SignUpForm.swift
//  BRNPulseApp
//
//  Created by Vadde Narendra on 11/6/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//
import UIKit

import Foundation

class SignUpForm : UIViewController
{
    @IBOutlet weak var signUpNameTF: UITextField!
    @IBOutlet weak var signUpGenderTF: UITextField!
    @IBOutlet weak var signUpMaritalStatusTF: UITextField!
    @IBOutlet weak var signUpMobileNoTF: UITextField!
    @IBOutlet weak var signUpCityTF: UITextField!
    @IBOutlet weak var signUpStateTF: UITextField!
    @IBOutlet weak var signUpEmailTF: UITextField!
    @IBOutlet weak var signUpPasswordTF: UITextField!
    @IBOutlet weak var signUpRetypePasswordTF: UITextField!
    
    @IBOutlet weak var signUpImageView: UIImageView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
    }
    
    @IBAction func selectImageBtnTapped(_ sender: UIButton)
    {
        
    }
    
    @IBAction func signUpCheckBoxTapped(_ sender: UIButton)
    {
        if sender.isSelected
        {
            sender.isSelected = false
        }
        else
        {
            sender.isSelected = true
        }
    }
    
    @IBAction func signUpTermsOfServiceBtnTapped(_ sender: UIButton)
    {
        
    }
    
    @IBAction func signUpPrivacyPolicyBtnTapped(_ sender: UIButton)
    {
        
    }
    
    @IBAction func signUpBackBtnTapped(_ sender: UIButton)
    {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let signInView = storyBoard.instantiateViewController(withIdentifier: "signIn") as! ViewController
        self.present(signInView, animated: true, completion: nil)
    }
    
    @IBAction func signUpSubmitBtnTapped(_ sender: UIButton)
    {
        
    }
    
}
