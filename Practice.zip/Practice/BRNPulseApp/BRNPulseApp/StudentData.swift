//
//  StudentData.swift
//  BRNPulseApp
//
//  Created by Vadde Narendra on 11/6/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//
import UIKit

import Foundation

class StudentData : UIViewController
{
    override func viewDidLoad()
    {
        super.viewDidLoad()
    }
    
    @IBAction func logOutBtnTapped(_ sender: Any)
    {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let signInView = storyBoard.instantiateViewController(withIdentifier: "signIn") as! ViewController
        self.present(signInView, animated: true, completion: nil)
    }
    
}
