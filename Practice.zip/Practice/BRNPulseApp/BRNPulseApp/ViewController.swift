//
//  ViewController.swift
//  BRNPulseApp
//
//  Created by Vadde Narendra on 11/5/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{

    @IBOutlet weak var loginEmailTF: UIStackView!
    @IBOutlet weak var loginPasswordTF: UIStackView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
    }
    
    @IBAction func checkBoxTapped(_ sender: UIButton)
    {
        if sender.isSelected
        {
            sender.isSelected = false
        }
        else
        {
            sender.isSelected = true
        }
    }
    
    @IBAction func loginBtnTapped(_ sender: UIButton)
    {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let studentDetailsView = storyBoard.instantiateViewController(withIdentifier: "studentDetails") as! StudentData
        self.present(studentDetailsView, animated: true, completion: nil)
    }
    
    @IBAction func forgotPasswordBtnTapped(_ sender: Any)
    {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let forgotPasswordView = storyBoard.instantiateViewController(withIdentifier: "passwordReset") as! ForgotPassword
        self.present(forgotPasswordView, animated: true, completion: nil)
    }
    
    @IBAction func createAccountBtnTapped(_ sender: Any)
    {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let forgotPasswordView = storyBoard.instantiateViewController(withIdentifier: "createAnAccount") as! SignUpForm
        self.present(forgotPasswordView, animated: true, completion: nil)
    }
}

