//
//  ContactDetails.swift
//  Data Passing through Singleton
//
//  Created by Vadde Narendra on 11/20/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ContactDetails: UIViewController
{

    @IBOutlet weak var phoneNoTF: UITextField!
    @IBOutlet weak var mobileNoTF: UITextField!
    @IBOutlet weak var emailTF: UITextField!
    @IBOutlet weak var linkedInTF: UITextField!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
    }
    
    @IBAction func nextBtnTapped(_ sender: Any)
    {
        DataSending.shared.phoneNo = phoneNoTF.text!
        DataSending.shared.mobileNo = mobileNoTF.text!
        DataSending.shared.email = emailTF.text!
        DataSending.shared.linkedInId = linkedInTF.text!
        
        let educationView = storyboard?.instantiateViewController(withIdentifier: "educatonalDetails") as! Educational_details
        
        present(educationView, animated: true, completion: nil)
    }
}
