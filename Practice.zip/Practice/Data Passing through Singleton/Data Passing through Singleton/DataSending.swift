//
//  DataSending.swift
//  Data Passing through Singleton
//
//  Created by Vadde Narendra on 11/20/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class DataSending: NSObject {
    
    static var shared:DataSending = DataSending()
    
    var firstName = ""
    var lastName = ""
    var dob = ""
    var qualification = ""
    
    var phoneNo = ""
    var mobileNo = ""
    var email = ""
    var linkedInId = ""
    
    var teluguMarks = ""
    var englishMarks = ""
    var hindiMarks = ""
    var mathsMarks = ""
    var scienceMarks = ""
    var socialMarks = ""
    var totalMarks = ""
    var percentage = ""
    var grade = ""
    var status = ""
    
    override init()
    {
        super.init()
    }
    

}
