//
//  Educational details.swift
//  Data Passing through Singleton
//
//  Created by Vadde Narendra on 11/20/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class Educational_details: UIViewController
{

    @IBOutlet weak var teluguMarksTF: UITextField!
    @IBOutlet weak var englishMarksTF: UITextField!
    @IBOutlet weak var hindiMarksTF: UITextField!
    @IBOutlet weak var mathsMarksTF: UITextField!
    @IBOutlet weak var scienceMarksTF: UITextField!
    @IBOutlet weak var socialMarksTF: UITextField!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
    }
    
    @IBAction func submitBtnTapped(_ sender: UIButton)
    {
        DataSending.shared.teluguMarks = teluguMarksTF.text!
        DataSending.shared.englishMarks = englishMarksTF.text!
        DataSending.shared.hindiMarks = hindiMarksTF.text!
        DataSending.shared.mathsMarks = mathsMarksTF.text!
        DataSending.shared.scienceMarks = scienceMarksTF.text!
        DataSending.shared.socialMarks = socialMarksTF.text!
        
        let resultView = storyboard?.instantiateViewController(withIdentifier: "overViewDetails") as! OverView
        
        present(resultView, animated: true, completion: nil)
    }
    
    
}
