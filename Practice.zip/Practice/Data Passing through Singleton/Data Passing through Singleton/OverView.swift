//
//  OverView.swift
//  Data Passing through Singleton
//
//  Created by Vadde Narendra on 11/20/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class OverView: UIViewController
{
    
    @IBOutlet weak var firstNameLbl: UILabel!
    @IBOutlet weak var lastNameLbl: UILabel!
    @IBOutlet weak var DOBLbl: UILabel!
    @IBOutlet weak var qualificationLbl: UILabel!
    @IBOutlet weak var phoneNoLbl: UILabel!
    @IBOutlet weak var mobileNoLbl: UILabel!
    @IBOutlet weak var emailLbl: UILabel!
    @IBOutlet weak var linkedInLbl: UILabel!
    @IBOutlet weak var teluguMarksLbl: UILabel!
    @IBOutlet weak var englishMarksLbl: UILabel!
    @IBOutlet weak var hindiMarksLbl: UILabel!
    @IBOutlet weak var mathsMarksLbl: UILabel!
    @IBOutlet weak var scienceMarksLbl: UILabel!
    @IBOutlet weak var socialMarksLbl: UILabel!
    @IBOutlet weak var totalMarksLbl: UILabel!
    @IBOutlet weak var percentageLbl: UILabel!
    @IBOutlet weak var gradeLbl: UILabel!
    @IBOutlet weak var statusLbl: UILabel!
    
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        firstNameLbl.text = DataSending.shared.firstName
        lastNameLbl.text = DataSending.shared.lastName
        DOBLbl.text = DataSending.shared.dob
        qualificationLbl.text = DataSending.shared.qualification
        phoneNoLbl.text = DataSending.shared.phoneNo
        mobileNoLbl.text = DataSending.shared.mobileNo
        emailLbl.text = DataSending.shared.email
        linkedInLbl.text = DataSending.shared.linkedInId
        teluguMarksLbl.text = DataSending.shared.teluguMarks
        englishMarksLbl.text = DataSending.shared.englishMarks
        hindiMarksLbl.text = DataSending.shared.hindiMarks
        mathsMarksLbl.text = DataSending.shared.mathsMarks
        scienceMarksLbl.text = DataSending.shared.scienceMarks
        socialMarksLbl.text = DataSending.shared.socialMarks
      
        Calculations(teluguMarks: Int(DataSending.shared.teluguMarks)!, englishMarks: Int(DataSending.shared.englishMarks)!, hindiMarks: Int(DataSending.shared.hindiMarks)!, mathsMarks: Int(DataSending.shared.mathsMarks)!, scienceMarks: Int(DataSending.shared.scienceMarks)!, socialMarks: Int(DataSending.shared.socialMarks)!)
        
    }
    
    
    func Calculations(teluguMarks:Int, englishMarks:Int, hindiMarks:Int, mathsMarks:Int, scienceMarks:Int, socialMarks:Int)
    {
        // Calculating Total Marks
        
        let gainedMarks:Int = teluguMarks + englishMarks + hindiMarks + mathsMarks + scienceMarks + socialMarks
        
        totalMarksLbl.text = "\(Int(gainedMarks))"
        
        // Calculating Percentage
        
        let totalMarks:Float = 600
        
        let marks:Float = Float(gainedMarks)
        
        let percentage:Float = (marks/totalMarks)*100
        
        percentageLbl.text = "\(Int(percentage))"
        
        // finding out subject wise pass or fail
        
        let subPassMarks:Int = 35
        
        var teluguSub:Bool = false
        var englishSub:Bool = false
        var hindiSub:Bool = false
        var mathsSub:Bool = false
        var scienceSub:Bool = false
        var socialSub:Bool = false
        
        if teluguMarks >= subPassMarks
        {
            teluguSub = true
        } else {
            teluguSub = false
        }
        
        if englishMarks >= subPassMarks
        {
            englishSub = true
        } else {
            englishSub = false
        }
        
        if hindiMarks >= subPassMarks
        {
            hindiSub = true
        } else {
            hindiSub = false
        }
        
        if mathsMarks >= subPassMarks
        {
            mathsSub = true
        } else {
            mathsSub = false
        }
        
        if socialMarks >= subPassMarks
        {
            socialSub = true
        } else {
            socialSub = false
        }
        
        if scienceMarks >= subPassMarks
        {
            scienceSub = true
        } else {
            scienceSub = false
        }
        
        // Total 2nd Year 2nd Sem pass or fail with grade
        
        if (teluguSub == true && englishSub == true && hindiSub == true && mathsSub == true && scienceSub == true && socialSub == true)
        {
            switch percentage
            {
            case 90...100:
                gradeLbl.text = "A"
            case 75..<90:
                gradeLbl.text = "B"
            case 50..<75:
                gradeLbl.text = "C"
            case 35..<50:
                gradeLbl.text = "D"
            default:
                gradeLbl.text = "E"
            }
            statusLbl.text = "PASSED"
        }
        else
        {
            statusLbl.text = "FAILED"
        }
        
    }
}
