//
//  ViewController.swift
//  Data Passing through Singleton
//
//  Created by Vadde Narendra on 11/20/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{

    @IBOutlet weak var firstNameTF: UITextField!
    @IBOutlet weak var lastNameTF: UITextField!
    @IBOutlet weak var ageTF: UITextField!
    @IBOutlet weak var qualificationTF: UITextField!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
    }
    
    @IBAction func nextBtnTapped(_ sender: UIButton)
    {
        DataSending.shared.firstName = firstNameTF.text!
        DataSending.shared.lastName = lastNameTF.text!
        DataSending.shared.dob = ageTF.text!
        DataSending.shared.qualification = qualificationTF.text!
        
        let contactView = storyboard?.instantiateViewController(withIdentifier: "contactDetails") as! ContactDetails
        
        present(contactView, animated: true, completion: nil)
        
    }
    

}

