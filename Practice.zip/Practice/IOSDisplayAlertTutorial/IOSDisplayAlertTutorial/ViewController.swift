//
//  ViewController.swift
//  IOSDisplayAlertTutorial
//
//  Created by Vadde Narendra on 9/20/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func showAlert(_ sender: Any) {
        
        let alertMsg = UIAlertController(title: "AD-ICICI", message: "Acct XXX254 debited with INR 40.00 on 20-Sep-19and paytmqr2810050501011cuknmeej98m@paytm credit.info:UPI-9263427891196.Call:18002662", preferredStyle: UIAlertController.Style.alert)
        
        alertMsg.addAction(UIAlertAction(title: "Dismiss", style: .default))
        
        self.present(alertMsg, animated: true, completion: nil)
        
    }
    
}

