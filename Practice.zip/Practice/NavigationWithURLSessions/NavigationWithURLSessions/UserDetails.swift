//
//  UserDetails.swift
//  NavigationWithURLSessions
//
//  Created by Vadde Narendra on 9/14/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class UserDetails: NSObject {

    var URLReqObj:URLRequest!
    var dataTaskObj:URLSessionDataTask!
    
    var holiday = "..... Date ..... \n"
    var holidaysReason = "..... Reason ..... \n"
    var leave = "..... Date ..... \n"
    var leaveReason = "..... Reason ..... \n"
    var lateDate = "..... Date ..... \n"
    var checkInTime = "..... Check In Timing ..... \n"
    var attendedDay = "..... Date ..... \n"
    var spendingTime = "..... Spending Time ..... \n"
    
    
    func getValidateLogin(email:String,password:String)
    {
        URLReqObj = URLRequest(url: URL(string: "https://www.brninfotech.com/pulse/modules/admin/ValidateLogin.php?")!)
        
        URLReqObj.httpMethod = "POST"
        
        let dataToSend = "registeredEmail=\(email)&registeredPassword=\(password)&funcName=verifyLogin"
        URLReqObj.httpBody = dataToSend.data(using: String.Encoding.utf8)
        
        dataTaskObj = URLSession.shared.dataTask(with: URLReqObj, completionHandler: { (Data, URLResponse, Error) in
            
            do {
                let convertedData = try JSONSerialization.jsonObject(with: Data!, options: JSONSerialization.ReadingOptions.allowFragments)  as! [String:String]
                
//                DispatchQueue.main.async {
//                    self.studentNameLbl.text = "\(convertedData["firstName"])"
//                    self.batchIDLbl.text = "\(convertedData["batchID"])"
//                    self.studentIDLbl.text = "\(convertedData["studentID"])"
//
//                }
                
            } catch {
                
                print("the error is \(String(describing: Error))")
                
            }
        })
        dataTaskObj.resume()
        
    }
    

    
    
    
    
    
    func getUserHolidays(){
        
//        holidayDates:UITextView, holidayReason:UITextView
        
        URLReqObj = URLRequest(url: URL(string: "https://www.brninfotech.com/pulse/modules/admin/DashboardSnippets.php")!)
        URLReqObj.httpMethod = "POST"
        let dataToSend = "funcName=getUserAttendance&studentIDByAdmin=NoValue"
        URLReqObj.httpBody = dataToSend.data(using: String.Encoding.utf8)
        dataTaskObj = URLSession.shared.dataTask(with: URLReqObj) { (Data, URLResponse, Error) in
            do{
                let convertedData = try JSONSerialization.jsonObject(with: Data!, options: JSONSerialization.ReadingOptions.allowFragments) as! [[String:Any]]
                
                for i in 1..<convertedData.count{
                    
                    if (convertedData[i]["dayType"] as? String == "Holiday"){
                        
                        self.holiday.append("\(convertedData[i]["attendanceDate"] as! String) \n")
                        self.holidaysReason.append("\(convertedData[i]["reasonForNonAttendance"] as! String) \n")
                        print("\(convertedData[i]["attendanceDate"] as! String) = \(convertedData[i]["reasonForNonAttendance"] as! String)")
                        
                    }
                    
                }
                
//                DispatchQueue.main.async {
//                    holidayDates.text = self.holiday
//                    holidayReason.text = self.holidaysReason
//                    
//                }
                
            } catch {
                print("the error is \(String(describing: Error))")
                
            }
            
        }
        dataTaskObj.resume()
        
    }
    
    
    
    func getUserLeaves(leaveDay:UITextView, leavesReason:UITextView){
        URLReqObj = URLRequest(url: URL(string: "https://www.brninfotech.com/pulse/modules/admin/DashboardSnippets.php")!)
        URLReqObj.httpMethod = "POST"
        let dataToSend = "funcName=getUserAttendance&studentIDByAdmin=NoValue"
        URLReqObj.httpBody = dataToSend.data(using: String.Encoding.utf8)
        dataTaskObj = URLSession.shared.dataTask(with: URLReqObj) { (Data, URLResponse, Error) in
            do{
                let convertedData = try JSONSerialization.jsonObject(with: Data!, options: JSONSerialization.ReadingOptions.allowFragments) as! [[String:Any]]
                
                for i in 1..<convertedData.count{
                    
                    if (((convertedData[i]["reasonForNonAttendance"] as? String)?.prefix(10) == "Sick Leave") || ((convertedData[i]["reasonForNonAttendance"] as? String)?.prefix(12) == "Casual Leave")){
                        
                        self.leave.append("\(convertedData[i]["attendanceDate"] as! String) \n")
                        self.leaveReason.append("\(convertedData[i]["reasonForNonAttendance"] as! String) \n")
                        
                    }
                    
                }
                
                DispatchQueue.main.async {
                    leaveDay.text = self.leave
                    leavesReason.text = self.leaveReason
                    
                }
                
            } catch {
                print("the error is \(String(describing: Error))")
                
            }
            
        }
        dataTaskObj.resume()
        
    }
    
    
    
    func getUserLateTimings(lateCommingDay:UITextView, lateCommingTime:UITextView){
        URLReqObj = URLRequest(url: URL(string: "https://www.brninfotech.com/pulse/modules/admin/DashboardSnippets.php")!)
        URLReqObj.httpMethod = "POST"
        let dataToSend = "funcName=getUserAttendance&studentIDByAdmin=NoValue"
        URLReqObj.httpBody = dataToSend.data(using: String.Encoding.utf8)
        dataTaskObj = URLSession.shared.dataTask(with: URLReqObj) { (Data, URLResponse, Error) in
            do{
                let convertedData = try JSONSerialization.jsonObject(with: Data!, options: JSONSerialization.ReadingOptions.allowFragments) as! [[String:Any]]
                
                for i in 1..<convertedData.count{
                    
                    if (convertedData[i]["isLateCheckIn"] as? Bool ?? false){
                        
                        self.lateDate.append("\(convertedData[i]["attendanceDate"] as! String) \n")
                        self.checkInTime.append("\(convertedData[i]["checkIn"] as! String) \n")
                        
                    }
                    
                }
                
                DispatchQueue.main.async {
                    
                    lateCommingDay.text = self.lateDate
                    lateCommingTime.text = self.checkInTime
                    
                }
                
            } catch {
                print("the error is \(String(describing: Error))")
                
            }
            
        }
        dataTaskObj.resume()
        
    }
    
    
    
    func getUserWorkingHours(workingDay:UITextView, workingTime:UITextView){
        URLReqObj = URLRequest(url: URL(string: "https://www.brninfotech.com/pulse/modules/admin/DashboardSnippets.php")!)
        URLReqObj.httpMethod = "POST"
        let dataToSend = "funcName=getUserAttendance&studentIDByAdmin=NoValue"
        URLReqObj.httpBody = dataToSend.data(using: String.Encoding.utf8)
        dataTaskObj = URLSession.shared.dataTask(with: URLReqObj) { (Data, URLResponse, Error) in
            do{
                let convertedData = try JSONSerialization.jsonObject(with: Data!, options: JSONSerialization.ReadingOptions.allowFragments) as! [[String:Any]]
                
                for i in 1..<convertedData.count{
                    
                    if (convertedData[i]["isAttended"] as? Bool == true){
                        
                        self.attendedDay.append("\(convertedData[i]["attendanceDate"] as! String) \n")
                        self.spendingTime.append("\(convertedData[i]["timeSpent"] as! String) \n")
                        
                    }
                    
                }
                
                DispatchQueue.main.async {
                    workingDay.text = self.attendedDay
                    workingTime.text = self.spendingTime
                    
                }
                
            } catch {
                print("the error is \(String(describing: Error))")
                
            }
            
        }
        dataTaskObj.resume()
        
    }
    
    
}


