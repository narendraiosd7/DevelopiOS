//
//  ViewController.swift
//  No of Switches
//
//  Created by Vadde Narendra on 9/18/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var scrol = UIScrollView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        scrolFrame()
    }
    
    func scrolFrame(){
        scrol.frame = CGRect(x: 10, y: 400, width: self.view.frame.size.width, height: 420)
        var yPos = 0.0
        for i in 0...10 {
            let mySwitch = UISwitch()
            mySwitch.frame = CGRect(x: 10, y: yPos + 10, width: 50, height: 25)
            mySwitch.isOn = false
            
            mySwitch.tag = i
            
            yPos = Double(mySwitch.frame.origin.y + mySwitch.frame.size.height)
            mySwitch.addTarget(self, action: #selector(onSwitchChange(_:)), for: UIControl.Event.valueChanged)
            scrol.addSubview(mySwitch)
        }
        scrol.backgroundColor = .yellow
        scrol.isScrollEnabled = true
        self.view.addSubview(scrol)
    }
    
    @objc func onSwitchChange(_ sender: UISwitch) {
        print(" switch tapped \(sender.tag)")
    }
    
}
