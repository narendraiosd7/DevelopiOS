//
//  MoviesDetails.swift
//  PageController
//
//  Created by Vadde Narendra on 12/10/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class MoviesDetails: UIViewController
{

    override func viewDidLoad()
    {
        super.viewDidLoad()
    }
    
}
