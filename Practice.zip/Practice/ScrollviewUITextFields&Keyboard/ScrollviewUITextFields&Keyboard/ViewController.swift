//
//  ViewController.swift
//  ScrollviewUITextFields&Keyboard
//
//  Created by Vadde Narendra on 10/5/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var myScrollView: UIScrollView!
    
    @IBOutlet weak var constraintContentHeight: NSLayoutConstraint!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
    }
    
    override func viewWillAppear(_ animated:Bool) {
        
        super.viewWillAppear(animated)
        
        //1  Add this observers to observe keyboard shown and hidden events
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillBeHidden(aNotification:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(aNotification:)), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        
        super.viewWillDisappear(animated)
        
        //2  Remove the observers added for keyboard from your ViewController
        
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardWillHide, object: nil)
        
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        
    }
    
    var activeField: UITextField?
    
    // MARK: – UITextField Delegates
    
    //3  ViewController activeField is an object of UITextField which will be used to manage and resign current active textField
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        textField.resignFirstResponder()
        
        return true
        
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        activeField = textField
        
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
        activeField = nil
        
    }
    
    // Called when the UIKeyboardWillHide is sent
    
    //4  This method is called from selector. So it requires @objc keyword and this method will adjust your scrollView (here myScrollView  ?)  and textFields to show as original.
    
    @objc func keyboardWillBeHidden(aNotification: NSNotification) {
        
        let contentInsets: UIEdgeInsets = .zero
        
        self.myScrollView.contentInset = contentInsets
        
        self.myScrollView.scrollIndicatorInsets = contentInsets
        
    }
    
    // Called when the UIKeyboardWillShow is sent
    
    //5
    This method will adjust your scrollView and will show textFields above the keyboard.
    @objc func keyboardWillShow(aNotification: NSNotification) {
        
        var info = aNotification.userInfo!
        
        let kbSize: CGSize = ((info[“UIKeyboardFrameEndUserInfoKey”] as? CGRect)?.size)!
        
        print(“kbSize = \(kbSize)”)
        
        let contentInsets: UIEdgeInsets = UIEdgeInsetsMake(0.0, 0.0, kbSize.height, 0.0)
        
        myScrollView.contentInset = contentInsets
        
        myScrollView.scrollIndicatorInsets = contentInsets
        
        var aRect: CGRect = self.view.frame
        
        aRect.size.height -= kbSize.height
        
        if !aRect.contains(activeField!.frame.origin) {
            
            self.myScrollView.scrollRectToVisible(activeField!.frame, animated: true)
            
        }
        
    }
    
} // Class End

