//
//  ViewController.swift
//  UIImageView
//
//  Created by Vadde Narendra on 11/28/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

class ViewController: UIViewController
{

    // MARK:- Variables
    
    @IBOutlet weak var stackView: UIStackView!
    
    var userData : [[String:Any]]!
    var buttonsArray:[UIButton] = []
    var labelsArray:[UILabel] = []
    var audioURLs:[[String]] = [[]]
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
    }

    // MARK:- creating Buttons, Labels, button tags and Passing data to Singleton class
    
    func creatingComponents()
    {
        var j = 0
        let moviesData = GettingMoviesData.shared.gettingMoviesDetails()
        
        for (x,y) in zip(buttonsArray,labelsArray)
        {
            x.removeFromSuperview()
            y.removeFromSuperview()
        }
        
        buttonsArray = [UIButton]()
        labelsArray = [UILabel]()
        
        GettingMoviesData.shared.movieBtnTags = 0
        GettingMoviesData.shared.moviesStory = [String]()
        GettingMoviesData.shared.MoviesTitle = [String]()
        GettingMoviesData.shared.actorsNames = [[String]]()
        GettingMoviesData.shared.directorName = [String]()
        GettingMoviesData.shared.moviePosterImage = [UIImage]()
        
        for i in moviesData
        {
            let posterImage = (i.posters!)[0]
            let urlString = posterImage.replacingOccurrences(of: " ", with: "%20")
            let posterURL = URL(string: "https://www.brninfotech.com/tws/\(urlString)")
            let posterDataTask = URLSession.shared.dataTask(with: posterURL!)
            {
                (posterData, conDetails, err) in
                
                DispatchQueue.main.async
                {
                    let moviePosterBtn = UIButton()
                    self.buttonsArray.append(moviePosterBtn)
                    self.stackView.addArrangedSubview(moviePosterBtn)
                    
                    moviePosterBtn.setImage(UIImage(data: posterData!), for: UIControl.State.normal)
                    moviePosterBtn.backgroundColor = UIColor.black
                    moviePosterBtn.translatesAutoresizingMaskIntoConstraints = false
                    moviePosterBtn.heightAnchor.constraint(equalToConstant: 300).isActive = true
                    //                button.widthAnchor.constraint(equalToConstant: 300).isActive = true
                    moviePosterBtn.imageView?.contentMode = .scaleAspectFit
                    
                    moviePosterBtn.addTarget(self, action: #selector(self.movieDetails(_:)), for: UIControl.Event.touchUpInside)
                    
                    moviePosterBtn.tag = j
                    
                    j += 1
                    
                    let movieTitle = i.title
                    let movieTitleLbl = UILabel()
                    movieTitleLbl.text = movieTitle
                    movieTitleLbl.font = UIFont.boldSystemFont(ofSize: 20)
                    movieTitleLbl.textColor = UIColor.black
                    movieTitleLbl.textAlignment = .center
                    self.labelsArray.append(movieTitleLbl)
                    self.stackView.addArrangedSubview(movieTitleLbl)
                    
                    GettingMoviesData.shared.moviePosterImage.append(UIImage(data: posterData!)!)
                    GettingMoviesData.shared.directorName.append(i.director!)
                    GettingMoviesData.shared.MoviesTitle.append(i.title!)
                    GettingMoviesData.shared.moviesStory.append(i.story ?? "Story not Available")
                
                    let actorsName = i.actors
                    GettingMoviesData.shared.actorsNames.append(actorsName!)
                    
                    let video = (i.trailers!)[0]
                    let videoURL = video.replacingOccurrences(of: " ", with: "%20")
                    let videoAVPlayer = AVPlayerViewController()
                    videoAVPlayer.player = AVPlayer(url: URL(string: "https://www.brninfotech.com/tws/\(videoURL)")!)
                    GettingMoviesData.shared.movieTrailer.append(videoAVPlayer)
                    
                    let arraySong:[String] = i.songs!
                    
                    let convString = arraySong.joined(separator: "")
                    
                    let string:String = "https://www.brninfotech.com/tws/ "
                    
                    let addString = string.replacingOccurrences(of: " ", with: convString,options:  .literal,range: nil)
                    
                    let finalStringSong = addString.replacingOccurrences(of: " ", with: "%20",options:  .literal,range: nil)
                    
                    var allSongsUrlInString = [String]()
                    
                    let stringSong:String = "https://www.brninfotech.com/tws/"
                    
                    for n in arraySong
                    {
                        let urlData = n.replacingOccurrences(of: " ", with: "%20")
                        
                            allSongsUrlInString.append(stringSong + urlData)
                            
                        }
                    GettingMoviesData.shared.audioSongArray.append(allSongsUrlInString)
                    
                    
                }
            }
            posterDataTask.resume()
        }
    }
  
    // MARK:- menu button
    
    @IBAction func menuBtnTapped(_ sender: UIButton)
    {
        creatingComponents()
    }
    
    // MARK:- event handler for poster buttons
    
    @objc func movieDetails(_ sender: UIButton)
    {
        
        GettingMoviesData.shared.movieBtnTags = sender.tag
        
        let movieDetailsVC = storyboard?.instantiateViewController(withIdentifier: "moviesDetails") as! MoviesDetails
        
        present(movieDetailsVC, animated: true, completion: nil)
    }
    
}

