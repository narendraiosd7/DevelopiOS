//
//  MoviesDetails.swift
//  UIImageView
//
//  Created by Vadde Narendra on 11/30/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

class MoviesDetails: UIViewController
{
    // MARK:- Variables

    @IBOutlet weak var posterImageView: UIImageView!
    @IBOutlet weak var movieTitleLbl: UILabel!
    @IBOutlet weak var directorNameLbl: UILabel!
    @IBOutlet weak var storyLbl: UILabel!
    @IBOutlet weak var actorsStackView: UIStackView!
    @IBOutlet weak var trailerView: UIView!
    @IBOutlet weak var audioStackView: UIStackView!
    
    var avPlayer:AVPlayerViewController!
    var audioBtnArray = [UIButton]()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        // MARK:- singleton data adssigning to buttons and labels
        
        posterImageView.image = GettingMoviesData.shared.moviePosterImage[GettingMoviesData.shared.movieBtnTags]
        movieTitleLbl.text = GettingMoviesData.shared.MoviesTitle[GettingMoviesData.shared.movieBtnTags]
        directorNameLbl.text = GettingMoviesData.shared.directorName[GettingMoviesData.shared.movieBtnTags]
        storyLbl.text = GettingMoviesData.shared.moviesStory[GettingMoviesData.shared.movieBtnTags]
        
        // MARK:- calling functions
        
        actorsDeatils()
        
        movieVideosDeatils()

        movieAudioDetails()
    }
    
    // MARK:- creating func about actors details
    
    func actorsDeatils()
    {
        for i in GettingMoviesData.shared.actorsNames[GettingMoviesData.shared.movieBtnTags]
        {
            let actorsNameLbl =  UILabel(frame: CGRect(x: 0, y: 0, width: 100, height: 30))
            actorsNameLbl.text = "\(i)"
            actorsStackView.addArrangedSubview(actorsNameLbl)
        }
    }
    
    // MARK:- creating func about trailers details
    
    func movieVideosDeatils()
    {
        avPlayer = AVPlayerViewController()
        avPlayer = GettingMoviesData.shared.movieTrailer[GettingMoviesData.shared.movieBtnTags]
        avPlayer.view.frame = CGRect(x: 0 , y: 0, width: trailerView.frame.width, height: trailerView.frame.height)
        trailerView.addSubview(avPlayer.view)
    }
    
    // MARK:- creating func about audio details
    
    func movieAudioDetails()
    {
        var n = 0
        
        for x in audioBtnArray
        {
            x.removeFromSuperview()
        }
        
        GettingMoviesData.shared.audioSongBtnTag = 0
        
        let audiofile = GettingMoviesData.shared.audioSongsPaths
        
        if (audiofile.count > 0)
        {
            for i in audiofile
            {
                let playAndPauseBtn = UIButton()
                playAndPauseBtn.backgroundColor = UIColor.black
                playAndPauseBtn.setTitle("Play", for: UIControl.State.normal)
                playAndPauseBtn.layer.cornerRadius = 10
                playAndPauseBtn.addTarget(self, action: #selector(audioPathsAssign(_sender:)), for: UIControl.Event.touchUpInside)
                playAndPauseBtn.tag = n
                audioBtnArray.append(playAndPauseBtn)
                audioStackView.addArrangedSubview(playAndPauseBtn)
                
            }
        }
        
    }
    
    // MARK:- back button func
    
    @IBAction func backBtnTapped(_ sender: UIButton)
    {
        dismiss(animated: true, completion: nil)
    }
    
    @objc func audioPathsAssign(_sender:UIButton)
    {
        GettingMoviesData.shared.audioSongBtnTag = _sender.tag
        
         let audiofile = GettingMoviesData.shared.audioSongsPaths
        
        for i in audiofile
        {
            let audioPlayer = AVPlayerViewController()
            audioPlayer.player = i
            present(audioPlayer, animated: true, completion: nil)
        }
    }
    
}
