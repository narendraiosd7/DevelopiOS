//
//  ViewController.swift
//  UISegmentation&UIView
//
//  Created by Vadde Narendra on 9/24/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var countSlider: UISlider!
    @IBOutlet weak var countStepper: UIStepper!
    @IBOutlet weak var countViewLbl: UILabel!
    
    var selectionOfComponentSegment = UISegmentedControl()
    var selectionOfModeSegment = UISegmentedControl()
    var selectionOfViewSegment = UISegmentedControl()
    
    var creatingLblSwitch: UISwitch!
    var creatingBtnSwitch: UISwitch!
    var creatingSwitchesSwitch: UISwitch!
    var HVSwitch: UISwitch!
    var VVSwitch: UISwitch!
    
    
    var xPos = 10.0
    var yPos = 20.0
    var loopCount = 1
    
    var labelArray:[UILabel] = []
    var buttonArray:[UIButton] = []
    var switchArray:[UISwitch] = []
    
    var scrollView = UIScrollView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        selectionOfModeSegment = UISegmentedControl(items: ["Off-Line" , "Online"])
        selectionOfModeSegment.frame = CGRect(x: 10, y: 45, width: 400, height: 30)
        selectionOfModeSegment.addTarget(self, action: #selector(ViewController.onSelectionOfMode(modeView:)), for: .valueChanged)
        selectionOfModeSegment.layer.cornerRadius = 5.0
        selectionOfModeSegment.backgroundColor = .white
        selectionOfModeSegment.tintColor = .blue
        
        view.addSubview(selectionOfModeSegment)
        
        scrollView.frame = CGRect(x: 20.0, y: 410.0, width: 374, height: 400)
        scrollView.backgroundColor = UIColor.yellow
        
        DispatchQueue.main.async {
            var contentRect = CGRect.zero
            
            for view in self.scrollView.subviews {
                contentRect = contentRect.union(view.frame)
            }
            
            self.scrollView.contentSize = contentRect.size
        }
        
        countStepper.addTarget(self, action: #selector(stepperValues), for: UIControl.Event.valueChanged)

        countSlider.isContinuous = false

        countSlider.addTarget(self, action: #selector(sliderValues), for: UIControl.Event.valueChanged)
        
        countSlider.value = Float(countStepper.value)
        
        selectionOfComponentSegment.addTarget(self, action: #selector(ViewController.onSelectionOfComponents(ComponentView:)), for: .valueChanged)
        
        selectionOfComponentSegment.addTarget(self, action: #selector(onSelectionOfComponents(ComponentView:)), for: UIControl.Event.valueChanged)
        
        selectionOfViewSegment.addTarget(self, action: #selector(ViewController.onSelectionOfView(viewSelection:)), for: .valueChanged)
        
        view.addSubview(scrollView)
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
     // creating function for on changing of slider
    
    @objc func sliderValues(){
        
        countStepper.value = Double(countSlider.value)
        countViewLbl.text = "\(Int(countSlider.value))"
        
    }
    
    // creating function for on changing of stepper
    
    @objc func stepperValues(){
        
        for val in labelArray{
            val.removeFromSuperview()
        }
        for val in buttonArray{
            val.removeFromSuperview()
        }
        for val in switchArray{
            val.removeFromSuperview()
        }
        
        countSlider.setValue(Float(countStepper.value), animated: true)
        countViewLbl.text = "\(Int(countSlider.value))"
        
    }

    // creating function for on Off-Line/Online View
    
    @objc func onSelectionOfMode(modeView:UISegmentedControl){
        
        switch modeView.selectedSegmentIndex{
        case 0:
            
            selectionOfComponentSegment = UISegmentedControl(items: ["Label" , "Button","Switch"])
            selectionOfComponentSegment.frame = CGRect(x: 10, y: 90, width: 180, height: 30)
            selectionOfComponentSegment.selectedSegmentIndex = 0
            selectionOfComponentSegment.layer.cornerRadius = 5.0
            selectionOfComponentSegment.backgroundColor = .blue
            selectionOfComponentSegment.tintColor = .white
            
            view.addSubview(selectionOfComponentSegment)
            
            selectionOfViewSegment = UISegmentedControl(items: ["Horizontal View" , "Vertical View"])
            selectionOfViewSegment.frame = CGRect(x: 210, y: 90, width: 180, height: 30)
            selectionOfViewSegment.selectedSegmentIndex = 0
            selectionOfViewSegment.layer.cornerRadius = 5.0
            selectionOfViewSegment.backgroundColor = .white
            selectionOfViewSegment.tintColor = .blue
            
            view.addSubview(selectionOfViewSegment)
            
        case 1:
            
            selectionOfComponentSegment.removeFromSuperview()
            selectionOfViewSegment.removeFromSuperview()

        default:
            break
        }
        
    }
    
    // creating function for view of components
    
    @objc func onSelectionOfComponents(ComponentView:UISegmentedControl){
        
        
        switch ComponentView.selectedSegmentIndex{
            
        case 0:
            
            let myLabel = UILabel(frame: CGRect(x: xPos, y: yPos, width: 40, height: 20))
            myLabel.text = "\(loopCount)"
            myLabel.textColor = UIColor.black
            myLabel.textAlignment = .center
            myLabel.backgroundColor = UIColor.green
            
            scrollView.addSubview(myLabel)
            
            labelArray.append(myLabel)
            
             print("abcd")

            
        case 1:
            
            
            let myBtn = UIButton(frame: CGRect(x: xPos, y: yPos, width: 40, height: 20))
            myBtn.backgroundColor = UIColor.red
            myBtn.setTitle("B.\(loopCount)", for: UIControl.State.normal)
            
            scrollView.addSubview(myBtn)
            
            buttonArray.append(myBtn)
            
            print("efgh")
            
            
        case 2:
            
             print("ijkl")
            
            let mySwitch = UISwitch(frame: CGRect(x: xPos, y: yPos, width: 40, height: 20))
            
            scrollView.addSubview(mySwitch)
            
            switchArray.append(mySwitch)
            
        default:
            break
        }
        
    }
    
    // creating function for horizontal/vertical view
    
    @objc func onSelectionOfView(viewSelection:UISegmentedControl){
       
        switch viewSelection.selectedSegmentIndex{
            
        case 0:
            
            for _ in 1...(Int(countSlider.value)){
                
                for _ in 1...10 {
                    
                    if (loopCount <= (Int(countSlider.value))){
                        
                        onSelectionOfComponents(ComponentView:selectionOfComponentSegment)
                        
                        loopCount += 1
                        
                        xPos += 50
                        
                    }
                    
                }
                
                xPos = 10
                yPos += 30
                
            }
            loopCount = 1
            xPos = 10.0
            yPos = 20.0
            
            
        case 1:
            
            for _ in 1...(Int(countSlider.value)){
                
                for _ in 1...10 {
                    
                    if (loopCount <= (Int(countSlider.value))){
                        
                       onSelectionOfComponents(ComponentView:selectionOfComponentSegment)
                        
                        loopCount += 1
                        
                        yPos += 40
                        
                    }
                    
                }
                yPos = 20
                xPos += 50
                
            }
            
            loopCount = 1
            xPos = 10.0
            yPos = 20.0
            
        default:
            break
        }
        
    }
    
    
    
    @IBAction func createComponentsBtnTapped(_ sender: Any) {
        
        for val in labelArray{
            val.removeFromSuperview()
        }
        for val in buttonArray{
            val.removeFromSuperview()
        }
        for val in switchArray{
            val.removeFromSuperview()
        }
        
        onSelectionOfView(viewSelection:selectionOfViewSegment)
    }

}

