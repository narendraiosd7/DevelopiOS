//
//  ViewController.swift
//  UIStackView
//
//  Created by Vadde Narendra on 12/13/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        uistackview()
        // Do any additional setup after loading the view, typically from a nib.
    }


    func uistackview()
    {
        let button = UIButton()
        button.backgroundColor = UIColor.blue
        button.setTitle("Submit", for: UIControl.State.normal)
        
        
        let label = UILabel()
        label.text = "Color Chooser"
        label.textColor = UIColor.white
        label.backgroundColor = UIColor.black
        label.textAlignment = .center
        
        let stackView = UIStackView(arrangedSubviews: [label,button])
        stackView.axis = .vertical
        stackView.distribution = .fillEqually
        stackView.alignment = .fill
        stackView.spacing = 10
//        stackView.translatesAutoresizingMaskIntoConstraints = false
        
//        view.addSubview(stackView)
//
//        let viewsDictionary = ["stackView":stackView]
//        let stackView_H = NSLayoutConstraint.constraints(withVisualFormat: "H:|-20-[stackView]-20-|", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: viewsDictionary)
//        let stackView_V = NSLayoutConstraint.constraints(withVisualFormat: "V:|-30-[stackView]-30-|", options: NSLayoutConstraint.FormatOptions(rawValue:0), metrics: nil, views: viewsDictionary)
//        view.addConstraints(stackView_H)
//        view.addConstraints(stackView_V)
        
        let myButton = UIButton()
        myButton.backgroundColor = UIColor.blue
        myButton.setTitle("Submit", for: UIControl.State.normal)
        
        let myLabel = UILabel()
        myLabel.text = "Color Chooser"
        myLabel.textColor = UIColor.white
        myLabel.backgroundColor = UIColor.black
        myLabel.textAlignment = .center
        
        let myStackView = UIStackView(arrangedSubviews: [myLabel,myButton])
        myStackView.axis = .vertical
        myStackView.distribution = .fillEqually
        myStackView.alignment = .fill
        myStackView.spacing = 10
//        myStackView.translatesAutoresizingMaskIntoConstraints = false
//
        let mainStackView = UIStackView(arrangedSubviews: [stackView,myStackView])
        mainStackView.axis = .horizontal
        mainStackView.distribution = .fillEqually
        mainStackView.alignment = .fill
        mainStackView.spacing = 10
        mainStackView.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(mainStackView)

        let myViewsDictionary = ["stackView":mainStackView]
        let mainStackView_H = NSLayoutConstraint.constraints(withVisualFormat: "H:|-20-[stackView]-20-|", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: myViewsDictionary)
        let mainStackView_V = NSLayoutConstraint.constraints(withVisualFormat: "V:|-30-[stackView]-30-|", options: NSLayoutConstraint.FormatOptions(rawValue:0), metrics: nil, views: myViewsDictionary)
        view.addConstraints(mainStackView_H)
        view.addConstraints(mainStackView_V)
        
    }
    
}

