//
//  ViewController.swift
//  UITextFiledsWithRegEx_Practice
//
//  Created by Vadde Narendra on 10/21/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var myTF = UITextField()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = UIColor.yellow
        
        creatingLblComponents(lblName: "First Name:", yPos: 80)
        creatingTFComponents(placeHolder: "Enter First Name", yPos: 80, keyBoard: UIKeyboardType.namePhonePad)
        leftImage(imgName: "firstName")
        
        creatingLblComponents(lblName: "Last Name:", yPos: 160)
        creatingTFComponents(placeHolder: "Enter Last Name", yPos: 160, keyBoard: UIKeyboardType.namePhonePad)
        rightImage(imgName: "lastName")
        
        
        creatingLblComponents(lblName: "Age:", yPos: 240)
        creatingTFComponents(placeHolder: "Enter Age", yPos: 240, keyBoard: UIKeyboardType.decimalPad)
        leftImage(imgName: "age")
        
        creatingLblComponents(lblName: "E-Mail:", yPos: 320)
        creatingTFComponents(placeHolder: "Enter E-Mail", yPos: 320, keyBoard: UIKeyboardType.emailAddress)
        leftImage(imgName: "email")
        
        creatingLblComponents(lblName: "Mobile No:", yPos: 400)
        creatingTFComponents(placeHolder: "Enter Mobile Number", yPos: 400, keyBoard: UIKeyboardType.numberPad)
        leftImage(imgName: "mobileno")
        
        creatingLblComponents(lblName: "Address:", yPos: 480)
        
        creatingLblComponents(lblName: "State Name:", yPos: 640)
        creatingTFComponents(placeHolder: "Enter State Name", yPos: 640, keyBoard: UIKeyboardType.namePhonePad)
        leftImage(imgName: "state")
        
        creatingLblComponents(lblName: "Country Name:", yPos: 720)
        creatingTFComponents(placeHolder: "Enter Country Name", yPos: 720, keyBoard: UIKeyboardType.namePhonePad)
        leftImage(imgName: "country")
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    func creatingLblComponents(lblName:String,yPos:Int)
    {
        let myLbl = UILabel(frame: CGRect(x: 20, y: yPos, width: 150, height: 40))
        myLbl.text = lblName
        myLbl.textColor = UIColor.red
        view.addSubview(myLbl)
    }

    func creatingTFComponents(placeHolder:String,yPos:Int,keyBoard:UIKeyboardType)
    {
        myTF = UITextField(frame: CGRect(x: 140, y: yPos, width: 250, height: 40))
        myTF.placeholder = placeHolder
        myTF.backgroundColor = UIColor.white
        myTF.textColor = UIColor.blue
        myTF.keyboardType = keyBoard
        myTF.clearButtonMode = UITextField.ViewMode.whileEditing
        
        
        view.addSubview(myTF)
    }
    
    func leftViewImage(textField:UITextField,img:UIImage)
    {
        let leftViewImage = UIImageView(frame: CGRect(x: 0, y: 0, width: 40, height: 40))
        leftViewImage.image = img
        textField.leftView = leftViewImage
        textField.leftViewMode = UITextField.ViewMode.always
    }
    
    func rightViewImage(textFiled:UITextField,img:UIImage)
    {
        let rightViewImage = UIImageView(frame: CGRect(x: 0, y: 0, width: 40, height: 40))
        rightViewImage.image = img
        textFiled.rightView = rightViewImage
        textFiled.rightViewMode = UITextField.ViewMode.always
    }
    
    func leftImage(imgName:String)
    {
        let myImg = UIImage(named: imgName)
        leftViewImage(textField: myTF, img: myImg!)
        view.addSubview(myTF)
    }
    
    func rightImage(imgName:String)
    {
        let myImg = UIImage(named: imgName)
        rightViewImage(textFiled: myTF, img: myImg!)
        view.addSubview(myTF)
    }
    
    // keyboard Control
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?)
    {
        view.endEditing(true)
    }
    
    func textView()
    {
        let myTextView = UITextView(frame: CGRect(x: <#T##Int#>, y: <#T##Int#>, width: <#T##Int#>, height: <#T##Int#>))
    }
    
    
    
}
