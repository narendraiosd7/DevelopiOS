//
//  ViewController.swift
//  UIsegments by Rakesh
//
//  Created by Vadde Narendra on 9/28/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    var convertedData:[String:Any]!
    var offlineStepper:UIStepper!
    var onlineStepper:UIStepper!
    var modeSC:UISegmentedControl!
    var componentType:UISegmentedControl!
    var axis:UISegmentedControl!
    var slider:UISlider!
    var label:UILabel!
    var scrollView:UIScrollView!
    var uiElements:[UIView] = []
    var submit:UIButton!
    var get:UIButton!
    var dataTaskObject:URLSessionDataTask!
    var URLReqObj:URLRequest!
    var onlineScrollView:UIScrollView!
    var arr:[String] = ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"]
    var value = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        modeSC = UISegmentedControl(items: ["offline","online"])
        modeSC.frame = CGRect(x: 20, y: 69, width: 374, height: 29)
        modeSC.backgroundColor = UIColor.orange
        view.addSubview(modeSC)
        
        componentType = UISegmentedControl(items: ["Label","Button","Switch"])
        componentType.frame = CGRect(x: 20, y: 138, width: 186, height: 29)
        componentType.backgroundColor = UIColor.orange
        
        axis = UISegmentedControl(items: ["Horizontal","Vertical"])
        axis.frame = CGRect(x: 223, y: 138, width: 186, height: 29)
        axis.backgroundColor = UIColor.orange
        
        slider = UISlider()
        slider.frame = CGRect(x: 24, y: 227, width: 307, height: 20)
        slider.backgroundColor = UIColor.orange
        slider.minimumValue = 1
        slider.maximumValue = 200
        
        offlineStepper = UIStepper()
        offlineStepper.frame = CGRect(x: 300, y: 833, width: 94, height: 29)
        offlineStepper.backgroundColor = UIColor.orange
        
        onlineStepper = UIStepper()
        onlineStepper.frame = CGRect(x: 300, y: 833, width: 94, height: 29)
        onlineStepper.backgroundColor = UIColor.red
        onlineStepper.minimumValue = 0
        onlineStepper.maximumValue = 500
        
        label = UILabel()
        label.frame = CGRect(x: 351, y: 227, width: 43, height: 29)
        label.backgroundColor = UIColor.orange
        label.text = "value"
        
        scrollView = UIScrollView()
        scrollView.frame = CGRect(x: 20, y: 350, width: 370, height: 350)
        scrollView.backgroundColor = UIColor.cyan
        scrollView.contentSize = CGSize(width: 600, height: 600)
        
        
        onlineScrollView = UIScrollView()
        onlineScrollView.frame = CGRect(x: 20, y: 350, width: 370, height: 350)
        onlineScrollView.backgroundColor = UIColor.cyan
        onlineScrollView.contentSize = CGSize(width: 600, height: 900)
        
        submit = UIButton()
        submit.frame = CGRect(x: 144, y: 280, width: 100, height: 40)
        submit.backgroundColor = UIColor.orange
        submit.setTitle("Submit", for: UIControl.State.normal)
        
        get = UIButton()
        get.frame = CGRect(x: 144, y: 138, width: 70, height: 30)
        get.backgroundColor = UIColor.orange
        get.setTitle("Submit", for: UIControl.State.normal)
        view.addSubview(get)
        
        modeSC.addTarget(self, action: #selector(onlineAndOffline), for: UIControl.Event.valueChanged)
        submit.addTarget(self, action: #selector(createUIElements), for: UIControl.Event.touchUpInside)
        get.addTarget(self, action: #selector(json), for: UIControl.Event.touchUpInside)
        
        
        
        onlineStepper.addTarget(self, action: #selector(json), for: UIControl.Event.valueChanged)
        
        // Do any additional setup after loading the view, typically from a nib.
    }


    @objc func onlineAndOffline() {
        
        if(modeSC.selectedSegmentIndex == 0){
            print("offline")
            
            view.addSubview(offlineStepper)
            view.addSubview(modeSC)
            view.addSubview(componentType)
            view.addSubview(slider)
            view.addSubview(axis)
            view.addSubview(label)
            view.addSubview(scrollView)
            view.addSubview(submit)
            get.isHidden = true
            onlineStepper.removeFromSuperview()
            
            
        }else{
            print("Online")
            
            componentType.removeFromSuperview()
            axis.removeFromSuperview()
            slider.removeFromSuperview()
            label.removeFromSuperview()
            offlineStepper.removeFromSuperview()
            submit.removeFromSuperview()
            get.isHidden = false
            scrollView.removeFromSuperview()
            view.addSubview(onlineScrollView)
            view.addSubview(onlineStepper)
            
        }
        
    }
    
    
    var someValue = 0
    
    
    
    @objc func json()
    {
        let convertedData = getDetails()
        
        remove()
        
        
        print("\(someValue) \n \(convertedData)")
        
        var value = convertedData["quantity"] as! Int
        
//        print(value)
        
        onlineStepper.value = Double(value)
        print(onlineStepper.value)
        
        // Creating labels in horizontal way
        
        
        // creating Horizontal labels
        
        var xPos:UInt16 = 10
        var yPos:UInt16 = 20
        var j:Int = 0
        var k:Int = 0
//        var changeValue = (self.convertedData[""] as! Int)
        
        
        
        for i in 0...value-1{
            
            if(self.convertedData["axis"] as! String == "Horizontal"){
                
                var rows:Int = self.convertedData["maxPerRow"] as! Int
                var output = i - (rows * j)
                if(rows == output){
                    j = j+1
                    xPos = 10
                    yPos = yPos+60
                    
                }
                
            }
            
            // Creating labels in horizontal way
            if(self.convertedData["axis"] as! String == "Horizontal" && self.convertedData["component"] as! String == "Label"){
                
                
                let horizontalLabel = UILabel()
                horizontalLabel.frame = CGRect(x: Int(xPos), y: Int(yPos), width: 30, height: 30)
                if(convertedData["displayNumbers"] as! Int == 1){
                    let arrvalue = i - arr.count * k
                    let key = arrvalue
                    if(arrvalue==25){
                        k = k+1
                    }
                    
                    horizontalLabel.text = "\(arr[key])"
                    print("\(arr[key])")
                }
                if(convertedData["displayNumbers"] as! Int == 0){
                    
                    horizontalLabel.text = "\(i)"
                }
                xPos = xPos+50
                horizontalLabel.backgroundColor = UIColor.red
                self.onlineScrollView.addSubview(horizontalLabel)
                self.uiElements.append(horizontalLabel)
                
                
                //  print("trial 1 \(someValue) label")
                
            }
            
            // Creating buttons in Horizontal way
            
            if(self.convertedData["axis"] as! String == "Horizontal" && self.convertedData["component"] as! String == "Button"){
                
                
                let horizontalButton = UIButton()
                horizontalButton.frame = CGRect(x: Int(xPos), y: Int(yPos), width: 50, height: 50)
                if(convertedData["displayNumbers"] as! Int == 1){
                    let arrvalue = i - (arr.count * k)
                    let key = arrvalue
                    if(arrvalue==25){
                        k = k+1
                    }
                    
                    horizontalButton.setTitle("\(arr[key])", for: UIControl.State.normal)
                }
                if(convertedData["displayNumbers"] as! Int == 0){
                    
                    horizontalButton.setTitle("\(i)", for: UIControl.State.normal)
                }
                
                xPos = xPos+50
                horizontalButton.backgroundColor = UIColor.orange
                self.onlineScrollView.addSubview(horizontalButton)
                self.uiElements.append(horizontalButton)
                
                //    print("trial 1 \(someValue) button")
                
                
            }
            
            // Creating switches in Horizontal way
            if(self.convertedData["axis"] as! String == "Horizontal" && self.convertedData["component"] as! String == "Switch"){
                
                let horizontalSwitch = UISwitch()
                horizontalSwitch.frame = CGRect(x: Int(xPos), y: Int(yPos), width: 10, height: 10)
                horizontalSwitch.onTintColor = .blue
                horizontalSwitch.thumbTintColor = .red
                horizontalSwitch.backgroundColor = UIColor.orange
                xPos = xPos+50
                self.onlineScrollView.addSubview(horizontalSwitch)
                self.uiElements.append(horizontalSwitch)
                
                
                //   print("trial 1 \(someValue) switch")
                
            }
        }
        
        
        
        // Creating labels in vertical way
        
        // creating vertical Labels
        
        for i in 0...value-1{
            if(self.convertedData["axis"] as! String == "Vertical"){
                let quantity:Int = self.convertedData["maxPerColumn"] as! Int
                let output = i - (quantity * j)
                if(output == quantity){
                    j = j+1
                    
                    xPos = xPos + 50
                    yPos = 20
                    
                }
                
            }
            
            
            
            // Creating labels in vertical way
            if(self.convertedData["axis"] as! String == "Vertical" && self.convertedData["component"] as! String == "Label"){
                let verticalLabel = UILabel()
                verticalLabel.frame = CGRect(x: Int(xPos), y: Int(yPos), width: 50, height: 40)
                
                if(convertedData["displayNumbers"] as! Int == 1){
                    let arrvalue = i - (arr.count * k)
                    let key = arrvalue
                    if(arrvalue==25){
                        k = k+1
                    }
                    
                    verticalLabel.text = "\(arr[key])"
                }
                
                if(convertedData["displayNumbers"] as! Int == 0){
                    verticalLabel.text = "\(i)"
                }
                yPos = yPos+50
                verticalLabel.backgroundColor = UIColor.red
                self.onlineScrollView.addSubview(verticalLabel)
                self.uiElements.append(verticalLabel)
                
                //  print("trial 2 \(someValue) label")
                
            }
            
            
            // Creating buttons in vertical way
            
            if(self.convertedData["axis"] as! String == "Vertical" && self.convertedData["component"] as! String == "Button"){
                
                
                let verticalButton = UIButton()
                verticalButton.frame = CGRect(x: Int(xPos), y: Int(yPos), width: 50, height: 40)
                if(convertedData["displayNumbers"] as! Int == 1){
                    let arrvalue = i - (arr.count * k)
                    let key = arrvalue
                    if(arrvalue==25){
                        k = k+1
                    }
                    
                    verticalButton.setTitle("\(arr[key])", for: UIControl.State.normal)
                }
                
                if (convertedData["displayNumbers"] as! Int == 0){
                    
                    verticalButton.setTitle("\(i)", for: UIControl.State.normal)
                }
                yPos = yPos+50
                verticalButton.backgroundColor = UIColor.orange
                self.onlineScrollView.addSubview(verticalButton)
                self.uiElements.append(verticalButton)
                
                //   print("trial 2 \(someValue) button")
                
            }
            
            if(self.convertedData["axis"] as! String == "Vertical" && self.convertedData["component"] as! String == "Switch"){
                
                let verticalSwitch = UISwitch()
                verticalSwitch.frame = CGRect(x: Int(xPos), y: Int(yPos), width: 50, height: 50)
                yPos = yPos+50
                verticalSwitch.backgroundColor = UIColor.orange
                self.onlineScrollView.addSubview(verticalSwitch)
                self.uiElements.append(verticalSwitch)
                
                //    print("trial 2 \(someValue) switch")
                
                
            }
            
            
            
        }
        
        someValue +=  1
    }

    
    
    func getDetails() -> [String:Any]{
        URLReqObj = URLRequest(url: URL(string:"https://www.brninfotech.com/tws/ComponentCreation.php")!)
        
        URLReqObj.httpMethod = "Get"
        
        
        dataTaskObject = URLSession.shared.dataTask(with: URLReqObj, completionHandler: { (data, connectionDetails, error) in
            
            print("got data from server")
            
            
            
            do {
                
                self.convertedData = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.allowFragments) as! [String:Any]
                print(self.convertedData)
                
            } catch {
                print("Something went wrong")
            }
        })
        
        dataTaskObject.resume()
        
        while (convertedData == nil)
        {
            
        }
    
        return convertedData!
    }
    
    
    //           offline
    
    @objc func remove(){
        for elements in uiElements{
            elements.removeFromSuperview()
        }
    }
    
    @objc func createUIElements(){
        
        remove()
        
        
        let value = Int(slider.value)
        print(value)
        
        // Creating labels in horizontal way
        
        
        // creating Horizontal labels
        
        var labelx:UInt16 = 10
        var labely:UInt16 = 20
        for i in 0...value{
            
            if(labelx >= 380){
                
                labelx = 10
                labely = labely+60
                
            }
            
            // Creating labels in horizontal way
            if(componentType.selectedSegmentIndex == 0 && axis.selectedSegmentIndex == 0){
                let horizontalLabel = UILabel()
                horizontalLabel.frame = CGRect(x: Int(labelx), y: Int(labely), width: 30, height: 30)
                horizontalLabel.text = "\(i)"
                labelx = labelx+50
                horizontalLabel.backgroundColor = UIColor.red
                scrollView.addSubview(horizontalLabel)
                uiElements.append(horizontalLabel)
                
            }
            
            // Creating buttons in Horizontal way
            
            if (componentType.selectedSegmentIndex == 1 && axis.selectedSegmentIndex == 0){
                
                let horizontalButton = UIButton()
                
                horizontalButton.frame = CGRect(x: Int(labelx), y: Int(labely), width: 50, height: 50)
                horizontalButton.setTitle("\(i)", for: UIControl.State.normal)
                labelx = labelx+50
                scrollView.addSubview(horizontalButton)
                uiElements.append(horizontalButton)
                
            }
            
            // Creating switches in Horizontal way
            if(componentType.selectedSegmentIndex == 2 && axis.selectedSegmentIndex == 0){
                
                let horizontalSwitch = UISwitch()
                horizontalSwitch.frame = CGRect(x: Int(labelx), y: Int(labely), width: 10, height: 10)
                horizontalSwitch.onTintColor = .blue
                horizontalSwitch.thumbTintColor = .red
                horizontalSwitch.backgroundColor = UIColor.black
                labelx = labelx+50
                scrollView.addSubview(horizontalSwitch)
                uiElements.append(horizontalSwitch)
                
            }
        }
        
        // Creating labels in vertical way
        
        // creating vertical Labels
        
        for i in 0...value{
            if(labely >= 800){
                labelx = labelx + 50
                labely = 20
                
            }
            
            // Creating labels in vertical way
            if(componentType.selectedSegmentIndex == 0 && axis.selectedSegmentIndex == 1){
                let verticalLabel = UILabel()
                verticalLabel.frame = CGRect(x: Int(labelx), y: Int(labely), width: 50, height: 40)
                verticalLabel.text = "\(i)"
                labely = labely+50
                scrollView.addSubview(verticalLabel)
                uiElements.append(verticalLabel)
            }
            
            
            // Creating buttons in vertical way
            
            if (componentType.selectedSegmentIndex == 1 && axis.selectedSegmentIndex == 1){
                let verticalButton = UIButton()
                verticalButton.frame = CGRect(x: Int(labelx), y: Int(labely), width: 50, height: 40)
                verticalButton.setTitle("\(i)", for: UIControl.State.normal)
                labely = labely+50
                scrollView.addSubview(verticalButton)
                uiElements.append(verticalButton)
            }
            
            if(componentType.selectedSegmentIndex == 2 && axis.selectedSegmentIndex == 1){
                
                let verticalSwitch = UISwitch()
                verticalSwitch.frame = CGRect(x: Int(labelx), y: Int(labely), width: 50, height: 50)
                labely = labely+50
                scrollView.addSubview(verticalSwitch)
                uiElements.append(verticalSwitch)
                
            }
            
            
            
        }
        
    }
    
//     creating function for removing and adding the elements
    
//        @objc func  stepperValue()
//        {
//            onlineStepper.value = Double(value)
//
//                onlineStepper.isHidden = false
//                value = Int(onlineStepper.value)
//
//        }
//
}




