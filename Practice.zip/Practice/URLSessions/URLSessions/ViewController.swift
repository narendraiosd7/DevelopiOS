//
//  ViewController.swift
//  URLSessions
//
//  Created by Vadde Narendra on 9/3/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var urlReqObj:URLRequest!
    var dataTaskObj:URLSessionDataTask!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        getIndiaDetails(sendingData: "registeredEmail=narendraiosd@gmail.com&registeredPassword:nanda143&funcName=verifyLogin")
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    func getIndiaDetails(sendingData:String){
        
        urlReqObj = URLRequest(url: URL(string: "https://www.brninfotech.com/pulse/modules/admin/ValidateLogin.php?")!)
        
        urlReqObj.httpMethod = "Post"
        
        var dataToSend = sendingData
        
        urlReqObj.httpBody = dataToSend.data(using: String.Encoding.utf8)
        
        dataTaskObj = URLSession.shared.dataTask(with: urlReqObj, completionHandler: { (Data, URLResponse, Error) in
            
            do{
                var convertedData = try JSONSerialization.jsonObject(with: Data!, options: JSONSerialization.ReadingOptions.allowFragments)
                
                print(convertedData)
                
            } catch {
                print("Error")
            }
        })
        dataTaskObj.resume()
        
    }

}

