//
//  ViewController.swift
//  classroomcontrollers
//
//  Created by Vadde Narendra on 9/17/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var mainPowerSupplySwitch:UISwitch!
    var fluorescentLamp1:UISwitch!
    var fluorescentLamp2:UISwitch!
    var ceilingFan1:UISwitch!
    var ceilingFan2:UISwitch!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        mainPowerSupplySwitch = UISwitch(frame: CGRect(x: 292, y: 75, width: 10, height: 10))
        mainPowerSupplySwitch.tintColor = UIColor.black
        mainPowerSupplySwitch.thumbTintColor = UIColor.black
        mainPowerSupplySwitch.onTintColor = UIColor.darkGray
        
        view.addSubview(mainPowerSupplySwitch)
        
        fluorescentLamp1 = UISwitch(frame: CGRect(x: 292, y: 125, width: 10, height: 10))
        fluorescentLamp1.tintColor = UIColor.black
        fluorescentLamp1.thumbTintColor = UIColor.black
        fluorescentLamp1.onTintColor = UIColor.darkGray
        
        view.addSubview(fluorescentLamp1)
        
        fluorescentLamp2 = UISwitch(frame: CGRect(x: 292, y: 175, width: 10, height: 10))
        fluorescentLamp2.tintColor = UIColor.black
        fluorescentLamp2.thumbTintColor = UIColor.black
        fluorescentLamp2.onTintColor = UIColor.darkGray
        
        view.addSubview(fluorescentLamp2)
        
        ceilingFan1 = UISwitch(frame: CGRect(x: 292, y: 225, width: 10, height: 10))
        ceilingFan1.tintColor = UIColor.black
        ceilingFan1.thumbTintColor = UIColor.black
        ceilingFan1.onTintColor = UIColor.darkGray
        
        view.addSubview(ceilingFan1)
        
        ceilingFan2 = UISwitch(frame: CGRect(x: 292, y: 300, width: 10, height: 10))
        ceilingFan2.tintColor = UIColor.black
        ceilingFan2.thumbTintColor = UIColor.black
        ceilingFan2.onTintColor = UIColor.darkGray
        
        view.addSubview(ceilingFan2)
        
        mainPowerSupplySwitch.addTarget(self, action: #selector(onSwitchChanging), for: UIControl.Event.valueChanged)
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    @objc func onSwitchChanging(){
        
        if (mainPowerSupplySwitch.isOn == false){
            
            fluorescentLamp1.setOn(false, animated: true)
            fluorescentLamp1.isEnabled = false
            
            fluorescentLamp2.setOn(false, animated: true)
            fluorescentLamp2.isEnabled = false
            
            ceilingFan1.setOn(false, animated: true)
            ceilingFan1.isEnabled = false
            
            ceilingFan2.setOn(false, animated: true)
            ceilingFan2.isEnabled = false
        }
        else
        {
            fluorescentLamp1.setOn(false, animated: true)
            fluorescentLamp1.isEnabled = true
            
            fluorescentLamp2.setOn(false, animated: true)
            fluorescentLamp2.isEnabled = true
            
            ceilingFan1.setOn(false, animated: true)
            ceilingFan1.isEnabled = true
            
            ceilingFan2.setOn(false, animated: true)
            ceilingFan2.isEnabled = true
        }
    }
    
}

