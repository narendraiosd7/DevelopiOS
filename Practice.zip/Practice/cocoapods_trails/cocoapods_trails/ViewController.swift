//
//  ViewController.swift
//  cocoapods_trails
//
//  Created by Vadde Narendra on 10/10/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = UIColor.orange
        creatingComponents()
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    func creatingComponents(){
        
        let firstNameLbl = UILabel(frame: CGRect(x: 20, y: 74, width: 115, height: 25))
        firstNameLbl.textColor = UIColor.black
        firstNameLbl.text = "First Name:"
        view.addSubview(firstNameLbl)
        
        let lastNameLbl = UILabel(frame: CGRect(x: 20, y: 146, width: 115, height: 25))
        lastNameLbl.textColor = UIColor.black
        lastNameLbl.text = "Last Name:"
        view.addSubview(lastNameLbl)
        
        let ageLbl = UILabel(frame: CGRect(x: 20, y: 219, width: 115, height: 25))
        ageLbl.textColor = UIColor.black
        ageLbl.text = "Age:"
        view.addSubview(ageLbl)
        
        let emailLbl = UILabel(frame: CGRect(x: 20, y: 298, width: 115, height: 25))
        emailLbl.textColor = UIColor.black
        emailLbl.text = "E-Mail:"
        view.addSubview(emailLbl)
        
        let mobieNoLbl = UILabel(frame: CGRect(x: 20, y: 373, width: 115, height: 25))
        mobieNoLbl.textColor = UIColor.black
        mobieNoLbl.text = "Mobile No:"
        view.addSubview(mobieNoLbl)
        
        let addressLbl = UILabel(frame: CGRect(x: 20, y: 449, width: 115, height: 25))
        addressLbl.textColor = UIColor.black
        addressLbl.text = "Address:"
        view.addSubview(addressLbl)
        
        let stateNameLbl = UILabel(frame: CGRect(x: 20, y: 633, width: 115, height: 25))
        stateNameLbl.textColor = UIColor.black
        stateNameLbl.text = "State Name:"
        view.addSubview(stateNameLbl)
        
        let countryNameLbl = UILabel(frame: CGRect(x: 20, y: 703, width: 120, height: 25))
        countryNameLbl.textColor = UIColor.black
        countryNameLbl.text = "Country Name:"
        view.addSubview(countryNameLbl)
        
        
        let firstNameTF = UITextField(frame: CGRect(x: 169, y: 71, width: 210, height: 30))
        firstNameTF.placeholder = "Enter First Name"
        firstNameTF.textColor = UIColor.blue
        firstNameTF.backgroundColor = UIColor.white
        firstNameTF.keyboardType = UIKeyboardType.namePhonePad
        firstNameTF.clearButtonMode = UITextField.ViewMode.whileEditing
        
        let firstNameImg = UIImage(named: "firstName")
        addLeftImage(txtField: firstNameTF, img: firstNameImg!)
        view.addSubview(firstNameTF)
        
        // Creating last name text field
        
        let lastNameTF = UITextField(frame: CGRect(x: 169, y: 143, width: 210, height: 30))
        lastNameTF.placeholder = "Enter Last Name"
        lastNameTF.textColor = UIColor.blue
        lastNameTF.backgroundColor = UIColor.white
        lastNameTF.minimumFontSize = 5
        lastNameTF.keyboardType = UIKeyboardType.asciiCapable
        lastNameTF.clearButtonMode = UITextField.ViewMode.whileEditing
        
        let lastNameImg = UIImage(named: "lastName")
        addRightImage(txtField: lastNameTF, img: lastNameImg!)
        view.addSubview(lastNameTF)
        
        // Creating age text field
        
        let ageTF = UITextField(frame: CGRect(x: 169, y: 216, width: 210, height: 30))
        ageTF.placeholder = "Enter your age"
        ageTF.textColor = UIColor.blue
        ageTF.backgroundColor = UIColor.white
        ageTF.keyboardType = UIKeyboardType.decimalPad
        ageTF.clearButtonMode = UITextField.ViewMode.whileEditing
        
        let ageImg = UIImage(named: "age")
        addLeftImage(txtField: ageTF, img: ageImg!)
        view.addSubview(ageTF)
        
        // Creating email text field
        
        let emailTF = UITextField(frame: CGRect(x: 169, y: 295, width: 210, height: 30))
        emailTF.placeholder = "Enter E-Mail Address"
        emailTF.textColor = UIColor.blue
        emailTF.backgroundColor = UIColor.white
        emailTF.minimumFontSize = 5
        emailTF.keyboardType = UIKeyboardType.emailAddress
        emailTF.clearButtonMode = UITextField.ViewMode.whileEditing
        
        let emailImg = UIImage(named: "email")
        addLeftImage(txtField: emailTF, img: emailImg!)
        view.addSubview(emailTF)
        
        // Creating mobile number text field
        
        let mobileNumberTF = UITextField(frame: CGRect(x: 169, y: 370, width: 210, height: 30))
        mobileNumberTF.placeholder = "Enter Mobile Number"
        mobileNumberTF.textColor = UIColor.blue
        mobileNumberTF.backgroundColor = UIColor.white
        mobileNumberTF.minimumFontSize = 5
        mobileNumberTF.keyboardType = UIKeyboardType.phonePad
        mobileNumberTF.clearButtonMode = UITextField.ViewMode.whileEditing
        
        let mobileNoImg = UIImage(named: "mobileno")
        addLeftImage(txtField: mobileNumberTF, img: mobileNoImg!)
        view.addSubview(mobileNumberTF)
        
        // Creating address text View
        
        let addressTV = UITextView(frame: CGRect(x: 169, y: 449, width: 210, height: 105))
        addressTV.textColor = UIColor.blue
        addressTV.keyboardType = UIKeyboardType.default
        view.addSubview(addressTV)
        
        // Creating submit button
        
        let submitBtn = UIButton(frame: CGRect(x: 150, y: 793, width: 114, height: 30))
        submitBtn.setTitle("SUBMIT", for: UIControl.State.normal)
        submitBtn.backgroundColor = UIColor.brown
        view.addSubview(submitBtn)
        
        // Creating state name text field
        
        let stateNameTF = UITextField(frame: CGRect(x: 169, y: 627, width: 210, height: 30))
        stateNameTF.placeholder = "Enter State Name"
        stateNameTF.textColor = UIColor.blue
        stateNameTF.backgroundColor = UIColor.white
        stateNameTF.minimumFontSize = 5
        stateNameTF.keyboardType = UIKeyboardType.asciiCapable
        stateNameTF.clearButtonMode = UITextField.ViewMode.whileEditing
        
        let stateImg = UIImage(named: "state")
        addLeftImage(txtField: stateNameTF, img: stateImg!)
        view.addSubview(stateNameTF)
        
        // Creating country name text field
        
        let countryNameTF = UITextField(frame: CGRect(x: 169, y: 700, width: 210, height: 30))
        countryNameTF.placeholder = "Enter Country Name"
        countryNameTF.textColor = UIColor.blue
        countryNameTF.backgroundColor = UIColor.white
        countryNameTF.minimumFontSize = 5
        countryNameTF.keyboardType = UIKeyboardType.asciiCapable
        countryNameTF.clearButtonMode = UITextField.ViewMode.whileEditing
        
        let countryImg = UIImage(named: "country")
        addLeftImage(txtField: countryNameTF, img: countryImg!)
        view.addSubview(countryNameTF)
    }
    
    // Creating function for leftview image in text field
    
    func addLeftImage(txtField:UITextField, img:UIImage){
        
        let leftViewImage = UIImageView(frame: CGRect(x: 0, y: 0, width: 30, height:30))
        leftViewImage.image = img
        txtField.leftView = leftViewImage
        txtField.leftViewMode = UITextField.ViewMode.always
        
    }
    
    // Creating function for rightview image in text field
    
    func addRightImage(txtField:UITextField, img:UIImage){
        
        let rightViewImage = UIImageView(frame: CGRect(x: 0, y: 0, width: 30, height:30))
        rightViewImage.image = img
        txtField.rightView = rightViewImage
        txtField.rightViewMode = UITextField.ViewMode.always
        
    }
    
    
}

