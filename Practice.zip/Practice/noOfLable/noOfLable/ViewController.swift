//
//  ViewController.swift
//  noOfLable
//
//  Created by Vadde Narendra on 9/18/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var scrol = UIScrollView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        scrol.frame = CGRect(x: 10, y: 400, width: self.view.frame.size.width, height: 420)
        var yPos = 0.0
        for i in 0...100
        {
            let mySwitch = UISwitch()
            mySwitch.frame = CGRect(x: 20, y: yPos + 10, width: 20, height: 4)
            mySwitch.isOn = false
            
            // mySwitch.center = self.view.center
            
            mySwitch.tag = i
            
//            mySwitch.thumbTintColor = UIColor.red
//            mySwitch.tintColor = UIColor.green
//            mySwitch.onTintColor = UIColor.black
//            mySwitch.backgroundColor = UIColor.white
            
            yPos = Double(mySwitch.frame.origin.y + mySwitch.frame.size.height)
            
            mySwitch.addTarget(self, action: #selector(onSwitchChange(_:)), for: .touchUpInside)
            scrol.addSubview(mySwitch)
        }
        scrol.backgroundColor = .yellow
        scrol.isScrollEnabled = true
        self.view.addSubview(scrol)
    }

    @objc func onSwitchChange(_ sender: UISwitch) {
        print(" switch tapped \(sender.tag)")
        
    }
    
    
    
}

