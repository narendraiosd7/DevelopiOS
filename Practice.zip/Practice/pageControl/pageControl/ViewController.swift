//
//  ViewController.swift
//  pageControl
//
//  Created by Sagi Harika on 09/12/19.
//  Copyright © 2019 Sagi Harika. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UIScrollViewDelegate
{

    let images = [UIImage(named: "1"),UIImage(named: "2"),UIImage(named:  "3"),UIImage(named: "4"),UIImage(named: "5"),UIImage(named: "6"),UIImage(named: "7"),UIImage(named: "8"),UIImage(named: "9"), UIImage(named: "10")]
    
    let scrollView = UIScrollView()
    
    
    @IBOutlet weak var pageControlObj: UIPageControl!
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        
        setupUI()
        
        
        
        pageControlObj.addTarget(self, action: #selector(pageControlEH), for: UIControl.Event.valueChanged)
        
        
        let timer = Timer.scheduledTimer(timeInterval: 2, target: self, selector: #selector(timerEH), userInfo: nil, repeats: true)
        
        
        
    }
    
    @objc func timerEH()
    {
        print(pageControlObj.currentPage)
        
        pageControlObj.currentPage += 1
        
        
    }
    
    
    func setupUI()
    {
        
        //Sxroll View
        scrollView.delegate = self
        
        scrollView.frame = CGRect(x: 0, y: 50, width: view.frame.width, height: 300)
        //scrollView.backgroundColor = UIColor.green
        scrollView.showsHorizontalScrollIndicator = false
        scrollView.isPagingEnabled = true
        view.addSubview(self.scrollView)
        
        
        //Image Views
        
        var i = 0
        for x in images
        {
            let imageView = UIImageView()
            
            imageView.frame = CGRect(x: CGFloat(i) * self.scrollView.bounds.width , y: 50, width: scrollView.frame.width, height: scrollView.bounds.height)
            
            
            
           imageView.image = x
            
            scrollView.addSubview(imageView)
            
            
            i += 1
        }
        
        scrollView.contentSize = CGSize(width: scrollView.bounds.width * CGFloat(i), height: scrollView.frame.height)
    }
    
    @objc func pageControlEH()
    {
        
        
        scrollView.contentOffset.x = CGFloat(pageControlObj.currentPage) * scrollView.frame.width
        scrollView.contentOffset.y = 50
        
        
        
    }
    
    
    func scrollViewDidScroll(_ scrollView: UIScrollView)
    {


        pageControlObj.currentPage = Int(scrollView.contentOffset.x / scrollView.bounds.width)
    }
    
    
    
    
    
    
    
    
    


}

