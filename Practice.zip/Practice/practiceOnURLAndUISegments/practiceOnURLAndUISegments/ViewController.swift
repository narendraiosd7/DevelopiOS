//
//  ViewController.swift
//  practiceOnURLAndUISegments
//
//  Created by Vadde Narendra on 10/1/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var urlReqObj:URLRequest!
    var dataTaskObj:URLSessionDataTask!
    
    var convertedData:[String:Any] = [:]
    var scrollView = UIScrollView()
    var component:String = ""
    var componentQuantity = 0
    var displayNumber = 0
    var addStepper = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        scrollView.frame = CGRect(x: 10, y: 10, width: 400, height: 800)
        scrollView.backgroundColor = UIColor.yellow
        view.addSubview(scrollView)
        
        serverConnection()
        
        component = convertedData["component"] as? String ?? ""
        
        createComponent()
        
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    func serverConnection() -> [String:Any]{
        
        urlReqObj = URLRequest(url: URL(string: "https://www.brninfotech.com/tws/ComponentCreation.php")!)
        
        urlReqObj.httpMethod = "GET"
        
        dataTaskObj = URLSession.shared.dataTask(with: urlReqObj, completionHandler: { (Data, URLResponse, Error) in
            
            do {
                self.convertedData = try! JSONSerialization.jsonObject(with: Data!, options: JSONSerialization.ReadingOptions.allowFragments) as! [String:Any]
                
        } catch {
            print("Something went wrong")
        }
            
        })
        dataTaskObj.resume()
        
        return convertedData
    }
    
    func getDataFromServer(){
        
//        onlineStepper.removeFromSuperview()
        
        convertedData = serverConnection()
        print(convertedData)
        
        var maxPerRow = ""
        
        var axis = convertedData["axis"] as? String ?? ""
        
        if(axis == "Horizontal") {
            maxPerRow = convertedData["maxPerRow"] as? String ?? ""
        }else {
            maxPerRow = convertedData["maxPerColumn"] as? String ?? ""
        }
        
        component = convertedData["component"] as? String ?? ""
        componentQuantity = convertedData["quantity"] as? Int ?? 0
        displayNumber = convertedData["displayNumber"] as? Int ?? 0
        addStepper = convertedData["changeQuantity"] as? Int ?? 0
        
//        alphabetNumber = 0

        createComponent()
        
//        if(addStepper == 1){
//            onlineStepper.frame =  CGRect(x: 165, y: 135, width: 30, height: 30)
//            view.addSubview(onlineStepper)
//        }
        
    }
    
    
    
    func componentsView(){
        
        scrollView.isScrollEnabled = true
        //        super.viewDidLayoutSubviews()
        
        
        DispatchQueue.main.async {
            var contentRect = CGRect.zero
            
            for view in self.scrollView.subviews {
                contentRect = contentRect.union(view.frame)
            }
            
            self.scrollView.contentSize = contentRect.size
        }
        
        
        view.addSubview(scrollView)
        
        scrollView.subviews.forEach({ $0.removeFromSuperview() })
        
    }
    
    func createComponent(){
        
//        var
        
//        component = convertedData["component"] as? String ?? ""
//        print(component)
        
        if (component == "Switch"){
            
            let mySwitch = UISwitch(frame: CGRect(x: 10, y: 10, width: 0, height: 0))
            scrollView.addSubview(mySwitch)
        }
        
        if (component == "Label"){
            
            let myLbl = UILabel(frame: CGRect(x: 10, y: 10, width: 50, height: 20))
            myLbl.backgroundColor = UIColor.red
            myLbl.text = "Label"
            scrollView.addSubview(myLbl)
        }
        
        if (component == "Button"){
            
            let myBtn = UIButton(frame: CGRect(x: 10, y: 10, width: 50, height: 20))
            myBtn.backgroundColor = UIColor.green
            scrollView.addSubview(myBtn)
        }
        
        
    }
    
    

}

