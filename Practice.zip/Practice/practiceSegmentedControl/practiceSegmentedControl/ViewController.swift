//
//  ViewController.swift
//  practiceSegmentedControl
//
//  Created by Vadde Narendra on 11/10/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var firstYearContainer: UIView!
    @IBOutlet weak var secondYearContainer: UIView!
    @IBOutlet weak var finalYearContainer: UIView!
    @IBOutlet weak var semSC: UISegmentedControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func SCTapped(_ sender: UISegmentedControl)
    {
        switch sender.selectedSegmentIndex {
        case 0:
            firstYearContainer.isHidden = false
            secondYearContainer.isHidden = true
            finalYearContainer.isHidden = true
            semSC.isHidden = true
        case 1:
            firstYearContainer.isHidden = false
            secondYearContainer.isHidden = true
            finalYearContainer.isHidden = true
            semSC.isHidden = false
        case 2:
            firstYearContainer.isHidden = false
            secondYearContainer.isHidden = true
            finalYearContainer.isHidden = true
            semSC.isHidden = false
        default:
            break
        }
    }
    
    @IBAction func semSCTapped(_ sender: UISegmentedControl)
    {
        switch sender.selectedSegmentIndex {
        case 0:
            firstYearContainer.isHidden = true
            secondYearContainer.isHidden = false
            finalYearContainer.isHidden = true
        case 1:
            firstYearContainer.isHidden = true
            secondYearContainer.isHidden = false
            finalYearContainer.isHidden = true
        default:
            break
        }
    }
    
    
    
}

