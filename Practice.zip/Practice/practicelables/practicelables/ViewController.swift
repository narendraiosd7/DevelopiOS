//
//  ViewController.swift
//  practicelables
//
//  Created by Vadde Narendra on 9/18/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var scrolFrame:UIScrollView!
    var noOfLables:UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        scrolFrame.frame = CGRect(x: 10, y: 0, width: self.view.frame.size.width, height: 1000)
        var yPos = 0.0
        for i in 0...100
        {
            
            noOfLables.frame = CGRect(x: 20, y: yPos + 10, width: 25, height: 8)
            
            // mySwitch.center = self.view.center
            
            noOfLables.tag = i
            noOfLables.backgroundColor = UIColor.white
            yPos = Double(noOfLables.frame.origin.y + noOfLables.frame.size.height)
            
            scrolFrame.addSubview(noOfLables)
        }
        
        scrolFrame.isScrollEnabled = true
        self.view.addSubview(scrolFrame)
        
        // Do any additional setup after loading the view, typically from a nib.
    }

//    @objc func onSwitchChange(_ sender: UISwitch) {
//        print(" switch tapped \(sender.tag)")
//
//    }
//

}

