//
//  ViewController.swift
//  segmentedViewControl
//
//  Created by Vadde Narendra on 9/24/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return games.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell()
        cell.textLabel?.text = games[indexPath.row]
        return cell
    }
    

    let segmentedControll:UISegmentedControl = {
        let sc = UISegmentedControl(items: ["Games","TV Shows","Devices"])
        sc.selectedSegmentIndex = 0
        sc.addTarget(self, action: #selector(handleSegmentChange), for: UIControl.Event.valueChanged)
        return sc
    }()
    
    @objc fileprivate func handleSegmentChange(){
        print(segmentedControll.selectedSegmentIndex)
    }
    
    let tableView = UITableView(frame: CGRect.zero, style: UITableView.Style.plain)
    
    let games = ["World of WarCraft","Fortnite","PUBG","Tetris"]
    
    let tvShows = ["Full House","Dr. Who",]
    
    let Devices = ["iMac Pro","Mac Mini"]
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.dataSource = self
        
        tableView.delegate = self
        
        view.backgroundColor = UIColor.white
        
        navigationItem.title = "Segmented Table View"
        
        let stackView = UIStackView(arrangedSubviews: [segmentedControll,tableView])
        
        stackView.axis = .vertical
        
        view.addSubview(stackView)
        
        stackView.translatesAutoresizingMaskIntoConstraints = false
        
        stackView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 0).isActive = true
        
        stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 0).isActive = true
        
        stackView.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant:0).isActive = true
        
        stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant:0).isActive = true
      
    }


}

