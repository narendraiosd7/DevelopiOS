//
//  ViewController.swift
//  serverData
//
//  Created by Vadde Narendra on 9/26/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var urlReqObj:URLRequest!
    var dataTaskObj:URLSessionDataTask!
    var convertedData:[String:Any] = [:]
    var scrollView = UIScrollView()
    var quantity = 0
    var maxPerRow = 0
    var maxPerColumn = 0
    var changeQuantity = 0
    var component = ""
    var axis = ""
    var displayNumbers = 0
    var xPos = 10
    var yPos = 20
    var componentQuantity = 0
    var componentCount = 0
    var componentNumber = 0
    var alphabets: [Character]  = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]
    var alphabetNumber = 0
    var offlineStepper = UIStepper()
    var onlineStepper = UIStepper()
    var addStepper = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        scrollView = UIScrollView(frame: CGRect(x: 0, y: 10, width: 400, height: 800))
        view.addSubview(scrollView)
        
        serverDataGetting()
      
        // Do any additional setup after loading the view, typically from a nib.
    }

    
   func serverDataGetting() {
        
        urlReqObj = URLRequest(url: URL(string: "https://www.brninfotech.com/tws/ComponentCreation.php")!)
        
        urlReqObj.httpMethod = "GET"

        dataTaskObj = URLSession.shared.dataTask(with: urlReqObj, completionHandler: { (Data, URLResponse, Error) in
            do{
                self.convertedData = try JSONSerialization.jsonObject(with: Data!, options: JSONSerialization.ReadingOptions.allowFragments) as! [String:Any]
                
                self.quantity = (self.convertedData["quantity"] as? Int ?? 0)
                self.maxPerRow = (self.convertedData["maxPerRow"] as? Int ?? 0)
                self.axis = (self.convertedData["axis"] as? String ?? "")
                self.component = (self.convertedData["component"] as? String ?? "")
                self.componentQuantity = (self.convertedData["componentQuantity"] as? Int ?? 0)
                self.maxPerColumn = (self.convertedData["maxPerColumn"] as? Int ?? 0)
                
               
                
                print(self.convertedData)
                self.creatingComponent()
                
                
            } catch {
                print("Wait for server responce")
            }
        })
        dataTaskObj.resume()
    
    
    
    
    }

    func creatingComponent(){
        
        if(addStepper == 1){
            onlineStepper.frame =  CGRect(x: 165, y: 135, width: 30, height: 30)
            view.addSubview(onlineStepper)
        }
//
//        if(axis == "Horizontal") {
//            maxPerRow = serverComponents.maxPerRow
//        }else {
//            maxPerRow = serverComponents.maxPerColumn
//        }
        
        scrollView.isScrollEnabled = true
        super.viewDidLayoutSubviews()
        
        
        DispatchQueue.main.async {
            var contentRect = CGRect.zero
            
            for view in self.scrollView.subviews {
                contentRect = contentRect.union(view.frame)
            }
            
            self.scrollView.contentSize = contentRect.size
        }
        
        
        view.addSubview(scrollView)
        
        
        
        scrollView.subviews.forEach({ $0.removeFromSuperview() })
        
        
        
        for _ in 1...quantity {
        
                if (component == "Label" || component == "Button" || component == "Switch"){
            
                    if(componentQuantity > 0 && maxPerRow > 0){
                        
                        for  _ in 1...componentQuantity {
                            
                            
                            for _ in 1...maxPerRow{
                                
                                if(componentCount < componentQuantity){
                                    
                                    componentNumber += 1
                                    
                                    if (component == "Label"){
                                        
                                        let label = UILabel()
                                        label.frame = CGRect(x: xPos, y: yPos, width: 35, height: 38)
                                        label.backgroundColor = UIColor.green
                                        label.textAlignment = .center
                                        if(displayNumbers == 1){
                                            label.text = "\(componentNumber)"
                                        }
                                        else {
                                            if(alphabetNumber == 26){
                                                alphabetNumber = 0
                                            }
                                            
                                            label.text = "\(alphabets[alphabetNumber])"
                                            alphabetNumber += 1
                                        }
                                        label.textColor = UIColor.black
                                        scrollView.addSubview(label)
                                    }
                                    
                                    if (component == "Button"){
                                        
                                        let button = UIButton()
                                        button.frame = CGRect(x: xPos, y: yPos, width: 50, height: 30)
                                        button.backgroundColor = UIColor.red
                                        if(displayNumbers == 1){
                                            button.setTitle("B.\(componentNumber)", for: UIControl.State.normal)
                                        }
                                        else {
                                            
                                            if(alphabetNumber == 26){
                                                alphabetNumber = 0
                                            }
                                            
                                            button.setTitle("\(alphabets[alphabetNumber])", for: UIControl.State.normal)
                                            alphabetNumber += 1
                                        }
                                        
                                        button.setTitleColor(UIColor.black, for: UIControl.State.normal)
                                        scrollView.addSubview(button)
                                        
                                    }
                                    
                                    if (component == "Switch"){
                                        
                                        let switchView = UISwitch()
                                        switchView.frame = CGRect(x: xPos, y: yPos, width: 35, height: 38)
                                        scrollView.addSubview(switchView)
                                        
                                    }
                                    
                                    
                                    if(axis == "Horizontal"){
                                        xPos += 60
                                    }
                                    if(axis == "Vertical"){
                                        yPos += 50
                                    }
                                    componentCount += 1
                                    
                                }
                                
                            }
                            
                            if(axis == "Horizontal"){
                                xPos = 10
                                yPos += 40
                            }
                            if(axis == "Vertical"){
                                yPos = 20
                                xPos += 60
                            }
                            
                        }
                        
                        xPos = 10
                        yPos = 20
                        componentCount = 0
                        componentNumber = 0
                        
                    }
                    
                    onlineStepper.value = Double(componentQuantity)
                    
            }
            
        }
        
    }
    
    @objc func stepperFunction(stepper: UIStepper) {
        alphabetNumber = 0
        
        if(stepper == onlineStepper){
            componentQuantity = Int(onlineStepper.value)
            
            creatingComponent()
        }
        
    }

    
}

