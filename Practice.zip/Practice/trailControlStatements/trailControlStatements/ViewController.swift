//
//  ViewController.swift
//  trailControlStatements
//
//  Created by Vadde Narendra on 9/23/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var switch1: UISwitch!
    @IBOutlet weak var switch2: UISwitch!
    @IBOutlet weak var switch3: UISwitch!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        switch1.addTarget(self, action: #selector(switchControlCondition), for: UIControl.Event.valueChanged)
        switch2.addTarget(self, action: #selector(switchControlCondition), for: UIControl.Event.valueChanged)
        switch3.addTarget(self, action: #selector(switchControlCondition), for: UIControl.Event.valueChanged)
        // Do any additional setup after loading the view, typically from a nib.
    }

    @objc func switchControlCondition(obj:UISwitch){
        
//        if (switch1.isOn == true){
//            switch2.setOn(false, animated: true)
//            switch3.setOn(false, animated: true)
//        }
//
//        if (switch2.isOn == true){
//            switch1.setOn(false, animated: true)
//            switch3.setOn(false, animated: true)
//        }
//
//        if (switch3.isOn == true){
//            switch2.setOn(false, animated: true)
//            switch1.setOn(false, animated: true)
//        }
        
        if(obj == switch1)
        {
            switch2.setOn(false, animated: true)
            switch3.setOn(false, animated: true)
        }
        else if(obj == switch2)
        {
            switch1.setOn(false, animated: true)
            switch3.setOn(false, animated: true)
        }
        else
        {
            switch2.setOn(false, animated: true)
            switch1.setOn(false, animated: true)
        }
    }
}
