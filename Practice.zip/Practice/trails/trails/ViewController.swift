//
//  ViewController.swift
//  trails
//
//  Created by Vadde Narendra on 9/21/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var scrol = UIScrollView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        scrol.frame = CGRect(x: 10, y: 50, width: 390, height: 800)
        scrol.backgroundColor = UIColor.orange
       scrol.contentSize = CGSize(width: 390, height: 1000)
        //scrol.isScrollEnabled = true
        
        var yPos = 10.0
        for i in 0...100 {
            let mySwitch = UISwitch()
            mySwitch.frame = CGRect(x: 10, y: yPos + 10, width: 50, height: 25)
            mySwitch.isOn = false
            // mySwitch.center = self.view.center
            mySwitch.tag = i
            mySwitch.thumbTintColor = UIColor(red: 23.0/255, green: 145.0/255, blue: 255.0/255, alpha: 1.0)
            mySwitch.tintColor = UIColor(red: 23.0/255, green: 145.0/255, blue: 255.0/255, alpha: 1.0)
            mySwitch.onTintColor = UIColor.black
            mySwitch.backgroundColor = UIColor.white
            yPos = Double(mySwitch.frame.origin.y + mySwitch.frame.size.height)
            mySwitch.addTarget(self, action: #selector(onSwitchChange(_:)), for: UIControl.Event.valueChanged)
//            mySwitch.addTarget(self, action: #selector(onSwitchChange(_:)), for: .touchUpInside)
            scrol.addSubview(mySwitch)
        }
//        scrol.backgroundColor = .yellow
//        scrol.isScrollEnabled = true
        view.addSubview(scrol)
    }
    @objc func onSwitchChange(_ sender: UISwitch) {
        print(" switch tapped \(sender.tag)")
        
    }

}

