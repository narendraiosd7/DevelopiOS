//
//  ViewController.swift
//  validationCheckPractice
//
//  Created by Vadde Narendra on 11/11/19.
//  Copyright © 2019 Vadde Narendra. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate
{
    @IBOutlet weak var firstNameTF: UITextField!
    @IBOutlet weak var lastNameTF: UITextField!
    @IBOutlet weak var dateOfBirthTF: UITextField!
    @IBOutlet weak var qualificationTF: UITextField!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        firstNameTF.delegate = self
        lastNameTF.delegate = self
        dateOfBirthTF.delegate = self
        qualificationTF.delegate = self
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    // marks validation function
    
    func isValidName(nameStr:String) -> Bool
    {
        let nameRegEx = "[A-Za-z ]{1,10}"
        
        let namePred = NSPredicate(format:"SELF MATCHES %@", nameRegEx)
        return namePred.evaluate(with: nameStr)
    }
    
    func isValidqualification(qualificationStr:String) -> Bool
    {
        let qualificationRegEx = "[A-Za-z.]{1,15}"
        
        let qualificationPred = NSPredicate(format:"SELF MATCHES %@", qualificationRegEx)
        return qualificationPred.evaluate(with: qualificationStr)
    }
    
    
    
    var returnValue = false
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool
    {
        
        
        if (textField == firstNameTF)
        {
            returnValue = true
        }
        else if (textField == lastNameTF)
        {
            if (((firstNameTF.text?.count)!) > 1)
            {
                returnValue = true
            }
            else
            {
                returnValue = false
            }
        }
        else if (textField == dateOfBirthTF)
        {
            if (((lastNameTF.text?.count)!) > 1)
            {
                returnValue = true
            }
            else
            {
                returnValue = false
            }
        }
        else if (textField == qualificationTF)
        {
            if (((qualificationTF.text?.count)!) > 1)
            {
                returnValue = true
            }
            else
            {
                returnValue = false
            }
        }
        
        return returnValue
    }
    
    
    
    func textFieldDidBeginEditing(_ textField: UITextField)
    {
        textField.backgroundColor = UIColor.red
    }
    
    
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool
    {
        var returnValue = true
        
        if (textField == firstNameTF || textField == lastNameTF)
        {
            returnValue = isValidName(nameStr: textField.text!)
        }
        else
        {
            returnValue = false
        }
        
        if (textField == qualificationTF)
        {
            returnValue = isValidqualification(qualificationStr: textField.text!)
        }
        else
        {
            returnValue = false
        }
        
        return returnValue
    }
    
    
    
    func textFieldDidEndEditing(_ textField: UITextField)
    {
        textField.backgroundColor = UIColor.white
    }
    
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool
    {
        return true
    }
    
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        return true
    }
    
}



