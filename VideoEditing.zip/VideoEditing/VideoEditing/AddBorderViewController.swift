//
//  AddBorderViewController.swift
//  VideoEditing
//
//  Created by Vadde Narendra on 5/10/20.
//  Copyright © 2020 Narendra Vadde. All rights reserved.
//

import UIKit
import AVFoundation

class AddBorderViewController: ViewController {
    
    @IBOutlet weak var colorSegment: UISegmentedControl!
    @IBOutlet weak var widthBar: UISlider!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    func image(with color: UIColor?, rectSize imageSize: CGRect) -> UIImage? {
        let rect = imageSize
        UIGraphicsBeginImageContextWithOptions(rect.size, _: false, _: 0)
        color?.setFill()
        UIRectFill(rect) // Fill it with your color
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return image
    }
    
    @IBAction func loadAsset(_ sender: Any) {
        startMediaBrowser(from: self, usingDelegate: self)
    }
    
    @IBAction func generateOutput(_ sender: Any) {
        videoOutput()
    }
    
    override func applyVideoEffects(to composition: AVMutableVideoComposition?, size: CGSize) {
        
        var borderImage: UIImage? = nil
        
        if colorSegment.selectedSegmentIndex == 0 {
            borderImage = image(with: UIColor.blue, rectSize: CGRect(x: 0, y: 0, width: size.width, height: size.height))
        } else if colorSegment.selectedSegmentIndex == 1 {
            borderImage = image(with: UIColor.red, rectSize: CGRect(x: 0, y: 0, width: size.width, height: size.height))
        } else if colorSegment.selectedSegmentIndex == 2 {
            borderImage = image(with: UIColor.green, rectSize: CGRect(x: 0, y: 0, width: size.width, height: size.height))
        } else if colorSegment.selectedSegmentIndex == 3 {
            borderImage = image(with: UIColor.white, rectSize: CGRect(x: 0, y: 0, width: size.width, height: size.height))
        }
        
        let backgroundLayer = CALayer()
        backgroundLayer.contents = borderImage?.cgImage
        backgroundLayer.frame = CGRect(x: 0, y: 0, width: size.width, height: size.height)
        backgroundLayer.masksToBounds = true
        
        let videoLayer = CALayer()
        videoLayer.frame = CGRect(
            x: CGFloat(widthBar.value),
            y: CGFloat(widthBar.value),
            width: size.width - CGFloat(widthBar.value),
            height: size.height - CGFloat(widthBar.value))
        
        let parentLayer = CALayer()
        parentLayer.frame = CGRect(x: 0, y: 0, width: size.width, height: size.height)
        parentLayer.addSublayer(backgroundLayer)
        parentLayer.addSublayer(videoLayer)
        
        composition!.animationTool = AVVideoCompositionCoreAnimationTool(
        postProcessingAsVideoLayer: videoLayer,
        in: parentLayer)
    }
    
}
