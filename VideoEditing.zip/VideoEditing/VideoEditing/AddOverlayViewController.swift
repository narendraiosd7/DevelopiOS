//
//  AddOverlayViewController.swift
//  VideoEditing
//
//  Created by Vadde Narendra on 5/10/20.
//  Copyright © 2020 Narendra Vadde. All rights reserved.
//

import UIKit
import AVFoundation

class AddOverlayViewController: ViewController {
    
    @IBOutlet weak var frameSelectSegment: UISegmentedControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func loadAsset(_ sender: Any) {
        startMediaBrowser(from: self, usingDelegate: self)
    }
    
    @IBAction func generateOutput(_ sender: Any) {
        videoOutput()
    }
    
    override func applyVideoEffects(to composition: AVMutableVideoComposition?, size: CGSize) {
        
        // 1 - set up the overlay
        let overlayLayer = CALayer()
        var overlayImage: UIImage? = nil
        if frameSelectSegment.selectedSegmentIndex == 0 {
            overlayImage = UIImage(named: "Frame-1.png")
        } else if frameSelectSegment.selectedSegmentIndex == 1 {
            overlayImage = UIImage(named: "Frame-2.png")
        } else if frameSelectSegment.selectedSegmentIndex == 2 {
            overlayImage = UIImage(named: "Frame-3.png")
        }
        
        overlayLayer.contents = overlayImage?.cgImage
        overlayLayer.frame = CGRect(x: 0, y: 0, width: size.width, height: size.height)
        overlayLayer.masksToBounds = true
        
        // 2 - set up the parent layer
        let parentLayer = CALayer()
        let videoLayer = CALayer()
        parentLayer.frame = CGRect(x: 0, y: 0, width: size.width, height: size.height)
        videoLayer.frame = CGRect(x: 0, y: 0, width: size.width, height: size.height)
        parentLayer.addSublayer(videoLayer)
        
        // 3 - apply magic
        composition!.animationTool = AVVideoCompositionCoreAnimationTool(
            postProcessingAsVideoLayer: videoLayer,
            in: parentLayer)
    }
}
