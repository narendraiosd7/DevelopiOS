//
//  AddSubtitleViewController.swift
//  VideoEditing
//
//  Created by Vadde Narendra on 5/10/20.
//  Copyright © 2020 Narendra Vadde. All rights reserved.
//

import UIKit
import AVFoundation

class AddSubtitleViewController: ViewController {
    
    @IBOutlet weak var subTitle1: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    @IBAction func loadAsset(_ sender: Any) {
        startMediaBrowser(from: self, usingDelegate: self)
    }
    
    @IBAction func generateOutput(_ sender: Any) {
        videoOutput()
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    override func applyVideoEffects(to composition: AVMutableVideoComposition?, size: CGSize) {
        
        // 1 - Set up the text layer
        let subtitle1Text = CATextLayer()
        subtitle1Text.font = "Helvetica-Bold" as CFTypeRef
        subtitle1Text.fontSize = 36
        subtitle1Text.frame = CGRect(x: 0, y: 0, width: size.width, height: 100)
        subtitle1Text.string = subTitle1.text
        subtitle1Text.alignmentMode = .center
        subtitle1Text.foregroundColor = UIColor.white.cgColor
        
        // 2 - The usual overlay
        let overlayLayer = CALayer()
        overlayLayer.addSublayer(subtitle1Text)
        overlayLayer.frame = CGRect(x: 0, y: 0, width: size.width, height: size.height)
        overlayLayer.masksToBounds = true
        
        let parentLayer = CALayer()
        let videoLayer = CALayer()
        parentLayer.frame = CGRect(x: 0, y: 0, width: size.width, height: size.height)
        videoLayer.frame = CGRect(x: 0, y: 0, width: size.width, height: size.height)
        parentLayer.addSublayer(videoLayer)
        parentLayer.addSublayer(overlayLayer)
        
        composition!.animationTool = AVVideoCompositionCoreAnimationTool(
        postProcessingAsVideoLayer: videoLayer,
        in: parentLayer)
    }
    
}
