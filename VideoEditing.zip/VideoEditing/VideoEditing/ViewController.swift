//
//  ViewController.swift
//  VideoEditing
//
//  Created by Vadde Narendra on 5/10/20.
//  Copyright © 2020 Narendra Vadde. All rights reserved.
//

import UIKit
import Photos
import AVFoundation
import MobileCoreServices

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    var videoAsset: AVAsset?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    //    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
    //        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
    //        // Custom initialization
    //    }
    
    //    required init?(coder: NSCoder) {
    //        fatalError("init(coder:) has not been implemented")
    //    }
    
    func startMediaBrowser(from controller: UIViewController?, usingDelegate delegate: Any?) -> Bool {
        
        // 1 - Validations
        if (UIImagePickerController.isSourceTypeAvailable(.savedPhotosAlbum) == false) || (delegate == nil) || (controller == nil) {
            return false
        }
        
        // 2 - Get image picker
        let mediaUI = UIImagePickerController()
        mediaUI.sourceType = .savedPhotosAlbum
        mediaUI.mediaTypes = [kUTTypeMovie as String]
        // Hides the controls for moving & scaling pictures, or for
        // trimming movies. To instead show the controls, use YES.
        mediaUI.allowsEditing = true
        mediaUI.delegate = self
        
        // 3 - Display image picker
        controller?.present(mediaUI, animated: true)
        return true
        
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        // 1 - Get media type
        let mediaType = info[.mediaType] as? String
        
        // 2 - Dismiss image picker
        dismiss(animated: true)
        
        // 3 - Handle video selection
        if CFStringCompare(mediaType as CFString?, kUTTypeMovie, []) == .compareEqualTo {
            
            if let object = info[.mediaURL] as? URL {
                videoAsset = AVAsset(url: object)
            }
            
            let alert = UIAlertController(title: "Asset Loaded", message: "Video asset loaded", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
            present(alert, animated: true, completion: nil)
        }
    }
    
    func applyVideoEffects(to composition: AVMutableVideoComposition?, size: CGSize) {
        // no-op - override this method in the subclass
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true)
    }
    
    func exportDidFinish(_ session: AVAssetExportSession?) {
        //        if session?.status == .completed {
        let outputURL = session!.outputURL
        PHPhotoLibrary.shared().performChanges({
            PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: outputURL!)
        }) { saved, error in
            if saved {
                DispatchQueue.main.async {
                    let alert = UIAlertController(title: "Your video was successfully saved", message: nil, preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
            } else {
                
                DispatchQueue.main.async {
                    print(error)
                    let alert = UIAlertController(title: "Your video was not saved due to something went wrong", message: nil, preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
            }
        }
        //        }
    }
    
    func videoOutput() {
        // 1 - Early exit if there's no video file selected
        if (videoAsset == nil) {
            
            let alert = UIAlertController(title: "Error", message: "Please Load a Video Asset First", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
            present(alert, animated: true, completion: nil)
            
            return
        }
        
        // 2 - Create AVMutableComposition object. This object will hold your AVMutableCompositionTrack instances.
        let mixComposition = AVMutableComposition()
        
        // 3 - Video track
        let videoTrack = mixComposition.addMutableTrack(
            withMediaType: .video,
            preferredTrackID: kCMPersistentTrackID_Invalid)
        do {
            try videoTrack?.insertTimeRange(
                CMTimeRangeMake(start: .zero, duration: videoAsset!.duration),
                of: videoAsset!.tracks(withMediaType: .video)[0],
                at: .zero)
        } catch {
        }
        
        // 3.1 - Create AVMutableVideoCompositionInstruction
        let mainInstruction = AVMutableVideoCompositionInstruction()
        mainInstruction.timeRange = CMTimeRangeMake(start: .zero, duration: videoAsset!.duration)
        
        // 3.2 - Create an AVMutableVideoCompositionLayerInstruction for the video track and fix the orientation.
        let videolayerInstruction = AVMutableVideoCompositionLayerInstruction(assetTrack: videoTrack!)
        let videoAssetTrack = videoAsset!.tracks(withMediaType: .video)[0]
        var videoAssetOrientation = UIImage.Orientation.up
        var isVideoAssetPortrait = false
        let videoTransform = videoAssetTrack.preferredTransform
        
        if videoTransform.a == 0 && videoTransform.b == 1.0 && videoTransform.c == -1.0 && videoTransform.d == 0 {
            videoAssetOrientation = UIImage.Orientation.right
            isVideoAssetPortrait = true
        }
        
        if videoTransform.a == 0 && videoTransform.b == -1.0 && videoTransform.c == 1.0 && videoTransform.d == 0 {
            videoAssetOrientation = UIImage.Orientation.left
            isVideoAssetPortrait = true
        }
        
        if videoTransform.a == 1.0 && videoTransform.b == 0 && videoTransform.c == 0 && videoTransform.d == 1.0 {
            videoAssetOrientation = UIImage.Orientation.up
        }
        if videoTransform.a == -1.0 && videoTransform.b == 0 && videoTransform.c == 0 && videoTransform.d == -1.0 {
            videoAssetOrientation = UIImage.Orientation.down
        }
        
        videolayerInstruction.setTransform(videoAssetTrack.preferredTransform, at: .zero)
        videolayerInstruction.setOpacity(0.0, at: videoAsset!.duration)
        
        // 3.3 - Add instructions
        if let array = [videolayerInstruction] as? [AVVideoCompositionLayerInstruction] {
            mainInstruction.layerInstructions = array
        }
        
        let mainCompositionInst = AVMutableVideoComposition()
        
        var naturalSize: CGSize
        if isVideoAssetPortrait {
            naturalSize = CGSize(width: videoAssetTrack.naturalSize.height, height: videoAssetTrack.naturalSize.width)
        } else {
            naturalSize = videoAssetTrack.naturalSize
        }
        
        var renderWidth: Float
        var renderHeight: Float
        renderWidth = Float(naturalSize.width)
        renderHeight = Float(naturalSize.height)
        mainCompositionInst.renderSize = CGSize(width: CGFloat(renderWidth), height: CGFloat(renderHeight))
        mainCompositionInst.instructions = [mainInstruction]
        mainCompositionInst.frameDuration = CMTimeMake(value: 1, timescale: 30)
        
        applyVideoEffects(to: mainCompositionInst, size: naturalSize)
        
        // 4 - Get path
        let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).map(\.path)
        let documentsDirectory = paths[0]
        let myPathDocs = URL(fileURLWithPath: documentsDirectory).appendingPathComponent("FinalVideo-\(arc4random() % 1000).mov").absoluteString
        let url = URL(fileURLWithPath: myPathDocs)
        
        // 5 - Create exporter
        let exporter = AVAssetExportSession(
            asset: mixComposition,
            presetName: AVAssetExportPresetHighestQuality)
        exporter?.outputURL = url
        exporter?.outputFileType = .mov
        exporter?.shouldOptimizeForNetworkUse = true
        exporter?.videoComposition = mainCompositionInst
        exporter?.exportAsynchronously(completionHandler: {
            DispatchQueue.main.async(execute: {
                self.exportDidFinish(exporter)
            })
        })
    }
}

