//
//  MergeVideoViewController.swift
//  VideoPlayAndRecord
//
//  Created by Vadde Narendra on 5/7/20.
//  Copyright © 2020 Narendra Vadde. All rights reserved.
//

import UIKit
import MobileCoreServices
import MediaPlayer
import Photos

class MergeVideoViewController: UIViewController {
    
    var firstAsset: AVAsset?
    var secondAsset: AVAsset?
    var audioAsset: AVAsset?
    var loadingAssetOne = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    func saveddPhotosAvailable() -> Bool {
        guard !UIImagePickerController.isSourceTypeAvailable(.savedPhotosAlbum) else {return true}
        
        let alert = UIAlertController(title: "Not Available", message: "No Saved Album found", preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
        present(alert, animated: true, completion: nil)
        return false
    }
    
    func exportDidFinish(_ session: AVAssetExportSession) {
        firstAsset = nil
        secondAsset = nil
        audioAsset = nil
        
        guard session.status == AVAssetExportSession.Status.completed, let outputURL = session.outputURL else {
            return
        }
        
        let saveVideoToPhotos = {
            PHPhotoLibrary.shared().performChanges({
                PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: outputURL)
            }) { (saved, error) in
                let success = saved && (error == nil)
                let title = success ? "Success":"Error"
                let message = success ? "Video Saved":"Failed to save video"
                
                let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.cancel, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
        }
        
        if PHPhotoLibrary.authorizationStatus() != .authorized {
            PHPhotoLibrary.requestAuthorization { (status) in
                if status == .authorized {
                    saveVideoToPhotos()
                }
            }
        } else {
            saveVideoToPhotos()
        }
    }
    
    @IBAction func loadAssetOneButtonTapped(_ sender: UIButton) {
        if saveddPhotosAvailable() {
            loadingAssetOne = true
            Video.startMideaBrowising(delegate: self, sourceType: UIImagePickerController.SourceType.savedPhotosAlbum)
        }
    }
    
    @IBAction func loadAssetTwoButtonTapped(_ sender: UIButton) {
        if saveddPhotosAvailable() {
            loadingAssetOne = false
            Video.startMideaBrowising(delegate: self, sourceType: .savedPhotosAlbum)
        }
    }
    @IBAction func loadAudioButtonTapped(_ sender: UIButton) {
        let mideaPickerController = MPMediaPickerController(mediaTypes: .any)
        mideaPickerController.delegate = self
        mideaPickerController.prompt = "Select Audio"
        present(mideaPickerController, animated: true, completion: nil)
    }
    
    @IBAction func mergeAndSaveButtonTapped(_ sender: UIButton) {
        guard let firstAsset = firstAsset, let secondAsset = secondAsset else {
            return
        }
        
        let mixComposition = AVMutableComposition()
        
        guard let firstTrack = mixComposition.addMutableTrack(withMediaType: .video, preferredTrackID: CMPersistentTrackID(Int(kCMPersistentTrackID_Invalid))) else {
            return
        }
        do {
            try firstTrack.insertTimeRange(CMTimeRangeMake(start: .zero, duration: firstAsset.duration), of: firstAsset.tracks(withMediaType: .video)[0], at: .zero)
        } catch {
            print("Failed to load first track")
            return
        }
        
        guard let secondTrack = mixComposition.addMutableTrack(withMediaType: .video, preferredTrackID: CMPersistentTrackID(Int(kCMPersistentTrackID_Invalid))) else {
            return
        }
        do {
            try secondTrack.insertTimeRange(CMTimeRangeMake(start: .zero, duration: secondAsset.duration), of: secondAsset.tracks(withMediaType: .video)[0], at: .zero)
        } catch {
            print("Failed to load second track")
            return
        }
        
        let mainInstruction = AVMutableVideoCompositionInstruction()
        mainInstruction.timeRange = CMTimeRangeMake(start: .zero, duration: CMTimeAdd(firstAsset.duration, secondAsset.duration))
        
        let firstInstruction = Video.videoCompositionInstruction(firstTrack, asset: firstAsset)
        firstInstruction.setOpacity(0.0, at: firstAsset.duration)
        let secondInstruction = Video.videoCompositionInstruction(secondTrack, asset: secondAsset)
        
        mainInstruction.layerInstructions = [firstInstruction, secondInstruction]
        let mainComposition = AVMutableVideoComposition()
        mainComposition.instructions = [mainInstruction]
        mainComposition.frameDuration = CMTimeMake(value: 1, timescale: 30)
        mainComposition.renderSize = CGSize(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        
        if let loadAudioAsset = audioAsset {
            let audioTrack = mixComposition.addMutableTrack(withMediaType: .audio, preferredTrackID: 0)
            do {
                try audioTrack?.insertTimeRange(CMTimeRangeMake(start: .zero, duration: CMTimeAdd(firstAsset.duration, secondAsset.duration)), of: loadAudioAsset.tracks(withMediaType: .audio)[0], at: CMTime.zero)
            } catch {
                print("Failed to load audio track")
            }
        }
        
        guard let documentDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else {
            return
        }
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .long
        dateFormatter.timeStyle = .short
        let date = dateFormatter.string(from: Date())
        let url = documentDirectory.appendingPathComponent("mergeVideo-\(date).mov")
        
        guard let exporter = AVAssetExportSession(asset: mixComposition, presetName: AVAssetExportPresetHighestQuality) else {return}
        exporter.outputURL = url
        exporter.outputFileType = AVFileType.mov
        exporter.shouldOptimizeForNetworkUse = true
        exporter.videoComposition = mainComposition
        
        exporter.exportAsynchronously {
            DispatchQueue.main.async {
                self.exportDidFinish(exporter)
            }
        }
    }
}
    
    extension MergeVideoViewController: MPMediaPickerControllerDelegate {
        
        func mediaPicker(_ mediaPicker: MPMediaPickerController, didPickMediaItems mediaItemCollection: MPMediaItemCollection) {
            
            dismiss(animated: true) {
                let selectedSongs = mediaItemCollection.items
                guard let song = selectedSongs.first else {return}
                
                let url = song.value(forProperty: MPMediaItemPropertyAssetURL) as? URL
                self.audioAsset = (url == nil) ? nil : AVAsset(url: url!)
                let title = (url == nil) ? "Asset not available":"Asset loaded"
                let message = (url == nil) ? "Audio not loaded": "Audio loaded"
                
                let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
        }
    }

extension MergeVideoViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
        
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            dismiss(animated: true, completion: nil)
            
            guard let mediaType = info[UIImagePickerController.InfoKey.mediaType] as? String, mediaType == (kUTTypeMovie as String), let url = info[UIImagePickerController.InfoKey.mediaURL] as? URL else {
                return
            }
            
            let avAsset = AVAsset(url: url)
            var message = ""
            if loadingAssetOne {
                message = "Video one loaded"
                firstAsset = avAsset
            } else {
                message = "Video two loaded"
                secondAsset = avAsset
            }
            let alert = UIAlertController(title: "Asset loaded", message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
            present(alert, animated: true, completion: nil)
        }
}
