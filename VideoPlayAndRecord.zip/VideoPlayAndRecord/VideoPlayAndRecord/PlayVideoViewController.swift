//
//  PlayVideoViewController.swift
//  VideoPlayAndRecord
//
//  Created by Vadde Narendra on 5/7/20.
//  Copyright © 2020 Narendra Vadde. All rights reserved.
//

import UIKit
import MobileCoreServices
import AVKit

class PlayVideoViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func playButtonTapped(_ sender: UIButton) {
        Video.startMideaBrowising(delegate: self, sourceType: .savedPhotosAlbum)
    }
}

extension PlayVideoViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        guard let mediaType = info[UIImagePickerController.InfoKey.mediaType] as? String, mediaType == (kUTTypeMovie as String), let url = info[UIImagePickerController.InfoKey.mediaType] as? URL else {return}
        
        dismiss(animated: true) {
            let player = AVPlayer(url: url)
            let vcPlayer = AVPlayerViewController()
            vcPlayer.player = player
            self.present(vcPlayer, animated: true, completion: nil)
        }
    }
}
