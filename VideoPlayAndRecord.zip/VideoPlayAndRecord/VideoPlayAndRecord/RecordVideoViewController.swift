//
//  RecordVideoViewController.swift
//  VideoPlayAndRecord
//
//  Created by Vadde Narendra on 5/7/20.
//  Copyright © 2020 Narendra Vadde. All rights reserved.
//

import UIKit
import MobileCoreServices

class RecordVideoViewController: UIViewController {
   
    let videoFileName = "/video.mp4"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    @IBAction func recordButtonTapped(_ sender: UIButton) {
        Video.startMideaBrowising(delegate: self, sourceType: .camera)
    }
    
    @objc func saveVideo(_ videoPath: String, didFinishSavingWithError error: Error?, contextInfo: AnyObject) {
        let title = (error == nil) ? "Success":"Error"
        let message = (error == nil) ? "Video was saved":"Video failed to save"
        
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
        present(alert, animated: true, completion: nil)
    }
}

extension RecordVideoViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {

        // 1
           if let selectedVideo:URL = (info[UIImagePickerController.InfoKey.mediaURL] as? URL) {
               // Save video to the main photo album
               let selectorToCall = #selector(saveVideo(_:didFinishSavingWithError:contextInfo:))
                 
               // 2
               UISaveVideoAtPathToSavedPhotosAlbum(selectedVideo.relativePath, self, selectorToCall, nil)
               // Save the video to the app directory
               let videoData = try? Data(contentsOf: selectedVideo)
               let paths = NSSearchPathForDirectoriesInDomains(
                   FileManager.SearchPathDirectory.documentDirectory, FileManager.SearchPathDomainMask.userDomainMask, true)
               let documentsDirectory: URL = URL(fileURLWithPath: paths[0])
               let dataPath = documentsDirectory.appendingPathComponent(videoFileName)
               try! videoData?.write(to: dataPath, options: [])
           }
           // 3
           picker.dismiss(animated: true)
    }
}
