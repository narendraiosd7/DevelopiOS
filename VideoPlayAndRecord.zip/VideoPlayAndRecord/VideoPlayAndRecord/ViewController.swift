//
//  ViewController.swift
//  VideoPlayAndRecord
//
//  Created by Vadde Narendra on 5/7/20.
//  Copyright © 2020 Narendra Vadde. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

