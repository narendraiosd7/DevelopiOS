//
//  main.m
//  dial-discovery-ios
//
//  Created by ramdhany on 12/08/2016.
//  Copyright (c) 2016 ramdhany. All rights reserved.
//

@import UIKit;
#import "RDAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([RDAppDelegate class]));
    }
}
