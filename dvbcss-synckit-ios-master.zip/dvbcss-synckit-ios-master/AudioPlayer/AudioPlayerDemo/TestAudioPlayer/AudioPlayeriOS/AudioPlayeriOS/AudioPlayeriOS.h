//
//  AudioPlayeriOS.h
//  AudioPlayeriOS
//
//  Created by Rajiv Ramdhany on 01/03/2016.
//  Copyright © 2016 BBC RD. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for AudioPlayeriOS.
FOUNDATION_EXPORT double AudioPlayeriOSVersionNumber;

//! Project version string for AudioPlayeriOS.
FOUNDATION_EXPORT const unsigned char AudioPlayeriOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AudioPlayeriOS/PublicHeader.h>


