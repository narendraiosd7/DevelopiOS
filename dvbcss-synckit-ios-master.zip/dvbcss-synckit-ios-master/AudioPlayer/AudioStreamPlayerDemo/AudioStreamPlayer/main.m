//
//  main.m
//  AudioStreamPlayer
//
//  Created by Rajiv Ramdhany on 29/05/2014.
//  Copyright (c) 2014 BBC R&D. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "RDAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([RDAppDelegate class]));
    }
}
