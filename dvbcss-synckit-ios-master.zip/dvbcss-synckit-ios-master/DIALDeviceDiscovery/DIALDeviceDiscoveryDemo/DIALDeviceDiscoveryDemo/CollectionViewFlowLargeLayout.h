//
//  AFCollectionViewFlowLargeLayout.h
//  UICollectionViewFlowLayoutExample
//  Created by Rajiv Ramdhany on 12/12/2014.
//  Copyright (c) 2014 BBC RD. All rights reserved

#import <UIKit/UIKit.h>


//------------------------------------------------------------------------------
#pragma mark - CollectionViewFlowLargeLayout
//------------------------------------------------------------------------------
/**
 *  Class collection view flowlayout with large images
 */
@interface CollectionViewFlowLargeLayout : UICollectionViewFlowLayout

@end
