//
//  AFCollectionViewFlowSmallLayout.h
//  UICollectionViewFlowLayoutExample
//
//  Created by Rajiv Ramdhany on 12/12/2014.
//  Copyright (c) 2014 BBC RD. All rights reserved
//

#import <UIKit/UIKit.h>



//------------------------------------------------------------------------------
#pragma mark - CollectionViewFlowSmallLayout
//------------------------------------------------------------------------------

/**
 *  Class collection view flowlayout with small images
 */
@interface CollectionViewFlowSmallLayout : UICollectionViewFlowLayout

@end
