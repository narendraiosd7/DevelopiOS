//
//  DIALDeviceViewConstants.h
//  Acolyte
//
//  Created by Rajiv Ramdhany on 10/02/2015.
//  Copyright (c) 2015 BBC RD. All rights reserved.
//

#ifndef Acolyte_DIALDeviceViewConstants_h
#define Acolyte_DIALDeviceViewConstants_h

FOUNDATION_EXPORT NSString* const kNewDIAL_HbbTV_ServiceSelected;
FOUNDATION_EXPORT NSString* const kTestMediaSelectedNotification;

#endif
