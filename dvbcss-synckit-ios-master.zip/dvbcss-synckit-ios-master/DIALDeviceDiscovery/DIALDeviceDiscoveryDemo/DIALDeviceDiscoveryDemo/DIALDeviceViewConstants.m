//
//  DIALDeviceViewConstants.m
//  Acolyte
//
//  Created by Rajiv Ramdhany on 11/02/2015.
//  Copyright (c) 2015 BBC RD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DIALDeviceViewConstants.h"

NSString* const kNewDIAL_HbbTV_ServiceSelected = @"kNewDIALHbbTVServiceSelected";
NSString* const kTestMediaSelectedNotification =@"TestMediaSelected";