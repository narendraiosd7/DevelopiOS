# <small>dvbcss-synckit-ios</small><br/>SyncKitCollections Framework


A collection of data structures and utility classes. This is required by
some of the other frameworks in *dvbcss-synckit-ios*.


[](---START EXCLUDE FROM DOC BUILD---)
## Read the documentation
The docs for this framework can be read [here](http://bbc.github.io/dvbcss-synckit-ios/latest/SyncKitCollections/).
[](---END EXCLUDE FROM DOC BUILD---)



## Licence

This framework is developed by BBC R&D and distributed under Licensed under the Apache License, [Version 2.0](http://www.apache.org/licenses/LICENSE-2.0).

© Copyright 2016 BBC R&D. All Rights Reserved