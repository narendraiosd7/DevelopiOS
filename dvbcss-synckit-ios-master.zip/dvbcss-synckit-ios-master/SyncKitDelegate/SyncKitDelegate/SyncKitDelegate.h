//
//  SyncKitDelegate.h
//  SyncKitDelegate
//
//  Created by Rajiv Ramdhany on 07/06/2015.
//  Copyright (c) 2015 BBC RD. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SyncKitDelegate.
FOUNDATION_EXPORT double SyncKitDelegateVersionNumber;

//! Project version string for SyncKitDelegate.
FOUNDATION_EXPORT const unsigned char SyncKitDelegateVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SyncKitDelegate/PublicHeader.h>
#import <SyncKitDelegate/SyncKitConfigurator.h>

