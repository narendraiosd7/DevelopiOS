//
//  ViewController.h
//  SyncKitVideoSyncTutorial
//
//  Created by Rajiv Ramdhany on 15/11/2016.
//  Copyright © 2016 BBC RD. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

